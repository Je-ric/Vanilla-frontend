<template>
  <svg fill='none' stroke='#0E1A27' stroke-width='8' stroke-dashoffset='0' stroke-dasharray='0' stroke-linecap='round' stroke-linejoin='round' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><polygon points="15,10 15,90 85,90 85,25 70,10"/>
    <line x1="35" y1="55" x2="65" y2="55" />
    <line x1="50" y1="40" x2="50" y2="70 " />
    <polyline fill="none" points="70,10 70,25 85,25"/>
  </svg>
</template>
