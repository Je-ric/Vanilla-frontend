declare module '*.png' {}
