<template>
  <svg
    fill="none"
    stroke="#eee"
    stroke-linecap="round"
    stroke-linejoin="round"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 100 100"
  >
    <rect x="10" y="10" width="32" height="79" />
    <rect x="57" y="10" width="32" height="32" />
    <rect x="57" y="57" width="32" height="32" />
  </svg>
</template>
