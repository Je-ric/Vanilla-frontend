import React from 'react'
import { Controls } from './Controls'

export default function App() {
  return <Controls />
}
