(window.webpackJsonp = window.webpackJsonp || []).push([
    [0], {
        108: function(e, n, o) {
            "use strict";
            o.r(n);
            var a = o(0),
                r = o.n(a),
                t = o(13),
                l = o.n(t),
                c = o(3),
                i = o(53),
                s = o(54),
                m = o(55),
                f = o(67),
                d = o(56),
                u = o(69),
                F = o(1),
                b = o(115),
                h = o(6),
                g = function(e) {
                    var n = e.width,
                        o = e.height,
                        a = e.baseColor,
                        t = e.gradient,
                        l = t.length > 0,
                        c = a;
                    l && "linear-gradient(120deg, ".concat(t.join(), " 100%)");
                    return r.a.createElement("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        xmlnsXlink: "http://www.w3.org/1999/xlink",
                        version: "1.1",
                        id: "Layer_1",
                        x: "0px",
                        y: "0px",
                        viewBox: "0 0 48 48",
                        style: {
                            enableBackground: "new 0 0 48 48"
                        },
                        xmlSpace: "preserve",
                        width: n || "480px",
                        height: o || "480px"
                    }, r.a.createElement("g", {
                        id: "surface1"
                    }, l && r.a.createElement("defs", null, r.a.createElement("linearGradient", {
                        id: "my-gradient",
                        x1: "0%",
                        y1: "0%",
                        x2: "100%",
                        y2: "0%"
                    }, t.map(function(e, n) {
                        return r.a.createElement("stop", {
                            offset: "".concat(100 * n / (t.length - 1), "%"),
                            style: {
                                stopColor: e
                            }
                        })
                    }))), r.a.createElement("path", {
                        style: {
                            fill: l ? "url(#my-gradient)" : Object(h.tint)(.5, c)
                        },
                        d: "M15,35c-0.5,0-1-0.2-1.4-0.6c-0.8-0.8-0.8-2,0-2.8l26-26c0.8-0.8,2-0.8,2.8,0c0.8,0.8,0.8,2,0,2.8   l-26,26C16,34.8,15.5,35,15,35z"
                    }), r.a.createElement("path", {
                        style: {
                            fill: l ? "url(#my-gradient)" : c
                        },
                        d: "M14,35c-0.3,0-0.5-0.1-0.7-0.3c-0.4-0.4-0.4-1,0-1.4l27-27c0.4-0.4,1-0.4,1.4,0s0.4,1,0,1.4l-27,27   C14.5,34.9,14.3,35,14,35z"
                    }), r.a.createElement("path", {
                        style: {
                            fill: "#90A4AE"
                        },
                        d: "M8.3,38.3l1.4,1.4L6.4,43L5,41.6L8.3,38.3z"
                    }), r.a.createElement("path", {
                        style: {
                            fill: "#90A4AE"
                        },
                        d: "M14.5,30.7l2.8,2.8L7.8,43L5,40.2L14.5,30.7z"
                    }), r.a.createElement("path", {
                        style: {
                            fill: "#37474F"
                        },
                        d: "M12.1,33.1l2.8,2.8L7.8,43L5,40.2L12.1,33.1z"
                    }), r.a.createElement("path", {
                        style: {
                            fill: "#37474F"
                        },
                        d: "M18,27.2l-3.9,3.9l2.8,2.8l1.1-1.1V27.2z"
                    }), r.a.createElement("path", {
                        style: {
                            fill: "#37474F"
                        },
                        d: "M11,32l3,3l-2,2l-3-3L11,32z"
                    })))
                },
                C = (Object(h.lighten)(.25, "#282a36"), "#ddd"),
                p = "#aaa",
                E = "#888",
                B = "#555",
                D = "#333";

            function x() {
                var e = Object(c.a)(["\n  margin-right: 2em;\n"]);
                return x = function() {
                    return e
                }, e
            }

            function A() {
                var e = Object(c.a)(["\n  color: ", ";\n  font-weight: bold;\n  font-size: 1.35rem;\n  text-align: center;\n\n  > span {\n    background-image: linear-gradient(\n      120deg,\n      ", ",\n      ", " 100%\n    );\n    background-repeat: no-repeat;\n    background-size: 100% 0.3em;\n    background-position: 0 80%;\n    transition: background-size 0.25s ease-in;\n\n    &:hover {\n      background-size: 100% 88% !important;\n    }\n  }\n"]);
                return A = function() {
                    return e
                }, e
            }

            function w() {
                var e = Object(c.a)(["\n  box-sizing: border-box;\n\n  width: 100%;\n  margin: 1em;\n\n  display: flex;\n  flex-direction: column;\n  justify-content: flex-start;\n  align-items: center;\n"]);
                return w = function() {
                    return e
                }, e
            }
            var y = F.default.div(w()),
                v = F.default.h1(A(), D, C, C),
                k = (F.default.div(x()), function(e) {
                    var n = e.baseColor,
                        o = e.gradient;
                    return r.a.createElement(y, null, r.a.createElement(g, {
                        width: "100px",
                        height: "100px",
                        baseColor: n,
                        gradient: o
                    }), r.a.createElement(v, null, r.a.createElement("span", null, "Underline Generator"), r.a.createElement("sup", {
                        style: {
                            fontSize: ".75rem"
                        }
                    }, "\xa0 \xa9")))
                });

            function S() {
                var e = Object(c.a)(["\n  padding: 1rem;\n  width: 100%;\n\n  border-radius: ", ";\n  background-color: ", ";\n  background-color: white;\n  box-shadow: 0px 10px 12px ", ";\n\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n\n  flex-grow: ", ";\n\n  min-height: 30px;\n  max-height: 30px;\n\n  @media (min-width: 1px) and (max-width: 767px) {\n    min-height: 120px;\n    max-height: 120px;\n    min-width: ", "px;\n    max-width: ", "px;\n    min-height: ", "px;\n    max-height: ", "px;\n\n    flex-direction: column;\n    align-items: center;\n    box-sizing: border-box;\n  }\n\n  width: ", "px;\n  height: ", "px;\n\n  i {\n    max-width: 30px;\n    max-height: 30px;\n  }\n"]);
                return S = function() {
                    return e
                }, e
            }
            var z = F.default.div(S(), "8px", C, Object(h.rgba)(D, .1), function(e) {
                    return e.grow || 0
                }, function(e) {
                    return 2 * e.width
                }, function(e) {
                    return 2 * e.width
                }, function(e) {
                    return e.height
                }, function(e) {
                    return e.height
                }, function(e) {
                    return e.width
                }, function(e) {
                    return e.height
                }),
                M = o(66),
                O = o(59),
                j = o(60),
                P = o.n(j),
                T = function(e) {
                    var n = e.fill,
                        o = e.size;
                    return r.a.createElement("svg", {
                        width: "".concat(o, "px"),
                        height: "".concat(o, "px"),
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        fill: n
                    }, r.a.createElement("g", {
                        "data-name": "Layer 2"
                    }, r.a.createElement("g", {
                        "data-name": "copy"
                    }, r.a.createElement("rect", {
                        width: "".concat(o, "px"),
                        height: "".concat(o, "px"),
                        opacity: "0"
                    }), r.a.createElement("path", {
                        d: "M18 21h-6a3 3 0 0 1-3-3v-6a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3zm-6-10a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1z"
                    }), r.a.createElement("path", {
                        d: "M9.73 15H5.67A2.68 2.68 0 0 1 3 12.33V5.67A2.68 2.68 0 0 1 5.67 3h6.66A2.68 2.68 0 0 1 15 5.67V9.4h-2V5.67a.67.67 0 0 0-.67-.67H5.67a.67.67 0 0 0-.67.67v6.66a.67.67 0 0 0 .67.67h4.06z"
                    }))))
                };

            function L() {
                var e = Object(c.a)(['\n  > span {\n    border-radius: 8px !important;\n    font-size: 12px;\n    font-weight: normal;\n    font-family: "Prompt", sans-serif;\n  }\n']);
                return L = function() {
                    return e
                }, e
            }
            var R = Object(F.default)(P.a)(L()),
                V = function(e) {
                    var n = e.cssCode,
                        o = e.baseColor,
                        t = (e.grow, Object(a.useState)(!1)),
                        l = Object(M.a)(t, 2),
                        c = l[0],
                        i = l[1];
                    return r.a.createElement(R, {
                        arrowSize: 8,
                        arrow: !1,
                        distance: 8,
                        background: D,
                        color: C,
                        content: "Copied!",
                        direction: "right",
                        isOpen: c
                    }, r.a.createElement(O.CopyToClipboard, {
                        text: n
                    }, r.a.createElement(z, {
                        width: 30,
                        height: 60,
                        onClick: function() {
                            i(!0), setTimeout(function() {
                                return i(!1)
                            }, 2e3)
                        }
                    }, r.a.createElement(T, {
                        size: 30,
                        fill: o
                    }))))
                };
            V.defaultProps = {
                onClick: function() {}
            };
            var H = V,
                I = o(15),
                W = o.n(I),
                Y = o(114);

            function G() {
                var e = Object(c.a)(["\n  min-width: 24px;\n  min-height: 24px;\n  max-width: 24px;\n  max-height: 24px;\n\n  margin-right: 4px;\n  border-radius: 50px;\n  box-sizing: border-box;\n  -moz-box-sizing: border-box;\n  -webkit-box-sizing: border-box;\n\n  transition: box-shadow 0.6s ease-out, transform 0.3s ease-out;\n  -webkit-transition: box-shadow 0.6s ease-out, transform 0.3s ease-out;\n  -moz-transition: box-shadow 0.6s ease-out, transform 0.3s ease-out;\n  -o-transition: box-shadow 0.6s ease-out, transform 0.3s ease-out;\n\n  ", ";\n\n  :hover {\n    transform: translateY(-2px) scale(1.1);\n    box-shadow: 0 5px 10px ", ";\n  }\n"]);
                return G = function() {
                    return e
                }, e
            }
            var N = F.default.div(G(), function(e) {
                    return e.selected ? "\n      border: 3px solid ".concat(e.colors[0], ";\n      background-color: white;\n    ") : "background: linear-gradient(-45deg, ".concat(e.colors.join(), ");")
                }, function(e) {
                    return Object(h.rgba)(e.colors[0], .5)
                }),
                K = [{
                    name: "Blu",
                    colors: ["#00416A", "#E4E5E6"]
                }, {
                    name: "Ver",
                    colors: ["#FFE000", "#799F0C"]
                }, {
                    name: "Ver Black",
                    colors: ["#F7F8F8", "#ACBB78"]
                }, {
                    name: "Combi",
                    colors: ["#00416A", "#799F0C", "#FFE000"]
                }, {
                    name: "Anwar",
                    colors: ["#334d50", "#cbcaa5"]
                }, {
                    name: "Bluelagoo",
                    colors: ["#0052D4", "#4364F7", "#6FB1FC"]
                }, {
                    name: "Lunada",
                    colors: ["#5433FF", "#20BDFF", "#A5FECB"]
                }, {
                    name: "Reaqua",
                    colors: ["#799F0C", "#ACBB78"]
                }, {
                    name: "Mango",
                    colors: ["#ffe259", "#ffa751"]
                }, {
                    name: "Bupe",
                    colors: ["#00416A", "#E4E5E6"]
                }, {
                    name: "Rea",
                    colors: ["#FFE000", "#799F0C"]
                }, {
                    name: "Windy",
                    colors: ["#acb6e5", "#86fde8"]
                }, {
                    name: "Royal Blue",
                    colors: ["#536976", "#292E49"]
                }, {
                    name: "Royal Blue + Petrol",
                    colors: ["#BBD2C5", "#536976", "#292E49"]
                }, {
                    name: "Copper",
                    colors: ["#B79891", "#94716B"]
                }, {
                    name: "Anamnisar",
                    colors: ["#9796f0", "#fbc7d4"]
                }, {
                    name: "Petrol",
                    colors: ["#BBD2C5", "#536976"]
                }, {
                    name: "Sky",
                    colors: ["#076585", "#fff"]
                }, {
                    name: "Sel",
                    colors: ["#00467F", "#A5CC82"]
                }, {
                    name: "Skyline",
                    colors: ["#1488CC", "#2B32B2"]
                }, {
                    name: "DIMIGO",
                    colors: ["#ec008c", "#fc6767"]
                }, {
                    name: "Purple Love",
                    colors: ["#cc2b5e", "#753a88"]
                }, {
                    name: "Sexy Blue",
                    colors: ["#2193b0", "#6dd5ed"]
                }, {
                    name: "Blooker20",
                    colors: ["#e65c00", "#F9D423"]
                }, {
                    name: "Sea Blue",
                    colors: ["#2b5876", "#4e4376"]
                }, {
                    name: "Nimvelo",
                    colors: ["#314755", "#26a0da"]
                }, {
                    name: "Hazel",
                    colors: ["#77A1D3", "#79CBCA", "#E684AE"]
                }, {
                    name: "Noon to Dusk",
                    colors: ["#ff6e7f", "#bfe9ff"]
                }, {
                    name: "YouTube",
                    colors: ["#e52d27", "#b31217"]
                }, {
                    name: "Cool Brown",
                    colors: ["#603813", "#b29f94"]
                }, {
                    name: "Harmonic Energy",
                    colors: ["#16A085", "#F4D03F"]
                }, {
                    name: "Playing with Reds",
                    colors: ["#D31027", "#EA384D"]
                }, {
                    name: "Sunny Days",
                    colors: ["#EDE574", "#E1F5C4"]
                }, {
                    name: "Green Beach",
                    colors: ["#02AAB0", "#00CDAC"]
                }, {
                    name: "Intuitive Purple",
                    colors: ["#DA22FF", "#9733EE"]
                }, {
                    name: "Emerald Water",
                    colors: ["#348F50", "#56B4D3"]
                }, {
                    name: "Lemon Twist",
                    colors: ["#3CA55C", "#B5AC49"]
                }, {
                    name: "Monte Carlo",
                    colors: ["#CC95C0", "#DBD4B4", "#7AA1D2"]
                }, {
                    name: "Horizon",
                    colors: ["#003973", "#E5E5BE"]
                }, {
                    name: "Rose Water",
                    colors: ["#E55D87", "#5FC3E4"]
                }, {
                    name: "Frozen",
                    colors: ["#403B4A", "#E7E9BB"]
                }, {
                    name: "Mango Pulp",
                    colors: ["#F09819", "#EDDE5D"]
                }, {
                    name: "Bloody Mary",
                    colors: ["#FF512F", "#DD2476"]
                }, {
                    name: "Aubergine",
                    colors: ["#AA076B", "#61045F"]
                }, {
                    name: "Aqua Marine",
                    colors: ["#1A2980", "#26D0CE"]
                }, {
                    name: "Sunrise",
                    colors: ["#FF512F", "#F09819"]
                }, {
                    name: "Purple Paradise",
                    colors: ["#1D2B64", "#F8CDDA"]
                }, {
                    name: "Stripe",
                    colors: ["#1FA2FF", "#12D8FA", "#A6FFCB"]
                }, {
                    name: "Sea Weed",
                    colors: ["#4CB8C4", "#3CD3AD"]
                }, {
                    name: "Pinky",
                    colors: ["#DD5E89", "#F7BB97"]
                }, {
                    name: "Cherry",
                    colors: ["#EB3349", "#F45C43"]
                }, {
                    name: "Mojito",
                    colors: ["#1D976C", "#93F9B9"]
                }, {
                    name: "Juicy Orange",
                    colors: ["#FF8008", "#FFC837"]
                }, {
                    name: "Mirage",
                    colors: ["#16222A", "#3A6073"]
                }, {
                    name: "Steel Gray",
                    colors: ["#1F1C2C", "#928DAB"]
                }, {
                    name: "Kashmir",
                    colors: ["#614385", "#516395"]
                }, {
                    name: "Electric Violet",
                    colors: ["#4776E6", "#8E54E9"]
                }, {
                    name: "Venice Blue",
                    colors: ["#085078", "#85D8CE"]
                }, {
                    name: "Bora Bora",
                    colors: ["#2BC0E4", "#EAECC6"]
                }, {
                    name: "Moss",
                    colors: ["#134E5E", "#71B280"]
                }, {
                    name: "Shroom Haze",
                    colors: ["#5C258D", "#4389A2"]
                }, {
                    name: "Mystic",
                    colors: ["#757F9A", "#D7DDE8"]
                }, {
                    name: "Midnight City",
                    colors: ["#232526", "#414345"]
                }, {
                    name: "Sea Blizz",
                    colors: ["#1CD8D2", "#93EDC7"]
                }, {
                    name: "Opa",
                    colors: ["#3D7EAA", "#FFE47A"]
                }, {
                    name: "Titanium",
                    colors: ["#283048", "#859398"]
                }, {
                    name: "Mantle",
                    colors: ["#24C6DC", "#514A9D"]
                }, {
                    name: "Dracula",
                    colors: ["#DC2424", "#4A569D"]
                }, {
                    name: "Peach",
                    colors: ["#ED4264", "#FFEDBC"]
                }, {
                    name: "Moonrise",
                    colors: ["#DAE2F8", "#D6A4A4"]
                }, {
                    name: "Clouds",
                    colors: ["#ECE9E6", "#FFFFFF"]
                }, {
                    name: "Stellar",
                    colors: ["#7474BF", "#348AC7"]
                }, {
                    name: "Bourbon",
                    colors: ["#EC6F66", "#F3A183"]
                }, {
                    name: "Calm Darya",
                    colors: ["#5f2c82", "#49a09d"]
                }, {
                    name: "Influenza",
                    colors: ["#C04848", "#480048"]
                }, {
                    name: "Shrimpy",
                    colors: ["#e43a15", "#e65245"]
                }, {
                    name: "Army",
                    colors: ["#414d0b", "#727a17"]
                }, {
                    name: "Miaka",
                    colors: ["#FC354C", "#0ABFBC"]
                }, {
                    name: "Pinot Noir",
                    colors: ["#4b6cb7", "#182848"]
                }, {
                    name: "Day Tripper",
                    colors: ["#f857a6", "#ff5858"]
                }, {
                    name: "Namn",
                    colors: ["#a73737", "#7a2828"]
                }, {
                    name: "Blurry Beach",
                    colors: ["#d53369", "#cbad6d"]
                }, {
                    name: "Vasily",
                    colors: ["#e9d362", "#333333"]
                }, {
                    name: "A Lost Memory",
                    colors: ["#DE6262", "#FFB88C"]
                }, {
                    name: "Petrichor",
                    colors: ["#666600", "#999966"]
                }, {
                    name: "Jonquil",
                    colors: ["#FFEEEE", "#DDEFBB"]
                }, {
                    name: "Sirius Tamed",
                    colors: ["#EFEFBB", "#D4D3DD"]
                }, {
                    name: "Kyoto",
                    colors: ["#c21500", "#ffc500"]
                }, {
                    name: "Misty Meadow",
                    colors: ["#215f00", "#e4e4d9"]
                }, {
                    name: "Aqualicious",
                    colors: ["#50C9C3", "#96DEDA"]
                }, {
                    name: "Moor",
                    colors: ["#616161", "#9bc5c3"]
                }, {
                    name: "Almost",
                    colors: ["#ddd6f3", "#faaca8"]
                }, {
                    name: "Forever Lost",
                    colors: ["#5D4157", "#A8CABA"]
                }, {
                    name: "Winter",
                    colors: ["#E6DADA", "#274046"]
                }, {
                    name: "Nelson",
                    colors: ["#f2709c", "#ff9472"]
                }, {
                    name: "Autumn",
                    colors: ["#DAD299", "#B0DAB9"]
                }, {
                    name: "Candy",
                    colors: ["#D3959B", "#BFE6BA"]
                }, {
                    name: "Reef",
                    colors: ["#00d2ff", "#3a7bd5"]
                }, {
                    name: "The Strain",
                    colors: ["#870000", "#190A05"]
                }, {
                    name: "Dirty Fog",
                    colors: ["#B993D6", "#8CA6DB"]
                }, {
                    name: "Earthly",
                    colors: ["#649173", "#DBD5A4"]
                }, {
                    name: "Virgin",
                    colors: ["#C9FFBF", "#FFAFBD"]
                }, {
                    name: "Ash",
                    colors: ["#606c88", "#3f4c6b"]
                }, {
                    name: "Cherryblossoms",
                    colors: ["#FBD3E9", "#BB377D"]
                }, {
                    name: "Parklife",
                    colors: ["#ADD100", "#7B920A"]
                }, {
                    name: "Dance To Forget",
                    colors: ["#FF4E50", "#F9D423"]
                }, {
                    name: "Starfall",
                    colors: ["#F0C27B", "#4B1248"]
                }, {
                    name: "Red Mist",
                    colors: ["#000000", "#e74c3c"]
                }, {
                    name: "Teal Love",
                    colors: ["#AAFFA9", "#11FFBD"]
                }, {
                    name: "Neon Life",
                    colors: ["#B3FFAB", "#12FFF7"]
                }, {
                    name: "Man of Steel",
                    colors: ["#780206", "#061161"]
                }, {
                    name: "Amethyst",
                    colors: ["#9D50BB", "#6E48AA"]
                }, {
                    name: "Cheer Up Emo Kid",
                    colors: ["#556270", "#FF6B6B"]
                }, {
                    name: "Shore",
                    colors: ["#70e1f5", "#ffd194"]
                }, {
                    name: "Facebook Messenger",
                    colors: ["#00c6ff", "#0072ff"]
                }, {
                    name: "SoundCloud",
                    colors: ["#fe8c00", "#f83600"]
                }, {
                    name: "Behongo",
                    colors: ["#52c234", "#061700"]
                }, {
                    name: "ServQuick",
                    colors: ["#485563", "#29323c"]
                }, {
                    name: "Friday",
                    colors: ["#83a4d4", "#b6fbff"]
                }, {
                    name: "Martini",
                    colors: ["#FDFC47", "#24FE41"]
                }, {
                    name: "Metallic Toad",
                    colors: ["#abbaab", "#ffffff"]
                }, {
                    name: "Between The Clouds",
                    colors: ["#73C8A9", "#373B44"]
                }, {
                    name: "Crazy Orange I",
                    colors: ["#D38312", "#A83279"]
                }, {
                    name: "Hersheys",
                    colors: ["#1e130c", "#9a8478"]
                }, {
                    name: "Talking To Mice Elf",
                    colors: ["#948E99", "#2E1437"]
                }, {
                    name: "Purple Bliss",
                    colors: ["#360033", "#0b8793"]
                }, {
                    name: "Predawn",
                    colors: ["#FFA17F", "#00223E"]
                }, {
                    name: "Endless River",
                    colors: ["#43cea2", "#185a9d"]
                }, {
                    name: "Pastel Orange at the Sun",
                    colors: ["#ffb347", "#ffcc33"]
                }, {
                    name: "Twitch",
                    colors: ["#6441A5", "#2a0845"]
                }, {
                    name: "Atlas",
                    colors: ["#FEAC5E", "#C779D0", "#4BC0C8"]
                }, {
                    name: "Instagram",
                    colors: ["#833ab4", "#fd1d1d", "#fcb045"]
                }, {
                    name: "Flickr",
                    colors: ["#ff0084", "#33001b"]
                }, {
                    name: "Vine",
                    colors: ["#00bf8f", "#001510"]
                }, {
                    name: "Turquoise flow",
                    colors: ["#136a8a", "#267871"]
                }, {
                    name: "Portrait",
                    colors: ["#8e9eab", "#eef2f3"]
                }, {
                    name: "Virgin America",
                    colors: ["#7b4397", "#dc2430"]
                }, {
                    name: "Koko Caramel",
                    colors: ["#D1913C", "#FFD194"]
                }, {
                    name: "Fresh Turboscent",
                    colors: ["#F1F2B5", "#135058"]
                }, {
                    name: "Green to dark",
                    colors: ["#6A9113", "#141517"]
                }, {
                    name: "Ukraine",
                    colors: ["#004FF9", "#FFF94C"]
                }, {
                    name: "Curiosity blue",
                    colors: ["#525252", "#3d72b4"]
                }, {
                    name: "Dark Knight",
                    colors: ["#BA8B02", "#181818"]
                }, {
                    name: "Piglet",
                    colors: ["#ee9ca7", "#ffdde1"]
                }, {
                    name: "Lizard",
                    colors: ["#304352", "#d7d2cc"]
                }, {
                    name: "Sage Persuasion",
                    colors: ["#CCCCB2", "#757519"]
                }, {
                    name: "Between Night and Day",
                    colors: ["#2c3e50", "#3498db"]
                }, {
                    name: "Timber",
                    colors: ["#fc00ff", "#00dbde"]
                }, {
                    name: "Passion",
                    colors: ["#e53935", "#e35d5b"]
                }, {
                    name: "Clear Sky",
                    colors: ["#005C97", "#363795"]
                }, {
                    name: "Master Card",
                    colors: ["#f46b45", "#eea849"]
                }, {
                    name: "Back To Earth",
                    colors: ["#00C9FF", "#92FE9D"]
                }, {
                    name: "Deep Purple",
                    colors: ["#673AB7", "#512DA8"]
                }, {
                    name: "Little Leaf",
                    colors: ["#76b852", "#8DC26F"]
                }, {
                    name: "Netflix",
                    colors: ["#8E0E00", "#1F1C18"]
                }, {
                    name: "Light Orange",
                    colors: ["#FFB75E", "#ED8F03"]
                }, {
                    name: "Green and Blue",
                    colors: ["#c2e59c", "#64b3f4"]
                }, {
                    name: "Poncho",
                    colors: ["#403A3E", "#BE5869"]
                }, {
                    name: "Back to the Future",
                    colors: ["#C02425", "#F0CB35"]
                }, {
                    name: "Blush",
                    colors: ["#B24592", "#F15F79"]
                }, {
                    name: "Inbox",
                    colors: ["#457fca", "#5691c8"]
                }, {
                    name: "Purplin",
                    colors: ["#6a3093", "#a044ff"]
                }, {
                    name: "Pale Wood",
                    colors: ["#eacda3", "#d6ae7b"]
                }, {
                    name: "Haikus",
                    colors: ["#fd746c", "#ff9068"]
                }, {
                    name: "Pizelex",
                    colors: ["#114357", "#F29492"]
                }, {
                    name: "Joomla",
                    colors: ["#1e3c72", "#2a5298"]
                }, {
                    name: "Christmas",
                    colors: ["#2F7336", "#AA3A38"]
                }, {
                    name: "Minnesota Vikings",
                    colors: ["#5614B0", "#DBD65C"]
                }, {
                    name: "Miami Dolphins",
                    colors: ["#4DA0B0", "#D39D38"]
                }, {
                    name: "Forest",
                    colors: ["#5A3F37", "#2C7744"]
                }, {
                    name: "Nighthawk",
                    colors: ["#2980b9", "#2c3e50"]
                }, {
                    name: "Superman",
                    colors: ["#0099F7", "#F11712"]
                }, {
                    name: "Suzy",
                    colors: ["#834d9b", "#d04ed6"]
                }, {
                    name: "Dark Skies",
                    colors: ["#4B79A1", "#283E51"]
                }, {
                    name: "Deep Space",
                    colors: ["#000000", "#434343"]
                }, {
                    name: "Decent",
                    colors: ["#4CA1AF", "#C4E0E5"]
                }, {
                    name: "Colors Of Sky",
                    colors: ["#E0EAFC", "#CFDEF3"]
                }, {
                    name: "Purple White",
                    colors: ["#BA5370", "#F4E2D8"]
                }, {
                    name: "Ali",
                    colors: ["#ff4b1f", "#1fddff"]
                }, {
                    name: "Alihossein",
                    colors: ["#f7ff00", "#db36a4"]
                }, {
                    name: "Shahabi",
                    colors: ["#a80077", "#66ff00"]
                }, {
                    name: "Red Ocean",
                    colors: ["#1D4350", "#A43931"]
                }, {
                    name: "Tranquil",
                    colors: ["#EECDA3", "#EF629F"]
                }, {
                    name: "Transfile",
                    colors: ["#16BFFD", "#CB3066"]
                }, {
                    name: "Sylvia",
                    colors: ["#ff4b1f", "#ff9068"]
                }, {
                    name: "Sweet Morning",
                    colors: ["#FF5F6D", "#FFC371"]
                }, {
                    name: "Politics",
                    colors: ["#2196f3", "#f44336"]
                }, {
                    name: "Bright Vault",
                    colors: ["#00d2ff", "#928DAB"]
                }, {
                    name: "Solid Vault",
                    colors: ["#3a7bd5", "#3a6073"]
                }, {
                    name: "Sunset",
                    colors: ["#0B486B", "#F56217"]
                }, {
                    name: "Grapefruit Sunset",
                    colors: ["#e96443", "#904e95"]
                }, {
                    name: "Deep Sea Space",
                    colors: ["#2C3E50", "#4CA1AF"]
                }, {
                    name: "Dusk",
                    colors: ["#2C3E50", "#FD746C"]
                }, {
                    name: "Minimal Red",
                    colors: ["#F00000", "#DC281E"]
                }, {
                    name: "Royal",
                    colors: ["#141E30", "#243B55"]
                }, {
                    name: "Mauve",
                    colors: ["#42275a", "#734b6d"]
                }, {
                    name: "Frost",
                    colors: ["#000428", "#004e92"]
                }, {
                    name: "Lush",
                    colors: ["#56ab2f", "#a8e063"]
                }, {
                    name: "Firewatch",
                    colors: ["#cb2d3e", "#ef473a"]
                }, {
                    name: "Sherbert",
                    colors: ["#f79d00", "#64f38c"]
                }, {
                    name: "Blood Red",
                    colors: ["#f85032", "#e73827"]
                }, {
                    name: "Sun on the Horizon",
                    colors: ["#fceabb", "#f8b500"]
                }, {
                    name: "IIIT Delhi",
                    colors: ["#808080", "#3fada8"]
                }, {
                    name: "Jupiter",
                    colors: ["#ffd89b", "#19547b"]
                }, {
                    name: "50 Shades of Grey",
                    colors: ["#bdc3c7", "#2c3e50"]
                }, {
                    name: "Dania",
                    colors: ["#BE93C5", "#7BC6CC"]
                }, {
                    name: "Limeade",
                    colors: ["#A1FFCE", "#FAFFD1"]
                }, {
                    name: "Disco",
                    colors: ["#4ECDC4", "#556270"]
                }, {
                    name: "Love Couple",
                    colors: ["#3a6186", "#89253e"]
                }, {
                    name: "Azure Pop",
                    colors: ["#ef32d9", "#89fffd"]
                }, {
                    name: "Nepal",
                    colors: ["#de6161", "#2657eb"]
                }, {
                    name: "Cosmic Fusion",
                    colors: ["#ff00cc", "#333399"]
                }, {
                    name: "Snapchat",
                    colors: ["#fffc00", "#ffffff"]
                }, {
                    name: "Ed's Sunset Gradient",
                    colors: ["#ff7e5f", "#feb47b"]
                }, {
                    name: "Brady Brady Fun Fun",
                    colors: ["#00c3ff", "#ffff1c"]
                }, {
                    name: "Black Ros\xe9",
                    colors: ["#f4c4f3", "#fc67fa"]
                }, {
                    name: "80's Purple",
                    colors: ["#41295a", "#2F0743"]
                }, {
                    name: "Radar",
                    colors: ["#A770EF", "#CF8BF3", "#FDB99B"]
                }, {
                    name: "Ibiza Sunset",
                    colors: ["#ee0979", "#ff6a00"]
                }, {
                    name: "Dawn",
                    colors: ["#F3904F", "#3B4371"]
                }, {
                    name: "Mild",
                    colors: ["#67B26F", "#4ca2cd"]
                }, {
                    name: "Vice City",
                    colors: ["#3494E6", "#EC6EAD"]
                }, {
                    name: "Jaipur",
                    colors: ["#DBE6F6", "#C5796D"]
                }, {
                    name: "Jodhpur",
                    colors: ["#9CECFB", "#65C7F7", "#0052D4"]
                }, {
                    name: "Cocoaa Ice",
                    colors: ["#c0c0aa", "#1cefff"]
                }, {
                    name: "EasyMed",
                    colors: ["#DCE35B", "#45B649"]
                }, {
                    name: "Rose Colored Lenses",
                    colors: ["#E8CBC0", "#636FA4"]
                }, {
                    name: "What lies Beyond",
                    colors: ["#F0F2F0", "#000C40"]
                }, {
                    name: "Roseanna",
                    colors: ["#FFAFBD", "#ffc3a0"]
                }, {
                    name: "Honey Dew",
                    colors: ["#43C6AC", "#F8FFAE"]
                }, {
                    name: "Under the Lake",
                    colors: ["#093028", "#237A57"]
                }, {
                    name: "The Blue Lagoon",
                    colors: ["#43C6AC", "#191654"]
                }, {
                    name: "Can You Feel The Love Tonight",
                    colors: ["#4568DC", "#B06AB3"]
                }, {
                    name: "Very Blue",
                    colors: ["#0575E6", "#021B79"]
                }, {
                    name: "Love and Liberty",
                    colors: ["#200122", "#6f0000"]
                }, {
                    name: "Orca",
                    colors: ["#44A08D", "#093637"]
                }, {
                    name: "Venice",
                    colors: ["#6190E8", "#A7BFE8"]
                }, {
                    name: "Pacific Dream",
                    colors: ["#34e89e", "#0f3443"]
                }, {
                    name: "Learning and Leading",
                    colors: ["#F7971E", "#FFD200"]
                }, {
                    name: "Celestial",
                    colors: ["#C33764", "#1D2671"]
                }, {
                    name: "Purplepine",
                    colors: ["#20002c", "#cbb4d4"]
                }, {
                    name: "Sha la la",
                    colors: ["#D66D75", "#E29587"]
                }, {
                    name: "Mini",
                    colors: ["#30E8BF", "#FF8235"]
                }, {
                    name: "Maldives",
                    colors: ["#B2FEFA", "#0ED2F7"]
                }, {
                    name: "Cinnamint",
                    colors: ["#4AC29A", "#BDFFF3"]
                }, {
                    name: "Html",
                    colors: ["#E44D26", "#F16529"]
                }, {
                    name: "Coal",
                    colors: ["#EB5757", "#000000"]
                }, {
                    name: "Sunkist",
                    colors: ["#F2994A", "#F2C94C"]
                }, {
                    name: "Blue Skies",
                    colors: ["#56CCF2", "#2F80ED"]
                }, {
                    name: "Chitty Chitty Bang Bang",
                    colors: ["#007991", "#78ffd6"]
                }, {
                    name: "Visions of Grandeur",
                    colors: ["#000046", "#1CB5E0"]
                }, {
                    name: "Crystal Clear",
                    colors: ["#159957", "#155799"]
                }, {
                    name: "Mello",
                    colors: ["#c0392b", "#8e44ad"]
                }, {
                    name: "Compare Now",
                    colors: ["#EF3B36", "#FFFFFF"]
                }, {
                    name: "Meridian",
                    colors: ["#283c86", "#45a247"]
                }, {
                    name: "Relay",
                    colors: ["#3A1C71", "#D76D77", "#FFAF7B"]
                }, {
                    name: "Alive",
                    colors: ["#CB356B", "#BD3F32"]
                }, {
                    name: "Scooter",
                    colors: ["#36D1DC", "#5B86E5"]
                }, {
                    name: "Terminal",
                    colors: ["#000000", "#0f9b0f"]
                }, {
                    name: "Telegram",
                    colors: ["#1c92d2", "#f2fcfe"]
                }, {
                    name: "Crimson Tide",
                    colors: ["#642B73", "#C6426E"]
                }, {
                    name: "Socialive",
                    colors: ["#06beb6", "#48b1bf"]
                }, {
                    name: "Subu",
                    colors: ["#0cebeb", "#20e3b2", "#29ffc6"]
                }, {
                    name: "Broken Hearts",
                    colors: ["#d9a7c7", "#fffcdc"]
                }, {
                    name: "Kimoby Is The New Blue",
                    colors: ["#396afc", "#2948ff"]
                }, {
                    name: "Dull",
                    colors: ["#C9D6FF", "#E2E2E2"]
                }, {
                    name: "Purpink",
                    colors: ["#7F00FF", "#E100FF"]
                }, {
                    name: "Orange Coral",
                    colors: ["#ff9966", "#ff5e62"]
                }, {
                    name: "Summer",
                    colors: ["#22c1c3", "#fdbb2d"]
                }, {
                    name: "King Yna",
                    colors: ["#1a2a6c", "#b21f1f", "#fdbb2d"]
                }, {
                    name: "Velvet Sun",
                    colors: ["#e1eec3", "#f05053"]
                }, {
                    name: "Zinc",
                    colors: ["#ADA996", "#F2F2F2", "#DBDBDB", "#EAEAEA"]
                }, {
                    name: "Hydrogen",
                    colors: ["#667db6", "#0082c8", "#0082c8", "#667db6"]
                }, {
                    name: "Argon",
                    colors: ["#03001e", "#7303c0", "#ec38bc", "#fdeff9"]
                }, {
                    name: "Lithium",
                    colors: ["#6D6027", "#D3CBB8"]
                }, {
                    name: "Digital Water",
                    colors: ["#74ebd5", "#ACB6E5"]
                }, {
                    name: "Orange Fun",
                    colors: ["#fc4a1a", "#f7b733"]
                }, {
                    name: "Rainbow Blue",
                    colors: ["#00F260", "#0575E6"]
                }, {
                    name: "Pink Flavour",
                    colors: ["#800080", "#ffc0cb"]
                }, {
                    name: "Sulphur",
                    colors: ["#CAC531", "#F3F9A7"]
                }, {
                    name: "Selenium",
                    colors: ["#3C3B3F", "#605C3C"]
                }, {
                    name: "Delicate",
                    colors: ["#D3CCE3", "#E9E4F0"]
                }, {
                    name: "Ohhappiness",
                    colors: ["#00b09b", "#96c93d"]
                }, {
                    name: "Lawrencium",
                    colors: ["#0f0c29", "#302b63", "#24243e"]
                }, {
                    name: "Relaxing red",
                    colors: ["#fffbd5", "#b20a2c"]
                }, {
                    name: "Taran Tado",
                    colors: ["#23074d", "#cc5333"]
                }, {
                    name: "Bighead",
                    colors: ["#c94b4b", "#4b134f"]
                }, {
                    name: "Sublime Vivid",
                    colors: ["#FC466B", "#3F5EFB"]
                }, {
                    name: "Sublime Light",
                    colors: ["#FC5C7D", "#6A82FB"]
                }, {
                    name: "Pun Yeta",
                    colors: ["#108dc7", "#ef8e38"]
                }, {
                    name: "Quepal",
                    colors: ["#11998e", "#38ef7d"]
                }, {
                    name: "Sand to Blue",
                    colors: ["#3E5151", "#DECBA4"]
                }, {
                    name: "Wedding Day Blues",
                    colors: ["#40E0D0", "#FF8C00", "#FF0080"]
                }, {
                    name: "Shifter",
                    colors: ["#bc4e9c", "#f80759"]
                }, {
                    name: "Red Sunset",
                    colors: ["#355C7D", "#6C5B7B", "#C06C84"]
                }, {
                    name: "Moon Purple",
                    colors: ["#4e54c8", "#8f94fb"]
                }, {
                    name: "Pure Lust",
                    colors: ["#333333", "#dd1818"]
                }, {
                    name: "Slight Ocean View",
                    colors: ["#a8c0ff", "#3f2b96"]
                }, {
                    name: "eXpresso",
                    colors: ["#ad5389", "#3c1053"]
                }, {
                    name: "Shifty",
                    colors: ["#636363", "#a2ab58"]
                }, {
                    name: "Vanusa",
                    colors: ["#DA4453", "#89216B"]
                }, {
                    name: "Evening Night",
                    colors: ["#005AA7", "#FFFDE4"]
                }, {
                    name: "Magic",
                    colors: ["#59C173", "#a17fe0", "#5D26C1"]
                }, {
                    name: "Margo",
                    colors: ["#FFEFBA", "#FFFFFF"]
                }, {
                    name: "Blue Raspberry",
                    colors: ["#00B4DB", "#0083B0"]
                }, {
                    name: "Citrus Peel",
                    colors: ["#FDC830", "#F37335"]
                }, {
                    name: "Sin City Red",
                    colors: ["#ED213A", "#93291E"]
                }, {
                    name: "Rastafari",
                    colors: ["#1E9600", "#FFF200", "#FF0000"]
                }, {
                    name: "Summer Dog",
                    colors: ["#a8ff78", "#78ffd6"]
                }, {
                    name: "Wiretap",
                    colors: ["#8A2387", "#E94057", "#F27121"]
                }, {
                    name: "Burning Orange",
                    colors: ["#FF416C", "#FF4B2B"]
                }, {
                    name: "Ultra Voilet",
                    colors: ["#654ea3", "#eaafc8"]
                }, {
                    name: "By Design",
                    colors: ["#009FFF", "#ec2F4B"]
                }, {
                    name: "Kyoo Tah",
                    colors: ["#544a7d", "#ffd452"]
                }, {
                    name: "Kye Meh",
                    colors: ["#8360c3", "#2ebf91"]
                }, {
                    name: "Kyoo Pal",
                    colors: ["#dd3e54", "#6be585"]
                }, {
                    name: "Metapolis",
                    colors: ["#659999", "#f4791f"]
                }, {
                    name: "Flare",
                    colors: ["#f12711", "#f5af19"]
                }, {
                    name: "Witching Hour",
                    colors: ["#c31432", "#240b36"]
                }, {
                    name: "Azur Lane",
                    colors: ["#7F7FD5", "#86A8E7", "#91EAE4"]
                }, {
                    name: "Neuromancer",
                    colors: ["#f953c6", "#b91d73"]
                }, {
                    name: "Harvey",
                    colors: ["#1f4037", "#99f2c8"]
                }, {
                    name: "Amin",
                    colors: ["#8E2DE2", "#4A00E0"]
                }, {
                    name: "Memariani",
                    colors: ["#aa4b6b", "#6b6b83", "#3b8d99"]
                }, {
                    name: "Yoda",
                    colors: ["#FF0099", "#493240"]
                }, {
                    name: "Cool Sky",
                    colors: ["#2980B9", "#6DD5FA", "#FFFFFF"]
                }, {
                    name: "Dark Ocean",
                    colors: ["#373B44", "#4286f4"]
                }, {
                    name: "Evening Sunshine",
                    colors: ["#b92b27", "#1565C0"]
                }, {
                    name: "JShine",
                    colors: ["#12c2e9", "#c471ed", "#f64f59"]
                }, {
                    name: "Moonlit Asteroid",
                    colors: ["#0F2027", "#203A43", "#2C5364"]
                }, {
                    name: "MegaTron",
                    colors: ["#C6FFDD", "#FBD786", "#f7797d"]
                }, {
                    name: "Cool Blues",
                    colors: ["#2193b0", "#6dd5ed"]
                }, {
                    name: "Piggy Pink",
                    colors: ["#ee9ca7", "#ffdde1"]
                }, {
                    name: "Grade Grey",
                    colors: ["#bdc3c7", "#2c3e50"]
                }];

            function J() {
                var e = Object(c.a)(["\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n  max-width: 160px;\n"]);
                return J = function() {
                    return e
                }, e
            }

            function q() {
                var e = Object(c.a)(["\n  display: flex;\n  flex-wrap: wrap;\n  & > * {\n    flex: 1 1 32px;\n  }\n"]);
                return q = function() {
                    return e
                }, e
            }

            function U() {
                var e = Object(c.a)(['\n  margin-bottom: 0.5rem;\n  margin-left: 0.5rem;\n\n  font-family: "Prompt", sans-serif;\n  font-size: 0.8rem;\n  font-weight: normal;\n  color: ', ";\n"]);
                return U = function() {
                    return e
                }, e
            }

            function _() {
                var e = Object(c.a)(["\n  padding: 0.75rem;\n  max-width: 160px;\n  max-height: 200px;\n"]);
                return _ = function() {
                    return e
                }, e
            }
            var Q = F.default.div(_()),
                X = F.default.div(U(), E),
                Z = F.default.div(q()),
                $ = Object(F.default)(Y.a)(J()),
                ee = function(e) {
                    var n = e.gradient,
                        o = e.handleChange;
                    return r.a.createElement($, {
                        alignSelf: "center",
                        dropContent: r.a.createElement(Q, null, r.a.createElement(X, null, "Pick a gradient:"), r.a.createElement(Z, null, K.slice(20, 70).map(function(e) {
                            return r.a.createElement(N, {
                                colors: e.colors,
                                value: e.colors,
                                onClick: function() {
                                    return o("gradient")({
                                        target: {
                                            value: e.colors
                                        }
                                    })
                                },
                                style: {
                                    margin: ".5rem"
                                }
                            })
                        }))),
                        dropProps: {
                            align: {
                                top: "bottom",
                                left: "left"
                            }
                        }
                    }, r.a.createElement(N, {
                        colors: n
                    }), r.a.createElement(W.a, {
                        name: "chevron-down-outline",
                        size: "medium",
                        animation: {
                            type: "pulse",
                            hover: !1,
                            infinite: !1
                        },
                        fill: p,
                        onChange: o("gradient")
                    }))
                };

            function ne() {
                var e = Object(c.a)(['\n  display: flex;\n  flex-direction: row;\n  justify-content: flex-start;\n  align-items: center;\n\n  margin-right: 1rem;\n\n  svg {\n    margin-right: 0.25rem;\n    display: flex;\n  }\n\n  font-family: "Prompt", sans-serif;\n  font-size: 0.8rem;\n  font-weight: normal;\n  color: ', ";\n"]);
                return ne = function() {
                    return e
                }, e
            }

            function oe() {
                var e = Object(c.a)(["\n  display: flex;\n  flex-direction: row;\n  justify-content: flex-start;\n  align-items: center;\n\n  /* @media (min-width: 1281px) {\n    min-width: 30%;\n    max-width: 30%;\n  }\n  @media (min-width: 768px) and (max-width: 1024px) {\n    min-width: 30%;\n    max-width: 30%;\n  } */\n  @media (min-width: 1px) and (max-width: 767px) {\n    min-width: 100%;\n  }\n"]);
                return oe = function() {
                    return e
                }, e
            }
            var ae, re = F.default.div(oe()),
                te = F.default.div(ne(), E),
                le = function(e) {
                    var n = e.children,
                        o = e.icon,
                        a = e.title;
                    return r.a.createElement(re, null, r.a.createElement(te, null, r.a.createElement(W.a, {
                        name: o,
                        size: "medium",
                        animation: {
                            hover: !1
                        },
                        fill: E
                    }), a), n)
                },
                ce = o(116),
                ie = function(e) {
                    var n = e.min,
                        o = e.max,
                        a = e.step,
                        t = e.value,
                        l = e.onChange;
                    return r.a.createElement(ce.a, {
                        min: n,
                        max: o,
                        step: a,
                        value: t,
                        onChange: l
                    })
                };
            ie.defaultProps = {
                min: 0,
                max: 1,
                step: .1,
                value: .1 * (ae = 10, Math.floor(Math.random() * Math.floor(ae))),
                onChange: function() {}
            };
            var se = ie;

            function me() {
                var e = Object(c.a)(["\n  width: 100%;\n\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n\n  > div:nth-child(1) {\n    margin-right: 1rem;\n  }\n\n  @media (min-width: 1px) and (max-width: 767px) {\n    flex-direction: column;\n    align-items: flex-start;\n    box-sizing: content-box;\n\n    > div:nth-child(1) {\n      margin-right: 0;\n      margin-bottom: 1rem;\n    }\n  }\n"]);
                return me = function() {
                    return e
                }, e
            }
            var fe = F.default.div(me()),
                de = function(e) {
                    e.cssCode;
                    var n = e.cssToCopied,
                        o = e.baseColor,
                        a = e.gradient,
                        t = e.position,
                        l = e.weight,
                        c = e.handleChange;
                    return r.a.createElement(fe, null, r.a.createElement(z, null, r.a.createElement(le, {
                        icon: "color-palette-outline",
                        title: "Gradient:"
                    }, r.a.createElement(ee, {
                        handleChange: c,
                        gradient: a
                    })), r.a.createElement(le, {
                        icon: "layers-outline",
                        title: "Position:"
                    }, r.a.createElement(se, {
                        value: t,
                        min: 0,
                        max: 100,
                        step: 10,
                        label: "position",
                        onChange: c("position")
                    })), r.a.createElement(le, {
                        icon: "crop-outline",
                        title: "Weight:"
                    }, r.a.createElement(se, {
                        value: l,
                        min: .1,
                        max: 1,
                        step: .1,
                        label: "weight",
                        onChange: c("weight")
                    }))), r.a.createElement(H, {
                        cssCode: n,
                        grow: 1,
                        baseColor: o
                    }))
                };

            function ue() {
                var e = Object(c.a)(["\n  border: 2px dotted #999;\n  border-radius: 8px;\n  box-sizing: border-box;\n  width: 100%;\n\n  padding: 4rem 2rem;\n  margin-bottom: 2rem;\n\n  background-color: transparent;\n\n  > span {\n    ", "\n  }\n\n  color: ", ";\n  font-size: 2em;\n  font-weight: bold;\n  text-align: center;\n  line-height: 1.2em;\n"]);
                return ue = function() {
                    return e
                }, e
            }
            var Fe = F.default.div(ue(), function(e) {
                    return e.cssCode
                }, D),
                be = function(e) {
                    var n = e.cssCode,
                        o = e.text;
                    return r.a.createElement(Fe, {
                        cssCode: n
                    }, r.a.createElement("span", null, o))
                };
            be.defaultProps = {};
            var he = be;

            function ge() {
                var e = Object(c.a)(["\n  width: 80%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n\n  @media (min-width: 1281px) {\n    width: 60%;\n  }\n  @media (min-width: 768px) and (max-width: 1024px) {\n    width: 80%;\n  }\n  @media (max-width: 767px) {\n    width: 100%;\n  }\n"]);
                return ge = function() {
                    return e
                }, e
            }
            var Ce = F.default.div(ge()),
                pe = function(e) {
                    var n = e.cssCode,
                        o = e.cssToCopied,
                        a = e.baseColor,
                        t = e.displayText,
                        l = e.gradient,
                        c = e.position,
                        i = e.weight,
                        s = e.handleChange;
                    return r.a.createElement(Ce, null, r.a.createElement(he, {
                        cssCode: n,
                        text: t
                    }), r.a.createElement(de, {
                        cssCode: n,
                        cssToCopied: o,
                        baseColor: a,
                        gradient: l,
                        position: c,
                        weight: i,
                        handleChange: s
                    }))
                };

            function Ee() {
                var e = Object(c.a)(["\n  color: ", ";\n  font-weight: bold;\n  font-size: 0.75rem;\n\n  &:focus {\n    outline-color: ", ";\n  }\n"]);
                return Ee = function() {
                    return e
                }, e
            }

            function Be() {
                var e = Object(c.a)(['\n  font-family: "Prompt", sans-serif;\n  font-size: 0.65rem;\n  color: ', ";\n"]);
                return Be = function() {
                    return e
                }, e
            }

            function De() {
                var e = Object(c.a)(["\n  max-width: 100%;\n  margin-top: 2em;\n  padding-top: 2em;\n\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  /* background-color: salmon; */\n"]);
                return De = function() {
                    return e
                }, e
            }
            var xe = F.default.div(De()),
                Ae = F.default.sup(Be(), B),
                we = F.default.a(Ee(), function(e) {
                    return e.baseColor
                }, function(e) {
                    return e.baseColor
                }),
                ye = function(e) {
                    var n = e.baseColor;
                    return r.a.createElement(xe, null, r.a.createElement(Ae, null, "Designed and Built by", " ", r.a.createElement(we, {
                        href: "https://twitter.com/d__raptis",
                        baseColor: n
                    }, "@draptis")))
                };

            function ve() {
                var e = Object(c.a)(['\n  position: absolute;\n  top: 32px;\n  right: 32px;\n\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n\n  align-self: flex-end;\n\n  cursor: pointer;\n\n  font-family: "Prompt", sans-serif;\n  font-size: 1rem;\n  color: ', ";\n  svg {\n    fill: ", ";\n  }\n\n  text-decoration: none;\n\n  -webkit-animation-duration: 1s;\n  animation-duration: 1s;\n  -webkit-animation-fill-mode: both;\n  animation-fill-mode: both;\n  -webkit-animation-timing-function: ease-in-out;\n  animation-timing-function: ease-in-out;\n  animation-iteration-count: 1;\n  -webkit-animation-iteration-count: 1;\n\n  &:hover {\n    animation-name: ", ";\n    -moz-animation-name: ", ";\n\n    color: ", ";\n    svg {\n      fill: ", ";\n    }\n  }\n\n  &:focus {\n    outline-color: ", ";\n  }\n"]);
                return ve = function() {
                    return e
                }, e
            }

            function ke() {
                var e = Object(c.a)(["\n\t0%, 100%, 20%, 50%, 80% {\n\t\t-webkit-transform: translateY(0);\n\t\t-ms-transform:     translateY(0);\n\t\ttransform:         translateY(0)\n\t}\n\t40% {\n\t\t-webkit-transform: translateY(-16px);\n\t\t-ms-transform:     translateY(-16px);\n\t\ttransform:         translateY(-16px)\n\t}\n\t60% {\n\t\t-webkit-transform: translateY(-8px);\n\t\t-ms-transform:     translateY(-8px);\n\t\ttransform:         translateY(-8px)\n\t}\n"]);
                return ke = function() {
                    return e
                }, e
            }
            var Se = Object(F.keyframes)(ke()),
                ze = F.default.a(ve(), E, E, Se, Se, function(e) {
                    return e.baseColor
                }, function(e) {
                    return e.baseColor
                }, function(e) {
                    return e.baseColor
                }),
                Me = function(e) {
                    var n = e.baseColor;
                    return r.a.createElement(ze, {
                        baseColor: n,
                        href: "https://github.com/dimitrisraptis96/underline-generator",
                        "aria-label": "Check the github repo"
                    }, r.a.createElement(W.a, {
                        name: "github",
                        fill: "black",
                        size: "large",
                        animation: {
                            type: "pulse",
                            hover: !1,
                            infinite: !1
                        }
                    }))
                },
                Oe = o(65),
                je = o(64),
                Pe = function(e) {
                    return Object(je.deepMerge)(Oe.grommet, {
                        global: {
                            spacing: "12px",
                            focus: {
                                border: {
                                    color: e
                                }
                            }
                        },
                        rangeInput: {
                            track: {
                                color: C,
                                height: "4px",
                                extend: function() {
                                    return "border-radius: 1000px"
                                }
                            },
                            thumb: {
                                color: e
                            }
                        }
                    })
                };

            function Te() {
                var e = Object(c.a)(['\n  position: absolute;\n  top: 32px;\n  right: 32px;\n\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n\n  align-self: flex-end;\n\n  cursor: pointer;\n\n  font-family: "Prompt", sans-serif;\n  font-size: 1rem;\n  color: ', ";\n  svg {\n    fill: ", ";\n    /* margin-right: 0.5rem; */\n  }\n\n  text-decoration: none;\n\n  &:hover {\n    color: ", ";\n    svg {\n      fill: ", ";\n    }\n  }\n\n  &:focus {\n    outline-color: ", ";\n  }\n"]);
                return Te = function() {
                    return e
                }, e
            }

            function Le() {
                var e = Object(c.a)(["\n  padding: 2em 4em;\n  background-color: ", ';\n\n  min-height: calc(100vh - 2 * 2em);\n  /* max-height: calc(100vh - 4em); */\n\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  align-items: center;\n\n  font-family: "Prata", serif;\n']);
                return Le = function() {
                    return e
                }, e
            }
            var Re = F.default.div(Le(), "#f4f4f4"),
                Ve = (F.default.a(Te(), E, E, function(e) {
                    return e.baseColor
                }, function(e) {
                    return e.baseColor
                }, function(e) {
                    return e.baseColor
                }), function(e) {
                    var n = e.baseColor,
                        o = e.gradient;
                    return r.a.createElement(b.a, {
                        theme: Pe(n)
                    }, r.a.createElement(Me, {
                        baseColor: n
                    }), r.a.createElement(Re, null, r.a.createElement(k, {
                        baseColor: n,
                        gradient: o
                    }), r.a.createElement(pe, Object.assign({}, e, {
                        baseColor: n
                    })), r.a.createElement(ye, {
                        baseColor: n
                    })))
                });

            function He() {
                var e = Object(c.a)(["\n      background-image: linear-gradient(", "deg, ", " 100%);\n      background-repeat: no-repeat;\n      background-size: 100% ", "em;\n      background-position: 0 ", "%;\n      transition: background-size 0.25s ease-in;\n\n      &:hover {\n        background-size: 100% 88% !important;\n      }\n    "]);
                return He = function() {
                    return e
                }, e
            }
            var Ie = function(e) {
                function n() {
                    var e, o;
                    Object(s.a)(this, n);
                    for (var a = arguments.length, r = new Array(a), t = 0; t < a; t++) r[t] = arguments[t];
                    return (o = Object(f.a)(this, (e = Object(d.a)(n)).call.apply(e, [this].concat(r)))).state = {
                        weight: .3,
                        position: 20,
                        gradient: ["#ec008c", "#fc6767"]
                    }, o.handleChange = function(e) {
                        return function(n) {
                            o.setState(Object(i.a)({}, e, n.target.value))
                        }
                    }, o.isMobileDevice = function() {
                        return "undefined" !== typeof window.orientation || -1 !== navigator.userAgent.indexOf("IEMobile")
                    }, o.getDisplayText = function() {
                        return o.isMobileDevice() ? "Hey buddy! Dare you to open me on a desktop!" : "Hey buddy! Dare you to hover me!"
                    }, o.getCSS = function() {
                        var e = o.state,
                            n = e.gradient,
                            a = e.position,
                            r = e.weight;
                        return {
                            mixin: Object(F.css)(He(), 120, n.join(), r, 100 - a),
                            text: "\n      .fancy-undeline {\n        background-image: linear-gradient(".concat(120, "deg, ").concat(n.join(), " 100%);\n        background-repeat: no-repeat;\n        background-size: 100% ").concat(r, "em;\n        background-position: 0 ").concat(100 - a, "%;\n        transition: background-size 0.25s ease-in;\n      }\n\n      .fancy-undeline:hover {\n        background-size: 100% 88% !important;\n      }\n    ")
                        }
                    }, o
                }
                return Object(u.a)(n, e), Object(m.a)(n, [{
                    key: "render",
                    value: function() {
                        var e = this.state,
                            n = e.gradient,
                            o = e.position,
                            a = e.weight,
                            t = n[0],
                            l = this.getDisplayText(),
                            c = this.getCSS(),
                            i = c.mixin,
                            s = c.text;
                        return r.a.createElement(Ve, {
                            cssCode: i,
                            cssToCopied: s,
                            baseColor: t,
                            displayText: l,
                            gradient: n,
                            position: o,
                            weight: a,
                            handleChange: this.handleChange
                        })
                    }
                }]), n
            }(r.a.Component);
            Boolean("localhost" === window.location.hostname || "[::1]" === window.location.hostname || window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/));
            l.a.render(r.a.createElement(Ie, null), document.getElementById("root")), "serviceWorker" in navigator && navigator.serviceWorker.ready.then(function(e) {
                e.unregister()
            })
        },
        71: function(e, n, o) {
            e.exports = o(108)
        }
    },
    [
        [71, 1, 2]
    ]
]);
//# sourceMappingURL=main.f3179743.chunk.js.map