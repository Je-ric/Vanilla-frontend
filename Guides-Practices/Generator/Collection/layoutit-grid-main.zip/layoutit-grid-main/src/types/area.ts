export interface AreaState {
  name: any
  color: any
  type: any
  display: any
  grid: any
  flex: any
  gridArea: any
  width: any
  height: any
  margin: any
  padding: any
  justifySelf: any
  alignSelf: any
  flexGrow: any
  flexShrink: any
  flexBasis: any
  text: any
  items: any
  children: any
  parent: any
}
