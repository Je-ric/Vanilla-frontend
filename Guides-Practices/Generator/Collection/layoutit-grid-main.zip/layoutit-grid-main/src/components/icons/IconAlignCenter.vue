<template>
  <svg fill='none' stroke='#0E1A27' stroke-linecap='round' stroke-linejoin='round' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'>
    <line x1="20" y1="50" x2="80" y2="50" />
    <rect x="40" y="20" width="20" height="20"/>
    <rect x="40" y="60" width="20" height="20"/>
  </svg>
</template>
