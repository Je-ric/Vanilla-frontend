<template>
  <svg width="20" height="20" viewBox="0 0 224 328">
    <polygon fill="#eee" points="0 192.157 96.126 192.157 40.126 328 224 134.685 127.433 134.685 182.992 0" />
  </svg>
</template>
