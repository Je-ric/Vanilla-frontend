<template>
  <svg
    fill="none"
    stroke="#eee"
    stroke-width="20"
    stroke-dashoffset="0"
    stroke-dasharray="0"
    stroke-linecap="round"
    stroke-linejoin="round"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 100 100"
    data-v-72c511f8=""
    data-v-0da319cf-s=""
  >
    <line x1="15" y1="15" x2="85" y2="85"></line>
    <line x1="85" y1="15" x2="15" y2="85"></line>
  </svg>
</template>
<style lang="postcss" scoped>
svg {
  transform: rotate(45deg);
}
</style>
