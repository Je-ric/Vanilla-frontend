<template>
  <svg
    fill="none"
    stroke="#eee"
    stroke-linecap="round"
    stroke-linejoin="round"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 100 100"
  >
    <line x1="20" y1="20" x2="20" y2="80" />
    <line x1="40" y1="50" x2="85" y2="50" />
    <polyline fill="none" points="70,30 85,50 70,70" />
  </svg>
</template>
