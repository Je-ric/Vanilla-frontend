export function createFlexState({ direction = 'row', wrap = 'nowrap' } = {}) {
  return { direction, wrap }
}
