<template>
  <svg
    fill="none"
    stroke="none"
    stroke-width="0"
    stroke-dashoffset="0"
    stroke-dasharray="0"
    stroke-linecap="round"
    stroke-linejoin="round"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 100 100"
  >
    <rect fill="#fff" x="10" y="10" width="32" height="32" />
    <rect fill="#fff" x="10" y="57" width="32" height="32" />
    <rect fill="#fff" x="57" y="10" width="32" height="32" />
    <rect fill="#fff" x="57" y="57" width="32" height="32" />
  </svg>
</template>
