<template>
  <svg fill='none' stroke='#0E1A27' stroke-linecap='round' stroke-linejoin='round' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'>
    <line x1="10" y1="20" x2="10" y2="80" />
    <line x1="90" y1="20" x2="90" y2="80" />
    <rect x="10" y="40" width="34" height="20"/>
    <rect x="56" y="40" width="34" height="20"/>
  </svg>
</template>
