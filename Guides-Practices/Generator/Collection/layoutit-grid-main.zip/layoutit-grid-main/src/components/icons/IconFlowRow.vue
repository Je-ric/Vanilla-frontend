<template>
  <svg
    fill="none"
    stroke="#eee"
    stroke-linecap="round"
    stroke-linejoin="round"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 100 100"
  >
    <line x1="20" y1="20" x2="80" y2="20" />
    <line x1="50" y1="40" x2="50" y2="85" />
    <polyline fill="none" points="30,70 50,85 70,70" />
  </svg>
</template>
