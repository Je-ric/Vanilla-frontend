<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    height="300px"
    width="300px"
    fill="#000000"
    version="1.1"
    x="0px"
    y="0px"
    viewBox="0 0 100 100"
    xml:space="preserve"
  >
    <path
      d="M84.8,45.9H54.2V14.6c0-2.4-1.9-4.3-4.3-4.3s-4.3,1.9-4.3,4.3v31.3H15.1c-2.4,0-4.3,1.9-4.3,4.3c0,2.4,1.9,4.3,4.3,4.3h30.6  v31.3c0,2.4,1.9,4.3,4.3,4.3c2.4,0,4.3-1.9,4.3-4.3V54.5h30.6c2.4,0,4.3-1.9,4.3-4.3C89.1,47.8,87.2,45.9,84.8,45.9z"
    />
  </svg>
</template>
