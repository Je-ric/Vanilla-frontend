module.exports = {
    plugins: {
        "postcss-nested": {}
    }
};