<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
    <line x1="10" y1="20" x2="10" y2="80" />
    <line x1="90" y1="20" x2="90" y2="80" />
    <rect x="20" y="40" width="20" height="20"/>
    <rect x="60" y="40" width="20" height="20"/>
  </svg>
</template>
