# Clippy

Live: https://bennettfeely.com/clippy

Shape up your website with CSS clip-paths!

Clippy is a tool for generating values for shape functions for the new and cool CSS clip-path property.

## Browser Support for CSS clip-path

[caniuse.com](http://caniuse.com/#search=clip-path)
