(window.webpackJsonp = window.webpackJsonp || []).push([
    [2],
    [function(e, t, a) {
        "use strict";
        e.exports = a(72)
    }, function(e, t, a) {
        "use strict";
        a.r(t),
            function(e) {
                a.d(t, "createGlobalStyle", function() {
                    return at
                }), a.d(t, "css", function() {
                    return ye
                }), a.d(t, "isStyledComponent", function() {
                    return L
                }), a.d(t, "keyframes", function() {
                    return nt
                }), a.d(t, "ServerStyleSheet", function() {
                    return Qe
                }), a.d(t, "StyleSheetConsumer", function() {
                    return Ge
                }), a.d(t, "StyleSheetContext", function() {
                    return Ye
                }), a.d(t, "StyleSheetManager", function() {
                    return Ke
                }), a.d(t, "ThemeConsumer", function() {
                    return $e
                }), a.d(t, "ThemeContext", function() {
                    return We
                }), a.d(t, "ThemeProvider", function() {
                    return qe
                }), a.d(t, "withTheme", function() {
                    return ot
                }), a.d(t, "__DO_NOT_USE_OR_YOU_WILL_BE_HAUNTED_BY_SPOOKY_GHOSTS", function() {
                    return it
                });
                var r = a(39),
                    n = a.n(r),
                    o = a(57),
                    i = a.n(o),
                    l = a(0),
                    c = a.n(l),
                    u = a(58),
                    d = a(22),
                    s = a(40),
                    h = (a(9), a(13), a(68)),
                    p = function(e, t) {
                        for (var a = [e[0]], r = 0, n = t.length; r < n; r += 1) a.push(t[r], e[r + 1]);
                        return a
                    },
                    f = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    },
                    g = function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    },
                    m = function() {
                        function e(e, t) {
                            for (var a = 0; a < t.length; a++) {
                                var r = t[a];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                            }
                        }
                        return function(t, a, r) {
                            return a && e(t.prototype, a), r && e(t, r), t
                        }
                    }(),
                    y = Object.assign || function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var a = arguments[t];
                            for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                        }
                        return e
                    },
                    v = function(e, t) {
                        if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                    },
                    b = function(e, t) {
                        var a = {};
                        for (var r in e) t.indexOf(r) >= 0 || Object.prototype.hasOwnProperty.call(e, r) && (a[r] = e[r]);
                        return a
                    },
                    w = function(e, t) {
                        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return !t || "object" !== typeof t && "function" !== typeof t ? e : t
                    },
                    z = function(e) {
                        return "object" === ("undefined" === typeof e ? "undefined" : f(e)) && e.constructor === Object
                    },
                    x = Object.freeze([]),
                    k = Object.freeze({});

                function M(e) {
                    return "function" === typeof e
                }

                function A(e) {
                    return e.displayName || e.name || "Component"
                }

                function L(e) {
                    return e && "string" === typeof e.styledComponentId
                }
                var S = "undefined" !== typeof e && Object({
                        NODE_ENV: "production",
                        PUBLIC_URL: ""
                    }).SC_ATTR || "data-styled",
                    O = "undefined" !== typeof window && "HTMLElement" in window,
                    C = "boolean" === typeof SC_DISABLE_SPEEDY && SC_DISABLE_SPEEDY || !1,
                    T = {};
                var j = function(e) {
                        function t(a) {
                            g(this, t);
                            for (var r = arguments.length, n = Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++) n[o - 1] = arguments[o];
                            var i = w(this, e.call(this, "An error occurred. See https://github.com/styled-components/styled-components/blob/master/packages/styled-components/src/utils/errors.md#" + a + " for more information. " + (n ? "Additional arguments: " + n.join(", ") : "")));
                            return w(i)
                        }
                        return v(t, e), t
                    }(Error),
                    E = /^[^\S\n]*?\/\* sc-component-id:\s*(\S+)\s+\*\//gm,
                    _ = function(e) {
                        var t = "" + (e || ""),
                            a = [];
                        return t.replace(E, function(e, t, r) {
                            return a.push({
                                componentId: t,
                                matchIndex: r
                            }), e
                        }), a.map(function(e, r) {
                            var n = e.componentId,
                                o = e.matchIndex,
                                i = a[r + 1];
                            return {
                                componentId: n,
                                cssFromDOM: i ? t.slice(o, i.matchIndex) : t.slice(o)
                            }
                        })
                    },
                    P = /^\s*\/\/.*$/gm,
                    V = new n.a({
                        global: !1,
                        cascade: !0,
                        keyframe: !1,
                        prefix: !1,
                        compress: !1,
                        semicolon: !0
                    }),
                    H = new n.a({
                        global: !1,
                        cascade: !0,
                        keyframe: !1,
                        prefix: !0,
                        compress: !1,
                        semicolon: !1
                    }),
                    I = [],
                    F = function(e) {
                        if (-2 === e) {
                            var t = I;
                            return I = [], t
                        }
                    },
                    R = i()(function(e) {
                        I.push(e)
                    }),
                    N = void 0,
                    D = void 0,
                    U = void 0,
                    B = function(e, t, a) {
                        return t > 0 && -1 !== a.slice(0, t).indexOf(D) && a.slice(t - D.length, t) !== D ? "." + N : e
                    };
                H.use([function(e, t, a) {
                    2 === e && a.length && a[0].lastIndexOf(D) > 0 && (a[0] = a[0].replace(U, B))
                }, R, F]), V.use([R, F]);

                function W(e, t, a) {
                    var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "&",
                        n = e.join("").replace(P, ""),
                        o = t && a ? a + " " + t + " { " + n + " }" : n;
                    return N = r, D = t, U = new RegExp("\\" + D + "\\b", "g"), H(a || !t ? "" : t, o)
                }
                var $ = function() {
                        return a.nc
                    },
                    q = function(e, t, a) {
                        a && ((e[t] || (e[t] = Object.create(null)))[a] = !0)
                    },
                    Q = function(e, t) {
                        e[t] = Object.create(null)
                    },
                    Y = function(e) {
                        return function(t, a) {
                            return void 0 !== e[t] && e[t][a]
                        }
                    },
                    G = function(e) {
                        var t = "";
                        for (var a in e) t += Object.keys(e[a]).join(" ") + " ";
                        return t.trim()
                    },
                    K = function(e) {
                        if (e.sheet) return e.sheet;
                        for (var t = document.styleSheets.length, a = 0; a < t; a += 1) {
                            var r = document.styleSheets[a];
                            if (r.ownerNode === e) return r
                        }
                        throw new j(10)
                    },
                    X = function(e, t, a) {
                        if (!t) return !1;
                        var r = e.cssRules.length;
                        try {
                            e.insertRule(t, a <= r ? a : r)
                        } catch (n) {
                            return !1
                        }
                        return !0
                    },
                    Z = function(e) {
                        return "\n/* sc-component-id: " + e + " */\n"
                    },
                    J = function(e, t) {
                        for (var a = 0, r = 0; r <= t; r += 1) a += e[r];
                        return a
                    },
                    ee = function(e, t) {
                        return function(a) {
                            var r = $();
                            return "<style " + [r && 'nonce="' + r + '"', S + '="' + G(t) + '"', 'data-styled-version="4.2.0"', a].filter(Boolean).join(" ") + ">" + e() + "</style>"
                        }
                    },
                    te = function(e, t) {
                        return function() {
                            var a, r = ((a = {})[S] = G(t), a["data-styled-version"] = "4.2.0", a),
                                n = $();
                            return n && (r.nonce = n), c.a.createElement("style", y({}, r, {
                                dangerouslySetInnerHTML: {
                                    __html: e()
                                }
                            }))
                        }
                    },
                    ae = function(e) {
                        return function() {
                            return Object.keys(e)
                        }
                    },
                    re = function(e) {
                        return document.createTextNode(Z(e))
                    },
                    ne = function e(t, a) {
                        var r = void 0 === t ? Object.create(null) : t,
                            n = void 0 === a ? Object.create(null) : a,
                            o = function(e) {
                                var t = n[e];
                                return void 0 !== t ? t : n[e] = [""]
                            },
                            i = function() {
                                var e = "";
                                for (var t in n) {
                                    var a = n[t][0];
                                    a && (e += Z(t) + a)
                                }
                                return e
                            };
                        return {
                            clone: function() {
                                var t = function(e) {
                                        var t = Object.create(null);
                                        for (var a in e) t[a] = y({}, e[a]);
                                        return t
                                    }(r),
                                    a = Object.create(null);
                                for (var o in n) a[o] = [n[o][0]];
                                return e(t, a)
                            },
                            css: i,
                            getIds: ae(n),
                            hasNameForId: Y(r),
                            insertMarker: o,
                            insertRules: function(e, t, a) {
                                o(e)[0] += t.join(" "), q(r, e, a)
                            },
                            removeRules: function(e) {
                                var t = n[e];
                                void 0 !== t && (t[0] = "", Q(r, e))
                            },
                            sealed: !1,
                            styleTag: null,
                            toElement: te(i, r),
                            toHTML: ee(i, r)
                        }
                    },
                    oe = function(e, t, a, r, n) {
                        if (O && !a) {
                            var o = function(e, t, a) {
                                var r = document.createElement("style");
                                r.setAttribute(S, ""), r.setAttribute("data-styled-version", "4.2.0");
                                var n = $();
                                if (n && r.setAttribute("nonce", n), r.appendChild(document.createTextNode("")), e && !t) e.appendChild(r);
                                else {
                                    if (!t || !e || !t.parentNode) throw new j(6);
                                    t.parentNode.insertBefore(r, a ? t : t.nextSibling)
                                }
                                return r
                            }(e, t, r);
                            return C ? function(e, t) {
                                var a = Object.create(null),
                                    r = Object.create(null),
                                    n = void 0 !== t,
                                    o = !1,
                                    i = function(t) {
                                        var n = r[t];
                                        return void 0 !== n ? n : (r[t] = re(t), e.appendChild(r[t]), a[t] = Object.create(null), r[t])
                                    },
                                    l = function() {
                                        var e = "";
                                        for (var t in r) e += r[t].data;
                                        return e
                                    };
                                return {
                                    clone: function() {
                                        throw new j(5)
                                    },
                                    css: l,
                                    getIds: ae(r),
                                    hasNameForId: Y(a),
                                    insertMarker: i,
                                    insertRules: function(e, r, l) {
                                        for (var c = i(e), u = [], d = r.length, s = 0; s < d; s += 1) {
                                            var h = r[s],
                                                p = n;
                                            if (p && -1 !== h.indexOf("@import")) u.push(h);
                                            else {
                                                p = !1;
                                                var f = s === d - 1 ? "" : " ";
                                                c.appendData("" + h + f)
                                            }
                                        }
                                        q(a, e, l), n && u.length > 0 && (o = !0, t().insertRules(e + "-import", u))
                                    },
                                    removeRules: function(i) {
                                        var l = r[i];
                                        if (void 0 !== l) {
                                            var c = re(i);
                                            e.replaceChild(c, l), r[i] = c, Q(a, i), n && o && t().removeRules(i + "-import")
                                        }
                                    },
                                    sealed: !1,
                                    styleTag: e,
                                    toElement: te(l, a),
                                    toHTML: ee(l, a)
                                }
                            }(o, n) : function(e, t) {
                                var a = Object.create(null),
                                    r = Object.create(null),
                                    n = [],
                                    o = void 0 !== t,
                                    i = !1,
                                    l = function(e) {
                                        var t = r[e];
                                        return void 0 !== t ? t : (r[e] = n.length, n.push(0), Q(a, e), r[e])
                                    },
                                    c = function() {
                                        var t = K(e).cssRules,
                                            a = "";
                                        for (var o in r) {
                                            a += Z(o);
                                            for (var i = r[o], l = J(n, i), c = l - n[i]; c < l; c += 1) {
                                                var u = t[c];
                                                void 0 !== u && (a += u.cssText)
                                            }
                                        }
                                        return a
                                    };
                                return {
                                    clone: function() {
                                        throw new j(5)
                                    },
                                    css: c,
                                    getIds: ae(r),
                                    hasNameForId: Y(a),
                                    insertMarker: l,
                                    insertRules: function(r, c, u) {
                                        for (var d = l(r), s = K(e), h = J(n, d), p = 0, f = [], g = c.length, m = 0; m < g; m += 1) {
                                            var y = c[m],
                                                v = o;
                                            v && -1 !== y.indexOf("@import") ? f.push(y) : X(s, y, h + p) && (v = !1, p += 1)
                                        }
                                        o && f.length > 0 && (i = !0, t().insertRules(r + "-import", f)), n[d] += p, q(a, r, u)
                                    },
                                    removeRules: function(l) {
                                        var c = r[l];
                                        if (void 0 !== c) {
                                            var u = n[c];
                                            ! function(e, t, a) {
                                                for (var r = t - a, n = t; n > r; n -= 1) e.deleteRule(n)
                                            }(K(e), J(n, c) - 1, u), n[c] = 0, Q(a, l), o && i && t().removeRules(l + "-import")
                                        }
                                    },
                                    sealed: !1,
                                    styleTag: e,
                                    toElement: te(c, a),
                                    toHTML: ee(c, a)
                                }
                            }(o, n)
                        }
                        return ne()
                    },
                    ie = /\s+/,
                    le = void 0;
                le = O ? C ? 40 : 1e3 : -1;
                var ce = 0,
                    ue = void 0,
                    de = function() {
                        function e() {
                            var t = this,
                                a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : O ? document.head : null,
                                r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                            g(this, e), this.getImportRuleTag = function() {
                                var e = t.importRuleTag;
                                if (void 0 !== e) return e;
                                var a = t.tags[0];
                                return t.importRuleTag = oe(t.target, a ? a.styleTag : null, t.forceServer, !0)
                            }, ce += 1, this.id = ce, this.forceServer = r, this.target = r ? null : a, this.tagMap = {}, this.deferred = {}, this.rehydratedNames = {}, this.ignoreRehydratedNames = {}, this.tags = [], this.capacity = 1, this.clones = []
                        }
                        return e.prototype.rehydrate = function() {
                            if (!O || this.forceServer) return this;
                            var e = [],
                                t = [],
                                a = !1,
                                r = document.querySelectorAll("style[" + S + '][data-styled-version="4.2.0"]'),
                                n = r.length;
                            if (!n) return this;
                            for (var o = 0; o < n; o += 1) {
                                var i = r[o];
                                a || (a = !!i.getAttribute("data-styled-streamed"));
                                for (var l, c = (i.getAttribute(S) || "").trim().split(ie), u = c.length, d = 0; d < u; d += 1) l = c[d], this.rehydratedNames[l] = !0;
                                t.push.apply(t, _(i.textContent)), e.push(i)
                            }
                            var s = t.length;
                            if (!s) return this;
                            var h = this.makeTag(null);
                            ! function(e, t, a) {
                                for (var r = 0, n = a.length; r < n; r += 1) {
                                    var o = a[r],
                                        i = o.componentId,
                                        l = o.cssFromDOM,
                                        c = V("", l);
                                    e.insertRules(i, c)
                                }
                                for (var u = 0, d = t.length; u < d; u += 1) {
                                    var s = t[u];
                                    s.parentNode && s.parentNode.removeChild(s)
                                }
                            }(h, e, t), this.capacity = Math.max(1, le - s), this.tags.push(h);
                            for (var p = 0; p < s; p += 1) this.tagMap[t[p].componentId] = h;
                            return this
                        }, e.reset = function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                            ue = new e(void 0, t).rehydrate()
                        }, e.prototype.clone = function() {
                            var t = new e(this.target, this.forceServer);
                            return this.clones.push(t), t.tags = this.tags.map(function(e) {
                                for (var a = e.getIds(), r = e.clone(), n = 0; n < a.length; n += 1) t.tagMap[a[n]] = r;
                                return r
                            }), t.rehydratedNames = y({}, this.rehydratedNames), t.deferred = y({}, this.deferred), t
                        }, e.prototype.sealAllTags = function() {
                            this.capacity = 1, this.tags.forEach(function(e) {
                                e.sealed = !0
                            })
                        }, e.prototype.makeTag = function(e) {
                            var t = e ? e.styleTag : null;
                            return oe(this.target, t, this.forceServer, !1, this.getImportRuleTag)
                        }, e.prototype.getTagForId = function(e) {
                            var t = this.tagMap[e];
                            if (void 0 !== t && !t.sealed) return t;
                            var a = this.tags[this.tags.length - 1];
                            return this.capacity -= 1, 0 === this.capacity && (this.capacity = le, a = this.makeTag(a), this.tags.push(a)), this.tagMap[e] = a
                        }, e.prototype.hasId = function(e) {
                            return void 0 !== this.tagMap[e]
                        }, e.prototype.hasNameForId = function(e, t) {
                            if (void 0 === this.ignoreRehydratedNames[e] && this.rehydratedNames[t]) return !0;
                            var a = this.tagMap[e];
                            return void 0 !== a && a.hasNameForId(e, t)
                        }, e.prototype.deferredInject = function(e, t) {
                            if (void 0 === this.tagMap[e]) {
                                for (var a = this.clones, r = 0; r < a.length; r += 1) a[r].deferredInject(e, t);
                                this.getTagForId(e).insertMarker(e), this.deferred[e] = t
                            }
                        }, e.prototype.inject = function(e, t, a) {
                            for (var r = this.clones, n = 0; n < r.length; n += 1) r[n].inject(e, t, a);
                            var o = this.getTagForId(e);
                            if (void 0 !== this.deferred[e]) {
                                var i = this.deferred[e].concat(t);
                                o.insertRules(e, i, a), this.deferred[e] = void 0
                            } else o.insertRules(e, t, a)
                        }, e.prototype.remove = function(e) {
                            var t = this.tagMap[e];
                            if (void 0 !== t) {
                                for (var a = this.clones, r = 0; r < a.length; r += 1) a[r].remove(e);
                                t.removeRules(e), this.ignoreRehydratedNames[e] = !0, this.deferred[e] = void 0
                            }
                        }, e.prototype.toHTML = function() {
                            return this.tags.map(function(e) {
                                return e.toHTML()
                            }).join("")
                        }, e.prototype.toReactElements = function() {
                            var e = this.id;
                            return this.tags.map(function(t, a) {
                                var r = "sc-" + e + "-" + a;
                                return Object(l.cloneElement)(t.toElement(), {
                                    key: r
                                })
                            })
                        }, m(e, null, [{
                            key: "master",
                            get: function() {
                                return ue || (ue = (new e).rehydrate())
                            }
                        }, {
                            key: "instance",
                            get: function() {
                                return e.master
                            }
                        }]), e
                    }(),
                    se = function() {
                        function e(t, a) {
                            var r = this;
                            g(this, e), this.inject = function(e) {
                                e.hasNameForId(r.id, r.name) || e.inject(r.id, r.rules, r.name)
                            }, this.toString = function() {
                                throw new j(12, String(r.name))
                            }, this.name = t, this.rules = a, this.id = "sc-keyframes-" + t
                        }
                        return e.prototype.getName = function() {
                            return this.name
                        }, e
                    }(),
                    he = /([A-Z])/g,
                    pe = /^ms-/;
                var fe = function(e) {
                        return void 0 === e || null === e || !1 === e || "" === e
                    },
                    ge = function e(t, a) {
                        var r = Object.keys(t).filter(function(e) {
                            return !fe(t[e])
                        }).map(function(a) {
                            return z(t[a]) ? e(t[a], a) : a.replace(he, "-$1").toLowerCase().replace(pe, "-ms-") + ": " + (r = a, null == (n = t[a]) || "boolean" === typeof n || "" === n ? "" : "number" !== typeof n || 0 === n || r in u.a ? String(n).trim() : n + "px") + ";";
                            var r, n
                        }).join(" ");
                        return a ? a + " {\n  " + r + "\n}" : r
                    };

                function me(e, t, a) {
                    if (Array.isArray(e)) {
                        for (var r, n = [], o = 0, i = e.length; o < i; o += 1) null !== (r = me(e[o], t, a)) && (Array.isArray(r) ? n.push.apply(n, r) : n.push(r));
                        return n
                    }
                    return fe(e) ? null : L(e) ? "." + e.styledComponentId : M(e) ? "function" !== typeof(l = e) || l.prototype && l.prototype.isReactComponent || !t ? e : me(e(t), t, a) : e instanceof se ? a ? (e.inject(a), e.getName()) : e : z(e) ? ge(e) : e.toString();
                    var l
                }

                function ye(e) {
                    for (var t = arguments.length, a = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) a[r - 1] = arguments[r];
                    return M(e) || z(e) ? me(p(x, [e].concat(a))) : me(p(e, a))
                }

                function ve(e) {
                    for (var t, a = 0 | e.length, r = 0 | a, n = 0; a >= 4;) t = 1540483477 * (65535 & (t = 255 & e.charCodeAt(n) | (255 & e.charCodeAt(++n)) << 8 | (255 & e.charCodeAt(++n)) << 16 | (255 & e.charCodeAt(++n)) << 24)) + ((1540483477 * (t >>> 16) & 65535) << 16), r = 1540483477 * (65535 & r) + ((1540483477 * (r >>> 16) & 65535) << 16) ^ (t = 1540483477 * (65535 & (t ^= t >>> 24)) + ((1540483477 * (t >>> 16) & 65535) << 16)), a -= 4, ++n;
                    switch (a) {
                        case 3:
                            r ^= (255 & e.charCodeAt(n + 2)) << 16;
                        case 2:
                            r ^= (255 & e.charCodeAt(n + 1)) << 8;
                        case 1:
                            r = 1540483477 * (65535 & (r ^= 255 & e.charCodeAt(n))) + ((1540483477 * (r >>> 16) & 65535) << 16)
                    }
                    return ((r = 1540483477 * (65535 & (r ^= r >>> 13)) + ((1540483477 * (r >>> 16) & 65535) << 16)) ^ r >>> 15) >>> 0
                }
                var be = 52,
                    we = function(e) {
                        return String.fromCharCode(e + (e > 25 ? 39 : 97))
                    };

                function ze(e) {
                    var t = "",
                        a = void 0;
                    for (a = e; a > be; a = Math.floor(a / be)) t = we(a % be) + t;
                    return we(a % be) + t
                }

                function xe(e, t) {
                    for (var a = 0; a < e.length; a += 1) {
                        var r = e[a];
                        if (Array.isArray(r) && !xe(r, t)) return !1;
                        if (M(r) && !L(r)) return !1
                    }
                    return !t.some(function(e) {
                        return M(e) || function(e) {
                            for (var t in e)
                                if (M(e[t])) return !0;
                            return !1
                        }(e)
                    })
                }
                var ke, Me = !1,
                    Ae = function(e) {
                        return ze(ve(e))
                    },
                    Le = function() {
                        function e(t, a, r) {
                            g(this, e), this.rules = t, this.isStatic = !Me && xe(t, a), this.componentId = r, de.master.hasId(r) || de.master.deferredInject(r, [])
                        }
                        return e.prototype.generateAndInjectStyles = function(e, t) {
                            var a = this.isStatic,
                                r = this.componentId,
                                n = this.lastClassName;
                            if (O && a && "string" === typeof n && t.hasNameForId(r, n)) return n;
                            var o = me(this.rules, e, t),
                                i = Ae(this.componentId + o.join(""));
                            return t.hasNameForId(r, i) || t.inject(this.componentId, W(o, "." + i, void 0, r), i), this.lastClassName = i, i
                        }, e.generateName = function(e) {
                            return Ae(e)
                        }, e
                    }(),
                    Se = function(e, t) {
                        var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : k,
                            r = !!a && e.theme === a.theme;
                        return e.theme && !r ? e.theme : t || a.theme
                    },
                    Oe = /[[\].#*$><+~=|^:(),"'`-]+/g,
                    Ce = /(^-|-$)/g;

                function Te(e) {
                    return e.replace(Oe, "-").replace(Ce, "")
                }

                function je(e) {
                    return "string" === typeof e && !0
                }
                var Ee = {
                        childContextTypes: !0,
                        contextTypes: !0,
                        defaultProps: !0,
                        displayName: !0,
                        getDerivedStateFromProps: !0,
                        propTypes: !0,
                        type: !0
                    },
                    _e = {
                        name: !0,
                        length: !0,
                        prototype: !0,
                        caller: !0,
                        callee: !0,
                        arguments: !0,
                        arity: !0
                    },
                    Pe = ((ke = {})[d.ForwardRef] = {
                        $$typeof: !0,
                        render: !0
                    }, ke),
                    Ve = Object.defineProperty,
                    He = Object.getOwnPropertyNames,
                    Ie = Object.getOwnPropertySymbols,
                    Fe = void 0 === Ie ? function() {
                        return []
                    } : Ie,
                    Re = Object.getOwnPropertyDescriptor,
                    Ne = Object.getPrototypeOf,
                    De = Object.prototype,
                    Ue = Array.prototype;

                function Be(e, t, a) {
                    if ("string" !== typeof t) {
                        var r = Ne(t);
                        r && r !== De && Be(e, r, a);
                        for (var n = Ue.concat(He(t), Fe(t)), o = Pe[e.$$typeof] || Ee, i = Pe[t.$$typeof] || Ee, l = n.length, c = void 0, u = void 0; l--;)
                            if (u = n[l], !_e[u] && (!a || !a[u]) && (!i || !i[u]) && (!o || !o[u]) && (c = Re(t, u))) try {
                                Ve(e, u, c)
                            } catch (d) {}
                        return e
                    }
                    return e
                }
                var We = Object(l.createContext)(),
                    $e = We.Consumer,
                    qe = function(e) {
                        function t(a) {
                            g(this, t);
                            var r = w(this, e.call(this, a));
                            return r.getContext = Object(s.a)(r.getContext.bind(r)), r.renderInner = r.renderInner.bind(r), r
                        }
                        return v(t, e), t.prototype.render = function() {
                            return this.props.children ? c.a.createElement(We.Consumer, null, this.renderInner) : null
                        }, t.prototype.renderInner = function(e) {
                            var t = this.getContext(this.props.theme, e);
                            return c.a.createElement(We.Provider, {
                                value: t
                            }, c.a.Children.only(this.props.children))
                        }, t.prototype.getTheme = function(e, t) {
                            if (M(e)) return e(t);
                            if (null === e || Array.isArray(e) || "object" !== ("undefined" === typeof e ? "undefined" : f(e))) throw new j(8);
                            return y({}, t, e)
                        }, t.prototype.getContext = function(e, t) {
                            return this.getTheme(e, t)
                        }, t
                    }(l.Component),
                    Qe = function() {
                        function e() {
                            g(this, e), this.masterSheet = de.master, this.instance = this.masterSheet.clone(), this.sealed = !1
                        }
                        return e.prototype.seal = function() {
                            if (!this.sealed) {
                                var e = this.masterSheet.clones.indexOf(this.instance);
                                this.masterSheet.clones.splice(e, 1), this.sealed = !0
                            }
                        }, e.prototype.collectStyles = function(e) {
                            if (this.sealed) throw new j(2);
                            return c.a.createElement(Ke, {
                                sheet: this.instance
                            }, e)
                        }, e.prototype.getStyleTags = function() {
                            return this.seal(), this.instance.toHTML()
                        }, e.prototype.getStyleElement = function() {
                            return this.seal(), this.instance.toReactElements()
                        }, e.prototype.interleaveWithNodeStream = function(e) {
                            throw new j(3)
                        }, e
                    }(),
                    Ye = Object(l.createContext)(),
                    Ge = Ye.Consumer,
                    Ke = function(e) {
                        function t(a) {
                            g(this, t);
                            var r = w(this, e.call(this, a));
                            return r.getContext = Object(s.a)(r.getContext), r
                        }
                        return v(t, e), t.prototype.getContext = function(e, t) {
                            if (e) return e;
                            if (t) return new de(t);
                            throw new j(4)
                        }, t.prototype.render = function() {
                            var e = this.props,
                                t = e.children,
                                a = e.sheet,
                                r = e.target;
                            return c.a.createElement(Ye.Provider, {
                                value: this.getContext(a, r)
                            }, t)
                        }, t
                    }(l.Component),
                    Xe = (new Set, {});
                var Ze = function(e) {
                    function t() {
                        g(this, t);
                        var a = w(this, e.call(this));
                        return a.attrs = {}, a.renderOuter = a.renderOuter.bind(a), a.renderInner = a.renderInner.bind(a), a
                    }
                    return v(t, e), t.prototype.render = function() {
                        return c.a.createElement(Ge, null, this.renderOuter)
                    }, t.prototype.renderOuter = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : de.master;
                        return this.styleSheet = e, this.props.forwardedComponent.componentStyle.isStatic ? this.renderInner() : c.a.createElement($e, null, this.renderInner)
                    }, t.prototype.renderInner = function(e) {
                        var t = this.props.forwardedComponent,
                            a = t.componentStyle,
                            r = t.defaultProps,
                            n = (t.displayName, t.foldedComponentIds),
                            o = t.styledComponentId,
                            i = t.target,
                            c = void 0;
                        c = a.isStatic ? this.generateAndInjectStyles(k, this.props) : void 0 !== e ? this.generateAndInjectStyles(Se(this.props, e, r), this.props) : this.generateAndInjectStyles(this.props.theme || k, this.props);
                        var u = this.props.as || this.attrs.as || i,
                            d = je(u),
                            s = {},
                            p = y({}, this.attrs, this.props),
                            f = void 0;
                        for (f in p) "forwardedComponent" !== f && "as" !== f && "suppressClassNameWarning" !== f && ("forwardedRef" === f ? s.ref = p[f] : d && !Object(h.a)(f) || (s[f] = p[f]));
                        return this.props.style && this.attrs.style && (s.style = y({}, this.attrs.style, this.props.style)), s.className = Array.prototype.concat(n, this.props.className, o, this.attrs.className, c).filter(Boolean).join(" "), Object(l.createElement)(u, s)
                    }, t.prototype.buildExecutionContext = function(e, t, a) {
                        var r = this,
                            n = y({}, t, {
                                theme: e
                            });
                        return a.length ? (this.attrs = {}, a.forEach(function(e) {
                            var t, a = e,
                                o = !1,
                                i = void 0,
                                l = void 0;
                            for (l in M(a) && (a = a(n), o = !0), a) i = a[l], o || !M(i) || (t = i) && t.prototype && t.prototype.isReactComponent || L(i) || (i = i(n)), r.attrs[l] = i, n[l] = i
                        }), n) : n
                    }, t.prototype.generateAndInjectStyles = function(e, t) {
                        var a = t.forwardedComponent,
                            r = a.attrs,
                            n = a.componentStyle;
                        a.warnTooManyClasses;
                        return n.isStatic && !r.length ? n.generateAndInjectStyles(k, this.styleSheet) : n.generateAndInjectStyles(this.buildExecutionContext(e, t, r), this.styleSheet)
                    }, t
                }(l.Component);

                function Je(e, t, a) {
                    var r = L(e),
                        n = !je(e),
                        o = t.displayName,
                        i = void 0 === o ? function(e) {
                            return je(e) ? "styled." + e : "Styled(" + A(e) + ")"
                        }(e) : o,
                        l = t.componentId,
                        u = void 0 === l ? function(e, t, a) {
                            var r = "string" !== typeof t ? "sc" : Te(t),
                                n = (Xe[r] || 0) + 1;
                            Xe[r] = n;
                            var o = r + "-" + e.generateName(r + n);
                            return a ? a + "-" + o : o
                        }(Le, t.displayName, t.parentComponentId) : l,
                        d = t.ParentComponent,
                        s = void 0 === d ? Ze : d,
                        h = t.attrs,
                        p = void 0 === h ? x : h,
                        f = t.displayName && t.componentId ? Te(t.displayName) + "-" + t.componentId : t.componentId || u,
                        g = r && e.attrs ? Array.prototype.concat(e.attrs, p).filter(Boolean) : p,
                        m = new Le(r ? e.componentStyle.rules.concat(a) : a, g, f),
                        v = c.a.forwardRef(function(e, t) {
                            return c.a.createElement(s, y({}, e, {
                                forwardedComponent: v,
                                forwardedRef: t
                            }))
                        });
                    return v.attrs = g, v.componentStyle = m, v.displayName = i, v.foldedComponentIds = r ? Array.prototype.concat(e.foldedComponentIds, e.styledComponentId) : x, v.styledComponentId = f, v.target = r ? e.target : e, v.withComponent = function(e) {
                        var r = t.componentId,
                            n = b(t, ["componentId"]),
                            o = r && r + "-" + (je(e) ? e : Te(A(e)));
                        return Je(e, y({}, n, {
                            attrs: g,
                            componentId: o,
                            ParentComponent: s
                        }), a)
                    }, v.toString = function() {
                        return "." + v.styledComponentId
                    }, n && Be(v, e, {
                        attrs: !0,
                        componentStyle: !0,
                        displayName: !0,
                        foldedComponentIds: !0,
                        styledComponentId: !0,
                        target: !0,
                        withComponent: !0
                    }), v
                }
                var et = function(e) {
                    return function e(t, a) {
                        var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : k;
                        if (!Object(d.isValidElementType)(a)) throw new j(1, String(a));
                        var n = function() {
                            return t(a, r, ye.apply(void 0, arguments))
                        };
                        return n.withConfig = function(n) {
                            return e(t, a, y({}, r, n))
                        }, n.attrs = function(n) {
                            return e(t, a, y({}, r, {
                                attrs: Array.prototype.concat(r.attrs, n).filter(Boolean)
                            }))
                        }, n
                    }(Je, e)
                };
                ["a", "abbr", "address", "area", "article", "aside", "audio", "b", "base", "bdi", "bdo", "big", "blockquote", "body", "br", "button", "canvas", "caption", "cite", "code", "col", "colgroup", "data", "datalist", "dd", "del", "details", "dfn", "dialog", "div", "dl", "dt", "em", "embed", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "iframe", "img", "input", "ins", "kbd", "keygen", "label", "legend", "li", "link", "main", "map", "mark", "marquee", "menu", "menuitem", "meta", "meter", "nav", "noscript", "object", "ol", "optgroup", "option", "output", "p", "param", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "script", "section", "select", "small", "source", "span", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "title", "tr", "track", "u", "ul", "var", "video", "wbr", "circle", "clipPath", "defs", "ellipse", "foreignObject", "g", "image", "line", "linearGradient", "marker", "mask", "path", "pattern", "polygon", "polyline", "radialGradient", "rect", "stop", "svg", "text", "tspan"].forEach(function(e) {
                    et[e] = et(e)
                });
                var tt = function() {
                    function e(t, a) {
                        g(this, e), this.rules = t, this.componentId = a, this.isStatic = xe(t, x), de.master.hasId(a) || de.master.deferredInject(a, [])
                    }
                    return e.prototype.createStyles = function(e, t) {
                        var a = W(me(this.rules, e, t), "");
                        t.inject(this.componentId, a)
                    }, e.prototype.removeStyles = function(e) {
                        var t = this.componentId;
                        e.hasId(t) && e.remove(t)
                    }, e.prototype.renderStyles = function(e, t) {
                        this.removeStyles(t), this.createStyles(e, t)
                    }, e
                }();

                function at(e) {
                    for (var t = arguments.length, a = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) a[r - 1] = arguments[r];
                    var n = ye.apply(void 0, [e].concat(a)),
                        o = "sc-global-" + ve(JSON.stringify(n)),
                        i = new tt(n, o),
                        l = function(e) {
                            function t(a) {
                                g(this, t);
                                var r = w(this, e.call(this, a)),
                                    n = r.constructor,
                                    o = n.globalStyle,
                                    i = n.styledComponentId;
                                return O && (window.scCGSHMRCache[i] = (window.scCGSHMRCache[i] || 0) + 1), r.state = {
                                    globalStyle: o,
                                    styledComponentId: i
                                }, r
                            }
                            return v(t, e), t.prototype.componentWillUnmount = function() {
                                window.scCGSHMRCache[this.state.styledComponentId] && (window.scCGSHMRCache[this.state.styledComponentId] -= 1), 0 === window.scCGSHMRCache[this.state.styledComponentId] && this.state.globalStyle.removeStyles(this.styleSheet)
                            }, t.prototype.render = function() {
                                var e = this;
                                return c.a.createElement(Ge, null, function(t) {
                                    e.styleSheet = t || de.master;
                                    var a = e.state.globalStyle;
                                    return a.isStatic ? (a.renderStyles(T, e.styleSheet), null) : c.a.createElement($e, null, function(t) {
                                        var r = e.constructor.defaultProps,
                                            n = y({}, e.props);
                                        return "undefined" !== typeof t && (n.theme = Se(e.props, t, r)), a.renderStyles(n, e.styleSheet), null
                                    })
                                })
                            }, t
                        }(c.a.Component);
                    return l.globalStyle = i, l.styledComponentId = o, l
                }
                O && (window.scCGSHMRCache = {});
                var rt = function(e) {
                    return e.replace(/\s|\\n/g, "")
                };

                function nt(e) {
                    for (var t = arguments.length, a = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) a[r - 1] = arguments[r];
                    var n = ye.apply(void 0, [e].concat(a)),
                        o = ze(ve(rt(JSON.stringify(n))));
                    return new se(o, W(n, o, "@keyframes"))
                }
                var ot = function(e) {
                        var t = c.a.forwardRef(function(t, a) {
                            return c.a.createElement($e, null, function(r) {
                                var n = e.defaultProps,
                                    o = Se(t, r, n);
                                return c.a.createElement(e, y({}, t, {
                                    theme: o,
                                    ref: a
                                }))
                            })
                        });
                        return Be(t, e), t.displayName = "WithTheme(" + A(e) + ")", t
                    },
                    it = {
                        StyleSheet: de
                    };
                t.default = et
            }.call(this, a(76))
    }, function(e, t, a) {
        "use strict";

        function r() {
            return (r = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        a.d(t, "a", function() {
            return r
        })
    }, function(e, t, a) {
        "use strict";

        function r(e, t) {
            return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                raw: {
                    value: Object.freeze(t)
                }
            }))
        }
        a.d(t, "a", function() {
            return r
        })
    }, function(e, t, a) {
        "use strict";
        a.d(t, "c", function() {
            return r
        }), a.d(t, "a", function() {
            return o
        }), a.d(t, "b", function() {
            return i
        });
        var r = function e(t, a, r) {
                var n = a.global.colors[t] || t,
                    o = n;
                return n && (a.dark && n.dark ? o = n.dark : !a.dark && n.light && (o = n.light)), o && a.global.colors[o] && (o = e(o, a)), r && o === t ? "inherit" : o
            },
            n = function(e) {
                return /^#/.test(e) ? function(e) {
                    return 4 === e.length ? e.match(/[A-Za-z0-9]{1}/g).map(function(e) {
                        return parseInt(e, 16)
                    }) : e.match(/[A-Za-z0-9]{2}/g).map(function(e) {
                        return parseInt(e, 16)
                    })
                }(e) : /^rgb/.test(e) ? e.match(/rgba?\((\s?[0-9]*\s?),(\s?[0-9]*\s?),(\s?[0-9]*\s?).*?\)/).splice(1) : e
            },
            o = function(e) {
                var t = n(e);
                return (299 * t[0] + 587 * t[1] + 114 * t[2]) / 1e3 < 125
            },
            i = function(e, t) {
                if (e && function(e) {
                        return /^#/.test(e) || /^rgb/.test(e)
                    }(e)) {
                    var a = n(e);
                    return "rgba(" + a[0] + ", " + a[1] + ", " + a[2] + ", " + (t || 1) + ")"
                }
            }
    }, function(e, t, a) {
        "use strict";
        a.d(t, "a", function() {
            return n
        });
        a(19);
        var r = a(42),
            n = {
                theme: r.a
            }
    }, function(e, t, a) {
        "use strict";
        a.r(t);
        var r = a(2);

        function n(e) {
            return e.charAt(0).toUpperCase() + e.slice(1)
        }
        a.d(t, "adjustHue", function() {
            return we
        }), a.d(t, "animation", function() {
            return Xe
        }), a.d(t, "backgroundImages", function() {
            return Ze
        }), a.d(t, "backgrounds", function() {
            return Je
        }), a.d(t, "between", function() {
            return y
        }), a.d(t, "border", function() {
            return tt
        }), a.d(t, "borderColor", function() {
            return I
        }), a.d(t, "borderRadius", function() {
            return at
        }), a.d(t, "borderStyle", function() {
            return rt
        }), a.d(t, "borderWidth", function() {
            return nt
        }), a.d(t, "buttons", function() {
            return ut
        }), a.d(t, "clearFix", function() {
            return v
        }), a.d(t, "complement", function() {
            return ze
        }), a.d(t, "cover", function() {
            return b
        }), a.d(t, "darken", function() {
            return Me
        }), a.d(t, "desaturate", function() {
            return Le
        }), a.d(t, "directionalProperty", function() {
            return l
        }), a.d(t, "ellipsis", function() {
            return w
        }), a.d(t, "em", function() {
            return s
        }), a.d(t, "fluidRange", function() {
            return z
        }), a.d(t, "fontFace", function() {
            return k
        }), a.d(t, "getLuminance", function() {
            return Se
        }), a.d(t, "getValueAndUnit", function() {
            return p
        }), a.d(t, "grayscale", function() {
            return Oe
        }), a.d(t, "invert", function() {
            return Ce
        }), a.d(t, "hideText", function() {
            return M
        }), a.d(t, "hideVisually", function() {
            return A
        }), a.d(t, "hiDPI", function() {
            return L
        }), a.d(t, "hsl", function() {
            return ce
        }), a.d(t, "hsla", function() {
            return ue
        }), a.d(t, "lighten", function() {
            return je
        }), a.d(t, "margin", function() {
            return dt
        }), a.d(t, "mix", function() {
            return _e
        }), a.d(t, "modularScale", function() {
            return g
        }), a.d(t, "normalize", function() {
            return S
        }), a.d(t, "opacify", function() {
            return Ve
        }), a.d(t, "padding", function() {
            return st
        }), a.d(t, "parseToHsl", function() {
            return ae
        }), a.d(t, "parseToRgb", function() {
            return te
        }), a.d(t, "placeholder", function() {
            return O
        }), a.d(t, "position", function() {
            return pt
        }), a.d(t, "radialGradient", function() {
            return E
        }), a.d(t, "readableColor", function() {
            return He
        }), a.d(t, "rem", function() {
            return m
        }), a.d(t, "retinaImage", function() {
            return _
        }), a.d(t, "rgb", function() {
            return de
        }), a.d(t, "rgba", function() {
            return se
        }), a.d(t, "saturate", function() {
            return Fe
        }), a.d(t, "selection", function() {
            return P
        }), a.d(t, "setHue", function() {
            return Ne
        }), a.d(t, "setLightness", function() {
            return Ue
        }), a.d(t, "setSaturation", function() {
            return We
        }), a.d(t, "shade", function() {
            return qe
        }), a.d(t, "size", function() {
            return ft
        }), a.d(t, "stripUnit", function() {
            return u
        }), a.d(t, "textInputs", function() {
            return yt
        }), a.d(t, "timingFunctions", function() {
            return H
        }), a.d(t, "tint", function() {
            return Ye
        }), a.d(t, "toColorString", function() {
            return ye
        }), a.d(t, "transitions", function() {
            return vt
        }), a.d(t, "transparentize", function() {
            return Ke
        }), a.d(t, "triangle", function() {
            return D
        }), a.d(t, "wordWrap", function() {
            return U
        });
        var o = ["Top", "Right", "Bottom", "Left"];

        function i(e, t) {
            if (!e) return t.toLowerCase();
            var a = e.split("-");
            if (a.length > 1) return a.splice(1, 0, t), a.reduce(function(e, t) {
                return "" + e + n(t)
            });
            var r = e.replace(/([a-z])([A-Z])/g, "$1" + t + "$2");
            return e === r ? "" + e + t : r
        }

        function l(e) {
            for (var t = arguments.length, a = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) a[r - 1] = arguments[r];
            var n = a[0],
                l = a[1],
                c = void 0 === l ? n : l,
                u = a[2],
                d = void 0 === u ? n : u,
                s = a[3];
            return function(e, t) {
                for (var a = {}, r = 0; r < t.length; r += 1)(t[r] || 0 === t[r]) && (a[i(e, o[r])] = t[r]);
                return a
            }(e, [n, c, d, void 0 === s ? c : s])
        }

        function c(e, t) {
            return e.substr(-t.length) === t
        }

        function u(e) {
            var t = parseFloat(e);
            return isNaN(t) ? e : t
        }
        var d = function(e) {
                return function(t, a) {
                    void 0 === a && (a = "16px");
                    var r = t,
                        n = a;
                    if ("string" === typeof t) {
                        if (!c(t, "px")) throw new Error('Expected a string ending in "px" or a number passed as the first argument to ' + e + '(), got "' + t + '" instead.');
                        r = u(t)
                    }
                    if ("string" === typeof a) {
                        if (!c(a, "px")) throw new Error('Expected a string ending in "px" or a number passed as the second argument to ' + e + '(), got "' + a + '" instead.');
                        n = u(a)
                    }
                    if ("string" === typeof r) throw new Error('Passed invalid pixel value ("' + t + '") to ' + e + '(), please pass a value like "12px" or 12.');
                    if ("string" === typeof n) throw new Error('Passed invalid base value ("' + a + '") to ' + e + '(), please pass a value like "12px" or 12.');
                    return "" + r / n + e
                }
            },
            s = d("em"),
            h = /^([+-]?(?:\d+|\d*\.\d+))([a-z]*|%)$/;

        function p(e) {
            if ("string" !== typeof e) return [e, ""];
            var t = e.match(h);
            return t ? [parseFloat(e), t[2]] : [e, void 0]
        }
        var f = {
            minorSecond: 1.067,
            majorSecond: 1.125,
            minorThird: 1.2,
            majorThird: 1.25,
            perfectFourth: 1.333,
            augFourth: 1.414,
            perfectFifth: 1.5,
            minorSixth: 1.6,
            goldenSection: 1.618,
            majorSixth: 1.667,
            minorSeventh: 1.778,
            majorSeventh: 1.875,
            octave: 2,
            majorTenth: 2.5,
            majorEleventh: 2.667,
            majorTwelfth: 3,
            doubleOctave: 4
        };

        function g(e, t, a) {
            if (void 0 === t && (t = "1em"), void 0 === a && (a = "perfectFourth"), "number" !== typeof e) throw new Error("Please provide a number of steps to the modularScale helper.");
            if ("string" === typeof a && !f[a]) throw new Error("Please pass a number or one of the predefined scales to the modularScale helper as the ratio.");
            var r = "string" === typeof t ? u(t) : t,
                n = "string" === typeof a ? f[a] : a;
            if ("string" === typeof r) throw new Error('Invalid value passed as base to modularScale, expected number or em string but got "' + t + '"');
            return r * Math.pow(n, e) + "em"
        }
        var m = d("rem");

        function y(e, t, a, r) {
            void 0 === a && (a = "320px"), void 0 === r && (r = "1200px");
            var n = p(e),
                o = n[0],
                i = n[1],
                l = p(t),
                c = l[0],
                u = l[1],
                d = p(a),
                s = d[0],
                h = d[1],
                f = p(r),
                g = f[0],
                m = f[1];
            if ("number" !== typeof s || "number" !== typeof g || !h || !m || h !== m) throw new Error("minScreen and maxScreen must be provided as stringified numbers with the same units.");
            if ("number" !== typeof o || "number" !== typeof c || !i || !u || i !== u) throw new Error("fromSize and toSize must be provided as stringified numbers with the same units.");
            var y = (o - c) / (s - g);
            return "calc(" + (c - y * g).toFixed(2) + i + " + " + (100 * y).toFixed(2) + "vw)"
        }

        function v(e) {
            var t;
            return void 0 === e && (e = "&"), (t = {})[e + "::after"] = {
                clear: "both",
                content: '""',
                display: "table"
            }, t
        }

        function b(e) {
            return void 0 === e && (e = 0), {
                position: "absolute",
                top: e,
                right: e,
                bottom: e,
                left: e
            }
        }

        function w(e) {
            return void 0 === e && (e = "100%"), {
                display: "inline-block",
                maxWidth: e,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                wordWrap: "normal"
            }
        }

        function z(e, t, a) {
            if (void 0 === t && (t = "320px"), void 0 === a && (a = "1200px"), !Array.isArray(e) && "object" !== typeof e || null === e) throw new Error("expects either an array of objects or a single object with the properties prop, fromSize, and toSize.");
            if (Array.isArray(e)) {
                var n = {},
                    o = {},
                    i = e,
                    l = Array.isArray(i),
                    c = 0;
                for (i = l ? i : i[Symbol.iterator]();;) {
                    var u, d, s;
                    if (l) {
                        if (c >= i.length) break;
                        s = i[c++]
                    } else {
                        if ((c = i.next()).done) break;
                        s = c.value
                    }
                    var h = s;
                    if (!h.prop || !h.fromSize || !h.toSize) throw new Error("expects the objects in the first argument array to have the properties `prop`, `fromSize`, and `toSize`.");
                    o[h.prop] = h.fromSize, n["@media (min-width: " + t + ")"] = Object(r.a)({}, n["@media (min-width: " + t + ")"], ((u = {})[h.prop] = y(h.fromSize, h.toSize, t, a), u)), n["@media (min-width: " + a + ")"] = Object(r.a)({}, n["@media (min-width: " + a + ")"], ((d = {})[h.prop] = h.toSize, d))
                }
                return Object(r.a)({}, o, n)
            }
            var p, f, g;
            if (!e.prop || !e.fromSize || !e.toSize) throw new Error("expects the first argument object to have the properties `prop`, `fromSize`, and `toSize`.");
            return (g = {})[e.prop] = e.fromSize, g["@media (min-width: " + t + ")"] = ((p = {})[e.prop] = y(e.fromSize, e.toSize, t, a), p), g["@media (min-width: " + a + ")"] = ((f = {})[e.prop] = e.toSize, f), g
        }

        function x(e, t, a) {
            var r = [];
            return t && r.push(function(e) {
                return e.map(function(e) {
                    return 'local("' + e + '")'
                }).join(", ")
            }(t)), e && r.push(function(e, t) {
                return t.map(function(t) {
                    return 'url("' + e + "." + t + '")'
                }).join(", ")
            }(e, a)), r.join(", ")
        }

        function k(e) {
            var t = e.fontFamily,
                a = e.fontFilePath,
                r = e.fontStretch,
                n = e.fontStyle,
                o = e.fontVariant,
                i = e.fontWeight,
                l = e.fileFormats,
                c = void 0 === l ? ["eot", "woff2", "woff", "ttf", "svg"] : l,
                u = e.localFonts,
                d = e.unicodeRange,
                s = e.fontDisplay,
                h = e.fontVariationSettings,
                p = e.fontFeatureSettings;
            if (!t) throw new Error("fontFace expects a name of a font-family.");
            if (!a && !u) throw new Error("fontFace expects either the path to the font file(s) or a name of a local copy.");
            if (u && !Array.isArray(u)) throw new Error("fontFace expects localFonts to be an array.");
            if (!Array.isArray(c)) throw new Error("fontFace expects fileFormats to be an array.");
            var f = {
                "@font-face": {
                    fontFamily: t,
                    src: x(a, u, c),
                    unicodeRange: d,
                    fontStretch: r,
                    fontStyle: n,
                    fontVariant: o,
                    fontWeight: i,
                    fontDisplay: s,
                    fontVariationSettings: h,
                    fontFeatureSettings: p
                }
            };
            return JSON.parse(JSON.stringify(f))
        }

        function M() {
            return {
                textIndent: "101%",
                overflow: "hidden",
                whiteSpace: "nowrap"
            }
        }

        function A() {
            return {
                border: "0",
                clip: "rect(0 0 0 0)",
                clipPath: "inset(50%)",
                height: "1px",
                margin: "-1px",
                overflow: "hidden",
                padding: "0",
                position: "absolute",
                whiteSpace: "nowrap",
                width: "1px"
            }
        }

        function L(e) {
            return void 0 === e && (e = 1.3), "\n    @media only screen and (-webkit-min-device-pixel-ratio: " + e + "),\n    only screen and (min--moz-device-pixel-ratio: " + e + "),\n    only screen and (-o-min-device-pixel-ratio: " + e + "/1),\n    only screen and (min-resolution: " + Math.round(96 * e) + "dpi),\n    only screen and (min-resolution: " + e + "dppx)\n  "
        }

        function S() {
            var e;
            return [(e = {
                html: {
                    lineHeight: "1.15",
                    textSizeAdjust: "100%"
                },
                body: {
                    margin: "0"
                },
                h1: {
                    fontSize: "2em",
                    margin: "0.67em 0"
                },
                hr: {
                    boxSizing: "content-box",
                    height: "0",
                    overflow: "visible"
                },
                pre: {
                    fontFamily: "monospace, monospace",
                    fontSize: "1em"
                },
                a: {
                    backgroundColor: "transparent"
                },
                "abbr[title]": {
                    borderBottom: "none",
                    textDecoration: "underline"
                }
            }, e["b,\n    strong"] = {
                fontWeight: "bolder"
            }, e["code,\n    kbd,\n    samp"] = {
                fontFamily: "monospace, monospace",
                fontSize: "1em"
            }, e.small = {
                fontSize: "80%"
            }, e["sub,\n    sup"] = {
                fontSize: "75%",
                lineHeight: "0",
                position: "relative",
                verticalAlign: "baseline"
            }, e.sub = {
                bottom: "-0.25em"
            }, e.sup = {
                top: "-0.5em"
            }, e.img = {
                borderStyle: "none"
            }, e["button,\n    input,\n    optgroup,\n    select,\n    textarea"] = {
                fontFamily: "inherit",
                fontSize: "100%",
                lineHeight: "1.15",
                margin: "0"
            }, e["button,\n    input"] = {
                overflow: "visible"
            }, e["button,\n    select"] = {
                textTransform: "none"
            }, e['button,\n    html [type="button"],\n    [type="reset"],\n    [type="submit"]'] = {
                WebkitAppearance: "button"
            }, e['button::-moz-focus-inner,\n    [type="button"]::-moz-focus-inner,\n    [type="reset"]::-moz-focus-inner,\n    [type="submit"]::-moz-focus-inner'] = {
                borderStyle: "none",
                padding: "0"
            }, e['button:-moz-focusring,\n    [type="button"]:-moz-focusring,\n    [type="reset"]:-moz-focusring,\n    [type="submit"]:-moz-focusring'] = {
                outline: "1px dotted ButtonText"
            }, e.fieldset = {
                padding: "0.35em 0.625em 0.75em"
            }, e.legend = {
                boxSizing: "border-box",
                color: "inherit",
                display: "table",
                maxWidth: "100%",
                padding: "0",
                whiteSpace: "normal"
            }, e.progress = {
                verticalAlign: "baseline"
            }, e.textarea = {
                overflow: "auto"
            }, e['[type="checkbox"],\n    [type="radio"]'] = {
                boxSizing: "border-box",
                padding: "0"
            }, e['[type="number"]::-webkit-inner-spin-button,\n    [type="number"]::-webkit-outer-spin-button'] = {
                height: "auto"
            }, e['[type="search"]'] = {
                WebkitAppearance: "textfield",
                outlineOffset: "-2px"
            }, e['[type="search"]::-webkit-search-decoration'] = {
                WebkitAppearance: "none"
            }, e["::-webkit-file-upload-button"] = {
                WebkitAppearance: "button",
                font: "inherit"
            }, e.details = {
                display: "block"
            }, e.summary = {
                display: "list-item"
            }, e.template = {
                display: "none"
            }, e["[hidden]"] = {
                display: "none"
            }, e), {
                "abbr[title]": {
                    textDecoration: "underline dotted"
                }
            }]
        }

        function O(e, t) {
            var a;
            return void 0 === t && (t = "&"), (a = {})[t + "::-webkit-input-placeholder"] = Object(r.a)({}, e), a[t + ":-moz-placeholder"] = Object(r.a)({}, e), a[t + "::-moz-placeholder"] = Object(r.a)({}, e), a[t + ":-ms-input-placeholder"] = Object(r.a)({}, e), a
        }

        function C() {
            var e, t, a = (e = ["radial-gradient(", "", "", "", ")"], t || (t = e.slice(0)), e.raw = t, e);
            return C = function() {
                return a
            }, a
        }

        function T(e) {
            return e[0].split(" ")[0]
        }

        function j(e) {
            for (var t = "", a = 0; a < e.length; a += 1) t += e[a], 3 === a && (a + 1 < 1 || arguments.length <= a + 1 ? void 0 : arguments[a + 1]) && ((arguments.length <= 1 ? void 0 : arguments[1]) || (arguments.length <= 2 ? void 0 : arguments[2]) || (arguments.length <= 3 ? void 0 : arguments[3])) ? (t = t.slice(0, -1), t += ", " + (a + 1 < 1 || arguments.length <= a + 1 ? void 0 : arguments[a + 1])) : 3 !== a || a + 1 < 1 || arguments.length <= a + 1 || !arguments[a + 1] || (arguments.length <= 1 ? void 0 : arguments[1]) || (arguments.length <= 2 ? void 0 : arguments[2]) || (arguments.length <= 3 ? void 0 : arguments[3]) ? (a + 1 < 1 || arguments.length <= a + 1 ? void 0 : arguments[a + 1]) && (t += (a + 1 < 1 || arguments.length <= a + 1 ? void 0 : arguments[a + 1]) + " ") : t += "" + (a + 1 < 1 || arguments.length <= a + 1 ? void 0 : arguments[a + 1]);
            return t.trim()
        }

        function E(e) {
            var t = e.colorStops,
                a = e.extent,
                r = e.fallback,
                n = e.position,
                o = e.shape;
            if (!t || t.length < 2) throw new Error("radialGradient requries at least 2 color-stops to properly render.");
            return {
                backgroundColor: r || T(t),
                backgroundImage: j(C(), n, o, a, t.join(", "))
            }
        }

        function _(e, t, a, n, o) {
            var i;
            if (void 0 === a && (a = "png"), void 0 === o && (o = "_2x"), !e) throw new Error("Please supply a filename to retinaImage() as the first argument.");
            var l = a.replace(/^\./, ""),
                c = n ? n + "." + l : "" + e + o + "." + l;
            return (i = {
                backgroundImage: "url(" + e + "." + l + ")"
            })[L()] = Object(r.a)({
                backgroundImage: "url(" + c + ")"
            }, t ? {
                backgroundSize: t
            } : {}), i
        }

        function P(e, t) {
            var a;
            return void 0 === t && (t = ""), (a = {})[t + "::-moz-selection"] = Object(r.a)({}, e), a[t + "::selection"] = Object(r.a)({}, e), a
        }
        var V = {
            easeInBack: "cubic-bezier(0.600, -0.280, 0.735, 0.045)",
            easeInCirc: "cubic-bezier(0.600,  0.040, 0.980, 0.335)",
            easeInCubic: "cubic-bezier(0.550,  0.055, 0.675, 0.190)",
            easeInExpo: "cubic-bezier(0.950,  0.050, 0.795, 0.035)",
            easeInQuad: "cubic-bezier(0.550,  0.085, 0.680, 0.530)",
            easeInQuart: "cubic-bezier(0.895,  0.030, 0.685, 0.220)",
            easeInQuint: "cubic-bezier(0.755,  0.050, 0.855, 0.060)",
            easeInSine: "cubic-bezier(0.470,  0.000, 0.745, 0.715)",
            easeOutBack: "cubic-bezier(0.175,  0.885, 0.320, 1.275)",
            easeOutCubic: "cubic-bezier(0.215,  0.610, 0.355, 1.000)",
            easeOutCirc: "cubic-bezier(0.075,  0.820, 0.165, 1.000)",
            easeOutExpo: "cubic-bezier(0.190,  1.000, 0.220, 1.000)",
            easeOutQuad: "cubic-bezier(0.250,  0.460, 0.450, 0.940)",
            easeOutQuart: "cubic-bezier(0.165,  0.840, 0.440, 1.000)",
            easeOutQuint: "cubic-bezier(0.230,  1.000, 0.320, 1.000)",
            easeOutSine: "cubic-bezier(0.390,  0.575, 0.565, 1.000)",
            easeInOutBack: "cubic-bezier(0.680, -0.550, 0.265, 1.550)",
            easeInOutCirc: "cubic-bezier(0.785,  0.135, 0.150, 0.860)",
            easeInOutCubic: "cubic-bezier(0.645,  0.045, 0.355, 1.000)",
            easeInOutExpo: "cubic-bezier(1.000,  0.000, 0.000, 1.000)",
            easeInOutQuad: "cubic-bezier(0.455,  0.030, 0.515, 0.955)",
            easeInOutQuart: "cubic-bezier(0.770,  0.000, 0.175, 1.000)",
            easeInOutQuint: "cubic-bezier(0.860,  0.000, 0.070, 1.000)",
            easeInOutSine: "cubic-bezier(0.445,  0.050, 0.550, 0.950)"
        };

        function H(e) {
            return V[e]
        }

        function I() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            return l.apply(void 0, ["borderColor"].concat(t))
        }
        var F = function(e, t, a) {
                switch (e) {
                    case "top":
                        return "0 " + a[0] / 2 + a[1] + " " + t[0] + t[1] + " " + a[0] / 2 + a[1];
                    case "left":
                        return "" + t[0] / 2 + t[1] + " " + a[0] + a[1] + " " + t[0] / 2 + t[1] + " 0";
                    case "bottom":
                        return "" + t[0] + t[1] + " " + a[0] / 2 + a[1] + " 0 " + a[0] / 2 + a[1];
                    case "right":
                        return "" + t[0] / 2 + t[1] + " 0 " + t[0] / 2 + t[1] + " " + a[0] + a[1];
                    default:
                        throw new Error("Passed invalid argument to triangle, please pass correct pointingDirection e.g. 'right'.")
                }
            },
            R = ["bottom", "left", "top", "right"],
            N = /(\d*\.?\d*)/;

        function D(e) {
            var t = e.pointingDirection,
                a = e.height,
                n = e.width,
                o = e.foregroundColor,
                i = e.backgroundColor,
                l = void 0 === i ? "transparent" : i,
                c = [parseFloat(n), String(n).replace(N, "") || "px"],
                u = [parseFloat(a), String(a).replace(N, "") || "px"];
            if (isNaN(u[0]) || isNaN(c[0])) throw new Error("Passed an invalid value to `height` or `width`. Please provide a pixel based unit");
            var d = R.indexOf(t);
            return Object(r.a)({
                width: "0",
                height: "0",
                borderWidth: F(t, u, c),
                borderStyle: "solid"
            }, I.apply(void 0, Array.from({
                length: 4
            }).map(function(e, t) {
                return t === d ? o : l
            })))
        }

        function U(e) {
            return void 0 === e && (e = "break-word"), {
                overflowWrap: e,
                wordWrap: e,
                wordBreak: "break-word" === e ? "break-all" : e
            }
        }

        function B(e) {
            return Math.round(255 * e)
        }

        function W(e, t, a) {
            return B(e) + "," + B(t) + "," + B(a)
        }

        function $(e, t, a, r) {
            if (void 0 === r && (r = W), 0 === t) return r(a, a, a);
            var n = e % 360 / 60,
                o = (1 - Math.abs(2 * a - 1)) * t,
                i = o * (1 - Math.abs(n % 2 - 1)),
                l = 0,
                c = 0,
                u = 0;
            n >= 0 && n < 1 ? (l = o, c = i) : n >= 1 && n < 2 ? (l = i, c = o) : n >= 2 && n < 3 ? (c = o, u = i) : n >= 3 && n < 4 ? (c = i, u = o) : n >= 4 && n < 5 ? (l = i, u = o) : n >= 5 && n < 6 && (l = o, u = i);
            var d = a - o / 2;
            return r(l + d, c + d, u + d)
        }
        var q = {
            aliceblue: "f0f8ff",
            antiquewhite: "faebd7",
            aqua: "00ffff",
            aquamarine: "7fffd4",
            azure: "f0ffff",
            beige: "f5f5dc",
            bisque: "ffe4c4",
            black: "000",
            blanchedalmond: "ffebcd",
            blue: "0000ff",
            blueviolet: "8a2be2",
            brown: "a52a2a",
            burlywood: "deb887",
            cadetblue: "5f9ea0",
            chartreuse: "7fff00",
            chocolate: "d2691e",
            coral: "ff7f50",
            cornflowerblue: "6495ed",
            cornsilk: "fff8dc",
            crimson: "dc143c",
            cyan: "00ffff",
            darkblue: "00008b",
            darkcyan: "008b8b",
            darkgoldenrod: "b8860b",
            darkgray: "a9a9a9",
            darkgreen: "006400",
            darkgrey: "a9a9a9",
            darkkhaki: "bdb76b",
            darkmagenta: "8b008b",
            darkolivegreen: "556b2f",
            darkorange: "ff8c00",
            darkorchid: "9932cc",
            darkred: "8b0000",
            darksalmon: "e9967a",
            darkseagreen: "8fbc8f",
            darkslateblue: "483d8b",
            darkslategray: "2f4f4f",
            darkslategrey: "2f4f4f",
            darkturquoise: "00ced1",
            darkviolet: "9400d3",
            deeppink: "ff1493",
            deepskyblue: "00bfff",
            dimgray: "696969",
            dimgrey: "696969",
            dodgerblue: "1e90ff",
            firebrick: "b22222",
            floralwhite: "fffaf0",
            forestgreen: "228b22",
            fuchsia: "ff00ff",
            gainsboro: "dcdcdc",
            ghostwhite: "f8f8ff",
            gold: "ffd700",
            goldenrod: "daa520",
            gray: "808080",
            green: "008000",
            greenyellow: "adff2f",
            grey: "808080",
            honeydew: "f0fff0",
            hotpink: "ff69b4",
            indianred: "cd5c5c",
            indigo: "4b0082",
            ivory: "fffff0",
            khaki: "f0e68c",
            lavender: "e6e6fa",
            lavenderblush: "fff0f5",
            lawngreen: "7cfc00",
            lemonchiffon: "fffacd",
            lightblue: "add8e6",
            lightcoral: "f08080",
            lightcyan: "e0ffff",
            lightgoldenrodyellow: "fafad2",
            lightgray: "d3d3d3",
            lightgreen: "90ee90",
            lightgrey: "d3d3d3",
            lightpink: "ffb6c1",
            lightsalmon: "ffa07a",
            lightseagreen: "20b2aa",
            lightskyblue: "87cefa",
            lightslategray: "789",
            lightslategrey: "789",
            lightsteelblue: "b0c4de",
            lightyellow: "ffffe0",
            lime: "0f0",
            limegreen: "32cd32",
            linen: "faf0e6",
            magenta: "f0f",
            maroon: "800000",
            mediumaquamarine: "66cdaa",
            mediumblue: "0000cd",
            mediumorchid: "ba55d3",
            mediumpurple: "9370db",
            mediumseagreen: "3cb371",
            mediumslateblue: "7b68ee",
            mediumspringgreen: "00fa9a",
            mediumturquoise: "48d1cc",
            mediumvioletred: "c71585",
            midnightblue: "191970",
            mintcream: "f5fffa",
            mistyrose: "ffe4e1",
            moccasin: "ffe4b5",
            navajowhite: "ffdead",
            navy: "000080",
            oldlace: "fdf5e6",
            olive: "808000",
            olivedrab: "6b8e23",
            orange: "ffa500",
            orangered: "ff4500",
            orchid: "da70d6",
            palegoldenrod: "eee8aa",
            palegreen: "98fb98",
            paleturquoise: "afeeee",
            palevioletred: "db7093",
            papayawhip: "ffefd5",
            peachpuff: "ffdab9",
            peru: "cd853f",
            pink: "ffc0cb",
            plum: "dda0dd",
            powderblue: "b0e0e6",
            purple: "800080",
            rebeccapurple: "639",
            red: "f00",
            rosybrown: "bc8f8f",
            royalblue: "4169e1",
            saddlebrown: "8b4513",
            salmon: "fa8072",
            sandybrown: "f4a460",
            seagreen: "2e8b57",
            seashell: "fff5ee",
            sienna: "a0522d",
            silver: "c0c0c0",
            skyblue: "87ceeb",
            slateblue: "6a5acd",
            slategray: "708090",
            slategrey: "708090",
            snow: "fffafa",
            springgreen: "00ff7f",
            steelblue: "4682b4",
            tan: "d2b48c",
            teal: "008080",
            thistle: "d8bfd8",
            tomato: "ff6347",
            turquoise: "40e0d0",
            violet: "ee82ee",
            wheat: "f5deb3",
            white: "fff",
            whitesmoke: "f5f5f5",
            yellow: "ff0",
            yellowgreen: "9acd32"
        };
        var Q = /^#[a-fA-F0-9]{6}$/,
            Y = /^#[a-fA-F0-9]{8}$/,
            G = /^#[a-fA-F0-9]{3}$/,
            K = /^#[a-fA-F0-9]{4}$/,
            X = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/,
            Z = /^rgba\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*([-+]?[0-9]*[.]?[0-9]+)\s*\)$/,
            J = /^hsl\(\s*(\d{0,3}[.]?[0-9]+)\s*,\s*(\d{1,3})%\s*,\s*(\d{1,3})%\s*\)$/,
            ee = /^hsla\(\s*(\d{0,3}[.]?[0-9]+)\s*,\s*(\d{1,3})%\s*,\s*(\d{1,3})%\s*,\s*([-+]?[0-9]*[.]?[0-9]+)\s*\)$/;

        function te(e) {
            if ("string" !== typeof e) throw new Error("Passed an incorrect argument to a color function, please pass a string representation of a color.");
            var t = function(e) {
                if ("string" !== typeof e) return e;
                var t = e.toLowerCase();
                return q[t] ? "#" + q[t] : e
            }(e);
            if (t.match(Q)) return {
                red: parseInt("" + t[1] + t[2], 16),
                green: parseInt("" + t[3] + t[4], 16),
                blue: parseInt("" + t[5] + t[6], 16)
            };
            if (t.match(Y)) {
                var a = parseFloat((parseInt("" + t[7] + t[8], 16) / 255).toFixed(2));
                return {
                    red: parseInt("" + t[1] + t[2], 16),
                    green: parseInt("" + t[3] + t[4], 16),
                    blue: parseInt("" + t[5] + t[6], 16),
                    alpha: a
                }
            }
            if (t.match(G)) return {
                red: parseInt("" + t[1] + t[1], 16),
                green: parseInt("" + t[2] + t[2], 16),
                blue: parseInt("" + t[3] + t[3], 16)
            };
            if (t.match(K)) {
                var r = parseFloat((parseInt("" + t[4] + t[4], 16) / 255).toFixed(2));
                return {
                    red: parseInt("" + t[1] + t[1], 16),
                    green: parseInt("" + t[2] + t[2], 16),
                    blue: parseInt("" + t[3] + t[3], 16),
                    alpha: r
                }
            }
            var n = X.exec(t);
            if (n) return {
                red: parseInt("" + n[1], 10),
                green: parseInt("" + n[2], 10),
                blue: parseInt("" + n[3], 10)
            };
            var o = Z.exec(t);
            if (o) return {
                red: parseInt("" + o[1], 10),
                green: parseInt("" + o[2], 10),
                blue: parseInt("" + o[3], 10),
                alpha: parseFloat("" + o[4])
            };
            var i = J.exec(t);
            if (i) {
                var l = "rgb(" + $(parseInt("" + i[1], 10), parseInt("" + i[2], 10) / 100, parseInt("" + i[3], 10) / 100) + ")",
                    c = X.exec(l);
                if (!c) throw new Error("Couldn't generate valid rgb string from " + t + ", it returned " + l + ".");
                return {
                    red: parseInt("" + c[1], 10),
                    green: parseInt("" + c[2], 10),
                    blue: parseInt("" + c[3], 10)
                }
            }
            var u = ee.exec(t);
            if (u) {
                var d = "rgb(" + $(parseInt("" + u[1], 10), parseInt("" + u[2], 10) / 100, parseInt("" + u[3], 10) / 100) + ")",
                    s = X.exec(d);
                if (!s) throw new Error("Couldn't generate valid rgb string from " + t + ", it returned " + d + ".");
                return {
                    red: parseInt("" + s[1], 10),
                    green: parseInt("" + s[2], 10),
                    blue: parseInt("" + s[3], 10),
                    alpha: parseFloat("" + u[4])
                }
            }
            throw new Error("Couldn't parse the color string. Please provide the color as a string in hex, rgb, rgba, hsl or hsla notation.")
        }

        function ae(e) {
            return function(e) {
                var t, a = e.red / 255,
                    r = e.green / 255,
                    n = e.blue / 255,
                    o = Math.max(a, r, n),
                    i = Math.min(a, r, n),
                    l = (o + i) / 2;
                if (o === i) return void 0 !== e.alpha ? {
                    hue: 0,
                    saturation: 0,
                    lightness: l,
                    alpha: e.alpha
                } : {
                    hue: 0,
                    saturation: 0,
                    lightness: l
                };
                var c = o - i,
                    u = l > .5 ? c / (2 - o - i) : c / (o + i);
                switch (o) {
                    case a:
                        t = (r - n) / c + (r < n ? 6 : 0);
                        break;
                    case r:
                        t = (n - a) / c + 2;
                        break;
                    default:
                        t = (a - r) / c + 4
                }
                return t *= 60, void 0 !== e.alpha ? {
                    hue: t,
                    saturation: u,
                    lightness: l,
                    alpha: e.alpha
                } : {
                    hue: t,
                    saturation: u,
                    lightness: l
                }
            }(te(e))
        }
        var re = function(e) {
            return 7 === e.length && e[1] === e[2] && e[3] === e[4] && e[5] === e[6] ? "#" + e[1] + e[3] + e[5] : e
        };

        function ne(e) {
            var t = e.toString(16);
            return 1 === t.length ? "0" + t : t
        }

        function oe(e) {
            return ne(Math.round(255 * e))
        }

        function ie(e, t, a) {
            return re("#" + oe(e) + oe(t) + oe(a))
        }

        function le(e, t, a) {
            return $(e, t, a, ie)
        }

        function ce(e, t, a) {
            if ("number" === typeof e && "number" === typeof t && "number" === typeof a) return le(e, t, a);
            if ("object" === typeof e && void 0 === t && void 0 === a) return le(e.hue, e.saturation, e.lightness);
            throw new Error("Passed invalid arguments to hsl, please pass multiple numbers e.g. hsl(360, 0.75, 0.4) or an object e.g. rgb({ hue: 255, saturation: 0.4, lightness: 0.75 }).")
        }

        function ue(e, t, a, r) {
            if ("number" === typeof e && "number" === typeof t && "number" === typeof a && "number" === typeof r) return r >= 1 ? le(e, t, a) : "rgba(" + $(e, t, a) + "," + r + ")";
            if ("object" === typeof e && void 0 === t && void 0 === a && void 0 === r) return e.alpha >= 1 ? le(e.hue, e.saturation, e.lightness) : "rgba(" + $(e.hue, e.saturation, e.lightness) + "," + e.alpha + ")";
            throw new Error("Passed invalid arguments to hsla, please pass multiple numbers e.g. hsl(360, 0.75, 0.4, 0.7) or an object e.g. rgb({ hue: 255, saturation: 0.4, lightness: 0.75, alpha: 0.7 }).")
        }

        function de(e, t, a) {
            if ("number" === typeof e && "number" === typeof t && "number" === typeof a) return re("#" + ne(e) + ne(t) + ne(a));
            if ("object" === typeof e && void 0 === t && void 0 === a) return re("#" + ne(e.red) + ne(e.green) + ne(e.blue));
            throw new Error("Passed invalid arguments to rgb, please pass multiple numbers e.g. rgb(255, 205, 100) or an object e.g. rgb({ red: 255, green: 205, blue: 100 }).")
        }

        function se(e, t, a, r) {
            if ("string" === typeof e && "number" === typeof t) {
                var n = te(e);
                return "rgba(" + n.red + "," + n.green + "," + n.blue + "," + t + ")"
            }
            if ("number" === typeof e && "number" === typeof t && "number" === typeof a && "number" === typeof r) return r >= 1 ? de(e, t, a) : "rgba(" + e + "," + t + "," + a + "," + r + ")";
            if ("object" === typeof e && void 0 === t && void 0 === a && void 0 === r) return e.alpha >= 1 ? de(e.red, e.green, e.blue) : "rgba(" + e.red + "," + e.green + "," + e.blue + "," + e.alpha + ")";
            throw new Error("Passed invalid arguments to rgba, please pass multiple numbers e.g. rgb(255, 205, 100, 0.75) or an object e.g. rgb({ red: 255, green: 205, blue: 100, alpha: 0.75 }).")
        }
        var he = function(e) {
                return "number" === typeof e.red && "number" === typeof e.green && "number" === typeof e.blue && ("number" !== typeof e.alpha || "undefined" === typeof e.alpha)
            },
            pe = function(e) {
                return "number" === typeof e.red && "number" === typeof e.green && "number" === typeof e.blue && "number" === typeof e.alpha
            },
            fe = function(e) {
                return "number" === typeof e.hue && "number" === typeof e.saturation && "number" === typeof e.lightness && ("number" !== typeof e.alpha || "undefined" === typeof e.alpha)
            },
            ge = function(e) {
                return "number" === typeof e.hue && "number" === typeof e.saturation && "number" === typeof e.lightness && "number" === typeof e.alpha
            },
            me = "Passed invalid argument to toColorString, please pass a RgbColor, RgbaColor, HslColor or HslaColor object.";

        function ye(e) {
            if ("object" !== typeof e) throw new Error(me);
            if (pe(e)) return se(e);
            if (he(e)) return de(e);
            if (ge(e)) return ue(e);
            if (fe(e)) return ce(e);
            throw new Error(me)
        }

        function ve(e) {
            return function e(t, a, r) {
                return function() {
                    var n = r.concat(Array.prototype.slice.call(arguments));
                    return n.length >= a ? t.apply(this, n) : e(t, a, n)
                }
            }(e, e.length, [])
        }

        function be(e, t) {
            var a = ae(t);
            return ye(Object(r.a)({}, a, {
                hue: (a.hue + parseFloat(e)) % 360
            }))
        }
        var we = ve(be);

        function ze(e) {
            var t = ae(e);
            return ye(Object(r.a)({}, t, {
                hue: (t.hue + 180) % 360
            }))
        }

        function xe(e, t, a) {
            return Math.max(e, Math.min(t, a))
        }

        function ke(e, t) {
            var a = ae(t);
            return ye(Object(r.a)({}, a, {
                lightness: xe(0, 1, a.lightness - parseFloat(e))
            }))
        }
        var Me = ve(ke);

        function Ae(e, t) {
            var a = ae(t);
            return ye(Object(r.a)({}, a, {
                saturation: xe(0, 1, a.saturation - parseFloat(e))
            }))
        }
        var Le = ve(Ae);

        function Se(e) {
            var t = te(e),
                a = Object.keys(t).map(function(e) {
                    var a = t[e] / 255;
                    return a <= .03928 ? a / 12.92 : Math.pow((a + .055) / 1.055, 2.4)
                }),
                r = a[0],
                n = a[1],
                o = a[2];
            return parseFloat((.2126 * r + .7152 * n + .0722 * o).toFixed(3))
        }

        function Oe(e) {
            return ye(Object(r.a)({}, ae(e), {
                saturation: 0
            }))
        }

        function Ce(e) {
            var t = te(e);
            return ye(Object(r.a)({}, t, {
                red: 255 - t.red,
                green: 255 - t.green,
                blue: 255 - t.blue
            }))
        }

        function Te(e, t) {
            var a = ae(t);
            return ye(Object(r.a)({}, a, {
                lightness: xe(0, 1, a.lightness + parseFloat(e))
            }))
        }
        var je = ve(Te);

        function Ee(e, t, a) {
            var n = te(t),
                o = Object(r.a)({}, n, {
                    alpha: "number" === typeof n.alpha ? n.alpha : 1
                }),
                i = te(a),
                l = Object(r.a)({}, i, {
                    alpha: "number" === typeof i.alpha ? i.alpha : 1
                }),
                c = o.alpha - l.alpha,
                u = 2 * parseFloat(e) - 1,
                d = ((u * c === -1 ? u : u + c) / (1 + u * c) + 1) / 2,
                s = 1 - d;
            return se({
                red: Math.floor(o.red * d + l.red * s),
                green: Math.floor(o.green * d + l.green * s),
                blue: Math.floor(o.blue * d + l.blue * s),
                alpha: o.alpha + (l.alpha - o.alpha) * (parseFloat(e) / 1)
            })
        }
        var _e = ve(Ee);

        function Pe(e, t) {
            var a = te(t),
                n = "number" === typeof a.alpha ? a.alpha : 1;
            return se(Object(r.a)({}, a, {
                alpha: xe(0, 1, (100 * n + 100 * parseFloat(e)) / 100)
            }))
        }
        var Ve = ve(Pe);

        function He(e) {
            return Se(e) > .179 ? "#000" : "#fff"
        }

        function Ie(e, t) {
            var a = ae(t);
            return ye(Object(r.a)({}, a, {
                saturation: xe(0, 1, a.saturation + parseFloat(e))
            }))
        }
        var Fe = ve(Ie);

        function Re(e, t) {
            return ye(Object(r.a)({}, ae(t), {
                hue: parseFloat(e)
            }))
        }
        var Ne = ve(Re);

        function De(e, t) {
            return ye(Object(r.a)({}, ae(t), {
                lightness: parseFloat(e)
            }))
        }
        var Ue = ve(De);

        function Be(e, t) {
            return ye(Object(r.a)({}, ae(t), {
                saturation: parseFloat(e)
            }))
        }
        var We = ve(Be);

        function $e(e, t) {
            return _e(parseFloat(e), "rgb(0, 0, 0)", t)
        }
        var qe = ve($e);

        function Qe(e, t) {
            return _e(parseFloat(e), "rgb(255, 255, 255)", t)
        }
        var Ye = ve(Qe);

        function Ge(e, t) {
            var a = te(t),
                n = "number" === typeof a.alpha ? a.alpha : 1;
            return se(Object(r.a)({}, a, {
                alpha: xe(0, 1, (100 * n - 100 * parseFloat(e)) / 100)
            }))
        }
        var Ke = ve(Ge);

        function Xe() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            var r = Array.isArray(t[0]);
            if (!r && t.length > 8) throw new Error("The animation shorthand only takes 8 arguments. See the specification for more information: http://mdn.io/animation");
            return {
                animation: t.map(function(e) {
                    if (r && !Array.isArray(e) || !r && Array.isArray(e)) throw new Error("To pass multiple animations please supply them in arrays, e.g. animation(['rotate', '2s'], ['move', '1s'])\nTo pass a single animation please supply them in simple values, e.g. animation('rotate', '2s')");
                    if (Array.isArray(e) && e.length > 8) throw new Error("The animation shorthand arrays can only have 8 elements. See the specification for more information: http://mdn.io/animation");
                    return Array.isArray(e) ? e.join(" ") : e
                }).join(", ")
            }
        }

        function Ze() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            return {
                backgroundImage: t.join(", ")
            }
        }

        function Je() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            return {
                background: t.join(", ")
            }
        }
        var et = ["top", "right", "bottom", "left"];

        function tt(e) {
            for (var t = arguments.length, a = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) a[r - 1] = arguments[r];
            var o;
            return "string" === typeof e && et.indexOf(e) >= 0 ? ((o = {})["border" + n(e) + "Width"] = a[0], o["border" + n(e) + "Style"] = a[1], o["border" + n(e) + "Color"] = a[2], o) : (a.unshift(e), {
                borderWidth: a[0],
                borderStyle: a[1],
                borderColor: a[2]
            })
        }

        function at(e, t) {
            var a, r, o = n(e);
            if (!t && 0 !== t) throw new Error("borderRadius expects a radius value as a string or number as the second argument.");
            if ("Top" === o || "Bottom" === o) return (a = {})["border" + o + "RightRadius"] = t, a["border" + o + "LeftRadius"] = t, a;
            if ("Left" === o || "Right" === o) return (r = {})["borderTop" + o + "Radius"] = t, r["borderBottom" + o + "Radius"] = t, r;
            throw new Error('borderRadius expects one of "top", "bottom", "left" or "right" as the first argument.')
        }

        function rt() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            return l.apply(void 0, ["borderStyle"].concat(t))
        }

        function nt() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            return l.apply(void 0, ["borderWidth"].concat(t))
        }

        function ot(e, t) {
            return e(t ? ":" + t : "")
        }

        function it(e, t, a) {
            if (!t) throw new Error("You must provide a template to this method.");
            if (0 === e.length) return ot(t, null);
            for (var r = [], n = 0; n < e.length; n += 1) {
                if (a && a.indexOf(e[n]) < 0) throw new Error("You passed an unsupported selector state to this method.");
                r.push(ot(t, e[n]))
            }
            return r = r.join(",")
        }
        var lt = [void 0, null, "active", "focus", "hover"];

        function ct(e) {
            return "button" + e + ',\n  input[type="button"]' + e + ',\n  input[type="reset"]' + e + ',\n  input[type="submit"]' + e
        }

        function ut() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            return it(t, ct, lt)
        }

        function dt() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            return l.apply(void 0, ["margin"].concat(t))
        }

        function st() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            return l.apply(void 0, ["padding"].concat(t))
        }
        var ht = ["absolute", "fixed", "relative", "static", "sticky"];

        function pt(e) {
            for (var t = arguments.length, a = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) a[n - 1] = arguments[n];
            if (ht.indexOf(e) >= 0) return Object(r.a)({
                position: e
            }, l.apply(void 0, [""].concat(a)));
            var o = e;
            return l.apply(void 0, ["", o].concat(a))
        }

        function ft(e, t) {
            return void 0 === t && (t = e), {
                height: e,
                width: t
            }
        }
        var gt = [void 0, null, "active", "focus", "hover"];

        function mt(e) {
            return 'input[type="color"]' + e + ',\n    input[type="date"]' + e + ',\n    input[type="datetime"]' + e + ',\n    input[type="datetime-local"]' + e + ',\n    input[type="email"]' + e + ',\n    input[type="month"]' + e + ',\n    input[type="number"]' + e + ',\n    input[type="password"]' + e + ',\n    input[type="search"]' + e + ',\n    input[type="tel"]' + e + ',\n    input[type="text"]' + e + ',\n    input[type="time"]' + e + ',\n    input[type="url"]' + e + ',\n    input[type="week"]' + e + ",\n    input:not([type])" + e + ",\n    textarea" + e
        }

        function yt() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            return it(t, mt, gt)
        }

        function vt() {
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            if (Array.isArray(t[0]) && 2 === t.length) {
                var r = t[1];
                if ("string" !== typeof r) throw new Error("Property must be a string value.");
                return {
                    transition: t[0].map(function(e) {
                        return e + " " + r
                    }).join(", ")
                }
            }
            return {
                transition: t.join(", ")
            }
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.StyledIcon = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = function(e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e)
                    for (var a in e)
                        if (Object.prototype.hasOwnProperty.call(e, a)) {
                            var r = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(e, a) : {};
                            r.get || r.set ? Object.defineProperty(t, a, r) : t[a] = e[a]
                        }
                return t.default = e, t
            }(a(1)),
            i = a(52),
            l = a(89);

        function c() {
            return (c = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        var u = (0, o.css)(["", " ", ' g{fill:inherit;stroke:inherit;}*:not([stroke]){&[fill="none"]{stroke-width:0;}}*[stroke*="#"],*[STROKE*="#"]{stroke:inherit;fill:none;}*[fill-rule],*[FILL-RULE],*[fill*="#"],*[FILL*="#"]{fill:inherit;stroke:none;}'], function(e) {
                return (0, i.colorStyle)("fill", e.color || e.theme.global.colors.icon, e.theme)
            }, function(e) {
                return (0, i.colorStyle)("stroke", e.color || e.theme.global.colors.icon, e.theme)
            }),
            d = function(e) {
                var t = e.a11yTitle,
                    a = (e.color, e.size, e.theme, function(e, t) {
                        if (null == e) return {};
                        var a, r, n = {},
                            o = Object.keys(e);
                        for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                        return n
                    }(e, ["a11yTitle", "color", "size", "theme"]));
                return n.default.createElement("svg", c({
                    "aria-label": t
                }, a))
            };
        d.displayName = "Icon";
        var s = (0, o.default)(d).withConfig({
            displayName: "StyledIcon",
            componentId: "ofa7kd-0"
        })(["display:inline-block;flex:0 0 auto;", " ", " ", ""], function(e) {
            var t = e.size,
                a = void 0 === t ? "medium" : t,
                r = e.theme;
            return "\n    width: " + (r.icon.size[a] || a) + ";\n    height: " + (r.icon.size[a] || a) + ";\n  "
        }, function(e) {
            return "plain" !== e.color && u
        }, function(e) {
            var t = e.theme;
            return t && t.icon.extend
        });
        t.StyledIcon = s, s.defaultProps = {}, Object.setPrototypeOf(s.defaultProps, l.defaultProps)
    }, , function(e, t, a) {
        e.exports = a(78)()
    }, function(e, t, a) {
        "use strict";
        var r = a(0),
            n = a.n(r),
            o = a(26),
            i = a.n(o),
            l = a(27),
            c = a.n(l);
        n.a.createContext(function(e, t, a) {
            void 0 === t && (t = "polite"), void 0 === a && (a = 500);
            var r = document.body.querySelector("[aria-live]") || function() {
                var e = document.createElement("div");
                return e.style.left = "-100%", e.style.right = "100%", e.style.position = "fixed", e.style["z-index"] = "-1", document.body.insertBefore(e, document.body.firstChild), e
            }();
            r.setAttribute("aria-live", "off"), r.innerHTML = e, r.setAttribute("aria-live", t), setTimeout(function() {
                r.innerHTML = ""
            }, a)
        });

        function u() {
            return (u = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }

        function d(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }

        function s(e, t, a) {
            return t in e ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = a, e
        }
        a.d(t, "a", function() {
            return h
        }), a.d(t, "b", function() {
            return p
        });
        var h = function(e) {
                var t = (void 0 === e ? {} : e).focusWithMouse;
                return function(e) {
                    var a = function(a) {
                            var r, o;

                            function i() {
                                for (var e, r = arguments.length, o = new Array(r), i = 0; i < r; i++) o[i] = arguments[i];
                                return s(d(e = a.call.apply(a, [this].concat(o)) || this), "mouseActive", !1), s(d(e), "state", {
                                    focus: !1,
                                    wrappedRef: n.a.createRef()
                                }), s(d(e), "componentDidMount", function() {
                                    var a = e.state.wrappedRef;
                                    t || window.addEventListener("mousedown", e.handleActiveMouse);
                                    var r = a.current;
                                    r && r.addEventListener && r.addEventListener("focus", e.setFocus)
                                }), s(d(e), "componentWillUnmount", function() {
                                    var t = e.state.wrappedRef;
                                    window.removeEventListener("mousedown", e.handleActiveMouse);
                                    var a = t.current;
                                    a && a.addEventListener && a.removeEventListener("focus", e.setFocus), clearTimeout(e.focusTimer), clearTimeout(e.mouseTimer)
                                }), s(d(e), "handleActiveMouse", function() {
                                    e.mouseActive = !0, clearTimeout(e.mouseTimer), e.mouseTimer = setTimeout(function() {
                                        e.mouseActive = !1
                                    }, 150)
                                }), s(d(e), "setFocus", function() {
                                    clearTimeout(e.focusTimer), e.focusTimer = setTimeout(function() {
                                        e.state.focus || e.mouseActive || e.setState({
                                            focus: !0
                                        })
                                    }, 1)
                                }), s(d(e), "resetFocus", function() {
                                    clearTimeout(e.focusTimer), e.focusTimer = setTimeout(function() {
                                        e.state.focus && e.setState({
                                            focus: !1
                                        })
                                    }, 1)
                                }), e
                            }
                            return o = a, (r = i).prototype = Object.create(o.prototype), r.prototype.constructor = r, r.__proto__ = o, i.getDerivedStateFromProps = function(e, t) {
                                var a = e.withFocusRef,
                                    r = t.wrappedRef,
                                    n = a || r;
                                return n !== r ? {
                                    wrappedRef: n
                                } : null
                            }, i.prototype.render = function() {
                                var t = this,
                                    a = this.props,
                                    r = a.onFocus,
                                    o = a.onBlur,
                                    i = (a.withFocusRef, function(e, t) {
                                        if (null == e) return {};
                                        var a, r, n = {},
                                            o = Object.keys(e);
                                        for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                                        return n
                                    }(a, ["onFocus", "onBlur", "withFocusRef"])),
                                    l = this.state,
                                    c = l.focus,
                                    d = l.wrappedRef;
                                return n.a.createElement(e, u({
                                    ref: d,
                                    focus: c
                                }, i, {
                                    onFocus: function(e) {
                                        t.setFocus(), r && r(e)
                                    },
                                    onBlur: function(e) {
                                        t.resetFocus(), o && o(e)
                                    }
                                }))
                            }, i
                        }(r.Component),
                        o = n.a.forwardRef(function(e, t) {
                            return n.a.createElement(a, u({}, e, {
                                withFocusRef: t
                            }))
                        });
                    return o.displayName = i()(e), o.name = o.displayName, o.defaultProps = e.defaultProps, c()(o, e), o
                }
            },
            p = function(e) {
                var t = n.a.forwardRef(function(t, a) {
                    return n.a.createElement(e, u({
                        forwardRef: a
                    }, t))
                });
                return t.displayName = i()(e), t.name = t.displayName, t.defaultProps = e.defaultProps, c()(t, e), t
            }
    }, function(e, t, a) {
        "use strict";
        a.d(t, "b", function() {
            return n
        }), a.d(t, "a", function() {
            return o
        });
        var r = a(1),
            n = function(e) {
                return parseFloat(e.replace(/[^0-9\/.]/g, ""), 10)
            },
            o = function(e, t) {
                return Object(r.css)(["@media only screen ", "{", ";}"], e.value && "and (max-width: " + e.value + "px)", t)
            }
    }, function(e, t, a) {
        "use strict";
        var r = a(0);
        a(2), a(17);

        function n(e, t) {
            e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
        }

        function o() {
            var e = this.constructor.getDerivedStateFromProps(this.props, this.state);
            null !== e && void 0 !== e && this.setState(e)
        }

        function i(e) {
            this.setState(function(t) {
                var a = this.constructor.getDerivedStateFromProps(e, t);
                return null !== a && void 0 !== a ? a : null
            }.bind(this))
        }

        function l(e, t) {
            try {
                var a = this.props,
                    r = this.state;
                this.props = e, this.state = t, this.__reactInternalSnapshotFlag = !0, this.__reactInternalSnapshot = this.getSnapshotBeforeUpdate(a, r)
            } finally {
                this.props = a, this.state = r
            }
        }
        o.__suppressDeprecationWarning = !0, i.__suppressDeprecationWarning = !0, l.__suppressDeprecationWarning = !0;
        a(61);
        var c = a(41),
            u = a(25);
        a.d(t, "a", function() {
            return s
        });
        Object.keys, r.Component;
        var d, s = function() {
                for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
                return t.reduce(function(e, t) {
                    return function() {
                        return e(t.apply(void 0, arguments))
                    }
                }, function(e) {
                    return e
                })
            },
            h = {
                fromESObservable: null,
                toESObservable: null
            },
            p = {
                fromESObservable: function(e) {
                    return "function" === typeof h.fromESObservable ? h.fromESObservable(e) : e
                },
                toESObservable: function(e) {
                    return "function" === typeof h.toESObservable ? h.toESObservable(e) : e
                }
            };
        d = p
    }, function(e, t, a) {
        "use strict";
        ! function e() {
            if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE) try {
                __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)
            } catch (t) {
                console.error(t)
            }
        }(), e.exports = a(73)
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.FormDown = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.FormDown = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "FormDown"
            }, e), n.default.createElement("polyline", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                points: "18 9 12 15 6 9"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r, n = a(85),
            o = (r = n) && r.__esModule ? r : {
                default: r
            };
        t.default = o.default
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.getRGBA = t.colorIsDark = t.normalizeColor = void 0;
        t.normalizeColor = function e(t, a, r) {
            var n = a.global.colors[t] || t,
                o = n;
            return n && (a.dark && n.dark ? o = n.dark : !a.dark && n.light && (o = n.light)), o && a.global.colors[o] && (o = e(o, a)), r && o === t ? "inherit" : o
        };
        var r = function(e) {
            return /^#/.test(e) ? function(e) {
                return 4 === e.length ? e.match(/[A-Za-z0-9]{1}/g).map(function(e) {
                    return parseInt(e, 16)
                }) : e.match(/[A-Za-z0-9]{2}/g).map(function(e) {
                    return parseInt(e, 16)
                })
            }(e) : /^rgb/.test(e) ? e.match(/rgba?\((\s?[0-9]*\s?),(\s?[0-9]*\s?),(\s?[0-9]*\s?).*?\)/).splice(1) : e
        };
        t.colorIsDark = function(e) {
            var t = r(e);
            return (299 * t[0] + 587 * t[1] + 114 * t[2]) / 1e3 < 125
        };
        t.getRGBA = function(e, t) {
            if (e && function(e) {
                    return /^#/.test(e) || /^rgb/.test(e)
                }(e)) {
                var a = r(e);
                return "rgba(" + a[0] + ", " + a[1] + ", " + a[2] + ", " + (t || 1) + ")"
            }
        }
    }, function(e, t, a) {
        "use strict";
        var r = Object.prototype.hasOwnProperty;

        function n(e, t) {
            return e === t ? 0 !== e || 0 !== t || 1 / e === 1 / t : e !== e && t !== t
        }
        e.exports = function(e, t) {
            if (n(e, t)) return !0;
            if ("object" !== typeof e || null === e || "object" !== typeof t || null === t) return !1;
            var a = Object.keys(e),
                o = Object.keys(t);
            if (a.length !== o.length) return !1;
            for (var i = 0; i < a.length; i++)
                if (!r.call(t, a[i]) || !n(e[a[i]], t[a[i]])) return !1;
            return !0
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.FormUp = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.FormUp = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "FormUp"
            }, e), n.default.createElement("polyline", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                points: "18 9 12 15 6 9",
                transform: "matrix(1 0 0 -1 0 24)"
            }))
        }
    }, function(e, t, a) {
        "use strict";

        function r() {
            return (r = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        a.d(t, "a", function() {
            return o
        }), a.d(t, "b", function() {
            return i
        });
        var n = function(e) {
                return e && "object" === typeof e && !Array.isArray(e)
            },
            o = function(e) {
                return Object.keys(e).forEach(function(t) {
                    return t && n(e[t]) && Object.freeze(e[t])
                }), Object.freeze(e)
            },
            i = function e(t) {
                for (var a = arguments.length, o = new Array(a > 1 ? a - 1 : 0), i = 1; i < a; i++) o[i - 1] = arguments[i];
                if (!o.length) return t;
                var l = r({}, t);
                return o.forEach(function(t) {
                    n(t) && Object.keys(t).forEach(function(a) {
                        n(t[a]) ? l[a] ? l[a] = e(l[a], t[a]) : l[a] = r({}, t[a]) : l[a] = t[a]
                    })
                }), l
            }
    }, function(e, t, a) {
        "use strict";

        function r() {
            return (r = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.__esModule = !0, t.removeUndefined = t.deepMerge = t.deepFreeze = t.isObject = void 0;
        var n = function(e) {
            return e && "object" === typeof e && !Array.isArray(e)
        };
        t.isObject = n;
        t.deepFreeze = function(e) {
            return Object.keys(e).forEach(function(t) {
                return t && n(e[t]) && Object.freeze(e[t])
            }), Object.freeze(e)
        };
        t.deepMerge = function e(t) {
            for (var a = arguments.length, o = new Array(a > 1 ? a - 1 : 0), i = 1; i < a; i++) o[i - 1] = arguments[i];
            if (!o.length) return t;
            var l = r({}, t);
            return o.forEach(function(t) {
                n(t) && Object.keys(t).forEach(function(a) {
                    n(t[a]) ? l[a] ? l[a] = e(l[a], t[a]) : l[a] = r({}, t[a]) : l[a] = t[a]
                })
            }), l
        };
        t.removeUndefined = function(e) {
            var t = {};
            return Object.keys(e).forEach(function(a) {
                void 0 !== e[a] && (t[a] = e[a])
            }), t
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.base = void 0;
        t.base = {
            global: {
                colors: {
                    icon: "#666666"
                }
            },
            icon: {
                size: {
                    small: "12px",
                    medium: "24px",
                    large: "48px",
                    xlarge: "96px"
                }
            }
        }
    }, function(e, t, a) {
        "use strict";
        e.exports = a(77)
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.Previous = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.Previous = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "Previous"
            }, e), n.default.createElement("polyline", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                points: "7 2 17 12 7 22",
                transform: "matrix(-1 0 0 1 24 0)"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.Next = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.Next = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "Next"
            }, e), n.default.createElement("polyline", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                points: "7 2 17 12 7 22"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        (function(e, r) {
            var n, o = a(62);
            n = "undefined" !== typeof self ? self : "undefined" !== typeof window ? window : "undefined" !== typeof e ? e : r;
            var i = Object(o.a)(n);
            t.a = i
        }).call(this, a(45), a(88)(e))
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.default = void 0;
        var r = function(e) {
            return "string" === typeof e ? e : e ? e.displayName || e.name || "Component" : void 0
        };
        t.default = r
    }, function(e, t, a) {
        "use strict";
        var r = a(22),
            n = {
                childContextTypes: !0,
                contextType: !0,
                contextTypes: !0,
                defaultProps: !0,
                displayName: !0,
                getDefaultProps: !0,
                getDerivedStateFromError: !0,
                getDerivedStateFromProps: !0,
                mixins: !0,
                propTypes: !0,
                type: !0
            },
            o = {
                name: !0,
                length: !0,
                prototype: !0,
                caller: !0,
                callee: !0,
                arguments: !0,
                arity: !0
            },
            i = {
                $$typeof: !0,
                compare: !0,
                defaultProps: !0,
                displayName: !0,
                propTypes: !0,
                type: !0
            },
            l = {};

        function c(e) {
            return r.isMemo(e) ? i : l[e.$$typeof] || n
        }
        l[r.ForwardRef] = {
            $$typeof: !0,
            render: !0,
            defaultProps: !0,
            displayName: !0,
            propTypes: !0
        };
        var u = Object.defineProperty,
            d = Object.getOwnPropertyNames,
            s = Object.getOwnPropertySymbols,
            h = Object.getOwnPropertyDescriptor,
            p = Object.getPrototypeOf,
            f = Object.prototype;
        e.exports = function e(t, a, r) {
            if ("string" !== typeof a) {
                if (f) {
                    var n = p(a);
                    n && n !== f && e(t, n, r)
                }
                var i = d(a);
                s && (i = i.concat(s(a)));
                for (var l = c(t), g = c(a), m = 0; m < i.length; ++m) {
                    var y = i[m];
                    if (!o[y] && (!r || !r[y]) && (!g || !g[y]) && (!l || !l[y])) {
                        var v = h(a, y);
                        try {
                            u(t, y, v)
                        } catch (b) {}
                    }
                }
                return t
            }
            return t
        }
    }, , function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.FormPrevious = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.FormPrevious = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "FormPrevious"
            }, e), n.default.createElement("polyline", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                points: "9 6 15 12 9 18",
                transform: "matrix(-1 0 0 1 24 0)"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.FormNext = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.FormNext = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "FormNext"
            }, e), n.default.createElement("polyline", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                points: "9 6 15 12 9 18"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.Subtract = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.Subtract = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "Subtract"
            }, e), n.default.createElement("path", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                d: "M2,12 L22,12"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.ClosedCaption = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.ClosedCaption = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "ClosedCaption"
            }, e), n.default.createElement("path", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                d: "M1,12 C1,5 2.5,4 12,4 C21.5,4 23,5 23,12 C23,19 21.5,20 12,20 C2.5,20 1,19 1,12 Z M5.25,14 C5.25,15.5 6,16 7.75,16 C9.5,16 10.25,15.5 10.25,14 L9.97861679,14 C9.97861671,15.25 8.97905547,16 7.75,16 C6.52094453,16 5.52138329,15.25 5.52138321,14 L5.52138321,10 C5.5,8.75 6.5,8 7.75,8 C9,8 10,8.75 9.97861679,10 L10.25,10 C10.25,8.75 9.2286998,8 7.75,8 C6.2713002,8 5.25,8.75 5.25,10 L5.25,14 Z M13.25,14 C13.25,15.5 14,16 15.75,16 C17.5,16 18.25,15.5 18.25,14 L17.9786168,14 C17.9786167,15.25 16.9790555,16 15.75,16 C14.5209445,16 13.5213833,15.25 13.5213832,14 L13.5213832,10 C13.5,8.75 14.5,8 15.75,8 C17,8 18,8.75 17.9786168,10 L18.25,10 C18.25,8.75 17.2286998,8 15.75,8 C14.2713002,8 13.25,8.75 13.25,10 L13.25,14 Z"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.Actions = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.Actions = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "Actions"
            }, e), n.default.createElement("path", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                d: "M12,17.5 C15.0375661,17.5 17.5,15.0375661 17.5,12 C17.5,8.96243388 15.0375661,6.5 12,6.5 C8.96243388,6.5 6.5,8.96243388 6.5,12 C6.5,15.0375661 8.96243388,17.5 12,17.5 Z M12,6.5 L12,1 M12,23 L12,17.5 M1,12 L6.5,12 M17.5,12 L23,12 M4.4375,4.4375 L8.5625,8.5625 M15.4375,15.4375 L19.5625,19.5625 M19.5625,4.4375 L15.4375,8.5625 M8.5625,15.4375 L4.4375,19.5625"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.Expand = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.Expand = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "Expand"
            }, e), n.default.createElement("path", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                d: "M10,14 L2,22 M1,15 L1,23 L9,23 M22,2 L14,10 M15,1 L23,1 L23,9"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.Pause = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.Pause = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "Pause"
            }, e), n.default.createElement("path", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                d: "M3,21 L9,21 L9,3 L3,3 L3,21 Z M15,21 L21,21 L21,3 L15,3 L15,21 Z"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.Play = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.Play = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "Play"
            }, e), n.default.createElement("polygon", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                points: "3 22 21 12 3 2"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.VolumeLow = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.VolumeLow = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "VolumeLow"
            }, e), n.default.createElement("path", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                d: "M1,8 L1,16 L6.09901951,16 L12,21 L12,3 L6,8 L1,8 Z M15,16 L15,16 C17.209139,16 19,14.209139 19,12 C19,9.790861 17.209139,8 15,8"
            }))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.Volume = void 0;
        var r, n = (r = a(0)) && r.__esModule ? r : {
                default: r
            },
            o = a(7);

        function i() {
            return (i = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        t.Volume = function(e) {
            return n.default.createElement(o.StyledIcon, i({
                viewBox: "0 0 24 24",
                a11yTitle: "Volume"
            }, e), n.default.createElement("path", {
                fill: "none",
                stroke: "#000",
                strokeWidth: "2",
                d: "M15,16 C17.209,16 19,14.209 19,12 C19,9.791 17.209,8 15,8 M15,20 C20,20 23,16.411 23,12 C23,7.589 19.411,4 15,4 M1,12 L1,8 L6,8 L12,3 L12,21 L6,16 L1,16 L1,12"
            }))
        }
    }, function(e, t, a) {
        e.exports = function e(t) {
            "use strict";
            var a = /^\0+/g,
                r = /[\0\r\f]/g,
                n = /: */g,
                o = /zoo|gra/,
                i = /([,: ])(transform)/g,
                l = /,+\s*(?![^(]*[)])/g,
                c = / +\s*(?![^(]*[)])/g,
                u = / *[\0] */g,
                d = /,\r+?/g,
                s = /([\t\r\n ])*\f?&/g,
                h = /:global\(((?:[^\(\)\[\]]*|\[.*\]|\([^\(\)]*\))*)\)/g,
                p = /\W+/g,
                f = /@(k\w+)\s*(\S*)\s*/,
                g = /::(place)/g,
                m = /:(read-only)/g,
                y = /\s+(?=[{\];=:>])/g,
                v = /([[}=:>])\s+/g,
                b = /(\{[^{]+?);(?=\})/g,
                w = /\s{2,}/g,
                z = /([^\(])(:+) */g,
                x = /[svh]\w+-[tblr]{2}/,
                k = /\(\s*(.*)\s*\)/g,
                M = /([\s\S]*?);/g,
                A = /-self|flex-/g,
                L = /[^]*?(:[rp][el]a[\w-]+)[^]*/,
                S = /stretch|:\s*\w+\-(?:conte|avail)/,
                O = /([^-])(image-set\()/,
                C = "-webkit-",
                T = "-moz-",
                j = "-ms-",
                E = 59,
                _ = 125,
                P = 123,
                V = 40,
                H = 41,
                I = 91,
                F = 93,
                R = 10,
                N = 13,
                D = 9,
                U = 64,
                B = 32,
                W = 38,
                $ = 45,
                q = 95,
                Q = 42,
                Y = 44,
                G = 58,
                K = 39,
                X = 34,
                Z = 47,
                J = 62,
                ee = 43,
                te = 126,
                ae = 0,
                re = 12,
                ne = 11,
                oe = 107,
                ie = 109,
                le = 115,
                ce = 112,
                ue = 111,
                de = 105,
                se = 99,
                he = 100,
                pe = 112,
                fe = 1,
                ge = 1,
                me = 0,
                ye = 1,
                ve = 1,
                be = 1,
                we = 0,
                ze = 0,
                xe = 0,
                ke = [],
                Me = [],
                Ae = 0,
                Le = null,
                Se = -2,
                Oe = -1,
                Ce = 0,
                Te = 1,
                je = 2,
                Ee = 3,
                _e = 0,
                Pe = 1,
                Ve = "",
                He = "",
                Ie = "";

            function Fe(e, t, n, o, i) {
                for (var l, c, d = 0, s = 0, h = 0, p = 0, y = 0, v = 0, b = 0, w = 0, x = 0, M = 0, A = 0, L = 0, S = 0, O = 0, q = 0, we = 0, Me = 0, Le = 0, Se = 0, Oe = n.length, Ne = Oe - 1, qe = "", Qe = "", Ye = "", Ge = "", Ke = "", Xe = ""; q < Oe;) {
                    if (b = n.charCodeAt(q), q === Ne && s + p + h + d !== 0 && (0 !== s && (b = s === Z ? R : Z), p = h = d = 0, Oe++, Ne++), s + p + h + d === 0) {
                        if (q === Ne && (we > 0 && (Qe = Qe.replace(r, "")), Qe.trim().length > 0)) {
                            switch (b) {
                                case B:
                                case D:
                                case E:
                                case N:
                                case R:
                                    break;
                                default:
                                    Qe += n.charAt(q)
                            }
                            b = E
                        }
                        if (1 === Me) switch (b) {
                            case P:
                            case _:
                            case E:
                            case X:
                            case K:
                            case V:
                            case H:
                            case Y:
                                Me = 0;
                            case D:
                            case N:
                            case R:
                            case B:
                                break;
                            default:
                                for (Me = 0, Se = q, y = b, q--, b = E; Se < Oe;) switch (n.charCodeAt(Se++)) {
                                    case R:
                                    case N:
                                    case E:
                                        ++q, b = y, Se = Oe;
                                        break;
                                    case G:
                                        we > 0 && (++q, b = y);
                                    case P:
                                        Se = Oe
                                }
                        }
                        switch (b) {
                            case P:
                                for (y = (Qe = Qe.trim()).charCodeAt(0), A = 1, Se = ++q; q < Oe;) {
                                    switch (b = n.charCodeAt(q)) {
                                        case P:
                                            A++;
                                            break;
                                        case _:
                                            A--;
                                            break;
                                        case Z:
                                            switch (v = n.charCodeAt(q + 1)) {
                                                case Q:
                                                case Z:
                                                    q = $e(v, q, Ne, n)
                                            }
                                            break;
                                        case I:
                                            b++;
                                        case V:
                                            b++;
                                        case X:
                                        case K:
                                            for (; q++ < Ne && n.charCodeAt(q) !== b;);
                                    }
                                    if (0 === A) break;
                                    q++
                                }
                                switch (Ye = n.substring(Se, q), y === ae && (y = (Qe = Qe.replace(a, "").trim()).charCodeAt(0)), y) {
                                    case U:
                                        switch (we > 0 && (Qe = Qe.replace(r, "")), v = Qe.charCodeAt(1)) {
                                            case he:
                                            case ie:
                                            case le:
                                            case $:
                                                l = t;
                                                break;
                                            default:
                                                l = ke
                                        }
                                        if (Se = (Ye = Fe(t, l, Ye, v, i + 1)).length, xe > 0 && 0 === Se && (Se = Qe.length), Ae > 0 && (l = Re(ke, Qe, Le), c = We(Ee, Ye, l, t, ge, fe, Se, v, i, o), Qe = l.join(""), void 0 !== c && 0 === (Se = (Ye = c.trim()).length) && (v = 0, Ye = "")), Se > 0) switch (v) {
                                            case le:
                                                Qe = Qe.replace(k, Be);
                                            case he:
                                            case ie:
                                            case $:
                                                Ye = Qe + "{" + Ye + "}";
                                                break;
                                            case oe:
                                                Ye = (Qe = Qe.replace(f, "$1 $2" + (Pe > 0 ? Ve : ""))) + "{" + Ye + "}", Ye = 1 === ve || 2 === ve && Ue("@" + Ye, 3) ? "@" + C + Ye + "@" + Ye : "@" + Ye;
                                                break;
                                            default:
                                                Ye = Qe + Ye, o === pe && (Ge += Ye, Ye = "")
                                        } else Ye = "";
                                        break;
                                    default:
                                        Ye = Fe(t, Re(t, Qe, Le), Ye, o, i + 1)
                                }
                                Ke += Ye, L = 0, Me = 0, O = 0, we = 0, Le = 0, S = 0, Qe = "", Ye = "", b = n.charCodeAt(++q);
                                break;
                            case _:
                            case E:
                                if ((Se = (Qe = (we > 0 ? Qe.replace(r, "") : Qe).trim()).length) > 1) switch (0 === O && ((y = Qe.charCodeAt(0)) === $ || y > 96 && y < 123) && (Se = (Qe = Qe.replace(" ", ":")).length), Ae > 0 && void 0 !== (c = We(Te, Qe, t, e, ge, fe, Ge.length, o, i, o)) && 0 === (Se = (Qe = c.trim()).length) && (Qe = "\0\0"), y = Qe.charCodeAt(0), v = Qe.charCodeAt(1), y) {
                                    case ae:
                                        break;
                                    case U:
                                        if (v === de || v === se) {
                                            Xe += Qe + n.charAt(q);
                                            break
                                        }
                                    default:
                                        if (Qe.charCodeAt(Se - 1) === G) break;
                                        Ge += De(Qe, y, v, Qe.charCodeAt(2))
                                }
                                L = 0, Me = 0, O = 0, we = 0, Le = 0, Qe = "", b = n.charCodeAt(++q)
                        }
                    }
                    switch (b) {
                        case N:
                        case R:
                            if (s + p + h + d + ze === 0) switch (M) {
                                case H:
                                case K:
                                case X:
                                case U:
                                case te:
                                case J:
                                case Q:
                                case ee:
                                case Z:
                                case $:
                                case G:
                                case Y:
                                case E:
                                case P:
                                case _:
                                    break;
                                default:
                                    O > 0 && (Me = 1)
                            }
                            s === Z ? s = 0 : ye + L === 0 && o !== oe && Qe.length > 0 && (we = 1, Qe += "\0"), Ae * _e > 0 && We(Ce, Qe, t, e, ge, fe, Ge.length, o, i, o), fe = 1, ge++;
                            break;
                        case E:
                        case _:
                            if (s + p + h + d === 0) {
                                fe++;
                                break
                            }
                        default:
                            switch (fe++, qe = n.charAt(q), b) {
                                case D:
                                case B:
                                    if (p + d + s === 0) switch (w) {
                                        case Y:
                                        case G:
                                        case D:
                                        case B:
                                            qe = "";
                                            break;
                                        default:
                                            b !== B && (qe = " ")
                                    }
                                    break;
                                case ae:
                                    qe = "\\0";
                                    break;
                                case re:
                                    qe = "\\f";
                                    break;
                                case ne:
                                    qe = "\\v";
                                    break;
                                case W:
                                    p + s + d === 0 && ye > 0 && (Le = 1, we = 1, qe = "\f" + qe);
                                    break;
                                case 108:
                                    if (p + s + d + me === 0 && O > 0) switch (q - O) {
                                        case 2:
                                            w === ce && n.charCodeAt(q - 3) === G && (me = w);
                                        case 8:
                                            x === ue && (me = x)
                                    }
                                    break;
                                case G:
                                    p + s + d === 0 && (O = q);
                                    break;
                                case Y:
                                    s + h + p + d === 0 && (we = 1, qe += "\r");
                                    break;
                                case X:
                                case K:
                                    0 === s && (p = p === b ? 0 : 0 === p ? b : p);
                                    break;
                                case I:
                                    p + s + h === 0 && d++;
                                    break;
                                case F:
                                    p + s + h === 0 && d--;
                                    break;
                                case H:
                                    p + s + d === 0 && h--;
                                    break;
                                case V:
                                    if (p + s + d === 0) {
                                        if (0 === L) switch (2 * w + 3 * x) {
                                            case 533:
                                                break;
                                            default:
                                                A = 0, L = 1
                                        }
                                        h++
                                    }
                                    break;
                                case U:
                                    s + h + p + d + O + S === 0 && (S = 1);
                                    break;
                                case Q:
                                case Z:
                                    if (p + d + h > 0) break;
                                    switch (s) {
                                        case 0:
                                            switch (2 * b + 3 * n.charCodeAt(q + 1)) {
                                                case 235:
                                                    s = Z;
                                                    break;
                                                case 220:
                                                    Se = q, s = Q
                                            }
                                            break;
                                        case Q:
                                            b === Z && w === Q && Se + 2 !== q && (33 === n.charCodeAt(Se + 2) && (Ge += n.substring(Se, q + 1)), qe = "", s = 0)
                                    }
                            }
                            if (0 === s) {
                                if (ye + p + d + S === 0 && o !== oe && b !== E) switch (b) {
                                    case Y:
                                    case te:
                                    case J:
                                    case ee:
                                    case H:
                                    case V:
                                        if (0 === L) {
                                            switch (w) {
                                                case D:
                                                case B:
                                                case R:
                                                case N:
                                                    qe += "\0";
                                                    break;
                                                default:
                                                    qe = "\0" + qe + (b === Y ? "" : "\0")
                                            }
                                            we = 1
                                        } else switch (b) {
                                            case V:
                                                O + 7 === q && 108 === w && (O = 0), L = ++A;
                                                break;
                                            case H:
                                                0 == (L = --A) && (we = 1, qe += "\0")
                                        }
                                        break;
                                    case D:
                                    case B:
                                        switch (w) {
                                            case ae:
                                            case P:
                                            case _:
                                            case E:
                                            case Y:
                                            case re:
                                            case D:
                                            case B:
                                            case R:
                                            case N:
                                                break;
                                            default:
                                                0 === L && (we = 1, qe += "\0")
                                        }
                                }
                                Qe += qe, b !== B && b !== D && (M = b)
                            }
                    }
                    x = w, w = b, q++
                }
                if (Se = Ge.length, xe > 0 && 0 === Se && 0 === Ke.length && 0 === t[0].length == 0 && (o !== ie || 1 === t.length && (ye > 0 ? He : Ie) === t[0]) && (Se = t.join(",").length + 2), Se > 0) {
                    if (l = 0 === ye && o !== oe ? function(e) {
                            for (var t, a, n = 0, o = e.length, i = Array(o); n < o; ++n) {
                                for (var l = e[n].split(u), c = "", d = 0, s = 0, h = 0, p = 0, f = l.length; d < f; ++d)
                                    if (!(0 === (s = (a = l[d]).length) && f > 1)) {
                                        if (h = c.charCodeAt(c.length - 1), p = a.charCodeAt(0), t = "", 0 !== d) switch (h) {
                                            case Q:
                                            case te:
                                            case J:
                                            case ee:
                                            case B:
                                            case V:
                                                break;
                                            default:
                                                t = " "
                                        }
                                        switch (p) {
                                            case W:
                                                a = t + He;
                                            case te:
                                            case J:
                                            case ee:
                                            case B:
                                            case H:
                                            case V:
                                                break;
                                            case I:
                                                a = t + a + He;
                                                break;
                                            case G:
                                                switch (2 * a.charCodeAt(1) + 3 * a.charCodeAt(2)) {
                                                    case 530:
                                                        if (be > 0) {
                                                            a = t + a.substring(8, s - 1);
                                                            break
                                                        }
                                                    default:
                                                        (d < 1 || l[d - 1].length < 1) && (a = t + He + a)
                                                }
                                                break;
                                            case Y:
                                                t = "";
                                            default:
                                                a = s > 1 && a.indexOf(":") > 0 ? t + a.replace(z, "$1" + He + "$2") : t + a + He
                                        }
                                        c += a
                                    }
                                i[n] = c.replace(r, "").trim()
                            }
                            return i
                        }(t) : t, Ae > 0 && void 0 !== (c = We(je, Ge, l, e, ge, fe, Se, o, i, o)) && 0 === (Ge = c).length) return Xe + Ge + Ke;
                    if (Ge = l.join(",") + "{" + Ge + "}", ve * me != 0) {
                        switch (2 !== ve || Ue(Ge, 2) || (me = 0), me) {
                            case ue:
                                Ge = Ge.replace(m, ":" + T + "$1") + Ge;
                                break;
                            case ce:
                                Ge = Ge.replace(g, "::" + C + "input-$1") + Ge.replace(g, "::" + T + "$1") + Ge.replace(g, ":" + j + "input-$1") + Ge
                        }
                        me = 0
                    }
                }
                return Xe + Ge + Ke
            }

            function Re(e, t, a) {
                var r = t.trim().split(d),
                    n = r,
                    o = r.length,
                    i = e.length;
                switch (i) {
                    case 0:
                    case 1:
                        for (var l = 0, c = 0 === i ? "" : e[0] + " "; l < o; ++l) n[l] = Ne(c, n[l], a, i).trim();
                        break;
                    default:
                        l = 0;
                        var u = 0;
                        for (n = []; l < o; ++l)
                            for (var s = 0; s < i; ++s) n[u++] = Ne(e[s] + " ", r[l], a, i).trim()
                }
                return n
            }

            function Ne(e, t, a, r) {
                var n = t,
                    o = n.charCodeAt(0);
                switch (o < 33 && (o = (n = n.trim()).charCodeAt(0)), o) {
                    case W:
                        switch (ye + r) {
                            case 0:
                            case 1:
                                if (0 === e.trim().length) break;
                            default:
                                return n.replace(s, "$1" + e.trim())
                        }
                        break;
                    case G:
                        switch (n.charCodeAt(1)) {
                            case 103:
                                if (be > 0 && ye > 0) return n.replace(h, "$1").replace(s, "$1" + Ie);
                                break;
                            default:
                                return e.trim() + n.replace(s, "$1" + e.trim())
                        }
                    default:
                        if (a * ye > 0 && n.indexOf("\f") > 0) return n.replace(s, (e.charCodeAt(0) === G ? "" : "$1") + e.trim())
                }
                return e + n
            }

            function De(e, t, a, r) {
                var u, d = 0,
                    s = e + ";",
                    h = 2 * t + 3 * a + 4 * r;
                if (944 === h) return function(e) {
                    var t = e.length,
                        a = e.indexOf(":", 9) + 1,
                        r = e.substring(0, a).trim(),
                        n = e.substring(a, t - 1).trim();
                    switch (e.charCodeAt(9) * Pe) {
                        case 0:
                            break;
                        case $:
                            if (110 !== e.charCodeAt(10)) break;
                        default:
                            for (var o = n.split((n = "", l)), i = 0, a = 0, t = o.length; i < t; a = 0, ++i) {
                                for (var u = o[i], d = u.split(c); u = d[a];) {
                                    var s = u.charCodeAt(0);
                                    if (1 === Pe && (s > U && s < 90 || s > 96 && s < 123 || s === q || s === $ && u.charCodeAt(1) !== $)) switch (isNaN(parseFloat(u)) + (-1 !== u.indexOf("("))) {
                                        case 1:
                                            switch (u) {
                                                case "infinite":
                                                case "alternate":
                                                case "backwards":
                                                case "running":
                                                case "normal":
                                                case "forwards":
                                                case "both":
                                                case "none":
                                                case "linear":
                                                case "ease":
                                                case "ease-in":
                                                case "ease-out":
                                                case "ease-in-out":
                                                case "paused":
                                                case "reverse":
                                                case "alternate-reverse":
                                                case "inherit":
                                                case "initial":
                                                case "unset":
                                                case "step-start":
                                                case "step-end":
                                                    break;
                                                default:
                                                    u += Ve
                                            }
                                    }
                                    d[a++] = u
                                }
                                n += (0 === i ? "" : ",") + d.join(" ")
                            }
                    }
                    return n = r + n + ";", 1 === ve || 2 === ve && Ue(n, 1) ? C + n + n : n
                }(s);
                if (0 === ve || 2 === ve && !Ue(s, 1)) return s;
                switch (h) {
                    case 1015:
                        return 97 === s.charCodeAt(10) ? C + s + s : s;
                    case 951:
                        return 116 === s.charCodeAt(3) ? C + s + s : s;
                    case 963:
                        return 110 === s.charCodeAt(5) ? C + s + s : s;
                    case 1009:
                        if (100 !== s.charCodeAt(4)) break;
                    case 969:
                    case 942:
                        return C + s + s;
                    case 978:
                        return C + s + T + s + s;
                    case 1019:
                    case 983:
                        return C + s + T + s + j + s + s;
                    case 883:
                        return s.charCodeAt(8) === $ ? C + s + s : s.indexOf("image-set(", 11) > 0 ? s.replace(O, "$1" + C + "$2") + s : s;
                    case 932:
                        if (s.charCodeAt(4) === $) switch (s.charCodeAt(5)) {
                            case 103:
                                return C + "box-" + s.replace("-grow", "") + C + s + j + s.replace("grow", "positive") + s;
                            case 115:
                                return C + s + j + s.replace("shrink", "negative") + s;
                            case 98:
                                return C + s + j + s.replace("basis", "preferred-size") + s
                        }
                        return C + s + j + s + s;
                    case 964:
                        return C + s + j + "flex-" + s + s;
                    case 1023:
                        if (99 !== s.charCodeAt(8)) break;
                        return u = s.substring(s.indexOf(":", 15)).replace("flex-", "").replace("space-between", "justify"), C + "box-pack" + u + C + s + j + "flex-pack" + u + s;
                    case 1005:
                        return o.test(s) ? s.replace(n, ":" + C) + s.replace(n, ":" + T) + s : s;
                    case 1e3:
                        switch (d = (u = s.substring(13).trim()).indexOf("-") + 1, u.charCodeAt(0) + u.charCodeAt(d)) {
                            case 226:
                                u = s.replace(x, "tb");
                                break;
                            case 232:
                                u = s.replace(x, "tb-rl");
                                break;
                            case 220:
                                u = s.replace(x, "lr");
                                break;
                            default:
                                return s
                        }
                        return C + s + j + u + s;
                    case 1017:
                        if (-1 === s.indexOf("sticky", 9)) return s;
                    case 975:
                        switch (d = (s = e).length - 10, h = (u = (33 === s.charCodeAt(d) ? s.substring(0, d) : s).substring(e.indexOf(":", 7) + 1).trim()).charCodeAt(0) + (0 | u.charCodeAt(7))) {
                            case 203:
                                if (u.charCodeAt(8) < 111) break;
                            case 115:
                                s = s.replace(u, C + u) + ";" + s;
                                break;
                            case 207:
                            case 102:
                                s = s.replace(u, C + (h > 102 ? "inline-" : "") + "box") + ";" + s.replace(u, C + u) + ";" + s.replace(u, j + u + "box") + ";" + s
                        }
                        return s + ";";
                    case 938:
                        if (s.charCodeAt(5) === $) switch (s.charCodeAt(6)) {
                            case 105:
                                return u = s.replace("-items", ""), C + s + C + "box-" + u + j + "flex-" + u + s;
                            case 115:
                                return C + s + j + "flex-item-" + s.replace(A, "") + s;
                            default:
                                return C + s + j + "flex-line-pack" + s.replace("align-content", "").replace(A, "") + s
                        }
                        break;
                    case 973:
                    case 989:
                        if (s.charCodeAt(3) !== $ || 122 === s.charCodeAt(4)) break;
                    case 931:
                    case 953:
                        if (!0 === S.test(e)) return 115 === (u = e.substring(e.indexOf(":") + 1)).charCodeAt(0) ? De(e.replace("stretch", "fill-available"), t, a, r).replace(":fill-available", ":stretch") : s.replace(u, C + u) + s.replace(u, T + u.replace("fill-", "")) + s;
                        break;
                    case 962:
                        if (s = C + s + (102 === s.charCodeAt(5) ? j + s : "") + s, a + r === 211 && 105 === s.charCodeAt(13) && s.indexOf("transform", 10) > 0) return s.substring(0, s.indexOf(";", 27) + 1).replace(i, "$1" + C + "$2") + s
                }
                return s
            }

            function Ue(e, t) {
                var a = e.indexOf(1 === t ? ":" : "{"),
                    r = e.substring(0, 3 !== t ? a : 10),
                    n = e.substring(a + 1, e.length - 1);
                return Le(2 !== t ? r : r.replace(L, "$1"), n, t)
            }

            function Be(e, t) {
                var a = De(t, t.charCodeAt(0), t.charCodeAt(1), t.charCodeAt(2));
                return a !== t + ";" ? a.replace(M, " or ($1)").substring(4) : "(" + t + ")"
            }

            function We(e, t, a, r, n, o, i, l, c, u) {
                for (var d, s = 0, h = t; s < Ae; ++s) switch (d = Me[s].call(Qe, e, h, a, r, n, o, i, l, c, u)) {
                    case void 0:
                    case !1:
                    case !0:
                    case null:
                        break;
                    default:
                        h = d
                }
                if (h !== t) return h
            }

            function $e(e, t, a, r) {
                for (var n = t + 1; n < a; ++n) switch (r.charCodeAt(n)) {
                    case Z:
                        if (e === Q && r.charCodeAt(n - 1) === Q && t + 2 !== n) return n + 1;
                        break;
                    case R:
                        if (e === Z) return n + 1
                }
                return n
            }

            function qe(e) {
                for (var t in e) {
                    var a = e[t];
                    switch (t) {
                        case "keyframe":
                            Pe = 0 | a;
                            break;
                        case "global":
                            be = 0 | a;
                            break;
                        case "cascade":
                            ye = 0 | a;
                            break;
                        case "compress":
                            we = 0 | a;
                            break;
                        case "semicolon":
                            ze = 0 | a;
                            break;
                        case "preserve":
                            xe = 0 | a;
                            break;
                        case "prefix":
                            Le = null, a ? "function" != typeof a ? ve = 1 : (ve = 2, Le = a) : ve = 0
                    }
                }
                return qe
            }

            function Qe(t, a) {
                if (void 0 !== this && this.constructor === Qe) return e(t);
                var n = t,
                    o = n.charCodeAt(0);
                o < 33 && (o = (n = n.trim()).charCodeAt(0)), Pe > 0 && (Ve = n.replace(p, o === I ? "" : "-")), o = 1, 1 === ye ? Ie = n : He = n;
                var i, l = [Ie];
                Ae > 0 && void 0 !== (i = We(Oe, a, l, l, ge, fe, 0, 0, 0, 0)) && "string" == typeof i && (a = i);
                var c = Fe(ke, l, a, 0, 0);
                return Ae > 0 && void 0 !== (i = We(Se, c, l, l, ge, fe, c.length, 0, 0, 0)) && "string" != typeof(c = i) && (o = 0), Ve = "", Ie = "", He = "", me = 0, ge = 1, fe = 1, we * o == 0 ? c : c.replace(r, "").replace(y, "").replace(v, "$1").replace(b, "$1").replace(w, " ")
            }
            return Qe.use = function e(t) {
                switch (t) {
                    case void 0:
                    case null:
                        Ae = Me.length = 0;
                        break;
                    default:
                        if ("function" == typeof t) Me[Ae++] = t;
                        else if ("object" == typeof t)
                            for (var a = 0, r = t.length; a < r; ++a) e(t[a]);
                        else _e = 0 | !!t
                }
                return e
            }, Qe.set = qe, void 0 !== t && qe(t), Qe
        }(null)
    }, function(e, t, a) {
        "use strict";

        function r(e, t) {
            if (e.length !== t.length) return !1;
            for (var a = 0; a < e.length; a++)
                if (e[a] !== t[a]) return !1;
            return !0
        }
        t.a = function(e, t) {
            var a;
            void 0 === t && (t = r);
            var n, o = [],
                i = !1;
            return function() {
                for (var r = arguments.length, l = new Array(r), c = 0; c < r; c++) l[c] = arguments[c];
                return i && a === this && t(l, o) ? n : (n = e.apply(this, l), i = !0, a = this, o = l, n)
            }
        }
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        t.createChangeEmitter = function() {
            var e = [],
                t = e;

            function a() {
                t === e && (t = e.slice())
            }
            return {
                listen: function(e) {
                    if ("function" !== typeof e) throw new Error("Expected listener to be a function.");
                    var r = !0;
                    return a(), t.push(e),
                        function() {
                            if (r) {
                                r = !1, a();
                                var n = t.indexOf(e);
                                t.splice(n, 1)
                            }
                        }
                },
                emit: function() {
                    for (var a = e = t, r = 0; r < a.length; r++) a[r].apply(a, arguments)
                }
            }
        }
    }, function(e, t, a) {
        "use strict";
        a.d(t, "a", function() {
            return O
        });
        var r = a(6),
            n = a(1),
            o = a(33),
            i = a(32),
            l = a(34),
            c = a(14),
            u = a(30),
            d = a(29),
            s = a(18),
            h = a(24),
            p = a(35),
            f = a(36),
            g = a(23),
            m = a(31),
            y = a(38),
            v = a(37),
            b = a(21),
            w = a(19),
            z = a(4);

        function x() {
            return (x = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        var k = ["#6FFFB0", "#FD6FFF", "#81FCED", "#FFCA58"],
            M = {
                critical: "#FF4040",
                error: "#FF4040",
                warning: "#FFAA15",
                ok: "#00C781",
                unknown: "#CCCCCC",
                disabled: "#CCCCCC"
            },
            A = k[0],
            L = {
                active: Object(r.rgba)(221, 221, 221, .5),
                black: "#000000",
                border: {
                    dark: Object(r.rgba)(255, 255, 255, .33),
                    light: Object(r.rgba)(0, 0, 0, .33)
                },
                brand: "#7D4CDB",
                control: {
                    dark: "accent-1",
                    light: "brand"
                },
                focus: A,
                placeholder: "#AAAAAA",
                selected: "brand",
                text: {
                    dark: "#f8f8f8",
                    light: "#444444"
                },
                icon: {
                    dark: "#f8f8f8",
                    light: "#666666"
                },
                white: "#FFFFFF"
            },
            S = function(e, t) {
                return e.forEach(function(e, a) {
                    L[t + "-" + (a + 1)] = e
                })
            };
        S(k, "accent"), S(["#333333", "#555555", "#777777", "#999999", "#999999", "#999999"], "dark"), S(["#F8F8F8", "#F2F2F2", "#EDEDED", "#DADADA", "#DADADA", "#DADADA"], "light"), S(["#00873D", "#3D138D", "#00739D", "#A2423D"], "neutral"), Object.keys(M).forEach(function(e) {
            L["status-" + e] = M[e]
        });
        var O = function(e, t) {
            void 0 === e && (e = 24), void 0 === t && (t = 6);
            var a = .75 * e,
                k = e / t,
                M = function(t) {
                    return {
                        size: a + t * k + "px",
                        height: e + t * k + "px",
                        maxWidth: e * (a + t * k) + "px"
                    }
                },
                A = Object(w.b)(b.base, {
                    global: {
                        animation: {
                            duration: "1s",
                            jiggle: {
                                duration: "0.1s"
                            }
                        },
                        borderSize: {
                            xsmall: "1px",
                            small: "2px",
                            medium: e / 6 + "px",
                            large: e / 2 + "px",
                            xlarge: e + "px"
                        },
                        breakpoints: {
                            small: {
                                value: 32 * e,
                                borderSize: {
                                    xsmall: "1px",
                                    small: "2px",
                                    medium: e / 6 + "px",
                                    large: e / 4 + "px",
                                    xlarge: e / 2 + "px"
                                },
                                edgeSize: {
                                    none: "0px",
                                    hair: "1px",
                                    xxsmall: "2px",
                                    xsmall: e / 8 + "px",
                                    small: e / 4 + "px",
                                    medium: e / 2 + "px",
                                    large: e + "px",
                                    xlarge: 2 * e + "px"
                                },
                                size: {
                                    xxsmall: e + "px",
                                    xsmall: 2 * e + "px",
                                    small: 4 * e + "px",
                                    medium: 8 * e + "px",
                                    large: 16 * e + "px",
                                    xlarge: 32 * e + "px",
                                    full: "100%"
                                }
                            },
                            medium: {
                                value: 64 * e
                            },
                            large: {}
                        },
                        deviceBreakpoints: {
                            phone: "small",
                            tablet: "medium",
                            computer: "large"
                        },
                        colors: L,
                        control: {
                            border: {
                                width: "1px",
                                radius: "4px",
                                color: "border"
                            },
                            disabled: {
                                opacity: .3
                            }
                        },
                        debounceDelay: 300,
                        drop: {
                            background: "#ffffff",
                            border: {
                                radius: "0px"
                            },
                            shadowSize: "small",
                            zIndex: "20"
                        },
                        edgeSize: {
                            none: "0px",
                            hair: "1px",
                            xxsmall: e / 8 + "px",
                            xsmall: e / 4 + "px",
                            small: e / 2 + "px",
                            medium: e + "px",
                            large: 2 * e + "px",
                            xlarge: 4 * e + "px",
                            responsiveBreakpoint: "small"
                        },
                        elevation: {
                            light: {
                                none: "none",
                                xsmall: "0px 1px 2px rgba(0, 0, 0, 0.20)",
                                small: "0px 2px 4px rgba(0, 0, 0, 0.20)",
                                medium: "0px 4px 8px rgba(0, 0, 0, 0.20)",
                                large: "0px 8px 16px rgba(0, 0, 0, 0.20)",
                                xlarge: "0px 12px 24px rgba(0, 0, 0, 0.20)"
                            },
                            dark: {
                                none: "none",
                                xsmall: "0px 2px 2px rgba(255, 255, 255, 0.40)",
                                small: "0px 4px 4px rgba(255, 255, 255, 0.40)",
                                medium: "0px 6px 8px rgba(255, 255, 255, 0.40)",
                                large: "0px 8px 16px rgba(255, 255, 255, 0.40)",
                                xlarge: "0px 12px 24px rgba(255, 255, 255, 0.40)"
                            }
                        },
                        focus: {
                            border: {
                                color: "focus"
                            }
                        },
                        font: x({}, M(0)),
                        hover: {
                            background: {
                                dark: {
                                    color: "active",
                                    opacity: "medium"
                                },
                                light: {
                                    color: "active",
                                    opacity: "medium"
                                }
                            },
                            color: {
                                dark: "white",
                                light: "black"
                            }
                        },
                        input: {
                            padding: e / 2 + "px",
                            weight: 600
                        },
                        opacity: {
                            strong: .8,
                            medium: .4,
                            weak: .1
                        },
                        selected: {
                            background: "selected",
                            color: "white"
                        },
                        spacing: e + "px",
                        size: {
                            xxsmall: 2 * e + "px",
                            xsmall: 4 * e + "px",
                            small: 8 * e + "px",
                            medium: 16 * e + "px",
                            large: 32 * e + "px",
                            xlarge: 48 * e + "px",
                            xxlarge: 64 * e + "px",
                            full: "100%"
                        }
                    },
                    accordion: {
                        border: {
                            side: "bottom",
                            color: "border"
                        },
                        heading: {
                            level: "4"
                        },
                        icons: {
                            collapse: s.FormUp,
                            expand: c.FormDown
                        }
                    },
                    anchor: {
                        textDecoration: "none",
                        fontWeight: 600,
                        color: {
                            dark: "accent-1",
                            light: "brand"
                        },
                        hover: {
                            textDecoration: "underline"
                        }
                    },
                    box: {
                        responsiveBreakpoint: "small"
                    },
                    button: {
                        border: {
                            width: "2px",
                            radius: .75 * e + "px"
                        },
                        primary: {},
                        padding: {
                            vertical: e / 4 - 2 + "px",
                            horizontal: e - 2 + "px"
                        }
                    },
                    calendar: {
                        small: {
                            fontSize: a - k + "px",
                            lineHeight: 1.375,
                            daySize: 8 * e / 7 + "px",
                            slideDuration: "0.2s"
                        },
                        medium: {
                            fontSize: a + "px",
                            lineHeight: 1.45,
                            daySize: 16 * e / 7 + "px",
                            slideDuration: "0.5s"
                        },
                        large: {
                            fontSize: a + 3 * k + "px",
                            lineHeight: 1.11,
                            daySize: 32 * e / 7 + "px",
                            slideDuration: "0.8s"
                        },
                        icons: {
                            previous: g.Previous,
                            next: h.Next,
                            small: {
                                previous: d.FormPrevious,
                                next: u.FormNext
                            }
                        }
                    },
                    carousel: {
                        icons: {
                            current: m.Subtract,
                            next: h.Next,
                            previous: g.Previous
                        }
                    },
                    chart: {},
                    checkBox: {
                        border: {
                            color: {
                                dark: "rgba(255, 255, 255, 0.5)",
                                light: "rgba(0, 0, 0, 0.15)"
                            },
                            width: "2px"
                        },
                        check: {
                            radius: "4px",
                            thickness: "4px"
                        },
                        icon: {},
                        icons: {},
                        hover: {
                            border: {
                                color: {
                                    dark: "white",
                                    light: "black"
                                }
                            }
                        },
                        size: e + "px",
                        toggle: {
                            color: {
                                dark: "#d9d9d9",
                                light: "#d9d9d9"
                            },
                            radius: e + "px",
                            size: 2 * e + "px",
                            knob: {}
                        }
                    },
                    clock: {
                        analog: {
                            hour: {
                                color: {
                                    dark: "light-2",
                                    light: "dark-3"
                                },
                                width: e / 3 + "px",
                                size: e + "px",
                                shape: "round"
                            },
                            minute: {
                                color: {
                                    dark: "light-4",
                                    light: "dark-3"
                                },
                                width: e / 6 + "px",
                                size: Math.round(e / 2) + "px",
                                shape: "round"
                            },
                            second: {
                                color: {
                                    dark: "accent-1",
                                    light: "accent-1"
                                },
                                width: e / 8 + "px",
                                size: Math.round(e / 2.666) + "px",
                                shape: "round"
                            },
                            size: {
                                small: 3 * e + "px",
                                medium: 4 * e + "px",
                                large: 6 * e + "px",
                                xlarge: 9 * e + "px",
                                huge: 12 * e + "px"
                            }
                        },
                        digital: {
                            text: {
                                xsmall: {
                                    size: a - 2 * k + "px",
                                    height: 1.5
                                },
                                small: {
                                    size: a - k + "px",
                                    height: 1.43
                                },
                                medium: {
                                    size: a + "px",
                                    height: 1.375
                                },
                                large: {
                                    size: a + k + "px",
                                    height: 1.167
                                },
                                xlarge: {
                                    size: a + 2 * k + "px",
                                    height: 1.1875
                                },
                                xxlarge: {
                                    size: a + 4 * k + "px",
                                    height: 1.125
                                }
                            }
                        }
                    },
                    collapsible: {
                        minSpeed: 200,
                        baseline: 500
                    },
                    dataTable: {
                        header: {},
                        groupHeader: {
                            border: {
                                side: "bottom",
                                size: "xsmall"
                            },
                            fill: "vertical",
                            pad: {
                                horizontal: "small",
                                vertical: "xsmall"
                            },
                            background: {
                                dark: "dark-2",
                                light: "light-2"
                            }
                        },
                        icons: {
                            ascending: c.FormDown,
                            contract: s.FormUp,
                            descending: s.FormUp,
                            expand: c.FormDown
                        },
                        resize: {
                            border: {
                                side: "right",
                                color: "border"
                            }
                        },
                        primary: {
                            weight: "bold"
                        }
                    },
                    diagram: {
                        line: {
                            color: "accent-1"
                        }
                    },
                    formField: {
                        border: {
                            color: "border",
                            position: "inner",
                            side: "bottom",
                            error: {
                                color: {
                                    dark: "white",
                                    light: "status-critical"
                                }
                            }
                        },
                        content: {
                            pad: {
                                horizontal: "small",
                                bottom: "small"
                            }
                        },
                        error: {
                            margin: {
                                vertical: "xsmall",
                                horizontal: "small"
                            },
                            color: {
                                dark: "status-critical",
                                light: "status-critical"
                            }
                        },
                        help: {
                            margin: {
                                left: "small"
                            },
                            color: {
                                dark: "dark-3",
                                light: "dark-3"
                            }
                        },
                        label: {
                            margin: {
                                vertical: "xsmall",
                                horizontal: "small"
                            }
                        },
                        margin: {
                            bottom: "small"
                        }
                    },
                    grommet: {},
                    heading: {
                        font: {},
                        level: {
                            1: {
                                font: {},
                                small: x({}, M(4)),
                                medium: x({}, M(8)),
                                large: x({}, M(16)),
                                xlarge: x({}, M(24))
                            },
                            2: {
                                font: {},
                                small: x({}, M(2)),
                                medium: x({}, M(4)),
                                large: x({}, M(8)),
                                xlarge: x({}, M(12))
                            },
                            3: {
                                font: {},
                                small: x({}, M(1)),
                                medium: x({}, M(2)),
                                large: x({}, M(4)),
                                xlarge: x({}, M(6))
                            },
                            4: {
                                font: {},
                                small: x({}, M(0)),
                                medium: x({}, M(0)),
                                large: x({}, M(0)),
                                xlarge: x({}, M(0))
                            },
                            5: {
                                font: {},
                                small: x({}, M(-.5)),
                                medium: x({}, M(-.5)),
                                large: x({}, M(-.5)),
                                xlarge: x({}, M(-.5))
                            },
                            6: {
                                font: {},
                                small: x({}, M(-1)),
                                medium: x({}, M(-1)),
                                large: x({}, M(-1)),
                                xlarge: x({}, M(-1))
                            }
                        },
                        responsiveBreakpoint: "small",
                        weight: 600
                    },
                    layer: {
                        background: "white",
                        border: {
                            radius: "4px"
                        },
                        container: {
                            zIndex: "15"
                        },
                        overlay: {
                            background: "rgba(0, 0, 0, 0.5)"
                        },
                        responsiveBreakpoint: "small",
                        zIndex: "10"
                    },
                    maskedInput: {},
                    menu: {
                        icons: {
                            down: c.FormDown
                        }
                    },
                    meter: {
                        color: "accent-1"
                    },
                    paragraph: {
                        small: x({}, M(-1)),
                        medium: x({}, M(0)),
                        large: x({}, M(1)),
                        xlarge: x({}, M(2)),
                        xxlarge: x({}, M(4))
                    },
                    radioButton: {
                        border: {
                            color: {
                                dark: "rgba(255, 255, 255, 0.5)",
                                light: "rgba(0, 0, 0, 0.15)"
                            },
                            width: "2px"
                        },
                        check: {
                            radius: "100%"
                        },
                        hover: {
                            border: {
                                color: {
                                    dark: "white",
                                    light: "black"
                                }
                            }
                        },
                        icon: {},
                        icons: {},
                        gap: "small",
                        size: e + "px"
                    },
                    rangeInput: {
                        track: {
                            height: "4px",
                            color: Object(n.css)(["", ";"], function(e) {
                                return Object(r.rgba)(Object(z.c)("border", e.theme), .2)
                            })
                        },
                        thumb: {}
                    },
                    rangeSelector: {
                        background: {
                            invert: {
                                color: "light-4"
                            }
                        }
                    },
                    select: {
                        container: {},
                        control: {},
                        icons: {
                            down: c.FormDown
                        },
                        options: {
                            box: {
                                align: "start",
                                pad: "small"
                            },
                            text: {
                                margin: "none"
                            }
                        },
                        step: 20
                    },
                    tab: {
                        active: {
                            color: "text"
                        },
                        border: {
                            side: "bottom",
                            size: "small",
                            color: {
                                dark: "accent-1",
                                light: "brand"
                            },
                            active: {
                                color: {
                                    dark: "white",
                                    light: "black"
                                }
                            },
                            hover: {
                                color: {
                                    dark: "white",
                                    light: "black"
                                }
                            }
                        },
                        color: "control",
                        hover: {
                            color: {
                                dark: "white",
                                light: "black"
                            }
                        },
                        margin: {
                            vertical: "xxsmall",
                            horizontal: "small"
                        },
                        pad: {
                            bottom: "xsmall"
                        }
                    },
                    tabs: {
                        header: {},
                        panel: {}
                    },
                    table: {
                        header: {
                            align: "start",
                            pad: {
                                horizontal: "small",
                                vertical: "xsmall"
                            },
                            border: "bottom",
                            verticalAlign: "bottom",
                            fill: "vertical"
                        },
                        body: {
                            align: "start",
                            pad: {
                                horizontal: "small",
                                vertical: "xsmall"
                            }
                        },
                        footer: {
                            align: "start",
                            pad: {
                                horizontal: "small",
                                vertical: "xsmall"
                            },
                            border: "top",
                            verticalAlign: "top",
                            fill: "vertical"
                        }
                    },
                    text: {
                        xsmall: x({}, M(-1.5)),
                        small: x({}, M(-1)),
                        medium: x({}, M(0)),
                        large: x({}, M(1)),
                        xlarge: x({}, M(2)),
                        xxlarge: x({}, M(4))
                    },
                    textArea: {},
                    textInput: {},
                    video: {
                        captions: {
                            background: "rgba(0, 0, 0, 0.7)"
                        },
                        icons: {
                            closedCaption: i.ClosedCaption,
                            configure: o.Actions,
                            fullScreen: l.Expand,
                            pause: p.Pause,
                            play: f.Play,
                            reduceVolume: v.VolumeLow,
                            volume: y.Volume
                        },
                        scrubber: {
                            color: "light-4"
                        }
                    },
                    worldMap: {
                        color: "light-3",
                        continent: {
                            active: "8px",
                            base: "6px"
                        },
                        hover: {
                            color: "light-4"
                        },
                        place: {
                            active: "20px",
                            base: "8px"
                        }
                    }
                });
            return Object(w.a)(A)
        }(24)
    }, , function(e, t, a) {
        "use strict";
        var r = Object.getOwnPropertySymbols,
            n = Object.prototype.hasOwnProperty,
            o = Object.prototype.propertyIsEnumerable;
        e.exports = function() {
            try {
                if (!Object.assign) return !1;
                var e = new String("abc");
                if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
                for (var t = {}, a = 0; a < 10; a++) t["_" + String.fromCharCode(a)] = a;
                if ("0123456789" !== Object.getOwnPropertyNames(t).map(function(e) {
                        return t[e]
                    }).join("")) return !1;
                var r = {};
                return "abcdefghijklmnopqrst".split("").forEach(function(e) {
                    r[e] = e
                }), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, r)).join("")
            } catch (n) {
                return !1
            }
        }() ? Object.assign : function(e, t) {
            for (var a, i, l = function(e) {
                    if (null === e || void 0 === e) throw new TypeError("Object.assign cannot be called with null or undefined");
                    return Object(e)
                }(e), c = 1; c < arguments.length; c++) {
                for (var u in a = Object(arguments[c])) n.call(a, u) && (l[u] = a[u]);
                if (r) {
                    i = r(a);
                    for (var d = 0; d < i.length; d++) o.call(a, i[d]) && (l[i[d]] = a[i[d]])
                }
            }
            return l
        }
    }, function(e, t) {
        var a;
        a = function() {
            return this
        }();
        try {
            a = a || new Function("return this")()
        } catch (r) {
            "object" === typeof window && (a = window)
        }
        e.exports = a
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.minArrowPadding = void 0;
        var r = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var a = arguments[t];
                for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
            }
            return e
        };
        t.getScrollLeft = s, t.getArrowSpacing = p, t.default = function(e, t, a, n, o, u) {
            var g = function(e) {
                    var t = e.split("-");
                    if (t.length > 1) return t[1];
                    return "middle"
                }(e),
                m = e.split("-")[0],
                y = m;
            if (!t && a) {
                var v = u.arrow && f(n, a, m, o, u);
                y = (0, i.default)(m, a, n, u, c, v)
            }
            var b = h(),
                w = void 0;
            if (a) {
                var z = a.style.width ? 0 : 1;
                w = Math.min(a.offsetWidth, b) + z
            }
            var x = "up" === y || "down" === y ? function(e, t, a, r, n, o) {
                var i = -1e7,
                    l = void 0,
                    u = a.showTip ? void 0 : "translateX(-10000000px)",
                    f = p(o);
                if (e) {
                    var g = s(),
                        m = t.getBoundingClientRect(),
                        y = m.left + g,
                        v = Math.round(t.offsetWidth / 2),
                        b = Math.min(h(), e.offsetWidth),
                        w = y + v,
                        z = w - o.arrowSize,
                        x = w + o.arrowSize;
                    if ("start" === n) i = o.arrow ? Math.min(z, y) : y;
                    else if ("end" === n) {
                        var k = Math.max(x, y + t.offsetWidth),
                            M = o.arrow ? k : y + t.offsetWidth;
                        i = Math.max(M - b, c + g)
                    } else {
                        var A = y + v - Math.round(b / 2),
                            L = c + g;
                        i = Math.max(A, L)
                    }
                    var S = i + b,
                        O = g + document.documentElement.clientWidth - c,
                        C = S - O;
                    C > 0 && (i -= C), l = "up" === r ? m.top + d() - (e.offsetHeight + f) : m.bottom + d() + f
                }
                return {
                    left: i,
                    top: l,
                    transform: u
                }
            }(a, n, o, y, g, u) : function(e, t, a, r, n, o) {
                var i = -1e7,
                    u = 0,
                    h = a.showTip ? void 0 : "translateX(-10000000px)",
                    f = p(o),
                    g = o.arrow ? l : 0;
                if (e) {
                    var m = d(),
                        y = s(),
                        v = t.getBoundingClientRect(),
                        b = v.top + m,
                        w = Math.round(t.offsetHeight / 2),
                        z = b + w - o.arrowSize,
                        x = v.top + m + w + o.arrowSize;
                    if ("start" === n) u = o.arrow ? Math.min(b, z) : b;
                    else if ("end" === n) {
                        var k = v.bottom + m - e.offsetHeight;
                        u = o.arrow ? Math.max(k, x - e.offsetHeight) : k
                    } else {
                        var M = Math.max(b + w - Math.round(e.offsetHeight / 2), c + m);
                        u = Math.min(M, z - g)
                    }
                    var A = u - m + e.offsetHeight + c - window.innerHeight;
                    A > 0 && (u = Math.max(u - A, x + g - e.offsetHeight)), i = "right" === r ? v.right + f + y : v.left - f - e.offsetWidth + y
                }
                return {
                    left: i,
                    top: u,
                    transform: h
                }
            }(a, n, o, y, g, u);
            return {
                tip: r({}, x, {
                    maxWidth: b,
                    width: w
                }),
                arrow: f(n, a, y, o, u),
                realDirection: y
            }
        };
        var n, o = a(84),
            i = (n = o) && n.__esModule ? n : {
                default: n
            };
        var l = t.minArrowPadding = 5,
            c = 10,
            u = 3;

        function d() {
            return window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0
        }

        function s() {
            return window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0
        }

        function h() {
            return "undefined" !== typeof document ? document.documentElement.clientWidth - 2 * c : 1e3
        }

        function p(e) {
            var t = e.arrow ? e.arrowSize : u;
            return "number" === typeof e.distance ? e.distance : t
        }

        function f(e, t, a, n, o) {
            if (!e || !o.arrow) return {
                top: "0",
                left: "-10000000px"
            };
            var i = e.getBoundingClientRect(),
                l = Math.round(e.offsetHeight / 2),
                c = Math.round(e.offsetWidth / 2),
                u = d(),
                h = s(),
                f = p(o),
                g = {};
            switch (a) {
                case "right":
                    return g.borderTop = o.arrowSize + "px solid transparent", g.borderBottom = o.arrowSize + "px solid transparent", o.background ? g.borderRight = o.arrowSize + "px solid " + o.background : (g.borderRightWidth = o.arrowSize + "px", g.borderRightStyle = "solid"), r({}, g, {
                        top: n.showTip && t ? i.top + u + l - o.arrowSize : "-10000000px",
                        left: i.right + h + f - o.arrowSize
                    });
                case "left":
                    return g.borderTop = o.arrowSize + "px solid transparent", g.borderBottom = o.arrowSize + "px solid transparent", o.background ? g.borderLeft = o.arrowSize + "px solid " + o.background : (g.borderLeftWidth = o.arrowSize + "px", g.borderLeftStyle = "solid"), r({}, g, {
                        top: n.showTip && t ? i.top + u + l - o.arrowSize : "-10000000px",
                        left: i.left + h - f - 1
                    });
                case "up":
                    return g.borderLeft = o.arrowSize + "px solid transparent", g.borderRight = o.arrowSize + "px solid transparent", o.background ? g.borderTop = o.arrowSize + "px solid " + o.background : (g.borderTopWidth = o.arrowSize + "px", g.borderTopStyle = "solid"), r({}, g, {
                        left: n.showTip && t ? i.left + h + c - o.arrowSize : "-10000000px",
                        top: i.top + u - f
                    });
                case "down":
                default:
                    return g.borderLeft = o.arrowSize + "px solid transparent", g.borderRight = o.arrowSize + "px solid transparent", o.background ? g.borderBottom = "10px solid " + o.background : (g.borderBottomWidth = o.arrowSize + "px", g.borderBottomStyle = "solid"), r({}, g, {
                        left: n.showTip && t ? i.left + h + c - o.arrowSize : "-10000000px",
                        top: i.bottom + u + f - o.arrowSize
                    })
            }
        }
    }, function(e, t, a) {
        "use strict";
        a.d(t, "a", function() {
            return n
        }), a.d(t, "b", function() {
            return o
        });
        var r = function(e) {
                return /^#/.test(e) ? function(e) {
                    return e.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function(e, t, a, r) {
                        return "#" + t + t + a + a + r + r
                    }).substring(1).match(/.{2}/g).map(function(e) {
                        return parseInt(e, 16)
                    })
                }(e) : /^rgb/.test(e) ? e.match(/rgba?\((\s?[0-9]*\s?),(\s?[0-9]*\s?),(\s?[0-9]*\s?).*?\)/).splice(1) : e
            },
            n = function(e) {
                var t = r(e);
                return (299 * t[0] + 587 * t[1] + 114 * t[2]) / 1e3 < 125
            },
            o = function e(t, a) {
                var r = a.global.colors[t] || t,
                    n = r;
                return a.dark && r.dark ? n = r.dark : !a.dark && r.light && (n = r.light), n && a.global.colors[n] && a.global.colors[n] !== n && (n = e(n, a)), n
            }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.getAvailableAtBadge = t.findAllByType = t.breakpointStyle = t.fontSize = t.parseMetricToNum = void 0;
        var r = a(1),
            n = function(e) {
                return parseFloat(e.replace(/[^0-9\/.]/g, ""), 10)
            };
        t.parseMetricToNum = n;
        t.fontSize = function(e, t) {
            return (0, r.css)(["font-size:", ";line-height:", ";"], function(t) {
                return n(e) / n(t.theme.global.font.size) * 1 + "rem"
            }, function(a) {
                return t || Math.ceil(n(e) / n(a.theme.global.lineHeight)) * (n(a.theme.global.lineHeight) / n(e)) + "px"
            })
        };
        t.breakpointStyle = function(e, t) {
            return (0, r.css)(["@media only screen ", "{", ";}"], e.value && "and (max-width: " + e.value + "px)", t)
        };
        t.findAllByType = function e(t, a) {
            var r = [];
            return t.type === a && r.push(t), t.children && t.children.forEach(function(t) {
                r = r.concat(e(t, a))
            }), r
        };
        t.getAvailableAtBadge = function(e) {
            return [{
                url: "https://storybook.grommet.io/?selectedKind=" + e + "&full=0&addons=0&stories=1&panelRight=0",
                badge: "https://cdn-images-1.medium.com/fit/c/120/120/1*TD1P0HtIH9zF0UEH28zYtw.png",
                label: "Storybook"
            }, {
                url: "https://codesandbox.io/s/github/grommet/grommet-sandbox?initialpath=" + e.toLowerCase() + "&module=%2Fsrc%2F" + e + ".js",
                badge: "https://codesandbox.io/static/img/play-codesandbox.svg",
                label: "CodeSandbox"
            }]
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.disabledStyle = t.genericStyles = t.evalStyle = t.placeholderStyle = t.overflowStyle = t.inputStyle = t.focusStyle = t.edgeStyle = t.controlBorderStyle = t.baseStyle = void 0;
        var r = a(1),
            n = a(16),
            o = a(48),
            i = (0, r.css)(["font-family:", ";font-size:", ";line-height:", ";font-weight:", ";", " box-sizing:border-box;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;"], function(e) {
                return e.theme.global.font.family
            }, function(e) {
                return e.theme.global.font.size
            }, function(e) {
                return e.theme.global.font.height
            }, function(e) {
                return e.theme.global.font.weight
            }, function(e) {
                return !e.plain && e.theme.global.colors.background && (0, r.css)(["background:", ";color:", ";"], (0, n.normalizeColor)("background", e.theme, !0), (0, n.normalizeColor)("text", e.theme, !0))
            });
        t.baseStyle = i;
        var l = (0, r.css)(["border:", " solid ", ";border-radius:", ";"], function(e) {
            return e.theme.global.control.border.width
        }, function(e) {
            return (0, n.normalizeColor)(e.theme.global.control.border.color || "border", e.theme)
        }, function(e) {
            return e.theme.global.control.border.radius
        });
        t.controlBorderStyle = l;
        var c = function(e, t, a, n, i) {
            var l = n && i.global.breakpoints[n];
            if ("string" === typeof t) return (0, r.css)(["", ":", ";", ";"], e, i.global.edgeSize[t] || t, a && l ? (0, o.breakpointStyle)(l, "\n        " + e + ": " + (l.edgeSize[t] || t) + ";\n      ") : "");
            var c = [];
            return t.horizontal && c.push((0, r.css)(["", "-left:", ";", "-right:", ";", ";"], e, i.global.edgeSize[t.horizontal] || t.horizontal, e, i.global.edgeSize[t.horizontal] || t.horizontal, a && l ? (0, o.breakpointStyle)(l, "\n        " + e + "-left: " + (l.edgeSize[t.horizontal] || t.horizontal) + ";\n        " + e + "-right: " + (l.edgeSize[t.horizontal] || t.horizontal) + ";\n      ") : "")), t.vertical && c.push((0, r.css)(["", "-top:", ";", "-bottom:", ";", ";"], e, i.global.edgeSize[t.vertical] || t.vertical, e, i.global.edgeSize[t.vertical] || t.vertical, a && l ? (0, o.breakpointStyle)(l, "\n        " + e + "-top: " + (l.edgeSize[t.vertical] || t.vertical) + ";\n        " + e + "-bottom: " + (l.edgeSize[t.vertical] || t.vertical) + ";\n      ") : "")), t.top && c.push((0, r.css)(["", "-top:", ";", ";"], e, i.global.edgeSize[t.top] || t.top, a && l ? (0, o.breakpointStyle)(l, "\n        " + e + "-top: " + (l.edgeSize[t.top] || t.top) + ";\n      ") : "")), t.bottom && c.push((0, r.css)(["", "-bottom:", ";", ";"], e, i.global.edgeSize[t.bottom] || t.bottom, a && l ? (0, o.breakpointStyle)(l, "\n        " + e + "-bottom: " + (l.edgeSize[t.bottom] || t.bottom) + ";\n      ") : "")), t.left && c.push((0, r.css)(["", "-left:", ";", ";"], e, i.global.edgeSize[t.left] || t.left, a && l ? (0, o.breakpointStyle)(l, "\n        " + e + "-left: " + (l.edgeSize[t.left] || t.left) + ";\n      ") : "")), t.right && c.push((0, r.css)(["", "-right:", ";", ";"], e, i.global.edgeSize[t.right] || t.right, a && l ? (0, o.breakpointStyle)(l, "\n        " + e + "-right: " + (l.edgeSize[t.right] || t.right) + ";\n      ") : "")), c
        };
        t.edgeStyle = c;
        var u = (0, r.css)(["> circle,> ellipse,> line,> path,> polygon,> polyline,> rect{outline:", " solid 2px;}border-color:", ";box-shadow:0 0 2px 2px ", ";::-moz-focus-inner{border:0;}"], function(e) {
            return (0, n.normalizeColor)(e.theme.global.focus.border.color, e.theme)
        }, function(e) {
            return (0, n.normalizeColor)(e.theme.global.focus.border.color, e.theme)
        }, function(e) {
            return (0, n.normalizeColor)(e.theme.global.focus.border.color, e.theme)
        });
        t.focusStyle = u;
        var d = (0, r.css)(["box-sizing:border-box;font-size:inherit;border:none;-webkit-appearance:none;padding:", "px;outline:none;background:transparent;color:inherit;", " margin:0;", " ", "::-webkit-search-decoration{-webkit-appearance:none;}"], function(e) {
            return (0, o.parseMetricToNum)(e.theme.global.input.padding) - (0, o.parseMetricToNum)(e.theme.global.control.border.width)
        }, function(e) {
            return e.theme.global.input.weight && (0, r.css)(["font-weight:", ";"], e.theme.global.input.weight)
        }, function(e) {
            return e.focus && (!e.plain || e.focusIndicator) && u
        }, l);
        t.inputStyle = d;
        t.overflowStyle = function(e) {
            return "string" === typeof e ? (0, r.css)(["overflow:", ";"], e) : (0, r.css)(["", " ", ";"], e.horizontal && "overflow-x: " + e.horizontal + ";", e.vertical && "overflow-y: " + e.vertical + ";")
        };
        var s = (0, r.css)(["color:", ";"], function(e) {
                return e.theme.global.colors.placeholder
            }),
            h = (0, r.css)(["&::-webkit-input-placeholder{", ";}&::-moz-placeholder{", ";}&:-ms-input-placeholder{", ";}"], s, s, s);
        t.placeholderStyle = h;
        t.evalStyle = function(e, t) {
            return e && Array.isArray(e) && "function" === typeof e[0] ? e[0]({
                theme: t
            }) : e
        };
        var p = {
                center: "center",
                end: "flex-end",
                start: "flex-start",
                stretch: "stretch"
            },
            f = (0, r.css)(["", " ", " ", ""], function(e) {
                return e.alignSelf && "align-self: " + p[e.alignSelf] + ";"
            }, function(e) {
                return e.gridArea && "grid-area: " + e.gridArea + ";"
            }, function(e) {
                return e.margin && c("margin", e.margin, e.responsive, e.theme.global.edgeSize.responsiveBreakpoint, e.theme)
            });
        t.genericStyles = f;
        t.disabledStyle = function(e) {
            return (0, r.css)(["opacity:", ";cursor:default;"], function(t) {
                return e || t.theme.global.control.disabled.opacity
            })
        }
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = o(a(97)),
            n = o(a(98));

        function o(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        t.PropTypes = r.default, t.describe = n.default, t.default = {
            describe: n.default,
            PropTypes: r.default
        }
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var a = arguments[t];
                for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
            }
            return e
        };
        t.default = function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            if (!e) throw new Error("react-desc: component is required");
            var a = r({
                name: e.displayName || e.name
            }, t);
            if (t && (delete a.propTypes, t.propTypes)) {
                var n = [];
                Object.keys(t.propTypes).forEach(function(a) {
                    var r = t.propTypes[a];
                    n.push(l(r, a, (e.defaultProps || {})[a]))
                }), n.length > 0 && (a.properties = n)
            }
            return a
        };
        var n = function(e, t) {
                return e.map(function(e) {
                    return i(e, t)
                })
            },
            o = function(e, t) {
                var a = Object.keys(e).map(function(a) {
                    var r = e[a],
                        n = void 0;
                    return n = r.type && ("arrayOf" === r.type || "oneOfType" === r.type || "oneOf" === r.type) && Array.isArray(r.args) ? "\n" + i(r, t + "    ") : "shape" === r.type ? "\n" + i(r, t + "    ") : i(r), t + "  " + a + ": " + n
                });
                return t + "{\n" + a.join(",\n") + "\n" + t + "}"
            },
            i = function e(t) {
                var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                    r = void 0;
                if (t.type) switch (t.type) {
                    case "arrayOf":
                        r = Array.isArray(t.args) ? a + "[\n" + n(t.args, a + "  ").join("\n") + "\n" + a + "]" : "oneOfType" === t.args.type ? a + "[\n" + e(t.args, a + "  ") + "\n" + a + "]" : a + "[" + e(t.args) + "]";
                        break;
                    case "bool":
                        r = a + "boolean";
                        break;
                    case "func":
                        r = a + "function";
                        break;
                    case "instanceOf":
                        r = a + "new " + t.args.name + "(...)";
                        break;
                    case "objectOf":
                        r = a + "{ test: " + t.args.type + ", ... }";
                        break;
                    case "oneOf":
                        r = t.args.map(function(e) {
                            return "" + a + e
                        }).join("\n");
                        break;
                    case "oneOfType":
                        r = Array.isArray(t.args) ? n(t.args, a).join("\n") : "" + a + e(t.args);
                        break;
                    case "shape":
                        r = "" + o(t.args, a);
                        break;
                    default:
                        r = "" + a + t.type
                } else r = a + "custom";
                return r
            },
            l = function(e, t, a) {
                var n = r({}, e.reactDesc, {
                    name: t
                });
                return a && (n.defaultValue = a), n.format = n.format || i(e), n
            }
    }, function(e, t, a) {
        "use strict";
        a.r(t);
        var r = a(1),
            n = a(47),
            o = function(e, t, a, o) {
                return Object(r.css)(["", ":", ";"], e, Object(n.b)(t, a, o))
            },
            i = function(e, t, a) {
                return Object(r.css)(["", ":", ";"], e, a.global.size[t] || t)
            };
        a.d(t, "colorStyle", function() {
            return o
        }), a.d(t, "sizeStyle", function() {
            return i
        }), a.d(t, "colorIsDark", function() {
            return n.a
        }), a.d(t, "normalizeColor", function() {
            return n.b
        })
    }, function(e, t, a) {
        "use strict";

        function r(e, t, a) {
            return t in e ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = a, e
        }
        a.d(t, "a", function() {
            return r
        })
    }, function(e, t, a) {
        "use strict";

        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        a.d(t, "a", function() {
            return r
        })
    }, function(e, t, a) {
        "use strict";

        function r(e, t) {
            for (var a = 0; a < t.length; a++) {
                var r = t[a];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
            }
        }

        function n(e, t, a) {
            return t && r(e.prototype, t), a && r(e, a), e
        }
        a.d(t, "a", function() {
            return n
        })
    }, function(e, t, a) {
        "use strict";

        function r(e) {
            return (r = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                return e.__proto__ || Object.getPrototypeOf(e)
            })(e)
        }
        a.d(t, "a", function() {
            return r
        })
    }, function(e, t, a) {
        e.exports = function() {
            "use strict";
            return function(e) {
                function t(t) {
                    if (t) try {
                        e(t + "}")
                    } catch (a) {}
                }
                return function(a, r, n, o, i, l, c, u, d, s) {
                    switch (a) {
                        case 1:
                            if (0 === d && 64 === r.charCodeAt(0)) return e(r + ";"), "";
                            break;
                        case 2:
                            if (0 === u) return r + "/*|*/";
                            break;
                        case 3:
                            switch (u) {
                                case 102:
                                case 112:
                                    return e(n[0] + r), "";
                                default:
                                    return r + (0 === s ? "/*|*/" : "")
                            }
                        case -2:
                            r.split("/*|*/}").forEach(t)
                    }
                }
            }
        }()
    }, function(e, t, a) {
        "use strict";
        t.a = {
            animationIterationCount: 1,
            borderImageOutset: 1,
            borderImageSlice: 1,
            borderImageWidth: 1,
            boxFlex: 1,
            boxFlexGroup: 1,
            boxOrdinalGroup: 1,
            columnCount: 1,
            columns: 1,
            flex: 1,
            flexGrow: 1,
            flexPositive: 1,
            flexShrink: 1,
            flexNegative: 1,
            flexOrder: 1,
            gridRow: 1,
            gridRowEnd: 1,
            gridRowSpan: 1,
            gridRowStart: 1,
            gridColumn: 1,
            gridColumnEnd: 1,
            gridColumnSpan: 1,
            gridColumnStart: 1,
            msGridRow: 1,
            msGridRowSpan: 1,
            msGridColumn: 1,
            msGridColumnSpan: 1,
            fontWeight: 1,
            lineHeight: 1,
            opacity: 1,
            order: 1,
            orphans: 1,
            tabSize: 1,
            widows: 1,
            zIndex: 1,
            zoom: 1,
            WebkitLineClamp: 1,
            fillOpacity: 1,
            floodOpacity: 1,
            stopOpacity: 1,
            strokeDasharray: 1,
            strokeDashoffset: 1,
            strokeMiterlimit: 1,
            strokeOpacity: 1,
            strokeWidth: 1
        }
    }, function(e, t, a) {
        "use strict";
        var r = a(80).CopyToClipboard;
        r.CopyToClipboard = r, e.exports = r
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            },
            n = function() {
                function e(e, t) {
                    for (var a = 0; a < t.length; a++) {
                        var r = t[a];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                return function(t, a, r) {
                    return a && e(t.prototype, a), r && e(t, r), t
                }
            }(),
            o = u(a(0)),
            i = u(a(9)),
            l = u(a(83)),
            c = u(a(46));

        function u(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var d = function(e) {
                return e.stopPropagation()
            },
            s = function(e) {
                function t() {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, t);
                    var e = function(e, t) {
                        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return !t || "object" !== typeof t && "function" !== typeof t ? e : t
                    }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                    return e.debounceTimeout = !1, e.hoverTimeout = !1, e.state = {
                        showTip: !1,
                        hasHover: !1,
                        ignoreShow: !1,
                        hasBeenShown: !1
                    }, e.showTip = e.showTip.bind(e), e.hideTip = e.hideTip.bind(e), e.checkHover = e.checkHover.bind(e), e.toggleTip = e.toggleTip.bind(e), e.startHover = e.startHover.bind(e), e.endHover = e.endHover.bind(e), e.listenResizeScroll = e.listenResizeScroll.bind(e), e.handleResizeScroll = e.handleResizeScroll.bind(e), e
                }
                return function(e, t) {
                    if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                }(t, o.default.Component), n(t, null, [{
                    key: "getDerivedStateFromProps",
                    value: function(e) {
                        return e.isOpen ? {
                            hasBeenShown: !0
                        } : null
                    }
                }]), n(t, [{
                    key: "componentDidMount",
                    value: function() {
                        this.props.isOpen && this.setState({
                            isOpen: !0
                        }), window.addEventListener("resize", this.listenResizeScroll), window.addEventListener("scroll", this.listenResizeScroll)
                    }
                }, {
                    key: "componentDidUpdate",
                    value: function(e, t) {
                        if (!this.state.hasBeenShown && this.props.isOpen) return this.setState({
                            hasBeenShown: !0
                        }), setTimeout(this.showTip, 0);
                        !t.hasBeenShown && this.state.hasBeenShown && this.showTip()
                    }
                }, {
                    key: "componentWillUnmount",
                    value: function() {
                        window.removeEventListener("resize", this.listenResizeScroll), window.removeEventListener("scroll", this.listenResizeScroll), clearTimeout(this.debounceTimeout)
                    }
                }, {
                    key: "listenResizeScroll",
                    value: function() {
                        clearTimeout(this.debounceTimeout), this.debounceTimeout = setTimeout(this.handleResizeScroll, 100)
                    }
                }, {
                    key: "handleResizeScroll",
                    value: function() {
                        if (this.state.showTip) {
                            var e = 5 * Math.round(document.documentElement.clientWidth / 5);
                            this.setState({
                                clientWidth: e
                            })
                        }
                    }
                }, {
                    key: "toggleTip",
                    value: function() {
                        this.state.showTip ? this.hideTip() : this.showTip()
                    }
                }, {
                    key: "showTip",
                    value: function() {
                        if (!this.state.hasBeenShown) return this.setState({
                            hasBeenShown: !0
                        });
                        this.setState({
                            showTip: !0
                        })
                    }
                }, {
                    key: "hideTip",
                    value: function() {
                        this.setState({
                            hasHover: !1
                        }), this.setState({
                            showTip: !1
                        })
                    }
                }, {
                    key: "startHover",
                    value: function() {
                        this.state.ignoreShow || (this.setState({
                            hasHover: !0
                        }), clearTimeout(this.hoverTimeout), this.hoverTimeout = setTimeout(this.checkHover, this.props.hoverDelay))
                    }
                }, {
                    key: "endHover",
                    value: function() {
                        this.setState({
                            hasHover: !1
                        }), clearTimeout(this.hoverTimeout), this.hoverTimeout = setTimeout(this.checkHover, this.props.hoverDelay)
                    }
                }, {
                    key: "checkHover",
                    value: function() {
                        this.state.hasHover ? this.showTip() : this.hideTip()
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this,
                            t = this.props,
                            a = t.arrow,
                            n = t.arrowSize,
                            i = t.background,
                            u = t.className,
                            s = t.children,
                            h = t.color,
                            p = t.content,
                            f = t.direction,
                            g = t.distance,
                            m = t.eventOff,
                            y = t.eventOn,
                            v = t.eventToggle,
                            b = t.forceDirection,
                            w = t.isOpen,
                            z = t.padding,
                            x = t.styles,
                            k = t.tagName,
                            M = t.tipContentHover,
                            A = t.tipContentClassName,
                            L = t.useDefaultStyles,
                            S = t.useHover,
                            O = !("undefined" === typeof w),
                            C = O ? w : this.state.showTip,
                            T = {
                                style: r({
                                    position: "relative"
                                }, x),
                                ref: function(t) {
                                    e.target = t
                                },
                                className: u
                            },
                            j = {
                                onClick: d
                            };
                        m && (T[m] = this.hideTip), y && (T[y] = this.showTip), v ? T[v] = this.toggleTip : S && !O && (T.onMouseOver = this.startHover, T.onMouseOut = M ? this.endHover : this.hideTip, T.onTouchStart = this.toggleTip, M && (j.onMouseOver = this.startHover, j.onMouseOut = this.endHover, j.onTouchStart = d));
                        var E = void 0;
                        if (this.state.hasBeenShown) {
                            var _ = (0, c.default)(f, b, this.tip, this.target, r({}, this.state, {
                                    showTip: C
                                }), {
                                    background: L ? "#333" : i,
                                    arrow: a,
                                    arrowSize: n,
                                    distance: g
                                }),
                                P = r({}, _.tip, {
                                    background: L ? "#333" : i,
                                    color: L ? "#fff" : h,
                                    padding: z,
                                    boxSizing: "border-box",
                                    zIndex: 1e3,
                                    position: "absolute",
                                    display: "inline-block"
                                }),
                                V = r({}, _.arrow, {
                                    position: "absolute",
                                    width: "0px",
                                    height: "0px",
                                    zIndex: 1001
                                });
                            E = o.default.createElement(l.default, null, o.default.createElement("div", r({}, j, {
                                className: "undefined" !== typeof A ? A : u
                            }), o.default.createElement("span", {
                                className: "react-tooltip-lite",
                                style: P,
                                ref: function(t) {
                                    e.tip = t
                                }
                            }, p), o.default.createElement("span", {
                                className: "react-tooltip-lite-arrow react-tooltip-lite-" + _.realDirection + "-arrow",
                                style: V
                            })))
                        }
                        return o.default.createElement(k, T, s, E)
                    }
                }]), t
            }();
        s.propTypes = {
            arrow: i.default.bool,
            arrowSize: i.default.number,
            background: i.default.string,
            children: i.default.node.isRequired,
            className: i.default.string,
            color: i.default.string,
            content: i.default.node.isRequired,
            direction: i.default.string,
            distance: i.default.number,
            eventOff: i.default.string,
            eventOn: i.default.string,
            eventToggle: i.default.string,
            forceDirection: i.default.bool,
            hoverDelay: i.default.number,
            isOpen: i.default.bool,
            padding: i.default.string,
            styles: i.default.object,
            tagName: i.default.string,
            tipContentHover: i.default.bool,
            tipContentClassName: i.default.string,
            useDefaultStyles: i.default.bool,
            useHover: i.default.bool
        }, s.defaultProps = {
            arrow: !0,
            arrowSize: 10,
            background: "",
            className: "",
            color: "",
            direction: "up",
            distance: void 0,
            forceDirection: !1,
            hoverDelay: 200,
            padding: "10px",
            styles: {},
            tagName: "div",
            tipContentHover: !1,
            tipContentClassName: void 0,
            useDefaultStyles: !1,
            useHover: !0
        }, t.default = s
    }, function(e, t, a) {
        "use strict";
        var r = {
                childContextTypes: !0,
                contextTypes: !0,
                defaultProps: !0,
                displayName: !0,
                getDefaultProps: !0,
                getDerivedStateFromProps: !0,
                mixins: !0,
                propTypes: !0,
                type: !0
            },
            n = {
                name: !0,
                length: !0,
                prototype: !0,
                caller: !0,
                callee: !0,
                arguments: !0,
                arity: !0
            },
            o = Object.defineProperty,
            i = Object.getOwnPropertyNames,
            l = Object.getOwnPropertySymbols,
            c = Object.getOwnPropertyDescriptor,
            u = Object.getPrototypeOf,
            d = u && u(Object);
        e.exports = function e(t, a, s) {
            if ("string" !== typeof a) {
                if (d) {
                    var h = u(a);
                    h && h !== d && e(t, h, s)
                }
                var p = i(a);
                l && (p = p.concat(l(a)));
                for (var f = 0; f < p.length; ++f) {
                    var g = p[f];
                    if (!r[g] && !n[g] && (!s || !s[g])) {
                        var m = c(a, g);
                        try {
                            o(t, g, m)
                        } catch (y) {}
                    }
                }
                return t
            }
            return t
        }
    }, function(e, t, a) {
        "use strict";

        function r(e) {
            var t, a = e.Symbol;
            return "function" === typeof a ? a.observable ? t = a.observable : (t = a("observable"), a.observable = t) : t = "@@observable", t
        }
        a.d(t, "a", function() {
            return r
        })
    }, function(e, t, a) {
        "use strict";
        a.d(t, "a", function() {
            return i
        }), a.d(t, "c", function() {
            return c
        }), a.d(t, "e", function() {
            return u
        }), a.d(t, "g", function() {
            return d
        }), a.d(t, "d", function() {
            return h
        }), a.d(t, "f", function() {
            return f
        }), a.d(t, "b", function() {
            return g
        });
        var r = a(1),
            n = a(4),
            o = a(11),
            i = Object(r.css)(["font-family:", ";font-size:", ";line-height:", ";font-weight:", ";", " box-sizing:border-box;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;"], function(e) {
                return e.theme.global.font.family
            }, function(e) {
                return e.theme.global.font.size
            }, function(e) {
                return e.theme.global.font.height
            }, function(e) {
                return e.theme.global.font.weight
            }, function(e) {
                return !e.plain && e.theme.global.colors.background && Object(r.css)(["background:", ";color:", ";"], Object(n.c)("background", e.theme, !0), Object(n.c)("text", e.theme, !0))
            }),
            l = Object(r.css)(["border:", " solid ", ";border-radius:", ";"], function(e) {
                return e.theme.global.control.border.width
            }, function(e) {
                return Object(n.c)(e.theme.global.control.border.color || "border", e.theme)
            }, function(e) {
                return e.theme.global.control.border.radius
            }),
            c = function(e, t, a, n, i) {
                var l = n && i.global.breakpoints[n];
                if ("string" === typeof t) return Object(r.css)(["", ":", ";", ";"], e, i.global.edgeSize[t] || t, a && l ? Object(o.a)(l, "\n        " + e + ": " + (l.edgeSize[t] || t) + ";\n      ") : "");
                var c = [];
                return t.horizontal && c.push(Object(r.css)(["", "-left:", ";", "-right:", ";", ";"], e, i.global.edgeSize[t.horizontal] || t.horizontal, e, i.global.edgeSize[t.horizontal] || t.horizontal, a && l ? Object(o.a)(l, "\n        " + e + "-left: " + (l.edgeSize[t.horizontal] || t.horizontal) + ";\n        " + e + "-right: " + (l.edgeSize[t.horizontal] || t.horizontal) + ";\n      ") : "")), t.vertical && c.push(Object(r.css)(["", "-top:", ";", "-bottom:", ";", ";"], e, i.global.edgeSize[t.vertical] || t.vertical, e, i.global.edgeSize[t.vertical] || t.vertical, a && l ? Object(o.a)(l, "\n        " + e + "-top: " + (l.edgeSize[t.vertical] || t.vertical) + ";\n        " + e + "-bottom: " + (l.edgeSize[t.vertical] || t.vertical) + ";\n      ") : "")), t.top && c.push(Object(r.css)(["", "-top:", ";", ";"], e, i.global.edgeSize[t.top] || t.top, a && l ? Object(o.a)(l, "\n        " + e + "-top: " + (l.edgeSize[t.top] || t.top) + ";\n      ") : "")), t.bottom && c.push(Object(r.css)(["", "-bottom:", ";", ";"], e, i.global.edgeSize[t.bottom] || t.bottom, a && l ? Object(o.a)(l, "\n        " + e + "-bottom: " + (l.edgeSize[t.bottom] || t.bottom) + ";\n      ") : "")), t.left && c.push(Object(r.css)(["", "-left:", ";", ";"], e, i.global.edgeSize[t.left] || t.left, a && l ? Object(o.a)(l, "\n        " + e + "-left: " + (l.edgeSize[t.left] || t.left) + ";\n      ") : "")), t.right && c.push(Object(r.css)(["", "-right:", ";", ";"], e, i.global.edgeSize[t.right] || t.right, a && l ? Object(o.a)(l, "\n        " + e + "-right: " + (l.edgeSize[t.right] || t.right) + ";\n      ") : "")), c
            },
            u = Object(r.css)(["> circle,> ellipse,> line,> path,> polygon,> polyline,> rect{outline:", " solid 2px;}border-color:", ";box-shadow:0 0 2px 2px ", ";::-moz-focus-inner{border:0;}"], function(e) {
                return Object(n.c)(e.theme.global.focus.border.color, e.theme)
            }, function(e) {
                return Object(n.c)(e.theme.global.focus.border.color, e.theme)
            }, function(e) {
                return Object(n.c)(e.theme.global.focus.border.color, e.theme)
            }),
            d = (Object(r.css)(["box-sizing:border-box;font-size:inherit;border:none;-webkit-appearance:none;padding:", "px;outline:none;background:transparent;color:inherit;", " margin:0;", " ", "::-webkit-search-decoration{-webkit-appearance:none;}"], function(e) {
                return Object(o.b)(e.theme.global.input.padding) - Object(o.b)(e.theme.global.control.border.width)
            }, function(e) {
                return e.theme.global.input.weight && Object(r.css)(["font-weight:", ";"], e.theme.global.input.weight)
            }, function(e) {
                return e.focus && (!e.plain || e.focusIndicator) && u
            }, l), function(e) {
                return "string" === typeof e ? Object(r.css)(["overflow:", ";"], e) : Object(r.css)(["", " ", ";"], e.horizontal && "overflow-x: " + e.horizontal + ";", e.vertical && "overflow-y: " + e.vertical + ";")
            }),
            s = Object(r.css)(["color:", ";"], function(e) {
                return e.theme.global.colors.placeholder
            }),
            h = (Object(r.css)(["&::-webkit-input-placeholder{", ";}&::-moz-placeholder{", ";}&:-ms-input-placeholder{", ";}"], s, s, s), function(e, t) {
                return e && Array.isArray(e) && "function" === typeof e[0] ? e[0]({
                    theme: t
                }) : e
            }),
            p = {
                center: "center",
                end: "flex-end",
                start: "flex-start",
                stretch: "stretch"
            },
            f = Object(r.css)(["", " ", " ", ""], function(e) {
                return e.alignSelf && "align-self: " + p[e.alignSelf] + ";"
            }, function(e) {
                return e.gridArea && "grid-area: " + e.gridArea + ";"
            }, function(e) {
                return e.margin && c("margin", e.margin, e.responsive, e.theme.global.edgeSize.responsiveBreakpoint, e.theme)
            }),
            g = function(e) {
                return Object(r.css)(["opacity:", ";cursor:default;"], function(t) {
                    return e || t.theme.global.control.disabled.opacity
                })
            }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0;
        var r = a(48);
        Object.keys(r).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = r[e])
        });
        var n = a(92);
        Object.keys(n).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = n[e])
        });
        var o = a(16);
        Object.keys(o).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = o[e])
        });
        var i = a(93);
        Object.keys(i).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = i[e])
        });
        var l = a(94);
        Object.keys(l).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = l[e])
        });
        var c = a(95);
        Object.keys(c).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = c[e])
        });
        var u = a(96);
        Object.keys(u).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = u[e])
        });
        var d = a(49);
        Object.keys(d).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = d[e])
        });
        var s = a(20);
        Object.keys(s).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = s[e])
        });
        var h = a(101);
        Object.keys(h).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = h[e])
        });
        var p = a(102);
        Object.keys(p).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = p[e])
        });
        var f = a(103);
        Object.keys(f).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = f[e])
        });
        var g = a(104);
        Object.keys(g).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (t[e] = g[e])
        })
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.dark = t.grommet = t.generate = t.base = void 0;
        var r = a(105);
        t.base = r.base, t.generate = r.generate;
        var n = a(106);
        t.grommet = n.grommet;
        var o = a(107);
        t.dark = o.dark
    }, function(e, t, a) {
        "use strict";

        function r(e, t) {
            return function(e) {
                if (Array.isArray(e)) return e
            }(e) || function(e, t) {
                var a = [],
                    r = !0,
                    n = !1,
                    o = void 0;
                try {
                    for (var i, l = e[Symbol.iterator](); !(r = (i = l.next()).done) && (a.push(i.value), !t || a.length !== t); r = !0);
                } catch (c) {
                    n = !0, o = c
                } finally {
                    try {
                        r || null == l.return || l.return()
                    } finally {
                        if (n) throw o
                    }
                }
                return a
            }(e, t) || function() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance")
            }()
        }
        a.d(t, "a", function() {
            return r
        })
    }, function(e, t, a) {
        "use strict";

        function r(e) {
            return (r = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                return typeof e
            } : function(e) {
                return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            })(e)
        }

        function n(e) {
            return (n = "function" === typeof Symbol && "symbol" === r(Symbol.iterator) ? function(e) {
                return r(e)
            } : function(e) {
                return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : r(e)
            })(e)
        }

        function o(e, t) {
            return !t || "object" !== n(t) && "function" !== typeof t ? function(e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e
            }(e) : t
        }
        a.d(t, "a", function() {
            return o
        })
    }, function(e, t, a) {
        "use strict";
        var r = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|default|defer|dir|disabled|download|draggable|encType|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|itemProp|itemScope|itemType|itemID|itemRef|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,
            n = function(e) {
                var t = {};
                return function(a) {
                    return void 0 === t[a] && (t[a] = e(a)), t[a]
                }
            }(function(e) {
                return r.test(e) || 111 === e.charCodeAt(0) && 110 === e.charCodeAt(1) && e.charCodeAt(2) < 91
            });
        t.a = n
    }, function(e, t, a) {
        "use strict";

        function r(e, t) {
            return (r = Object.setPrototypeOf || function(e, t) {
                return e.__proto__ = t, e
            })(e, t)
        }

        function n(e, t) {
            if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), t && r(e, t)
        }
        a.d(t, "a", function() {
            return n
        })
    }, , , function(e, t, a) {
        "use strict";
        var r = a(44),
            n = "function" === typeof Symbol && Symbol.for,
            o = n ? Symbol.for("react.element") : 60103,
            i = n ? Symbol.for("react.portal") : 60106,
            l = n ? Symbol.for("react.fragment") : 60107,
            c = n ? Symbol.for("react.strict_mode") : 60108,
            u = n ? Symbol.for("react.profiler") : 60114,
            d = n ? Symbol.for("react.provider") : 60109,
            s = n ? Symbol.for("react.context") : 60110,
            h = n ? Symbol.for("react.concurrent_mode") : 60111,
            p = n ? Symbol.for("react.forward_ref") : 60112,
            f = n ? Symbol.for("react.suspense") : 60113,
            g = n ? Symbol.for("react.memo") : 60115,
            m = n ? Symbol.for("react.lazy") : 60116,
            y = "function" === typeof Symbol && Symbol.iterator;

        function v(e) {
            for (var t = arguments.length - 1, a = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, r = 0; r < t; r++) a += "&args[]=" + encodeURIComponent(arguments[r + 1]);
            ! function(e, t, a, r, n, o, i, l) {
                if (!e) {
                    if (e = void 0, void 0 === t) e = Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                    else {
                        var c = [a, r, n, o, i, l],
                            u = 0;
                        (e = Error(t.replace(/%s/g, function() {
                            return c[u++]
                        }))).name = "Invariant Violation"
                    }
                    throw e.framesToPop = 1, e
                }
            }(!1, "Minified React error #" + e + "; visit %s for the full message or use the non-minified dev environment for full errors and additional helpful warnings. ", a)
        }
        var b = {
                isMounted: function() {
                    return !1
                },
                enqueueForceUpdate: function() {},
                enqueueReplaceState: function() {},
                enqueueSetState: function() {}
            },
            w = {};

        function z(e, t, a) {
            this.props = e, this.context = t, this.refs = w, this.updater = a || b
        }

        function x() {}

        function k(e, t, a) {
            this.props = e, this.context = t, this.refs = w, this.updater = a || b
        }
        z.prototype.isReactComponent = {}, z.prototype.setState = function(e, t) {
            "object" !== typeof e && "function" !== typeof e && null != e && v("85"), this.updater.enqueueSetState(this, e, t, "setState")
        }, z.prototype.forceUpdate = function(e) {
            this.updater.enqueueForceUpdate(this, e, "forceUpdate")
        }, x.prototype = z.prototype;
        var M = k.prototype = new x;
        M.constructor = k, r(M, z.prototype), M.isPureReactComponent = !0;
        var A = {
                current: null
            },
            L = {
                current: null
            },
            S = Object.prototype.hasOwnProperty,
            O = {
                key: !0,
                ref: !0,
                __self: !0,
                __source: !0
            };

        function C(e, t, a) {
            var r = void 0,
                n = {},
                i = null,
                l = null;
            if (null != t)
                for (r in void 0 !== t.ref && (l = t.ref), void 0 !== t.key && (i = "" + t.key), t) S.call(t, r) && !O.hasOwnProperty(r) && (n[r] = t[r]);
            var c = arguments.length - 2;
            if (1 === c) n.children = a;
            else if (1 < c) {
                for (var u = Array(c), d = 0; d < c; d++) u[d] = arguments[d + 2];
                n.children = u
            }
            if (e && e.defaultProps)
                for (r in c = e.defaultProps) void 0 === n[r] && (n[r] = c[r]);
            return {
                $$typeof: o,
                type: e,
                key: i,
                ref: l,
                props: n,
                _owner: L.current
            }
        }

        function T(e) {
            return "object" === typeof e && null !== e && e.$$typeof === o
        }
        var j = /\/+/g,
            E = [];

        function _(e, t, a, r) {
            if (E.length) {
                var n = E.pop();
                return n.result = e, n.keyPrefix = t, n.func = a, n.context = r, n.count = 0, n
            }
            return {
                result: e,
                keyPrefix: t,
                func: a,
                context: r,
                count: 0
            }
        }

        function P(e) {
            e.result = null, e.keyPrefix = null, e.func = null, e.context = null, e.count = 0, 10 > E.length && E.push(e)
        }

        function V(e, t, a) {
            return null == e ? 0 : function e(t, a, r, n) {
                var l = typeof t;
                "undefined" !== l && "boolean" !== l || (t = null);
                var c = !1;
                if (null === t) c = !0;
                else switch (l) {
                    case "string":
                    case "number":
                        c = !0;
                        break;
                    case "object":
                        switch (t.$$typeof) {
                            case o:
                            case i:
                                c = !0
                        }
                }
                if (c) return r(n, t, "" === a ? "." + H(t, 0) : a), 1;
                if (c = 0, a = "" === a ? "." : a + ":", Array.isArray(t))
                    for (var u = 0; u < t.length; u++) {
                        var d = a + H(l = t[u], u);
                        c += e(l, d, r, n)
                    } else if (d = null === t || "object" !== typeof t ? null : "function" === typeof(d = y && t[y] || t["@@iterator"]) ? d : null, "function" === typeof d)
                        for (t = d.call(t), u = 0; !(l = t.next()).done;) c += e(l = l.value, d = a + H(l, u++), r, n);
                    else "object" === l && v("31", "[object Object]" === (r = "" + t) ? "object with keys {" + Object.keys(t).join(", ") + "}" : r, "");
                return c
            }(e, "", t, a)
        }

        function H(e, t) {
            return "object" === typeof e && null !== e && null != e.key ? function(e) {
                var t = {
                    "=": "=0",
                    ":": "=2"
                };
                return "$" + ("" + e).replace(/[=:]/g, function(e) {
                    return t[e]
                })
            }(e.key) : t.toString(36)
        }

        function I(e, t) {
            e.func.call(e.context, t, e.count++)
        }

        function F(e, t, a) {
            var r = e.result,
                n = e.keyPrefix;
            e = e.func.call(e.context, t, e.count++), Array.isArray(e) ? R(e, r, a, function(e) {
                return e
            }) : null != e && (T(e) && (e = function(e, t) {
                return {
                    $$typeof: o,
                    type: e.type,
                    key: t,
                    ref: e.ref,
                    props: e.props,
                    _owner: e._owner
                }
            }(e, n + (!e.key || t && t.key === e.key ? "" : ("" + e.key).replace(j, "$&/") + "/") + a)), r.push(e))
        }

        function R(e, t, a, r, n) {
            var o = "";
            null != a && (o = ("" + a).replace(j, "$&/") + "/"), V(e, F, t = _(t, o, r, n)), P(t)
        }

        function N() {
            var e = A.current;
            return null === e && v("321"), e
        }
        var D = {
                Children: {
                    map: function(e, t, a) {
                        if (null == e) return e;
                        var r = [];
                        return R(e, r, null, t, a), r
                    },
                    forEach: function(e, t, a) {
                        if (null == e) return e;
                        V(e, I, t = _(null, null, t, a)), P(t)
                    },
                    count: function(e) {
                        return V(e, function() {
                            return null
                        }, null)
                    },
                    toArray: function(e) {
                        var t = [];
                        return R(e, t, null, function(e) {
                            return e
                        }), t
                    },
                    only: function(e) {
                        return T(e) || v("143"), e
                    }
                },
                createRef: function() {
                    return {
                        current: null
                    }
                },
                Component: z,
                PureComponent: k,
                createContext: function(e, t) {
                    return void 0 === t && (t = null), (e = {
                        $$typeof: s,
                        _calculateChangedBits: t,
                        _currentValue: e,
                        _currentValue2: e,
                        _threadCount: 0,
                        Provider: null,
                        Consumer: null
                    }).Provider = {
                        $$typeof: d,
                        _context: e
                    }, e.Consumer = e
                },
                forwardRef: function(e) {
                    return {
                        $$typeof: p,
                        render: e
                    }
                },
                lazy: function(e) {
                    return {
                        $$typeof: m,
                        _ctor: e,
                        _status: -1,
                        _result: null
                    }
                },
                memo: function(e, t) {
                    return {
                        $$typeof: g,
                        type: e,
                        compare: void 0 === t ? null : t
                    }
                },
                useCallback: function(e, t) {
                    return N().useCallback(e, t)
                },
                useContext: function(e, t) {
                    return N().useContext(e, t)
                },
                useEffect: function(e, t) {
                    return N().useEffect(e, t)
                },
                useImperativeHandle: function(e, t, a) {
                    return N().useImperativeHandle(e, t, a)
                },
                useDebugValue: function() {},
                useLayoutEffect: function(e, t) {
                    return N().useLayoutEffect(e, t)
                },
                useMemo: function(e, t) {
                    return N().useMemo(e, t)
                },
                useReducer: function(e, t, a) {
                    return N().useReducer(e, t, a)
                },
                useRef: function(e) {
                    return N().useRef(e)
                },
                useState: function(e) {
                    return N().useState(e)
                },
                Fragment: l,
                StrictMode: c,
                Suspense: f,
                createElement: C,
                cloneElement: function(e, t, a) {
                    (null === e || void 0 === e) && v("267", e);
                    var n = void 0,
                        i = r({}, e.props),
                        l = e.key,
                        c = e.ref,
                        u = e._owner;
                    if (null != t) {
                        void 0 !== t.ref && (c = t.ref, u = L.current), void 0 !== t.key && (l = "" + t.key);
                        var d = void 0;
                        for (n in e.type && e.type.defaultProps && (d = e.type.defaultProps), t) S.call(t, n) && !O.hasOwnProperty(n) && (i[n] = void 0 === t[n] && void 0 !== d ? d[n] : t[n])
                    }
                    if (1 === (n = arguments.length - 2)) i.children = a;
                    else if (1 < n) {
                        d = Array(n);
                        for (var s = 0; s < n; s++) d[s] = arguments[s + 2];
                        i.children = d
                    }
                    return {
                        $$typeof: o,
                        type: e.type,
                        key: l,
                        ref: c,
                        props: i,
                        _owner: u
                    }
                },
                createFactory: function(e) {
                    var t = C.bind(null, e);
                    return t.type = e, t
                },
                isValidElement: T,
                version: "16.8.6",
                unstable_ConcurrentMode: h,
                unstable_Profiler: u,
                __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: {
                    ReactCurrentDispatcher: A,
                    ReactCurrentOwner: L,
                    assign: r
                }
            },
            U = {
                default: D
            },
            B = U && D || U;
        e.exports = B.default || B
    }, function(e, t, a) {
        "use strict";
        var r = a(0),
            n = a(44),
            o = a(74);

        function i(e) {
            for (var t = arguments.length - 1, a = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, r = 0; r < t; r++) a += "&args[]=" + encodeURIComponent(arguments[r + 1]);
            ! function(e, t, a, r, n, o, i, l) {
                if (!e) {
                    if (e = void 0, void 0 === t) e = Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                    else {
                        var c = [a, r, n, o, i, l],
                            u = 0;
                        (e = Error(t.replace(/%s/g, function() {
                            return c[u++]
                        }))).name = "Invariant Violation"
                    }
                    throw e.framesToPop = 1, e
                }
            }(!1, "Minified React error #" + e + "; visit %s for the full message or use the non-minified dev environment for full errors and additional helpful warnings. ", a)
        }
        r || i("227");
        var l = !1,
            c = null,
            u = !1,
            d = null,
            s = {
                onError: function(e) {
                    l = !0, c = e
                }
            };

        function h(e, t, a, r, n, o, i, u, d) {
            l = !1, c = null,
                function(e, t, a, r, n, o, i, l, c) {
                    var u = Array.prototype.slice.call(arguments, 3);
                    try {
                        t.apply(a, u)
                    } catch (d) {
                        this.onError(d)
                    }
                }.apply(s, arguments)
        }
        var p = null,
            f = {};

        function g() {
            if (p)
                for (var e in f) {
                    var t = f[e],
                        a = p.indexOf(e);
                    if (-1 < a || i("96", e), !y[a])
                        for (var r in t.extractEvents || i("97", e), y[a] = t, a = t.eventTypes) {
                            var n = void 0,
                                o = a[r],
                                l = t,
                                c = r;
                            v.hasOwnProperty(c) && i("99", c), v[c] = o;
                            var u = o.phasedRegistrationNames;
                            if (u) {
                                for (n in u) u.hasOwnProperty(n) && m(u[n], l, c);
                                n = !0
                            } else o.registrationName ? (m(o.registrationName, l, c), n = !0) : n = !1;
                            n || i("98", r, e)
                        }
                }
        }

        function m(e, t, a) {
            b[e] && i("100", e), b[e] = t, w[e] = t.eventTypes[a].dependencies
        }
        var y = [],
            v = {},
            b = {},
            w = {},
            z = null,
            x = null,
            k = null;

        function M(e, t, a) {
            var r = e.type || "unknown-event";
            e.currentTarget = k(a),
                function(e, t, a, r, n, o, s, p, f) {
                    if (h.apply(this, arguments), l) {
                        if (l) {
                            var g = c;
                            l = !1, c = null
                        } else i("198"), g = void 0;
                        u || (u = !0, d = g)
                    }
                }(r, t, void 0, e), e.currentTarget = null
        }

        function A(e, t) {
            return null == t && i("30"), null == e ? t : Array.isArray(e) ? Array.isArray(t) ? (e.push.apply(e, t), e) : (e.push(t), e) : Array.isArray(t) ? [e].concat(t) : [e, t]
        }

        function L(e, t, a) {
            Array.isArray(e) ? e.forEach(t, a) : e && t.call(a, e)
        }
        var S = null;

        function O(e) {
            if (e) {
                var t = e._dispatchListeners,
                    a = e._dispatchInstances;
                if (Array.isArray(t))
                    for (var r = 0; r < t.length && !e.isPropagationStopped(); r++) M(e, t[r], a[r]);
                else t && M(e, t, a);
                e._dispatchListeners = null, e._dispatchInstances = null, e.isPersistent() || e.constructor.release(e)
            }
        }
        var C = {
            injectEventPluginOrder: function(e) {
                p && i("101"), p = Array.prototype.slice.call(e), g()
            },
            injectEventPluginsByName: function(e) {
                var t, a = !1;
                for (t in e)
                    if (e.hasOwnProperty(t)) {
                        var r = e[t];
                        f.hasOwnProperty(t) && f[t] === r || (f[t] && i("102", t), f[t] = r, a = !0)
                    }
                a && g()
            }
        };

        function T(e, t) {
            var a = e.stateNode;
            if (!a) return null;
            var r = z(a);
            if (!r) return null;
            a = r[t];
            e: switch (t) {
                case "onClick":
                case "onClickCapture":
                case "onDoubleClick":
                case "onDoubleClickCapture":
                case "onMouseDown":
                case "onMouseDownCapture":
                case "onMouseMove":
                case "onMouseMoveCapture":
                case "onMouseUp":
                case "onMouseUpCapture":
                    (r = !r.disabled) || (r = !("button" === (e = e.type) || "input" === e || "select" === e || "textarea" === e)), e = !r;
                    break e;
                default:
                    e = !1
            }
            return e ? null : (a && "function" !== typeof a && i("231", t, typeof a), a)
        }

        function j(e) {
            if (null !== e && (S = A(S, e)), e = S, S = null, e && (L(e, O), S && i("95"), u)) throw e = d, u = !1, d = null, e
        }
        var E = Math.random().toString(36).slice(2),
            _ = "__reactInternalInstance$" + E,
            P = "__reactEventHandlers$" + E;

        function V(e) {
            if (e[_]) return e[_];
            for (; !e[_];) {
                if (!e.parentNode) return null;
                e = e.parentNode
            }
            return 5 === (e = e[_]).tag || 6 === e.tag ? e : null
        }

        function H(e) {
            return !(e = e[_]) || 5 !== e.tag && 6 !== e.tag ? null : e
        }

        function I(e) {
            if (5 === e.tag || 6 === e.tag) return e.stateNode;
            i("33")
        }

        function F(e) {
            return e[P] || null
        }

        function R(e) {
            do {
                e = e.return
            } while (e && 5 !== e.tag);
            return e || null
        }

        function N(e, t, a) {
            (t = T(e, a.dispatchConfig.phasedRegistrationNames[t])) && (a._dispatchListeners = A(a._dispatchListeners, t), a._dispatchInstances = A(a._dispatchInstances, e))
        }

        function D(e) {
            if (e && e.dispatchConfig.phasedRegistrationNames) {
                for (var t = e._targetInst, a = []; t;) a.push(t), t = R(t);
                for (t = a.length; 0 < t--;) N(a[t], "captured", e);
                for (t = 0; t < a.length; t++) N(a[t], "bubbled", e)
            }
        }

        function U(e, t, a) {
            e && a && a.dispatchConfig.registrationName && (t = T(e, a.dispatchConfig.registrationName)) && (a._dispatchListeners = A(a._dispatchListeners, t), a._dispatchInstances = A(a._dispatchInstances, e))
        }

        function B(e) {
            e && e.dispatchConfig.registrationName && U(e._targetInst, null, e)
        }

        function W(e) {
            L(e, D)
        }
        var $ = !("undefined" === typeof window || !window.document || !window.document.createElement);

        function q(e, t) {
            var a = {};
            return a[e.toLowerCase()] = t.toLowerCase(), a["Webkit" + e] = "webkit" + t, a["Moz" + e] = "moz" + t, a
        }
        var Q = {
                animationend: q("Animation", "AnimationEnd"),
                animationiteration: q("Animation", "AnimationIteration"),
                animationstart: q("Animation", "AnimationStart"),
                transitionend: q("Transition", "TransitionEnd")
            },
            Y = {},
            G = {};

        function K(e) {
            if (Y[e]) return Y[e];
            if (!Q[e]) return e;
            var t, a = Q[e];
            for (t in a)
                if (a.hasOwnProperty(t) && t in G) return Y[e] = a[t];
            return e
        }
        $ && (G = document.createElement("div").style, "AnimationEvent" in window || (delete Q.animationend.animation, delete Q.animationiteration.animation, delete Q.animationstart.animation), "TransitionEvent" in window || delete Q.transitionend.transition);
        var X = K("animationend"),
            Z = K("animationiteration"),
            J = K("animationstart"),
            ee = K("transitionend"),
            te = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
            ae = null,
            re = null,
            ne = null;

        function oe() {
            if (ne) return ne;
            var e, t, a = re,
                r = a.length,
                n = "value" in ae ? ae.value : ae.textContent,
                o = n.length;
            for (e = 0; e < r && a[e] === n[e]; e++);
            var i = r - e;
            for (t = 1; t <= i && a[r - t] === n[o - t]; t++);
            return ne = n.slice(e, 1 < t ? 1 - t : void 0)
        }

        function ie() {
            return !0
        }

        function le() {
            return !1
        }

        function ce(e, t, a, r) {
            for (var n in this.dispatchConfig = e, this._targetInst = t, this.nativeEvent = a, e = this.constructor.Interface) e.hasOwnProperty(n) && ((t = e[n]) ? this[n] = t(a) : "target" === n ? this.target = r : this[n] = a[n]);
            return this.isDefaultPrevented = (null != a.defaultPrevented ? a.defaultPrevented : !1 === a.returnValue) ? ie : le, this.isPropagationStopped = le, this
        }

        function ue(e, t, a, r) {
            if (this.eventPool.length) {
                var n = this.eventPool.pop();
                return this.call(n, e, t, a, r), n
            }
            return new this(e, t, a, r)
        }

        function de(e) {
            e instanceof this || i("279"), e.destructor(), 10 > this.eventPool.length && this.eventPool.push(e)
        }

        function se(e) {
            e.eventPool = [], e.getPooled = ue, e.release = de
        }
        n(ce.prototype, {
            preventDefault: function() {
                this.defaultPrevented = !0;
                var e = this.nativeEvent;
                e && (e.preventDefault ? e.preventDefault() : "unknown" !== typeof e.returnValue && (e.returnValue = !1), this.isDefaultPrevented = ie)
            },
            stopPropagation: function() {
                var e = this.nativeEvent;
                e && (e.stopPropagation ? e.stopPropagation() : "unknown" !== typeof e.cancelBubble && (e.cancelBubble = !0), this.isPropagationStopped = ie)
            },
            persist: function() {
                this.isPersistent = ie
            },
            isPersistent: le,
            destructor: function() {
                var e, t = this.constructor.Interface;
                for (e in t) this[e] = null;
                this.nativeEvent = this._targetInst = this.dispatchConfig = null, this.isPropagationStopped = this.isDefaultPrevented = le, this._dispatchInstances = this._dispatchListeners = null
            }
        }), ce.Interface = {
            type: null,
            target: null,
            currentTarget: function() {
                return null
            },
            eventPhase: null,
            bubbles: null,
            cancelable: null,
            timeStamp: function(e) {
                return e.timeStamp || Date.now()
            },
            defaultPrevented: null,
            isTrusted: null
        }, ce.extend = function(e) {
            function t() {}

            function a() {
                return r.apply(this, arguments)
            }
            var r = this;
            t.prototype = r.prototype;
            var o = new t;
            return n(o, a.prototype), a.prototype = o, a.prototype.constructor = a, a.Interface = n({}, r.Interface, e), a.extend = r.extend, se(a), a
        }, se(ce);
        var he = ce.extend({
                data: null
            }),
            pe = ce.extend({
                data: null
            }),
            fe = [9, 13, 27, 32],
            ge = $ && "CompositionEvent" in window,
            me = null;
        $ && "documentMode" in document && (me = document.documentMode);
        var ye = $ && "TextEvent" in window && !me,
            ve = $ && (!ge || me && 8 < me && 11 >= me),
            be = String.fromCharCode(32),
            we = {
                beforeInput: {
                    phasedRegistrationNames: {
                        bubbled: "onBeforeInput",
                        captured: "onBeforeInputCapture"
                    },
                    dependencies: ["compositionend", "keypress", "textInput", "paste"]
                },
                compositionEnd: {
                    phasedRegistrationNames: {
                        bubbled: "onCompositionEnd",
                        captured: "onCompositionEndCapture"
                    },
                    dependencies: "blur compositionend keydown keypress keyup mousedown".split(" ")
                },
                compositionStart: {
                    phasedRegistrationNames: {
                        bubbled: "onCompositionStart",
                        captured: "onCompositionStartCapture"
                    },
                    dependencies: "blur compositionstart keydown keypress keyup mousedown".split(" ")
                },
                compositionUpdate: {
                    phasedRegistrationNames: {
                        bubbled: "onCompositionUpdate",
                        captured: "onCompositionUpdateCapture"
                    },
                    dependencies: "blur compositionupdate keydown keypress keyup mousedown".split(" ")
                }
            },
            ze = !1;

        function xe(e, t) {
            switch (e) {
                case "keyup":
                    return -1 !== fe.indexOf(t.keyCode);
                case "keydown":
                    return 229 !== t.keyCode;
                case "keypress":
                case "mousedown":
                case "blur":
                    return !0;
                default:
                    return !1
            }
        }

        function ke(e) {
            return "object" === typeof(e = e.detail) && "data" in e ? e.data : null
        }
        var Me = !1;
        var Ae = {
                eventTypes: we,
                extractEvents: function(e, t, a, r) {
                    var n = void 0,
                        o = void 0;
                    if (ge) e: {
                        switch (e) {
                            case "compositionstart":
                                n = we.compositionStart;
                                break e;
                            case "compositionend":
                                n = we.compositionEnd;
                                break e;
                            case "compositionupdate":
                                n = we.compositionUpdate;
                                break e
                        }
                        n = void 0
                    }
                    else Me ? xe(e, a) && (n = we.compositionEnd) : "keydown" === e && 229 === a.keyCode && (n = we.compositionStart);
                    return n ? (ve && "ko" !== a.locale && (Me || n !== we.compositionStart ? n === we.compositionEnd && Me && (o = oe()) : (re = "value" in (ae = r) ? ae.value : ae.textContent, Me = !0)), n = he.getPooled(n, t, a, r), o ? n.data = o : null !== (o = ke(a)) && (n.data = o), W(n), o = n) : o = null, (e = ye ? function(e, t) {
                        switch (e) {
                            case "compositionend":
                                return ke(t);
                            case "keypress":
                                return 32 !== t.which ? null : (ze = !0, be);
                            case "textInput":
                                return (e = t.data) === be && ze ? null : e;
                            default:
                                return null
                        }
                    }(e, a) : function(e, t) {
                        if (Me) return "compositionend" === e || !ge && xe(e, t) ? (e = oe(), ne = re = ae = null, Me = !1, e) : null;
                        switch (e) {
                            case "paste":
                                return null;
                            case "keypress":
                                if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                                    if (t.char && 1 < t.char.length) return t.char;
                                    if (t.which) return String.fromCharCode(t.which)
                                }
                                return null;
                            case "compositionend":
                                return ve && "ko" !== t.locale ? null : t.data;
                            default:
                                return null
                        }
                    }(e, a)) ? ((t = pe.getPooled(we.beforeInput, t, a, r)).data = e, W(t)) : t = null, null === o ? t : null === t ? o : [o, t]
                }
            },
            Le = null,
            Se = null,
            Oe = null;

        function Ce(e) {
            if (e = x(e)) {
                "function" !== typeof Le && i("280");
                var t = z(e.stateNode);
                Le(e.stateNode, e.type, t)
            }
        }

        function Te(e) {
            Se ? Oe ? Oe.push(e) : Oe = [e] : Se = e
        }

        function je() {
            if (Se) {
                var e = Se,
                    t = Oe;
                if (Oe = Se = null, Ce(e), t)
                    for (e = 0; e < t.length; e++) Ce(t[e])
            }
        }

        function Ee(e, t) {
            return e(t)
        }

        function _e(e, t, a) {
            return e(t, a)
        }

        function Pe() {}
        var Ve = !1;

        function He(e, t) {
            if (Ve) return e(t);
            Ve = !0;
            try {
                return Ee(e, t)
            } finally {
                Ve = !1, (null !== Se || null !== Oe) && (Pe(), je())
            }
        }
        var Ie = {
            color: !0,
            date: !0,
            datetime: !0,
            "datetime-local": !0,
            email: !0,
            month: !0,
            number: !0,
            password: !0,
            range: !0,
            search: !0,
            tel: !0,
            text: !0,
            time: !0,
            url: !0,
            week: !0
        };

        function Fe(e) {
            var t = e && e.nodeName && e.nodeName.toLowerCase();
            return "input" === t ? !!Ie[e.type] : "textarea" === t
        }

        function Re(e) {
            return (e = e.target || e.srcElement || window).correspondingUseElement && (e = e.correspondingUseElement), 3 === e.nodeType ? e.parentNode : e
        }

        function Ne(e) {
            if (!$) return !1;
            var t = (e = "on" + e) in document;
            return t || ((t = document.createElement("div")).setAttribute(e, "return;"), t = "function" === typeof t[e]), t
        }

        function De(e) {
            var t = e.type;
            return (e = e.nodeName) && "input" === e.toLowerCase() && ("checkbox" === t || "radio" === t)
        }

        function Ue(e) {
            e._valueTracker || (e._valueTracker = function(e) {
                var t = De(e) ? "checked" : "value",
                    a = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
                    r = "" + e[t];
                if (!e.hasOwnProperty(t) && "undefined" !== typeof a && "function" === typeof a.get && "function" === typeof a.set) {
                    var n = a.get,
                        o = a.set;
                    return Object.defineProperty(e, t, {
                        configurable: !0,
                        get: function() {
                            return n.call(this)
                        },
                        set: function(e) {
                            r = "" + e, o.call(this, e)
                        }
                    }), Object.defineProperty(e, t, {
                        enumerable: a.enumerable
                    }), {
                        getValue: function() {
                            return r
                        },
                        setValue: function(e) {
                            r = "" + e
                        },
                        stopTracking: function() {
                            e._valueTracker = null, delete e[t]
                        }
                    }
                }
            }(e))
        }

        function Be(e) {
            if (!e) return !1;
            var t = e._valueTracker;
            if (!t) return !0;
            var a = t.getValue(),
                r = "";
            return e && (r = De(e) ? e.checked ? "true" : "false" : e.value), (e = r) !== a && (t.setValue(e), !0)
        }
        var We = r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
        We.hasOwnProperty("ReactCurrentDispatcher") || (We.ReactCurrentDispatcher = {
            current: null
        });
        var $e = /^(.*)[\\\/]/,
            qe = "function" === typeof Symbol && Symbol.for,
            Qe = qe ? Symbol.for("react.element") : 60103,
            Ye = qe ? Symbol.for("react.portal") : 60106,
            Ge = qe ? Symbol.for("react.fragment") : 60107,
            Ke = qe ? Symbol.for("react.strict_mode") : 60108,
            Xe = qe ? Symbol.for("react.profiler") : 60114,
            Ze = qe ? Symbol.for("react.provider") : 60109,
            Je = qe ? Symbol.for("react.context") : 60110,
            et = qe ? Symbol.for("react.concurrent_mode") : 60111,
            tt = qe ? Symbol.for("react.forward_ref") : 60112,
            at = qe ? Symbol.for("react.suspense") : 60113,
            rt = qe ? Symbol.for("react.memo") : 60115,
            nt = qe ? Symbol.for("react.lazy") : 60116,
            ot = "function" === typeof Symbol && Symbol.iterator;

        function it(e) {
            return null === e || "object" !== typeof e ? null : "function" === typeof(e = ot && e[ot] || e["@@iterator"]) ? e : null
        }

        function lt(e) {
            if (null == e) return null;
            if ("function" === typeof e) return e.displayName || e.name || null;
            if ("string" === typeof e) return e;
            switch (e) {
                case et:
                    return "ConcurrentMode";
                case Ge:
                    return "Fragment";
                case Ye:
                    return "Portal";
                case Xe:
                    return "Profiler";
                case Ke:
                    return "StrictMode";
                case at:
                    return "Suspense"
            }
            if ("object" === typeof e) switch (e.$$typeof) {
                case Je:
                    return "Context.Consumer";
                case Ze:
                    return "Context.Provider";
                case tt:
                    var t = e.render;
                    return t = t.displayName || t.name || "", e.displayName || ("" !== t ? "ForwardRef(" + t + ")" : "ForwardRef");
                case rt:
                    return lt(e.type);
                case nt:
                    if (e = 1 === e._status ? e._result : null) return lt(e)
            }
            return null
        }

        function ct(e) {
            var t = "";
            do {
                e: switch (e.tag) {
                    case 3:
                    case 4:
                    case 6:
                    case 7:
                    case 10:
                    case 9:
                        var a = "";
                        break e;
                    default:
                        var r = e._debugOwner,
                            n = e._debugSource,
                            o = lt(e.type);
                        a = null, r && (a = lt(r.type)), r = o, o = "", n ? o = " (at " + n.fileName.replace($e, "") + ":" + n.lineNumber + ")" : a && (o = " (created by " + a + ")"), a = "\n    in " + (r || "Unknown") + o
                }
                t += a,
                e = e.return
            } while (e);
            return t
        }
        var ut = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
            dt = Object.prototype.hasOwnProperty,
            st = {},
            ht = {};

        function pt(e, t, a, r, n) {
            this.acceptsBooleans = 2 === t || 3 === t || 4 === t, this.attributeName = r, this.attributeNamespace = n, this.mustUseProperty = a, this.propertyName = e, this.type = t
        }
        var ft = {};
        "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
            ft[e] = new pt(e, 0, !1, e, null)
        }), [
            ["acceptCharset", "accept-charset"],
            ["className", "class"],
            ["htmlFor", "for"],
            ["httpEquiv", "http-equiv"]
        ].forEach(function(e) {
            var t = e[0];
            ft[t] = new pt(t, 1, !1, e[1], null)
        }), ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
            ft[e] = new pt(e, 2, !1, e.toLowerCase(), null)
        }), ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
            ft[e] = new pt(e, 2, !1, e, null)
        }), "allowFullScreen async autoFocus autoPlay controls default defer disabled formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
            ft[e] = new pt(e, 3, !1, e.toLowerCase(), null)
        }), ["checked", "multiple", "muted", "selected"].forEach(function(e) {
            ft[e] = new pt(e, 3, !0, e, null)
        }), ["capture", "download"].forEach(function(e) {
            ft[e] = new pt(e, 4, !1, e, null)
        }), ["cols", "rows", "size", "span"].forEach(function(e) {
            ft[e] = new pt(e, 6, !1, e, null)
        }), ["rowSpan", "start"].forEach(function(e) {
            ft[e] = new pt(e, 5, !1, e.toLowerCase(), null)
        });
        var gt = /[\-:]([a-z])/g;

        function mt(e) {
            return e[1].toUpperCase()
        }

        function yt(e, t, a, r) {
            var n = ft.hasOwnProperty(t) ? ft[t] : null;
            (null !== n ? 0 === n.type : !r && (2 < t.length && ("o" === t[0] || "O" === t[0]) && ("n" === t[1] || "N" === t[1]))) || (function(e, t, a, r) {
                if (null === t || "undefined" === typeof t || function(e, t, a, r) {
                        if (null !== a && 0 === a.type) return !1;
                        switch (typeof t) {
                            case "function":
                            case "symbol":
                                return !0;
                            case "boolean":
                                return !r && (null !== a ? !a.acceptsBooleans : "data-" !== (e = e.toLowerCase().slice(0, 5)) && "aria-" !== e);
                            default:
                                return !1
                        }
                    }(e, t, a, r)) return !0;
                if (r) return !1;
                if (null !== a) switch (a.type) {
                    case 3:
                        return !t;
                    case 4:
                        return !1 === t;
                    case 5:
                        return isNaN(t);
                    case 6:
                        return isNaN(t) || 1 > t
                }
                return !1
            }(t, a, n, r) && (a = null), r || null === n ? function(e) {
                return !!dt.call(ht, e) || !dt.call(st, e) && (ut.test(e) ? ht[e] = !0 : (st[e] = !0, !1))
            }(t) && (null === a ? e.removeAttribute(t) : e.setAttribute(t, "" + a)) : n.mustUseProperty ? e[n.propertyName] = null === a ? 3 !== n.type && "" : a : (t = n.attributeName, r = n.attributeNamespace, null === a ? e.removeAttribute(t) : (a = 3 === (n = n.type) || 4 === n && !0 === a ? "" : "" + a, r ? e.setAttributeNS(r, t, a) : e.setAttribute(t, a))))
        }

        function vt(e) {
            switch (typeof e) {
                case "boolean":
                case "number":
                case "object":
                case "string":
                case "undefined":
                    return e;
                default:
                    return ""
            }
        }

        function bt(e, t) {
            var a = t.checked;
            return n({}, t, {
                defaultChecked: void 0,
                defaultValue: void 0,
                value: void 0,
                checked: null != a ? a : e._wrapperState.initialChecked
            })
        }

        function wt(e, t) {
            var a = null == t.defaultValue ? "" : t.defaultValue,
                r = null != t.checked ? t.checked : t.defaultChecked;
            a = vt(null != t.value ? t.value : a), e._wrapperState = {
                initialChecked: r,
                initialValue: a,
                controlled: "checkbox" === t.type || "radio" === t.type ? null != t.checked : null != t.value
            }
        }

        function zt(e, t) {
            null != (t = t.checked) && yt(e, "checked", t, !1)
        }

        function xt(e, t) {
            zt(e, t);
            var a = vt(t.value),
                r = t.type;
            if (null != a) "number" === r ? (0 === a && "" === e.value || e.value != a) && (e.value = "" + a) : e.value !== "" + a && (e.value = "" + a);
            else if ("submit" === r || "reset" === r) return void e.removeAttribute("value");
            t.hasOwnProperty("value") ? Mt(e, t.type, a) : t.hasOwnProperty("defaultValue") && Mt(e, t.type, vt(t.defaultValue)), null == t.checked && null != t.defaultChecked && (e.defaultChecked = !!t.defaultChecked)
        }

        function kt(e, t, a) {
            if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
                var r = t.type;
                if (!("submit" !== r && "reset" !== r || void 0 !== t.value && null !== t.value)) return;
                t = "" + e._wrapperState.initialValue, a || t === e.value || (e.value = t), e.defaultValue = t
            }
            "" !== (a = e.name) && (e.name = ""), e.defaultChecked = !e.defaultChecked, e.defaultChecked = !!e._wrapperState.initialChecked, "" !== a && (e.name = a)
        }

        function Mt(e, t, a) {
            "number" === t && e.ownerDocument.activeElement === e || (null == a ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + a && (e.defaultValue = "" + a))
        }
        "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
            var t = e.replace(gt, mt);
            ft[t] = new pt(t, 1, !1, e, null)
        }), "xlink:actuate xlink:arcrole xlink:href xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
            var t = e.replace(gt, mt);
            ft[t] = new pt(t, 1, !1, e, "http://www.w3.org/1999/xlink")
        }), ["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
            var t = e.replace(gt, mt);
            ft[t] = new pt(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace")
        }), ["tabIndex", "crossOrigin"].forEach(function(e) {
            ft[e] = new pt(e, 1, !1, e.toLowerCase(), null)
        });
        var At = {
            change: {
                phasedRegistrationNames: {
                    bubbled: "onChange",
                    captured: "onChangeCapture"
                },
                dependencies: "blur change click focus input keydown keyup selectionchange".split(" ")
            }
        };

        function Lt(e, t, a) {
            return (e = ce.getPooled(At.change, e, t, a)).type = "change", Te(a), W(e), e
        }
        var St = null,
            Ot = null;

        function Ct(e) {
            j(e)
        }

        function Tt(e) {
            if (Be(I(e))) return e
        }

        function jt(e, t) {
            if ("change" === e) return t
        }
        var Et = !1;

        function _t() {
            St && (St.detachEvent("onpropertychange", Pt), Ot = St = null)
        }

        function Pt(e) {
            "value" === e.propertyName && Tt(Ot) && He(Ct, e = Lt(Ot, e, Re(e)))
        }

        function Vt(e, t, a) {
            "focus" === e ? (_t(), Ot = a, (St = t).attachEvent("onpropertychange", Pt)) : "blur" === e && _t()
        }

        function Ht(e) {
            if ("selectionchange" === e || "keyup" === e || "keydown" === e) return Tt(Ot)
        }

        function It(e, t) {
            if ("click" === e) return Tt(t)
        }

        function Ft(e, t) {
            if ("input" === e || "change" === e) return Tt(t)
        }
        $ && (Et = Ne("input") && (!document.documentMode || 9 < document.documentMode));
        var Rt = {
                eventTypes: At,
                _isInputEventSupported: Et,
                extractEvents: function(e, t, a, r) {
                    var n = t ? I(t) : window,
                        o = void 0,
                        i = void 0,
                        l = n.nodeName && n.nodeName.toLowerCase();
                    if ("select" === l || "input" === l && "file" === n.type ? o = jt : Fe(n) ? Et ? o = Ft : (o = Ht, i = Vt) : (l = n.nodeName) && "input" === l.toLowerCase() && ("checkbox" === n.type || "radio" === n.type) && (o = It), o && (o = o(e, t))) return Lt(o, a, r);
                    i && i(e, n, t), "blur" === e && (e = n._wrapperState) && e.controlled && "number" === n.type && Mt(n, "number", n.value)
                }
            },
            Nt = ce.extend({
                view: null,
                detail: null
            }),
            Dt = {
                Alt: "altKey",
                Control: "ctrlKey",
                Meta: "metaKey",
                Shift: "shiftKey"
            };

        function Ut(e) {
            var t = this.nativeEvent;
            return t.getModifierState ? t.getModifierState(e) : !!(e = Dt[e]) && !!t[e]
        }

        function Bt() {
            return Ut
        }
        var Wt = 0,
            $t = 0,
            qt = !1,
            Qt = !1,
            Yt = Nt.extend({
                screenX: null,
                screenY: null,
                clientX: null,
                clientY: null,
                pageX: null,
                pageY: null,
                ctrlKey: null,
                shiftKey: null,
                altKey: null,
                metaKey: null,
                getModifierState: Bt,
                button: null,
                buttons: null,
                relatedTarget: function(e) {
                    return e.relatedTarget || (e.fromElement === e.srcElement ? e.toElement : e.fromElement)
                },
                movementX: function(e) {
                    if ("movementX" in e) return e.movementX;
                    var t = Wt;
                    return Wt = e.screenX, qt ? "mousemove" === e.type ? e.screenX - t : 0 : (qt = !0, 0)
                },
                movementY: function(e) {
                    if ("movementY" in e) return e.movementY;
                    var t = $t;
                    return $t = e.screenY, Qt ? "mousemove" === e.type ? e.screenY - t : 0 : (Qt = !0, 0)
                }
            }),
            Gt = Yt.extend({
                pointerId: null,
                width: null,
                height: null,
                pressure: null,
                tangentialPressure: null,
                tiltX: null,
                tiltY: null,
                twist: null,
                pointerType: null,
                isPrimary: null
            }),
            Kt = {
                mouseEnter: {
                    registrationName: "onMouseEnter",
                    dependencies: ["mouseout", "mouseover"]
                },
                mouseLeave: {
                    registrationName: "onMouseLeave",
                    dependencies: ["mouseout", "mouseover"]
                },
                pointerEnter: {
                    registrationName: "onPointerEnter",
                    dependencies: ["pointerout", "pointerover"]
                },
                pointerLeave: {
                    registrationName: "onPointerLeave",
                    dependencies: ["pointerout", "pointerover"]
                }
            },
            Xt = {
                eventTypes: Kt,
                extractEvents: function(e, t, a, r) {
                    var n = "mouseover" === e || "pointerover" === e,
                        o = "mouseout" === e || "pointerout" === e;
                    if (n && (a.relatedTarget || a.fromElement) || !o && !n) return null;
                    if (n = r.window === r ? r : (n = r.ownerDocument) ? n.defaultView || n.parentWindow : window, o ? (o = t, t = (t = a.relatedTarget || a.toElement) ? V(t) : null) : o = null, o === t) return null;
                    var i = void 0,
                        l = void 0,
                        c = void 0,
                        u = void 0;
                    "mouseout" === e || "mouseover" === e ? (i = Yt, l = Kt.mouseLeave, c = Kt.mouseEnter, u = "mouse") : "pointerout" !== e && "pointerover" !== e || (i = Gt, l = Kt.pointerLeave, c = Kt.pointerEnter, u = "pointer");
                    var d = null == o ? n : I(o);
                    if (n = null == t ? n : I(t), (e = i.getPooled(l, o, a, r)).type = u + "leave", e.target = d, e.relatedTarget = n, (a = i.getPooled(c, t, a, r)).type = u + "enter", a.target = n, a.relatedTarget = d, r = t, o && r) e: {
                        for (n = r, u = 0, i = t = o; i; i = R(i)) u++;
                        for (i = 0, c = n; c; c = R(c)) i++;
                        for (; 0 < u - i;) t = R(t),
                        u--;
                        for (; 0 < i - u;) n = R(n),
                        i--;
                        for (; u--;) {
                            if (t === n || t === n.alternate) break e;
                            t = R(t), n = R(n)
                        }
                        t = null
                    }
                    else t = null;
                    for (n = t, t = []; o && o !== n && (null === (u = o.alternate) || u !== n);) t.push(o), o = R(o);
                    for (o = []; r && r !== n && (null === (u = r.alternate) || u !== n);) o.push(r), r = R(r);
                    for (r = 0; r < t.length; r++) U(t[r], "bubbled", e);
                    for (r = o.length; 0 < r--;) U(o[r], "captured", a);
                    return [e, a]
                }
            };

        function Zt(e, t) {
            return e === t && (0 !== e || 1 / e === 1 / t) || e !== e && t !== t
        }
        var Jt = Object.prototype.hasOwnProperty;

        function ea(e, t) {
            if (Zt(e, t)) return !0;
            if ("object" !== typeof e || null === e || "object" !== typeof t || null === t) return !1;
            var a = Object.keys(e),
                r = Object.keys(t);
            if (a.length !== r.length) return !1;
            for (r = 0; r < a.length; r++)
                if (!Jt.call(t, a[r]) || !Zt(e[a[r]], t[a[r]])) return !1;
            return !0
        }

        function ta(e) {
            var t = e;
            if (e.alternate)
                for (; t.return;) t = t.return;
            else {
                if (0 !== (2 & t.effectTag)) return 1;
                for (; t.return;)
                    if (0 !== (2 & (t = t.return).effectTag)) return 1
            }
            return 3 === t.tag ? 2 : 3
        }

        function aa(e) {
            2 !== ta(e) && i("188")
        }

        function ra(e) {
            if (!(e = function(e) {
                    var t = e.alternate;
                    if (!t) return 3 === (t = ta(e)) && i("188"), 1 === t ? null : e;
                    for (var a = e, r = t;;) {
                        var n = a.return,
                            o = n ? n.alternate : null;
                        if (!n || !o) break;
                        if (n.child === o.child) {
                            for (var l = n.child; l;) {
                                if (l === a) return aa(n), e;
                                if (l === r) return aa(n), t;
                                l = l.sibling
                            }
                            i("188")
                        }
                        if (a.return !== r.return) a = n, r = o;
                        else {
                            l = !1;
                            for (var c = n.child; c;) {
                                if (c === a) {
                                    l = !0, a = n, r = o;
                                    break
                                }
                                if (c === r) {
                                    l = !0, r = n, a = o;
                                    break
                                }
                                c = c.sibling
                            }
                            if (!l) {
                                for (c = o.child; c;) {
                                    if (c === a) {
                                        l = !0, a = o, r = n;
                                        break
                                    }
                                    if (c === r) {
                                        l = !0, r = o, a = n;
                                        break
                                    }
                                    c = c.sibling
                                }
                                l || i("189")
                            }
                        }
                        a.alternate !== r && i("190")
                    }
                    return 3 !== a.tag && i("188"), a.stateNode.current === a ? e : t
                }(e))) return null;
            for (var t = e;;) {
                if (5 === t.tag || 6 === t.tag) return t;
                if (t.child) t.child.return = t, t = t.child;
                else {
                    if (t === e) break;
                    for (; !t.sibling;) {
                        if (!t.return || t.return === e) return null;
                        t = t.return
                    }
                    t.sibling.return = t.return, t = t.sibling
                }
            }
            return null
        }
        var na = ce.extend({
                animationName: null,
                elapsedTime: null,
                pseudoElement: null
            }),
            oa = ce.extend({
                clipboardData: function(e) {
                    return "clipboardData" in e ? e.clipboardData : window.clipboardData
                }
            }),
            ia = Nt.extend({
                relatedTarget: null
            });

        function la(e) {
            var t = e.keyCode;
            return "charCode" in e ? 0 === (e = e.charCode) && 13 === t && (e = 13) : e = t, 10 === e && (e = 13), 32 <= e || 13 === e ? e : 0
        }
        var ca = {
                Esc: "Escape",
                Spacebar: " ",
                Left: "ArrowLeft",
                Up: "ArrowUp",
                Right: "ArrowRight",
                Down: "ArrowDown",
                Del: "Delete",
                Win: "OS",
                Menu: "ContextMenu",
                Apps: "ContextMenu",
                Scroll: "ScrollLock",
                MozPrintableKey: "Unidentified"
            },
            ua = {
                8: "Backspace",
                9: "Tab",
                12: "Clear",
                13: "Enter",
                16: "Shift",
                17: "Control",
                18: "Alt",
                19: "Pause",
                20: "CapsLock",
                27: "Escape",
                32: " ",
                33: "PageUp",
                34: "PageDown",
                35: "End",
                36: "Home",
                37: "ArrowLeft",
                38: "ArrowUp",
                39: "ArrowRight",
                40: "ArrowDown",
                45: "Insert",
                46: "Delete",
                112: "F1",
                113: "F2",
                114: "F3",
                115: "F4",
                116: "F5",
                117: "F6",
                118: "F7",
                119: "F8",
                120: "F9",
                121: "F10",
                122: "F11",
                123: "F12",
                144: "NumLock",
                145: "ScrollLock",
                224: "Meta"
            },
            da = Nt.extend({
                key: function(e) {
                    if (e.key) {
                        var t = ca[e.key] || e.key;
                        if ("Unidentified" !== t) return t
                    }
                    return "keypress" === e.type ? 13 === (e = la(e)) ? "Enter" : String.fromCharCode(e) : "keydown" === e.type || "keyup" === e.type ? ua[e.keyCode] || "Unidentified" : ""
                },
                location: null,
                ctrlKey: null,
                shiftKey: null,
                altKey: null,
                metaKey: null,
                repeat: null,
                locale: null,
                getModifierState: Bt,
                charCode: function(e) {
                    return "keypress" === e.type ? la(e) : 0
                },
                keyCode: function(e) {
                    return "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0
                },
                which: function(e) {
                    return "keypress" === e.type ? la(e) : "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0
                }
            }),
            sa = Yt.extend({
                dataTransfer: null
            }),
            ha = Nt.extend({
                touches: null,
                targetTouches: null,
                changedTouches: null,
                altKey: null,
                metaKey: null,
                ctrlKey: null,
                shiftKey: null,
                getModifierState: Bt
            }),
            pa = ce.extend({
                propertyName: null,
                elapsedTime: null,
                pseudoElement: null
            }),
            fa = Yt.extend({
                deltaX: function(e) {
                    return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
                },
                deltaY: function(e) {
                    return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
                },
                deltaZ: null,
                deltaMode: null
            }),
            ga = [
                ["abort", "abort"],
                [X, "animationEnd"],
                [Z, "animationIteration"],
                [J, "animationStart"],
                ["canplay", "canPlay"],
                ["canplaythrough", "canPlayThrough"],
                ["drag", "drag"],
                ["dragenter", "dragEnter"],
                ["dragexit", "dragExit"],
                ["dragleave", "dragLeave"],
                ["dragover", "dragOver"],
                ["durationchange", "durationChange"],
                ["emptied", "emptied"],
                ["encrypted", "encrypted"],
                ["ended", "ended"],
                ["error", "error"],
                ["gotpointercapture", "gotPointerCapture"],
                ["load", "load"],
                ["loadeddata", "loadedData"],
                ["loadedmetadata", "loadedMetadata"],
                ["loadstart", "loadStart"],
                ["lostpointercapture", "lostPointerCapture"],
                ["mousemove", "mouseMove"],
                ["mouseout", "mouseOut"],
                ["mouseover", "mouseOver"],
                ["playing", "playing"],
                ["pointermove", "pointerMove"],
                ["pointerout", "pointerOut"],
                ["pointerover", "pointerOver"],
                ["progress", "progress"],
                ["scroll", "scroll"],
                ["seeking", "seeking"],
                ["stalled", "stalled"],
                ["suspend", "suspend"],
                ["timeupdate", "timeUpdate"],
                ["toggle", "toggle"],
                ["touchmove", "touchMove"],
                [ee, "transitionEnd"],
                ["waiting", "waiting"],
                ["wheel", "wheel"]
            ],
            ma = {},
            ya = {};

        function va(e, t) {
            var a = e[0],
                r = "on" + ((e = e[1])[0].toUpperCase() + e.slice(1));
            t = {
                phasedRegistrationNames: {
                    bubbled: r,
                    captured: r + "Capture"
                },
                dependencies: [a],
                isInteractive: t
            }, ma[e] = t, ya[a] = t
        }[
            ["blur", "blur"],
            ["cancel", "cancel"],
            ["click", "click"],
            ["close", "close"],
            ["contextmenu", "contextMenu"],
            ["copy", "copy"],
            ["cut", "cut"],
            ["auxclick", "auxClick"],
            ["dblclick", "doubleClick"],
            ["dragend", "dragEnd"],
            ["dragstart", "dragStart"],
            ["drop", "drop"],
            ["focus", "focus"],
            ["input", "input"],
            ["invalid", "invalid"],
            ["keydown", "keyDown"],
            ["keypress", "keyPress"],
            ["keyup", "keyUp"],
            ["mousedown", "mouseDown"],
            ["mouseup", "mouseUp"],
            ["paste", "paste"],
            ["pause", "pause"],
            ["play", "play"],
            ["pointercancel", "pointerCancel"],
            ["pointerdown", "pointerDown"],
            ["pointerup", "pointerUp"],
            ["ratechange", "rateChange"],
            ["reset", "reset"],
            ["seeked", "seeked"],
            ["submit", "submit"],
            ["touchcancel", "touchCancel"],
            ["touchend", "touchEnd"],
            ["touchstart", "touchStart"],
            ["volumechange", "volumeChange"]
        ].forEach(function(e) {
            va(e, !0)
        }), ga.forEach(function(e) {
            va(e, !1)
        });
        var ba = {
                eventTypes: ma,
                isInteractiveTopLevelEventType: function(e) {
                    return void 0 !== (e = ya[e]) && !0 === e.isInteractive
                },
                extractEvents: function(e, t, a, r) {
                    var n = ya[e];
                    if (!n) return null;
                    switch (e) {
                        case "keypress":
                            if (0 === la(a)) return null;
                        case "keydown":
                        case "keyup":
                            e = da;
                            break;
                        case "blur":
                        case "focus":
                            e = ia;
                            break;
                        case "click":
                            if (2 === a.button) return null;
                        case "auxclick":
                        case "dblclick":
                        case "mousedown":
                        case "mousemove":
                        case "mouseup":
                        case "mouseout":
                        case "mouseover":
                        case "contextmenu":
                            e = Yt;
                            break;
                        case "drag":
                        case "dragend":
                        case "dragenter":
                        case "dragexit":
                        case "dragleave":
                        case "dragover":
                        case "dragstart":
                        case "drop":
                            e = sa;
                            break;
                        case "touchcancel":
                        case "touchend":
                        case "touchmove":
                        case "touchstart":
                            e = ha;
                            break;
                        case X:
                        case Z:
                        case J:
                            e = na;
                            break;
                        case ee:
                            e = pa;
                            break;
                        case "scroll":
                            e = Nt;
                            break;
                        case "wheel":
                            e = fa;
                            break;
                        case "copy":
                        case "cut":
                        case "paste":
                            e = oa;
                            break;
                        case "gotpointercapture":
                        case "lostpointercapture":
                        case "pointercancel":
                        case "pointerdown":
                        case "pointermove":
                        case "pointerout":
                        case "pointerover":
                        case "pointerup":
                            e = Gt;
                            break;
                        default:
                            e = ce
                    }
                    return W(t = e.getPooled(n, t, a, r)), t
                }
            },
            wa = ba.isInteractiveTopLevelEventType,
            za = [];

        function xa(e) {
            var t = e.targetInst,
                a = t;
            do {
                if (!a) {
                    e.ancestors.push(a);
                    break
                }
                var r;
                for (r = a; r.return;) r = r.return;
                if (!(r = 3 !== r.tag ? null : r.stateNode.containerInfo)) break;
                e.ancestors.push(a), a = V(r)
            } while (a);
            for (a = 0; a < e.ancestors.length; a++) {
                t = e.ancestors[a];
                var n = Re(e.nativeEvent);
                r = e.topLevelType;
                for (var o = e.nativeEvent, i = null, l = 0; l < y.length; l++) {
                    var c = y[l];
                    c && (c = c.extractEvents(r, t, o, n)) && (i = A(i, c))
                }
                j(i)
            }
        }
        var ka = !0;

        function Ma(e, t) {
            if (!t) return null;
            var a = (wa(e) ? La : Sa).bind(null, e);
            t.addEventListener(e, a, !1)
        }

        function Aa(e, t) {
            if (!t) return null;
            var a = (wa(e) ? La : Sa).bind(null, e);
            t.addEventListener(e, a, !0)
        }

        function La(e, t) {
            _e(Sa, e, t)
        }

        function Sa(e, t) {
            if (ka) {
                var a = Re(t);
                if (null === (a = V(a)) || "number" !== typeof a.tag || 2 === ta(a) || (a = null), za.length) {
                    var r = za.pop();
                    r.topLevelType = e, r.nativeEvent = t, r.targetInst = a, e = r
                } else e = {
                    topLevelType: e,
                    nativeEvent: t,
                    targetInst: a,
                    ancestors: []
                };
                try {
                    He(xa, e)
                } finally {
                    e.topLevelType = null, e.nativeEvent = null, e.targetInst = null, e.ancestors.length = 0, 10 > za.length && za.push(e)
                }
            }
        }
        var Oa = {},
            Ca = 0,
            Ta = "_reactListenersID" + ("" + Math.random()).slice(2);

        function ja(e) {
            return Object.prototype.hasOwnProperty.call(e, Ta) || (e[Ta] = Ca++, Oa[e[Ta]] = {}), Oa[e[Ta]]
        }

        function Ea(e) {
            if ("undefined" === typeof(e = e || ("undefined" !== typeof document ? document : void 0))) return null;
            try {
                return e.activeElement || e.body
            } catch (t) {
                return e.body
            }
        }

        function _a(e) {
            for (; e && e.firstChild;) e = e.firstChild;
            return e
        }

        function Pa(e, t) {
            var a, r = _a(e);
            for (e = 0; r;) {
                if (3 === r.nodeType) {
                    if (a = e + r.textContent.length, e <= t && a >= t) return {
                        node: r,
                        offset: t - e
                    };
                    e = a
                }
                e: {
                    for (; r;) {
                        if (r.nextSibling) {
                            r = r.nextSibling;
                            break e
                        }
                        r = r.parentNode
                    }
                    r = void 0
                }
                r = _a(r)
            }
        }

        function Va() {
            for (var e = window, t = Ea(); t instanceof e.HTMLIFrameElement;) {
                try {
                    var a = "string" === typeof t.contentWindow.location.href
                } catch (r) {
                    a = !1
                }
                if (!a) break;
                t = Ea((e = t.contentWindow).document)
            }
            return t
        }

        function Ha(e) {
            var t = e && e.nodeName && e.nodeName.toLowerCase();
            return t && ("input" === t && ("text" === e.type || "search" === e.type || "tel" === e.type || "url" === e.type || "password" === e.type) || "textarea" === t || "true" === e.contentEditable)
        }

        function Ia(e) {
            var t = Va(),
                a = e.focusedElem,
                r = e.selectionRange;
            if (t !== a && a && a.ownerDocument && function e(t, a) {
                    return !(!t || !a) && (t === a || (!t || 3 !== t.nodeType) && (a && 3 === a.nodeType ? e(t, a.parentNode) : "contains" in t ? t.contains(a) : !!t.compareDocumentPosition && !!(16 & t.compareDocumentPosition(a))))
                }(a.ownerDocument.documentElement, a)) {
                if (null !== r && Ha(a))
                    if (t = r.start, void 0 === (e = r.end) && (e = t), "selectionStart" in a) a.selectionStart = t, a.selectionEnd = Math.min(e, a.value.length);
                    else if ((e = (t = a.ownerDocument || document) && t.defaultView || window).getSelection) {
                    e = e.getSelection();
                    var n = a.textContent.length,
                        o = Math.min(r.start, n);
                    r = void 0 === r.end ? o : Math.min(r.end, n), !e.extend && o > r && (n = r, r = o, o = n), n = Pa(a, o);
                    var i = Pa(a, r);
                    n && i && (1 !== e.rangeCount || e.anchorNode !== n.node || e.anchorOffset !== n.offset || e.focusNode !== i.node || e.focusOffset !== i.offset) && ((t = t.createRange()).setStart(n.node, n.offset), e.removeAllRanges(), o > r ? (e.addRange(t), e.extend(i.node, i.offset)) : (t.setEnd(i.node, i.offset), e.addRange(t)))
                }
                for (t = [], e = a; e = e.parentNode;) 1 === e.nodeType && t.push({
                    element: e,
                    left: e.scrollLeft,
                    top: e.scrollTop
                });
                for ("function" === typeof a.focus && a.focus(), a = 0; a < t.length; a++)(e = t[a]).element.scrollLeft = e.left, e.element.scrollTop = e.top
            }
        }
        var Fa = $ && "documentMode" in document && 11 >= document.documentMode,
            Ra = {
                select: {
                    phasedRegistrationNames: {
                        bubbled: "onSelect",
                        captured: "onSelectCapture"
                    },
                    dependencies: "blur contextmenu dragend focus keydown keyup mousedown mouseup selectionchange".split(" ")
                }
            },
            Na = null,
            Da = null,
            Ua = null,
            Ba = !1;

        function Wa(e, t) {
            var a = t.window === t ? t.document : 9 === t.nodeType ? t : t.ownerDocument;
            return Ba || null == Na || Na !== Ea(a) ? null : ("selectionStart" in (a = Na) && Ha(a) ? a = {
                start: a.selectionStart,
                end: a.selectionEnd
            } : a = {
                anchorNode: (a = (a.ownerDocument && a.ownerDocument.defaultView || window).getSelection()).anchorNode,
                anchorOffset: a.anchorOffset,
                focusNode: a.focusNode,
                focusOffset: a.focusOffset
            }, Ua && ea(Ua, a) ? null : (Ua = a, (e = ce.getPooled(Ra.select, Da, e, t)).type = "select", e.target = Na, W(e), e))
        }
        var $a = {
            eventTypes: Ra,
            extractEvents: function(e, t, a, r) {
                var n, o = r.window === r ? r.document : 9 === r.nodeType ? r : r.ownerDocument;
                if (!(n = !o)) {
                    e: {
                        o = ja(o),
                        n = w.onSelect;
                        for (var i = 0; i < n.length; i++) {
                            var l = n[i];
                            if (!o.hasOwnProperty(l) || !o[l]) {
                                o = !1;
                                break e
                            }
                        }
                        o = !0
                    }
                    n = !o
                }
                if (n) return null;
                switch (o = t ? I(t) : window, e) {
                    case "focus":
                        (Fe(o) || "true" === o.contentEditable) && (Na = o, Da = t, Ua = null);
                        break;
                    case "blur":
                        Ua = Da = Na = null;
                        break;
                    case "mousedown":
                        Ba = !0;
                        break;
                    case "contextmenu":
                    case "mouseup":
                    case "dragend":
                        return Ba = !1, Wa(a, r);
                    case "selectionchange":
                        if (Fa) break;
                    case "keydown":
                    case "keyup":
                        return Wa(a, r)
                }
                return null
            }
        };

        function qa(e, t) {
            return e = n({
                children: void 0
            }, t), (t = function(e) {
                var t = "";
                return r.Children.forEach(e, function(e) {
                    null != e && (t += e)
                }), t
            }(t.children)) && (e.children = t), e
        }

        function Qa(e, t, a, r) {
            if (e = e.options, t) {
                t = {};
                for (var n = 0; n < a.length; n++) t["$" + a[n]] = !0;
                for (a = 0; a < e.length; a++) n = t.hasOwnProperty("$" + e[a].value), e[a].selected !== n && (e[a].selected = n), n && r && (e[a].defaultSelected = !0)
            } else {
                for (a = "" + vt(a), t = null, n = 0; n < e.length; n++) {
                    if (e[n].value === a) return e[n].selected = !0, void(r && (e[n].defaultSelected = !0));
                    null !== t || e[n].disabled || (t = e[n])
                }
                null !== t && (t.selected = !0)
            }
        }

        function Ya(e, t) {
            return null != t.dangerouslySetInnerHTML && i("91"), n({}, t, {
                value: void 0,
                defaultValue: void 0,
                children: "" + e._wrapperState.initialValue
            })
        }

        function Ga(e, t) {
            var a = t.value;
            null == a && (a = t.defaultValue, null != (t = t.children) && (null != a && i("92"), Array.isArray(t) && (1 >= t.length || i("93"), t = t[0]), a = t), null == a && (a = "")), e._wrapperState = {
                initialValue: vt(a)
            }
        }

        function Ka(e, t) {
            var a = vt(t.value),
                r = vt(t.defaultValue);
            null != a && ((a = "" + a) !== e.value && (e.value = a), null == t.defaultValue && e.defaultValue !== a && (e.defaultValue = a)), null != r && (e.defaultValue = "" + r)
        }

        function Xa(e) {
            var t = e.textContent;
            t === e._wrapperState.initialValue && (e.value = t)
        }
        C.injectEventPluginOrder("ResponderEventPlugin SimpleEventPlugin EnterLeaveEventPlugin ChangeEventPlugin SelectEventPlugin BeforeInputEventPlugin".split(" ")), z = F, x = H, k = I, C.injectEventPluginsByName({
            SimpleEventPlugin: ba,
            EnterLeaveEventPlugin: Xt,
            ChangeEventPlugin: Rt,
            SelectEventPlugin: $a,
            BeforeInputEventPlugin: Ae
        });
        var Za = {
            html: "http://www.w3.org/1999/xhtml",
            mathml: "http://www.w3.org/1998/Math/MathML",
            svg: "http://www.w3.org/2000/svg"
        };

        function Ja(e) {
            switch (e) {
                case "svg":
                    return "http://www.w3.org/2000/svg";
                case "math":
                    return "http://www.w3.org/1998/Math/MathML";
                default:
                    return "http://www.w3.org/1999/xhtml"
            }
        }

        function er(e, t) {
            return null == e || "http://www.w3.org/1999/xhtml" === e ? Ja(t) : "http://www.w3.org/2000/svg" === e && "foreignObject" === t ? "http://www.w3.org/1999/xhtml" : e
        }
        var tr, ar = void 0,
            rr = (tr = function(e, t) {
                if (e.namespaceURI !== Za.svg || "innerHTML" in e) e.innerHTML = t;
                else {
                    for ((ar = ar || document.createElement("div")).innerHTML = "<svg>" + t + "</svg>", t = ar.firstChild; e.firstChild;) e.removeChild(e.firstChild);
                    for (; t.firstChild;) e.appendChild(t.firstChild)
                }
            }, "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(e, t, a, r) {
                MSApp.execUnsafeLocalFunction(function() {
                    return tr(e, t)
                })
            } : tr);

        function nr(e, t) {
            if (t) {
                var a = e.firstChild;
                if (a && a === e.lastChild && 3 === a.nodeType) return void(a.nodeValue = t)
            }
            e.textContent = t
        }
        var or = {
                animationIterationCount: !0,
                borderImageOutset: !0,
                borderImageSlice: !0,
                borderImageWidth: !0,
                boxFlex: !0,
                boxFlexGroup: !0,
                boxOrdinalGroup: !0,
                columnCount: !0,
                columns: !0,
                flex: !0,
                flexGrow: !0,
                flexPositive: !0,
                flexShrink: !0,
                flexNegative: !0,
                flexOrder: !0,
                gridArea: !0,
                gridRow: !0,
                gridRowEnd: !0,
                gridRowSpan: !0,
                gridRowStart: !0,
                gridColumn: !0,
                gridColumnEnd: !0,
                gridColumnSpan: !0,
                gridColumnStart: !0,
                fontWeight: !0,
                lineClamp: !0,
                lineHeight: !0,
                opacity: !0,
                order: !0,
                orphans: !0,
                tabSize: !0,
                widows: !0,
                zIndex: !0,
                zoom: !0,
                fillOpacity: !0,
                floodOpacity: !0,
                stopOpacity: !0,
                strokeDasharray: !0,
                strokeDashoffset: !0,
                strokeMiterlimit: !0,
                strokeOpacity: !0,
                strokeWidth: !0
            },
            ir = ["Webkit", "ms", "Moz", "O"];

        function lr(e, t, a) {
            return null == t || "boolean" === typeof t || "" === t ? "" : a || "number" !== typeof t || 0 === t || or.hasOwnProperty(e) && or[e] ? ("" + t).trim() : t + "px"
        }

        function cr(e, t) {
            for (var a in e = e.style, t)
                if (t.hasOwnProperty(a)) {
                    var r = 0 === a.indexOf("--"),
                        n = lr(a, t[a], r);
                    "float" === a && (a = "cssFloat"), r ? e.setProperty(a, n) : e[a] = n
                }
        }
        Object.keys(or).forEach(function(e) {
            ir.forEach(function(t) {
                t = t + e.charAt(0).toUpperCase() + e.substring(1), or[t] = or[e]
            })
        });
        var ur = n({
            menuitem: !0
        }, {
            area: !0,
            base: !0,
            br: !0,
            col: !0,
            embed: !0,
            hr: !0,
            img: !0,
            input: !0,
            keygen: !0,
            link: !0,
            meta: !0,
            param: !0,
            source: !0,
            track: !0,
            wbr: !0
        });

        function dr(e, t) {
            t && (ur[e] && (null != t.children || null != t.dangerouslySetInnerHTML) && i("137", e, ""), null != t.dangerouslySetInnerHTML && (null != t.children && i("60"), "object" === typeof t.dangerouslySetInnerHTML && "__html" in t.dangerouslySetInnerHTML || i("61")), null != t.style && "object" !== typeof t.style && i("62", ""))
        }

        function sr(e, t) {
            if (-1 === e.indexOf("-")) return "string" === typeof t.is;
            switch (e) {
                case "annotation-xml":
                case "color-profile":
                case "font-face":
                case "font-face-src":
                case "font-face-uri":
                case "font-face-format":
                case "font-face-name":
                case "missing-glyph":
                    return !1;
                default:
                    return !0
            }
        }

        function hr(e, t) {
            var a = ja(e = 9 === e.nodeType || 11 === e.nodeType ? e : e.ownerDocument);
            t = w[t];
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                if (!a.hasOwnProperty(n) || !a[n]) {
                    switch (n) {
                        case "scroll":
                            Aa("scroll", e);
                            break;
                        case "focus":
                        case "blur":
                            Aa("focus", e), Aa("blur", e), a.blur = !0, a.focus = !0;
                            break;
                        case "cancel":
                        case "close":
                            Ne(n) && Aa(n, e);
                            break;
                        case "invalid":
                        case "submit":
                        case "reset":
                            break;
                        default:
                            -1 === te.indexOf(n) && Ma(n, e)
                    }
                    a[n] = !0
                }
            }
        }

        function pr() {}
        var fr = null,
            gr = null;

        function mr(e, t) {
            switch (e) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                    return !!t.autoFocus
            }
            return !1
        }

        function yr(e, t) {
            return "textarea" === e || "option" === e || "noscript" === e || "string" === typeof t.children || "number" === typeof t.children || "object" === typeof t.dangerouslySetInnerHTML && null !== t.dangerouslySetInnerHTML && null != t.dangerouslySetInnerHTML.__html
        }
        var vr = "function" === typeof setTimeout ? setTimeout : void 0,
            br = "function" === typeof clearTimeout ? clearTimeout : void 0,
            wr = o.unstable_scheduleCallback,
            zr = o.unstable_cancelCallback;

        function xr(e) {
            for (e = e.nextSibling; e && 1 !== e.nodeType && 3 !== e.nodeType;) e = e.nextSibling;
            return e
        }

        function kr(e) {
            for (e = e.firstChild; e && 1 !== e.nodeType && 3 !== e.nodeType;) e = e.nextSibling;
            return e
        }
        new Set;
        var Mr = [],
            Ar = -1;

        function Lr(e) {
            0 > Ar || (e.current = Mr[Ar], Mr[Ar] = null, Ar--)
        }

        function Sr(e, t) {
            Mr[++Ar] = e.current, e.current = t
        }
        var Or = {},
            Cr = {
                current: Or
            },
            Tr = {
                current: !1
            },
            jr = Or;

        function Er(e, t) {
            var a = e.type.contextTypes;
            if (!a) return Or;
            var r = e.stateNode;
            if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
            var n, o = {};
            for (n in a) o[n] = t[n];
            return r && ((e = e.stateNode).__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = o), o
        }

        function _r(e) {
            return null !== (e = e.childContextTypes) && void 0 !== e
        }

        function Pr(e) {
            Lr(Tr), Lr(Cr)
        }

        function Vr(e) {
            Lr(Tr), Lr(Cr)
        }

        function Hr(e, t, a) {
            Cr.current !== Or && i("168"), Sr(Cr, t), Sr(Tr, a)
        }

        function Ir(e, t, a) {
            var r = e.stateNode;
            if (e = t.childContextTypes, "function" !== typeof r.getChildContext) return a;
            for (var o in r = r.getChildContext()) o in e || i("108", lt(t) || "Unknown", o);
            return n({}, a, r)
        }

        function Fr(e) {
            var t = e.stateNode;
            return t = t && t.__reactInternalMemoizedMergedChildContext || Or, jr = Cr.current, Sr(Cr, t), Sr(Tr, Tr.current), !0
        }

        function Rr(e, t, a) {
            var r = e.stateNode;
            r || i("169"), a ? (t = Ir(e, t, jr), r.__reactInternalMemoizedMergedChildContext = t, Lr(Tr), Lr(Cr), Sr(Cr, t)) : Lr(Tr), Sr(Tr, a)
        }
        var Nr = null,
            Dr = null;

        function Ur(e) {
            return function(t) {
                try {
                    return e(t)
                } catch (a) {}
            }
        }

        function Br(e, t, a, r) {
            this.tag = e, this.key = a, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.contextDependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.effectTag = 0, this.lastEffect = this.firstEffect = this.nextEffect = null, this.childExpirationTime = this.expirationTime = 0, this.alternate = null
        }

        function Wr(e, t, a, r) {
            return new Br(e, t, a, r)
        }

        function $r(e) {
            return !(!(e = e.prototype) || !e.isReactComponent)
        }

        function qr(e, t) {
            var a = e.alternate;
            return null === a ? ((a = Wr(e.tag, t, e.key, e.mode)).elementType = e.elementType, a.type = e.type, a.stateNode = e.stateNode, a.alternate = e, e.alternate = a) : (a.pendingProps = t, a.effectTag = 0, a.nextEffect = null, a.firstEffect = null, a.lastEffect = null), a.childExpirationTime = e.childExpirationTime, a.expirationTime = e.expirationTime, a.child = e.child, a.memoizedProps = e.memoizedProps, a.memoizedState = e.memoizedState, a.updateQueue = e.updateQueue, a.contextDependencies = e.contextDependencies, a.sibling = e.sibling, a.index = e.index, a.ref = e.ref, a
        }

        function Qr(e, t, a, r, n, o) {
            var l = 2;
            if (r = e, "function" === typeof e) $r(e) && (l = 1);
            else if ("string" === typeof e) l = 5;
            else e: switch (e) {
                case Ge:
                    return Yr(a.children, n, o, t);
                case et:
                    return Gr(a, 3 | n, o, t);
                case Ke:
                    return Gr(a, 2 | n, o, t);
                case Xe:
                    return (e = Wr(12, a, t, 4 | n)).elementType = Xe, e.type = Xe, e.expirationTime = o, e;
                case at:
                    return (e = Wr(13, a, t, n)).elementType = at, e.type = at, e.expirationTime = o, e;
                default:
                    if ("object" === typeof e && null !== e) switch (e.$$typeof) {
                        case Ze:
                            l = 10;
                            break e;
                        case Je:
                            l = 9;
                            break e;
                        case tt:
                            l = 11;
                            break e;
                        case rt:
                            l = 14;
                            break e;
                        case nt:
                            l = 16, r = null;
                            break e
                    }
                    i("130", null == e ? e : typeof e, "")
            }
            return (t = Wr(l, a, t, n)).elementType = e, t.type = r, t.expirationTime = o, t
        }

        function Yr(e, t, a, r) {
            return (e = Wr(7, e, r, t)).expirationTime = a, e
        }

        function Gr(e, t, a, r) {
            return e = Wr(8, e, r, t), t = 0 === (1 & t) ? Ke : et, e.elementType = t, e.type = t, e.expirationTime = a, e
        }

        function Kr(e, t, a) {
            return (e = Wr(6, e, null, t)).expirationTime = a, e
        }

        function Xr(e, t, a) {
            return (t = Wr(4, null !== e.children ? e.children : [], e.key, t)).expirationTime = a, t.stateNode = {
                containerInfo: e.containerInfo,
                pendingChildren: null,
                implementation: e.implementation
            }, t
        }

        function Zr(e, t) {
            e.didError = !1;
            var a = e.earliestPendingTime;
            0 === a ? e.earliestPendingTime = e.latestPendingTime = t : a < t ? e.earliestPendingTime = t : e.latestPendingTime > t && (e.latestPendingTime = t), tn(t, e)
        }

        function Jr(e, t) {
            e.didError = !1, e.latestPingedTime >= t && (e.latestPingedTime = 0);
            var a = e.earliestPendingTime,
                r = e.latestPendingTime;
            a === t ? e.earliestPendingTime = r === t ? e.latestPendingTime = 0 : r : r === t && (e.latestPendingTime = a), a = e.earliestSuspendedTime, r = e.latestSuspendedTime, 0 === a ? e.earliestSuspendedTime = e.latestSuspendedTime = t : a < t ? e.earliestSuspendedTime = t : r > t && (e.latestSuspendedTime = t), tn(t, e)
        }

        function en(e, t) {
            var a = e.earliestPendingTime;
            return a > t && (t = a), (e = e.earliestSuspendedTime) > t && (t = e), t
        }

        function tn(e, t) {
            var a = t.earliestSuspendedTime,
                r = t.latestSuspendedTime,
                n = t.earliestPendingTime,
                o = t.latestPingedTime;
            0 === (n = 0 !== n ? n : o) && (0 === e || r < e) && (n = r), 0 !== (e = n) && a > e && (e = a), t.nextExpirationTimeToWorkOn = n, t.expirationTime = e
        }

        function an(e, t) {
            if (e && e.defaultProps)
                for (var a in t = n({}, t), e = e.defaultProps) void 0 === t[a] && (t[a] = e[a]);
            return t
        }
        var rn = (new r.Component).refs;

        function nn(e, t, a, r) {
            a = null === (a = a(r, t = e.memoizedState)) || void 0 === a ? t : n({}, t, a), e.memoizedState = a, null !== (r = e.updateQueue) && 0 === e.expirationTime && (r.baseState = a)
        }
        var on = {
            isMounted: function(e) {
                return !!(e = e._reactInternalFiber) && 2 === ta(e)
            },
            enqueueSetState: function(e, t, a) {
                e = e._reactInternalFiber;
                var r = xl(),
                    n = Ko(r = Gi(r, e));
                n.payload = t, void 0 !== a && null !== a && (n.callback = a), Bi(), Zo(e, n), Zi(e, r)
            },
            enqueueReplaceState: function(e, t, a) {
                e = e._reactInternalFiber;
                var r = xl(),
                    n = Ko(r = Gi(r, e));
                n.tag = Wo, n.payload = t, void 0 !== a && null !== a && (n.callback = a), Bi(), Zo(e, n), Zi(e, r)
            },
            enqueueForceUpdate: function(e, t) {
                e = e._reactInternalFiber;
                var a = xl(),
                    r = Ko(a = Gi(a, e));
                r.tag = $o, void 0 !== t && null !== t && (r.callback = t), Bi(), Zo(e, r), Zi(e, a)
            }
        };

        function ln(e, t, a, r, n, o, i) {
            return "function" === typeof(e = e.stateNode).shouldComponentUpdate ? e.shouldComponentUpdate(r, o, i) : !t.prototype || !t.prototype.isPureReactComponent || (!ea(a, r) || !ea(n, o))
        }

        function cn(e, t, a) {
            var r = !1,
                n = Or,
                o = t.contextType;
            return "object" === typeof o && null !== o ? o = Uo(o) : (n = _r(t) ? jr : Cr.current, o = (r = null !== (r = t.contextTypes) && void 0 !== r) ? Er(e, n) : Or), t = new t(a, o), e.memoizedState = null !== t.state && void 0 !== t.state ? t.state : null, t.updater = on, e.stateNode = t, t._reactInternalFiber = e, r && ((e = e.stateNode).__reactInternalMemoizedUnmaskedChildContext = n, e.__reactInternalMemoizedMaskedChildContext = o), t
        }

        function un(e, t, a, r) {
            e = t.state, "function" === typeof t.componentWillReceiveProps && t.componentWillReceiveProps(a, r), "function" === typeof t.UNSAFE_componentWillReceiveProps && t.UNSAFE_componentWillReceiveProps(a, r), t.state !== e && on.enqueueReplaceState(t, t.state, null)
        }

        function dn(e, t, a, r) {
            var n = e.stateNode;
            n.props = a, n.state = e.memoizedState, n.refs = rn;
            var o = t.contextType;
            "object" === typeof o && null !== o ? n.context = Uo(o) : (o = _r(t) ? jr : Cr.current, n.context = Er(e, o)), null !== (o = e.updateQueue) && (ai(e, o, a, n, r), n.state = e.memoizedState), "function" === typeof(o = t.getDerivedStateFromProps) && (nn(e, t, o, a), n.state = e.memoizedState), "function" === typeof t.getDerivedStateFromProps || "function" === typeof n.getSnapshotBeforeUpdate || "function" !== typeof n.UNSAFE_componentWillMount && "function" !== typeof n.componentWillMount || (t = n.state, "function" === typeof n.componentWillMount && n.componentWillMount(), "function" === typeof n.UNSAFE_componentWillMount && n.UNSAFE_componentWillMount(), t !== n.state && on.enqueueReplaceState(n, n.state, null), null !== (o = e.updateQueue) && (ai(e, o, a, n, r), n.state = e.memoizedState)), "function" === typeof n.componentDidMount && (e.effectTag |= 4)
        }
        var sn = Array.isArray;

        function hn(e, t, a) {
            if (null !== (e = a.ref) && "function" !== typeof e && "object" !== typeof e) {
                if (a._owner) {
                    a = a._owner;
                    var r = void 0;
                    a && (1 !== a.tag && i("309"), r = a.stateNode), r || i("147", e);
                    var n = "" + e;
                    return null !== t && null !== t.ref && "function" === typeof t.ref && t.ref._stringRef === n ? t.ref : ((t = function(e) {
                        var t = r.refs;
                        t === rn && (t = r.refs = {}), null === e ? delete t[n] : t[n] = e
                    })._stringRef = n, t)
                }
                "string" !== typeof e && i("284"), a._owner || i("290", e)
            }
            return e
        }

        function pn(e, t) {
            "textarea" !== e.type && i("31", "[object Object]" === Object.prototype.toString.call(t) ? "object with keys {" + Object.keys(t).join(", ") + "}" : t, "")
        }

        function fn(e) {
            function t(t, a) {
                if (e) {
                    var r = t.lastEffect;
                    null !== r ? (r.nextEffect = a, t.lastEffect = a) : t.firstEffect = t.lastEffect = a, a.nextEffect = null, a.effectTag = 8
                }
            }

            function a(a, r) {
                if (!e) return null;
                for (; null !== r;) t(a, r), r = r.sibling;
                return null
            }

            function r(e, t) {
                for (e = new Map; null !== t;) null !== t.key ? e.set(t.key, t) : e.set(t.index, t), t = t.sibling;
                return e
            }

            function n(e, t, a) {
                return (e = qr(e, t)).index = 0, e.sibling = null, e
            }

            function o(t, a, r) {
                return t.index = r, e ? null !== (r = t.alternate) ? (r = r.index) < a ? (t.effectTag = 2, a) : r : (t.effectTag = 2, a) : a
            }

            function l(t) {
                return e && null === t.alternate && (t.effectTag = 2), t
            }

            function c(e, t, a, r) {
                return null === t || 6 !== t.tag ? ((t = Kr(a, e.mode, r)).return = e, t) : ((t = n(t, a)).return = e, t)
            }

            function u(e, t, a, r) {
                return null !== t && t.elementType === a.type ? ((r = n(t, a.props)).ref = hn(e, t, a), r.return = e, r) : ((r = Qr(a.type, a.key, a.props, null, e.mode, r)).ref = hn(e, t, a), r.return = e, r)
            }

            function d(e, t, a, r) {
                return null === t || 4 !== t.tag || t.stateNode.containerInfo !== a.containerInfo || t.stateNode.implementation !== a.implementation ? ((t = Xr(a, e.mode, r)).return = e, t) : ((t = n(t, a.children || [])).return = e, t)
            }

            function s(e, t, a, r, o) {
                return null === t || 7 !== t.tag ? ((t = Yr(a, e.mode, r, o)).return = e, t) : ((t = n(t, a)).return = e, t)
            }

            function h(e, t, a) {
                if ("string" === typeof t || "number" === typeof t) return (t = Kr("" + t, e.mode, a)).return = e, t;
                if ("object" === typeof t && null !== t) {
                    switch (t.$$typeof) {
                        case Qe:
                            return (a = Qr(t.type, t.key, t.props, null, e.mode, a)).ref = hn(e, null, t), a.return = e, a;
                        case Ye:
                            return (t = Xr(t, e.mode, a)).return = e, t
                    }
                    if (sn(t) || it(t)) return (t = Yr(t, e.mode, a, null)).return = e, t;
                    pn(e, t)
                }
                return null
            }

            function p(e, t, a, r) {
                var n = null !== t ? t.key : null;
                if ("string" === typeof a || "number" === typeof a) return null !== n ? null : c(e, t, "" + a, r);
                if ("object" === typeof a && null !== a) {
                    switch (a.$$typeof) {
                        case Qe:
                            return a.key === n ? a.type === Ge ? s(e, t, a.props.children, r, n) : u(e, t, a, r) : null;
                        case Ye:
                            return a.key === n ? d(e, t, a, r) : null
                    }
                    if (sn(a) || it(a)) return null !== n ? null : s(e, t, a, r, null);
                    pn(e, a)
                }
                return null
            }

            function f(e, t, a, r, n) {
                if ("string" === typeof r || "number" === typeof r) return c(t, e = e.get(a) || null, "" + r, n);
                if ("object" === typeof r && null !== r) {
                    switch (r.$$typeof) {
                        case Qe:
                            return e = e.get(null === r.key ? a : r.key) || null, r.type === Ge ? s(t, e, r.props.children, n, r.key) : u(t, e, r, n);
                        case Ye:
                            return d(t, e = e.get(null === r.key ? a : r.key) || null, r, n)
                    }
                    if (sn(r) || it(r)) return s(t, e = e.get(a) || null, r, n, null);
                    pn(t, r)
                }
                return null
            }

            function g(n, i, l, c) {
                for (var u = null, d = null, s = i, g = i = 0, m = null; null !== s && g < l.length; g++) {
                    s.index > g ? (m = s, s = null) : m = s.sibling;
                    var y = p(n, s, l[g], c);
                    if (null === y) {
                        null === s && (s = m);
                        break
                    }
                    e && s && null === y.alternate && t(n, s), i = o(y, i, g), null === d ? u = y : d.sibling = y, d = y, s = m
                }
                if (g === l.length) return a(n, s), u;
                if (null === s) {
                    for (; g < l.length; g++)(s = h(n, l[g], c)) && (i = o(s, i, g), null === d ? u = s : d.sibling = s, d = s);
                    return u
                }
                for (s = r(n, s); g < l.length; g++)(m = f(s, n, g, l[g], c)) && (e && null !== m.alternate && s.delete(null === m.key ? g : m.key), i = o(m, i, g), null === d ? u = m : d.sibling = m, d = m);
                return e && s.forEach(function(e) {
                    return t(n, e)
                }), u
            }

            function m(n, l, c, u) {
                var d = it(c);
                "function" !== typeof d && i("150"), null == (c = d.call(c)) && i("151");
                for (var s = d = null, g = l, m = l = 0, y = null, v = c.next(); null !== g && !v.done; m++, v = c.next()) {
                    g.index > m ? (y = g, g = null) : y = g.sibling;
                    var b = p(n, g, v.value, u);
                    if (null === b) {
                        g || (g = y);
                        break
                    }
                    e && g && null === b.alternate && t(n, g), l = o(b, l, m), null === s ? d = b : s.sibling = b, s = b, g = y
                }
                if (v.done) return a(n, g), d;
                if (null === g) {
                    for (; !v.done; m++, v = c.next()) null !== (v = h(n, v.value, u)) && (l = o(v, l, m), null === s ? d = v : s.sibling = v, s = v);
                    return d
                }
                for (g = r(n, g); !v.done; m++, v = c.next()) null !== (v = f(g, n, m, v.value, u)) && (e && null !== v.alternate && g.delete(null === v.key ? m : v.key), l = o(v, l, m), null === s ? d = v : s.sibling = v, s = v);
                return e && g.forEach(function(e) {
                    return t(n, e)
                }), d
            }
            return function(e, r, o, c) {
                var u = "object" === typeof o && null !== o && o.type === Ge && null === o.key;
                u && (o = o.props.children);
                var d = "object" === typeof o && null !== o;
                if (d) switch (o.$$typeof) {
                    case Qe:
                        e: {
                            for (d = o.key, u = r; null !== u;) {
                                if (u.key === d) {
                                    if (7 === u.tag ? o.type === Ge : u.elementType === o.type) {
                                        a(e, u.sibling), (r = n(u, o.type === Ge ? o.props.children : o.props)).ref = hn(e, u, o), r.return = e, e = r;
                                        break e
                                    }
                                    a(e, u);
                                    break
                                }
                                t(e, u), u = u.sibling
                            }
                            o.type === Ge ? ((r = Yr(o.props.children, e.mode, c, o.key)).return = e, e = r) : ((c = Qr(o.type, o.key, o.props, null, e.mode, c)).ref = hn(e, r, o), c.return = e, e = c)
                        }
                        return l(e);
                    case Ye:
                        e: {
                            for (u = o.key; null !== r;) {
                                if (r.key === u) {
                                    if (4 === r.tag && r.stateNode.containerInfo === o.containerInfo && r.stateNode.implementation === o.implementation) {
                                        a(e, r.sibling), (r = n(r, o.children || [])).return = e, e = r;
                                        break e
                                    }
                                    a(e, r);
                                    break
                                }
                                t(e, r), r = r.sibling
                            }(r = Xr(o, e.mode, c)).return = e,
                            e = r
                        }
                        return l(e)
                }
                if ("string" === typeof o || "number" === typeof o) return o = "" + o, null !== r && 6 === r.tag ? (a(e, r.sibling), (r = n(r, o)).return = e, e = r) : (a(e, r), (r = Kr(o, e.mode, c)).return = e, e = r), l(e);
                if (sn(o)) return g(e, r, o, c);
                if (it(o)) return m(e, r, o, c);
                if (d && pn(e, o), "undefined" === typeof o && !u) switch (e.tag) {
                    case 1:
                    case 0:
                        i("152", (c = e.type).displayName || c.name || "Component")
                }
                return a(e, r)
            }
        }
        var gn = fn(!0),
            mn = fn(!1),
            yn = {},
            vn = {
                current: yn
            },
            bn = {
                current: yn
            },
            wn = {
                current: yn
            };

        function zn(e) {
            return e === yn && i("174"), e
        }

        function xn(e, t) {
            Sr(wn, t), Sr(bn, e), Sr(vn, yn);
            var a = t.nodeType;
            switch (a) {
                case 9:
                case 11:
                    t = (t = t.documentElement) ? t.namespaceURI : er(null, "");
                    break;
                default:
                    t = er(t = (a = 8 === a ? t.parentNode : t).namespaceURI || null, a = a.tagName)
            }
            Lr(vn), Sr(vn, t)
        }

        function kn(e) {
            Lr(vn), Lr(bn), Lr(wn)
        }

        function Mn(e) {
            zn(wn.current);
            var t = zn(vn.current),
                a = er(t, e.type);
            t !== a && (Sr(bn, e), Sr(vn, a))
        }

        function An(e) {
            bn.current === e && (Lr(vn), Lr(bn))
        }
        var Ln = 0,
            Sn = 2,
            On = 4,
            Cn = 8,
            Tn = 16,
            jn = 32,
            En = 64,
            _n = 128,
            Pn = We.ReactCurrentDispatcher,
            Vn = 0,
            Hn = null,
            In = null,
            Fn = null,
            Rn = null,
            Nn = null,
            Dn = null,
            Un = 0,
            Bn = null,
            Wn = 0,
            $n = !1,
            qn = null,
            Qn = 0;

        function Yn() {
            i("321")
        }

        function Gn(e, t) {
            if (null === t) return !1;
            for (var a = 0; a < t.length && a < e.length; a++)
                if (!Zt(e[a], t[a])) return !1;
            return !0
        }

        function Kn(e, t, a, r, n, o) {
            if (Vn = o, Hn = t, Fn = null !== e ? e.memoizedState : null, Pn.current = null === Fn ? uo : so, t = a(r, n), $n) {
                do {
                    $n = !1, Qn += 1, Fn = null !== e ? e.memoizedState : null, Dn = Rn, Bn = Nn = In = null, Pn.current = so, t = a(r, n)
                } while ($n);
                qn = null, Qn = 0
            }
            return Pn.current = co, (e = Hn).memoizedState = Rn, e.expirationTime = Un, e.updateQueue = Bn, e.effectTag |= Wn, e = null !== In && null !== In.next, Vn = 0, Dn = Nn = Rn = Fn = In = Hn = null, Un = 0, Bn = null, Wn = 0, e && i("300"), t
        }

        function Xn() {
            Pn.current = co, Vn = 0, Dn = Nn = Rn = Fn = In = Hn = null, Un = 0, Bn = null, Wn = 0, $n = !1, qn = null, Qn = 0
        }

        function Zn() {
            var e = {
                memoizedState: null,
                baseState: null,
                queue: null,
                baseUpdate: null,
                next: null
            };
            return null === Nn ? Rn = Nn = e : Nn = Nn.next = e, Nn
        }

        function Jn() {
            if (null !== Dn) Dn = (Nn = Dn).next, Fn = null !== (In = Fn) ? In.next : null;
            else {
                null === Fn && i("310");
                var e = {
                    memoizedState: (In = Fn).memoizedState,
                    baseState: In.baseState,
                    queue: In.queue,
                    baseUpdate: In.baseUpdate,
                    next: null
                };
                Nn = null === Nn ? Rn = e : Nn.next = e, Fn = In.next
            }
            return Nn
        }

        function eo(e, t) {
            return "function" === typeof t ? t(e) : t
        }

        function to(e) {
            var t = Jn(),
                a = t.queue;
            if (null === a && i("311"), a.lastRenderedReducer = e, 0 < Qn) {
                var r = a.dispatch;
                if (null !== qn) {
                    var n = qn.get(a);
                    if (void 0 !== n) {
                        qn.delete(a);
                        var o = t.memoizedState;
                        do {
                            o = e(o, n.action), n = n.next
                        } while (null !== n);
                        return Zt(o, t.memoizedState) || (xo = !0), t.memoizedState = o, t.baseUpdate === a.last && (t.baseState = o), a.lastRenderedState = o, [o, r]
                    }
                }
                return [t.memoizedState, r]
            }
            r = a.last;
            var l = t.baseUpdate;
            if (o = t.baseState, null !== l ? (null !== r && (r.next = null), r = l.next) : r = null !== r ? r.next : null, null !== r) {
                var c = n = null,
                    u = r,
                    d = !1;
                do {
                    var s = u.expirationTime;
                    s < Vn ? (d || (d = !0, c = l, n = o), s > Un && (Un = s)) : o = u.eagerReducer === e ? u.eagerState : e(o, u.action), l = u, u = u.next
                } while (null !== u && u !== r);
                d || (c = l, n = o), Zt(o, t.memoizedState) || (xo = !0), t.memoizedState = o, t.baseUpdate = c, t.baseState = n, a.lastRenderedState = o
            }
            return [t.memoizedState, a.dispatch]
        }

        function ao(e, t, a, r) {
            return e = {
                tag: e,
                create: t,
                destroy: a,
                deps: r,
                next: null
            }, null === Bn ? (Bn = {
                lastEffect: null
            }).lastEffect = e.next = e : null === (t = Bn.lastEffect) ? Bn.lastEffect = e.next = e : (a = t.next, t.next = e, e.next = a, Bn.lastEffect = e), e
        }

        function ro(e, t, a, r) {
            var n = Zn();
            Wn |= e, n.memoizedState = ao(t, a, void 0, void 0 === r ? null : r)
        }

        function no(e, t, a, r) {
            var n = Jn();
            r = void 0 === r ? null : r;
            var o = void 0;
            if (null !== In) {
                var i = In.memoizedState;
                if (o = i.destroy, null !== r && Gn(r, i.deps)) return void ao(Ln, a, o, r)
            }
            Wn |= e, n.memoizedState = ao(t, a, o, r)
        }

        function oo(e, t) {
            return "function" === typeof t ? (e = e(), t(e), function() {
                t(null)
            }) : null !== t && void 0 !== t ? (e = e(), t.current = e, function() {
                t.current = null
            }) : void 0
        }

        function io() {}

        function lo(e, t, a) {
            25 > Qn || i("301");
            var r = e.alternate;
            if (e === Hn || null !== r && r === Hn)
                if ($n = !0, e = {
                        expirationTime: Vn,
                        action: a,
                        eagerReducer: null,
                        eagerState: null,
                        next: null
                    }, null === qn && (qn = new Map), void 0 === (a = qn.get(t))) qn.set(t, e);
                else {
                    for (t = a; null !== t.next;) t = t.next;
                    t.next = e
                }
            else {
                Bi();
                var n = xl(),
                    o = {
                        expirationTime: n = Gi(n, e),
                        action: a,
                        eagerReducer: null,
                        eagerState: null,
                        next: null
                    },
                    l = t.last;
                if (null === l) o.next = o;
                else {
                    var c = l.next;
                    null !== c && (o.next = c), l.next = o
                }
                if (t.last = o, 0 === e.expirationTime && (null === r || 0 === r.expirationTime) && null !== (r = t.lastRenderedReducer)) try {
                    var u = t.lastRenderedState,
                        d = r(u, a);
                    if (o.eagerReducer = r, o.eagerState = d, Zt(d, u)) return
                } catch (s) {}
                Zi(e, n)
            }
        }
        var co = {
                readContext: Uo,
                useCallback: Yn,
                useContext: Yn,
                useEffect: Yn,
                useImperativeHandle: Yn,
                useLayoutEffect: Yn,
                useMemo: Yn,
                useReducer: Yn,
                useRef: Yn,
                useState: Yn,
                useDebugValue: Yn
            },
            uo = {
                readContext: Uo,
                useCallback: function(e, t) {
                    return Zn().memoizedState = [e, void 0 === t ? null : t], e
                },
                useContext: Uo,
                useEffect: function(e, t) {
                    return ro(516, _n | En, e, t)
                },
                useImperativeHandle: function(e, t, a) {
                    return a = null !== a && void 0 !== a ? a.concat([e]) : null, ro(4, On | jn, oo.bind(null, t, e), a)
                },
                useLayoutEffect: function(e, t) {
                    return ro(4, On | jn, e, t)
                },
                useMemo: function(e, t) {
                    var a = Zn();
                    return t = void 0 === t ? null : t, e = e(), a.memoizedState = [e, t], e
                },
                useReducer: function(e, t, a) {
                    var r = Zn();
                    return t = void 0 !== a ? a(t) : t, r.memoizedState = r.baseState = t, e = (e = r.queue = {
                        last: null,
                        dispatch: null,
                        lastRenderedReducer: e,
                        lastRenderedState: t
                    }).dispatch = lo.bind(null, Hn, e), [r.memoizedState, e]
                },
                useRef: function(e) {
                    return e = {
                        current: e
                    }, Zn().memoizedState = e
                },
                useState: function(e) {
                    var t = Zn();
                    return "function" === typeof e && (e = e()), t.memoizedState = t.baseState = e, e = (e = t.queue = {
                        last: null,
                        dispatch: null,
                        lastRenderedReducer: eo,
                        lastRenderedState: e
                    }).dispatch = lo.bind(null, Hn, e), [t.memoizedState, e]
                },
                useDebugValue: io
            },
            so = {
                readContext: Uo,
                useCallback: function(e, t) {
                    var a = Jn();
                    t = void 0 === t ? null : t;
                    var r = a.memoizedState;
                    return null !== r && null !== t && Gn(t, r[1]) ? r[0] : (a.memoizedState = [e, t], e)
                },
                useContext: Uo,
                useEffect: function(e, t) {
                    return no(516, _n | En, e, t)
                },
                useImperativeHandle: function(e, t, a) {
                    return a = null !== a && void 0 !== a ? a.concat([e]) : null, no(4, On | jn, oo.bind(null, t, e), a)
                },
                useLayoutEffect: function(e, t) {
                    return no(4, On | jn, e, t)
                },
                useMemo: function(e, t) {
                    var a = Jn();
                    t = void 0 === t ? null : t;
                    var r = a.memoizedState;
                    return null !== r && null !== t && Gn(t, r[1]) ? r[0] : (e = e(), a.memoizedState = [e, t], e)
                },
                useReducer: to,
                useRef: function() {
                    return Jn().memoizedState
                },
                useState: function(e) {
                    return to(eo)
                },
                useDebugValue: io
            },
            ho = null,
            po = null,
            fo = !1;

        function go(e, t) {
            var a = Wr(5, null, null, 0);
            a.elementType = "DELETED", a.type = "DELETED", a.stateNode = t, a.return = e, a.effectTag = 8, null !== e.lastEffect ? (e.lastEffect.nextEffect = a, e.lastEffect = a) : e.firstEffect = e.lastEffect = a
        }

        function mo(e, t) {
            switch (e.tag) {
                case 5:
                    var a = e.type;
                    return null !== (t = 1 !== t.nodeType || a.toLowerCase() !== t.nodeName.toLowerCase() ? null : t) && (e.stateNode = t, !0);
                case 6:
                    return null !== (t = "" === e.pendingProps || 3 !== t.nodeType ? null : t) && (e.stateNode = t, !0);
                case 13:
                default:
                    return !1
            }
        }

        function yo(e) {
            if (fo) {
                var t = po;
                if (t) {
                    var a = t;
                    if (!mo(e, t)) {
                        if (!(t = xr(a)) || !mo(e, t)) return e.effectTag |= 2, fo = !1, void(ho = e);
                        go(ho, a)
                    }
                    ho = e, po = kr(t)
                } else e.effectTag |= 2, fo = !1, ho = e
            }
        }

        function vo(e) {
            for (e = e.return; null !== e && 5 !== e.tag && 3 !== e.tag && 18 !== e.tag;) e = e.return;
            ho = e
        }

        function bo(e) {
            if (e !== ho) return !1;
            if (!fo) return vo(e), fo = !0, !1;
            var t = e.type;
            if (5 !== e.tag || "head" !== t && "body" !== t && !yr(t, e.memoizedProps))
                for (t = po; t;) go(e, t), t = xr(t);
            return vo(e), po = ho ? xr(e.stateNode) : null, !0
        }

        function wo() {
            po = ho = null, fo = !1
        }
        var zo = We.ReactCurrentOwner,
            xo = !1;

        function ko(e, t, a, r) {
            t.child = null === e ? mn(t, null, a, r) : gn(t, e.child, a, r)
        }

        function Mo(e, t, a, r, n) {
            a = a.render;
            var o = t.ref;
            return Do(t, n), r = Kn(e, t, a, r, o, n), null === e || xo ? (t.effectTag |= 1, ko(e, t, r, n), t.child) : (t.updateQueue = e.updateQueue, t.effectTag &= -517, e.expirationTime <= n && (e.expirationTime = 0), _o(e, t, n))
        }

        function Ao(e, t, a, r, n, o) {
            if (null === e) {
                var i = a.type;
                return "function" !== typeof i || $r(i) || void 0 !== i.defaultProps || null !== a.compare || void 0 !== a.defaultProps ? ((e = Qr(a.type, null, r, null, t.mode, o)).ref = t.ref, e.return = t, t.child = e) : (t.tag = 15, t.type = i, Lo(e, t, i, r, n, o))
            }
            return i = e.child, n < o && (n = i.memoizedProps, (a = null !== (a = a.compare) ? a : ea)(n, r) && e.ref === t.ref) ? _o(e, t, o) : (t.effectTag |= 1, (e = qr(i, r)).ref = t.ref, e.return = t, t.child = e)
        }

        function Lo(e, t, a, r, n, o) {
            return null !== e && ea(e.memoizedProps, r) && e.ref === t.ref && (xo = !1, n < o) ? _o(e, t, o) : Oo(e, t, a, r, o)
        }

        function So(e, t) {
            var a = t.ref;
            (null === e && null !== a || null !== e && e.ref !== a) && (t.effectTag |= 128)
        }

        function Oo(e, t, a, r, n) {
            var o = _r(a) ? jr : Cr.current;
            return o = Er(t, o), Do(t, n), a = Kn(e, t, a, r, o, n), null === e || xo ? (t.effectTag |= 1, ko(e, t, a, n), t.child) : (t.updateQueue = e.updateQueue, t.effectTag &= -517, e.expirationTime <= n && (e.expirationTime = 0), _o(e, t, n))
        }

        function Co(e, t, a, r, n) {
            if (_r(a)) {
                var o = !0;
                Fr(t)
            } else o = !1;
            if (Do(t, n), null === t.stateNode) null !== e && (e.alternate = null, t.alternate = null, t.effectTag |= 2), cn(t, a, r), dn(t, a, r, n), r = !0;
            else if (null === e) {
                var i = t.stateNode,
                    l = t.memoizedProps;
                i.props = l;
                var c = i.context,
                    u = a.contextType;
                "object" === typeof u && null !== u ? u = Uo(u) : u = Er(t, u = _r(a) ? jr : Cr.current);
                var d = a.getDerivedStateFromProps,
                    s = "function" === typeof d || "function" === typeof i.getSnapshotBeforeUpdate;
                s || "function" !== typeof i.UNSAFE_componentWillReceiveProps && "function" !== typeof i.componentWillReceiveProps || (l !== r || c !== u) && un(t, i, r, u), Qo = !1;
                var h = t.memoizedState;
                c = i.state = h;
                var p = t.updateQueue;
                null !== p && (ai(t, p, r, i, n), c = t.memoizedState), l !== r || h !== c || Tr.current || Qo ? ("function" === typeof d && (nn(t, a, d, r), c = t.memoizedState), (l = Qo || ln(t, a, l, r, h, c, u)) ? (s || "function" !== typeof i.UNSAFE_componentWillMount && "function" !== typeof i.componentWillMount || ("function" === typeof i.componentWillMount && i.componentWillMount(), "function" === typeof i.UNSAFE_componentWillMount && i.UNSAFE_componentWillMount()), "function" === typeof i.componentDidMount && (t.effectTag |= 4)) : ("function" === typeof i.componentDidMount && (t.effectTag |= 4), t.memoizedProps = r, t.memoizedState = c), i.props = r, i.state = c, i.context = u, r = l) : ("function" === typeof i.componentDidMount && (t.effectTag |= 4), r = !1)
            } else i = t.stateNode, l = t.memoizedProps, i.props = t.type === t.elementType ? l : an(t.type, l), c = i.context, "object" === typeof(u = a.contextType) && null !== u ? u = Uo(u) : u = Er(t, u = _r(a) ? jr : Cr.current), (s = "function" === typeof(d = a.getDerivedStateFromProps) || "function" === typeof i.getSnapshotBeforeUpdate) || "function" !== typeof i.UNSAFE_componentWillReceiveProps && "function" !== typeof i.componentWillReceiveProps || (l !== r || c !== u) && un(t, i, r, u), Qo = !1, c = t.memoizedState, h = i.state = c, null !== (p = t.updateQueue) && (ai(t, p, r, i, n), h = t.memoizedState), l !== r || c !== h || Tr.current || Qo ? ("function" === typeof d && (nn(t, a, d, r), h = t.memoizedState), (d = Qo || ln(t, a, l, r, c, h, u)) ? (s || "function" !== typeof i.UNSAFE_componentWillUpdate && "function" !== typeof i.componentWillUpdate || ("function" === typeof i.componentWillUpdate && i.componentWillUpdate(r, h, u), "function" === typeof i.UNSAFE_componentWillUpdate && i.UNSAFE_componentWillUpdate(r, h, u)), "function" === typeof i.componentDidUpdate && (t.effectTag |= 4), "function" === typeof i.getSnapshotBeforeUpdate && (t.effectTag |= 256)) : ("function" !== typeof i.componentDidUpdate || l === e.memoizedProps && c === e.memoizedState || (t.effectTag |= 4), "function" !== typeof i.getSnapshotBeforeUpdate || l === e.memoizedProps && c === e.memoizedState || (t.effectTag |= 256), t.memoizedProps = r, t.memoizedState = h), i.props = r, i.state = h, i.context = u, r = d) : ("function" !== typeof i.componentDidUpdate || l === e.memoizedProps && c === e.memoizedState || (t.effectTag |= 4), "function" !== typeof i.getSnapshotBeforeUpdate || l === e.memoizedProps && c === e.memoizedState || (t.effectTag |= 256), r = !1);
            return To(e, t, a, r, o, n)
        }

        function To(e, t, a, r, n, o) {
            So(e, t);
            var i = 0 !== (64 & t.effectTag);
            if (!r && !i) return n && Rr(t, a, !1), _o(e, t, o);
            r = t.stateNode, zo.current = t;
            var l = i && "function" !== typeof a.getDerivedStateFromError ? null : r.render();
            return t.effectTag |= 1, null !== e && i ? (t.child = gn(t, e.child, null, o), t.child = gn(t, null, l, o)) : ko(e, t, l, o), t.memoizedState = r.state, n && Rr(t, a, !0), t.child
        }

        function jo(e) {
            var t = e.stateNode;
            t.pendingContext ? Hr(0, t.pendingContext, t.pendingContext !== t.context) : t.context && Hr(0, t.context, !1), xn(e, t.containerInfo)
        }

        function Eo(e, t, a) {
            var r = t.mode,
                n = t.pendingProps,
                o = t.memoizedState;
            if (0 === (64 & t.effectTag)) {
                o = null;
                var i = !1
            } else o = {
                timedOutAt: null !== o ? o.timedOutAt : 0
            }, i = !0, t.effectTag &= -65;
            if (null === e)
                if (i) {
                    var l = n.fallback;
                    e = Yr(null, r, 0, null), 0 === (1 & t.mode) && (e.child = null !== t.memoizedState ? t.child.child : t.child), r = Yr(l, r, a, null), e.sibling = r, (a = e).return = r.return = t
                } else a = r = mn(t, null, n.children, a);
            else null !== e.memoizedState ? (l = (r = e.child).sibling, i ? (a = n.fallback, n = qr(r, r.pendingProps), 0 === (1 & t.mode) && ((i = null !== t.memoizedState ? t.child.child : t.child) !== r.child && (n.child = i)), r = n.sibling = qr(l, a, l.expirationTime), a = n, n.childExpirationTime = 0, a.return = r.return = t) : a = r = gn(t, r.child, n.children, a)) : (l = e.child, i ? (i = n.fallback, (n = Yr(null, r, 0, null)).child = l, 0 === (1 & t.mode) && (n.child = null !== t.memoizedState ? t.child.child : t.child), (r = n.sibling = Yr(i, r, a, null)).effectTag |= 2, a = n, n.childExpirationTime = 0, a.return = r.return = t) : r = a = gn(t, l, n.children, a)), t.stateNode = e.stateNode;
            return t.memoizedState = o, t.child = a, r
        }

        function _o(e, t, a) {
            if (null !== e && (t.contextDependencies = e.contextDependencies), t.childExpirationTime < a) return null;
            if (null !== e && t.child !== e.child && i("153"), null !== t.child) {
                for (a = qr(e = t.child, e.pendingProps, e.expirationTime), t.child = a, a.return = t; null !== e.sibling;) e = e.sibling, (a = a.sibling = qr(e, e.pendingProps, e.expirationTime)).return = t;
                a.sibling = null
            }
            return t.child
        }

        function Po(e, t, a) {
            var r = t.expirationTime;
            if (null !== e) {
                if (e.memoizedProps !== t.pendingProps || Tr.current) xo = !0;
                else if (r < a) {
                    switch (xo = !1, t.tag) {
                        case 3:
                            jo(t), wo();
                            break;
                        case 5:
                            Mn(t);
                            break;
                        case 1:
                            _r(t.type) && Fr(t);
                            break;
                        case 4:
                            xn(t, t.stateNode.containerInfo);
                            break;
                        case 10:
                            Ro(t, t.memoizedProps.value);
                            break;
                        case 13:
                            if (null !== t.memoizedState) return 0 !== (r = t.child.childExpirationTime) && r >= a ? Eo(e, t, a) : null !== (t = _o(e, t, a)) ? t.sibling : null
                    }
                    return _o(e, t, a)
                }
            } else xo = !1;
            switch (t.expirationTime = 0, t.tag) {
                case 2:
                    r = t.elementType, null !== e && (e.alternate = null, t.alternate = null, t.effectTag |= 2), e = t.pendingProps;
                    var n = Er(t, Cr.current);
                    if (Do(t, a), n = Kn(null, t, r, e, n, a), t.effectTag |= 1, "object" === typeof n && null !== n && "function" === typeof n.render && void 0 === n.$$typeof) {
                        if (t.tag = 1, Xn(), _r(r)) {
                            var o = !0;
                            Fr(t)
                        } else o = !1;
                        t.memoizedState = null !== n.state && void 0 !== n.state ? n.state : null;
                        var l = r.getDerivedStateFromProps;
                        "function" === typeof l && nn(t, r, l, e), n.updater = on, t.stateNode = n, n._reactInternalFiber = t, dn(t, r, e, a), t = To(null, t, r, !0, o, a)
                    } else t.tag = 0, ko(null, t, n, a), t = t.child;
                    return t;
                case 16:
                    switch (n = t.elementType, null !== e && (e.alternate = null, t.alternate = null, t.effectTag |= 2), o = t.pendingProps, e = function(e) {
                        var t = e._result;
                        switch (e._status) {
                            case 1:
                                return t;
                            case 2:
                            case 0:
                                throw t;
                            default:
                                switch (e._status = 0, (t = (t = e._ctor)()).then(function(t) {
                                    0 === e._status && (t = t.default, e._status = 1, e._result = t)
                                }, function(t) {
                                    0 === e._status && (e._status = 2, e._result = t)
                                }), e._status) {
                                    case 1:
                                        return e._result;
                                    case 2:
                                        throw e._result
                                }
                                throw e._result = t, t
                        }
                    }(n), t.type = e, n = t.tag = function(e) {
                        if ("function" === typeof e) return $r(e) ? 1 : 0;
                        if (void 0 !== e && null !== e) {
                            if ((e = e.$$typeof) === tt) return 11;
                            if (e === rt) return 14
                        }
                        return 2
                    }(e), o = an(e, o), l = void 0, n) {
                        case 0:
                            l = Oo(null, t, e, o, a);
                            break;
                        case 1:
                            l = Co(null, t, e, o, a);
                            break;
                        case 11:
                            l = Mo(null, t, e, o, a);
                            break;
                        case 14:
                            l = Ao(null, t, e, an(e.type, o), r, a);
                            break;
                        default:
                            i("306", e, "")
                    }
                    return l;
                case 0:
                    return r = t.type, n = t.pendingProps, Oo(e, t, r, n = t.elementType === r ? n : an(r, n), a);
                case 1:
                    return r = t.type, n = t.pendingProps, Co(e, t, r, n = t.elementType === r ? n : an(r, n), a);
                case 3:
                    return jo(t), null === (r = t.updateQueue) && i("282"), n = null !== (n = t.memoizedState) ? n.element : null, ai(t, r, t.pendingProps, null, a), (r = t.memoizedState.element) === n ? (wo(), t = _o(e, t, a)) : (n = t.stateNode, (n = (null === e || null === e.child) && n.hydrate) && (po = kr(t.stateNode.containerInfo), ho = t, n = fo = !0), n ? (t.effectTag |= 2, t.child = mn(t, null, r, a)) : (ko(e, t, r, a), wo()), t = t.child), t;
                case 5:
                    return Mn(t), null === e && yo(t), r = t.type, n = t.pendingProps, o = null !== e ? e.memoizedProps : null, l = n.children, yr(r, n) ? l = null : null !== o && yr(r, o) && (t.effectTag |= 16), So(e, t), 1 !== a && 1 & t.mode && n.hidden ? (t.expirationTime = t.childExpirationTime = 1, t = null) : (ko(e, t, l, a), t = t.child), t;
                case 6:
                    return null === e && yo(t), null;
                case 13:
                    return Eo(e, t, a);
                case 4:
                    return xn(t, t.stateNode.containerInfo), r = t.pendingProps, null === e ? t.child = gn(t, null, r, a) : ko(e, t, r, a), t.child;
                case 11:
                    return r = t.type, n = t.pendingProps, Mo(e, t, r, n = t.elementType === r ? n : an(r, n), a);
                case 7:
                    return ko(e, t, t.pendingProps, a), t.child;
                case 8:
                case 12:
                    return ko(e, t, t.pendingProps.children, a), t.child;
                case 10:
                    e: {
                        if (r = t.type._context, n = t.pendingProps, l = t.memoizedProps, Ro(t, o = n.value), null !== l) {
                            var c = l.value;
                            if (0 === (o = Zt(c, o) ? 0 : 0 | ("function" === typeof r._calculateChangedBits ? r._calculateChangedBits(c, o) : 1073741823))) {
                                if (l.children === n.children && !Tr.current) {
                                    t = _o(e, t, a);
                                    break e
                                }
                            } else
                                for (null !== (c = t.child) && (c.return = t); null !== c;) {
                                    var u = c.contextDependencies;
                                    if (null !== u) {
                                        l = c.child;
                                        for (var d = u.first; null !== d;) {
                                            if (d.context === r && 0 !== (d.observedBits & o)) {
                                                1 === c.tag && ((d = Ko(a)).tag = $o, Zo(c, d)), c.expirationTime < a && (c.expirationTime = a), null !== (d = c.alternate) && d.expirationTime < a && (d.expirationTime = a), d = a;
                                                for (var s = c.return; null !== s;) {
                                                    var h = s.alternate;
                                                    if (s.childExpirationTime < d) s.childExpirationTime = d, null !== h && h.childExpirationTime < d && (h.childExpirationTime = d);
                                                    else {
                                                        if (!(null !== h && h.childExpirationTime < d)) break;
                                                        h.childExpirationTime = d
                                                    }
                                                    s = s.return
                                                }
                                                u.expirationTime < a && (u.expirationTime = a);
                                                break
                                            }
                                            d = d.next
                                        }
                                    } else l = 10 === c.tag && c.type === t.type ? null : c.child;
                                    if (null !== l) l.return = c;
                                    else
                                        for (l = c; null !== l;) {
                                            if (l === t) {
                                                l = null;
                                                break
                                            }
                                            if (null !== (c = l.sibling)) {
                                                c.return = l.return, l = c;
                                                break
                                            }
                                            l = l.return
                                        }
                                    c = l
                                }
                        }
                        ko(e, t, n.children, a),
                        t = t.child
                    }
                    return t;
                case 9:
                    return n = t.type, r = (o = t.pendingProps).children, Do(t, a), r = r(n = Uo(n, o.unstable_observedBits)), t.effectTag |= 1, ko(e, t, r, a), t.child;
                case 14:
                    return o = an(n = t.type, t.pendingProps), Ao(e, t, n, o = an(n.type, o), r, a);
                case 15:
                    return Lo(e, t, t.type, t.pendingProps, r, a);
                case 17:
                    return r = t.type, n = t.pendingProps, n = t.elementType === r ? n : an(r, n), null !== e && (e.alternate = null, t.alternate = null, t.effectTag |= 2), t.tag = 1, _r(r) ? (e = !0, Fr(t)) : e = !1, Do(t, a), cn(t, r, n), dn(t, r, n, a), To(null, t, r, !0, e, a)
            }
            i("156")
        }
        var Vo = {
                current: null
            },
            Ho = null,
            Io = null,
            Fo = null;

        function Ro(e, t) {
            var a = e.type._context;
            Sr(Vo, a._currentValue), a._currentValue = t
        }

        function No(e) {
            var t = Vo.current;
            Lr(Vo), e.type._context._currentValue = t
        }

        function Do(e, t) {
            Ho = e, Fo = Io = null;
            var a = e.contextDependencies;
            null !== a && a.expirationTime >= t && (xo = !0), e.contextDependencies = null
        }

        function Uo(e, t) {
            return Fo !== e && !1 !== t && 0 !== t && ("number" === typeof t && 1073741823 !== t || (Fo = e, t = 1073741823), t = {
                context: e,
                observedBits: t,
                next: null
            }, null === Io ? (null === Ho && i("308"), Io = t, Ho.contextDependencies = {
                first: t,
                expirationTime: 0
            }) : Io = Io.next = t), e._currentValue
        }
        var Bo = 0,
            Wo = 1,
            $o = 2,
            qo = 3,
            Qo = !1;

        function Yo(e) {
            return {
                baseState: e,
                firstUpdate: null,
                lastUpdate: null,
                firstCapturedUpdate: null,
                lastCapturedUpdate: null,
                firstEffect: null,
                lastEffect: null,
                firstCapturedEffect: null,
                lastCapturedEffect: null
            }
        }

        function Go(e) {
            return {
                baseState: e.baseState,
                firstUpdate: e.firstUpdate,
                lastUpdate: e.lastUpdate,
                firstCapturedUpdate: null,
                lastCapturedUpdate: null,
                firstEffect: null,
                lastEffect: null,
                firstCapturedEffect: null,
                lastCapturedEffect: null
            }
        }

        function Ko(e) {
            return {
                expirationTime: e,
                tag: Bo,
                payload: null,
                callback: null,
                next: null,
                nextEffect: null
            }
        }

        function Xo(e, t) {
            null === e.lastUpdate ? e.firstUpdate = e.lastUpdate = t : (e.lastUpdate.next = t, e.lastUpdate = t)
        }

        function Zo(e, t) {
            var a = e.alternate;
            if (null === a) {
                var r = e.updateQueue,
                    n = null;
                null === r && (r = e.updateQueue = Yo(e.memoizedState))
            } else r = e.updateQueue, n = a.updateQueue, null === r ? null === n ? (r = e.updateQueue = Yo(e.memoizedState), n = a.updateQueue = Yo(a.memoizedState)) : r = e.updateQueue = Go(n) : null === n && (n = a.updateQueue = Go(r));
            null === n || r === n ? Xo(r, t) : null === r.lastUpdate || null === n.lastUpdate ? (Xo(r, t), Xo(n, t)) : (Xo(r, t), n.lastUpdate = t)
        }

        function Jo(e, t) {
            var a = e.updateQueue;
            null === (a = null === a ? e.updateQueue = Yo(e.memoizedState) : ei(e, a)).lastCapturedUpdate ? a.firstCapturedUpdate = a.lastCapturedUpdate = t : (a.lastCapturedUpdate.next = t, a.lastCapturedUpdate = t)
        }

        function ei(e, t) {
            var a = e.alternate;
            return null !== a && t === a.updateQueue && (t = e.updateQueue = Go(t)), t
        }

        function ti(e, t, a, r, o, i) {
            switch (a.tag) {
                case Wo:
                    return "function" === typeof(e = a.payload) ? e.call(i, r, o) : e;
                case qo:
                    e.effectTag = -2049 & e.effectTag | 64;
                case Bo:
                    if (null === (o = "function" === typeof(e = a.payload) ? e.call(i, r, o) : e) || void 0 === o) break;
                    return n({}, r, o);
                case $o:
                    Qo = !0
            }
            return r
        }

        function ai(e, t, a, r, n) {
            Qo = !1;
            for (var o = (t = ei(e, t)).baseState, i = null, l = 0, c = t.firstUpdate, u = o; null !== c;) {
                var d = c.expirationTime;
                d < n ? (null === i && (i = c, o = u), l < d && (l = d)) : (u = ti(e, 0, c, u, a, r), null !== c.callback && (e.effectTag |= 32, c.nextEffect = null, null === t.lastEffect ? t.firstEffect = t.lastEffect = c : (t.lastEffect.nextEffect = c, t.lastEffect = c))), c = c.next
            }
            for (d = null, c = t.firstCapturedUpdate; null !== c;) {
                var s = c.expirationTime;
                s < n ? (null === d && (d = c, null === i && (o = u)), l < s && (l = s)) : (u = ti(e, 0, c, u, a, r), null !== c.callback && (e.effectTag |= 32, c.nextEffect = null, null === t.lastCapturedEffect ? t.firstCapturedEffect = t.lastCapturedEffect = c : (t.lastCapturedEffect.nextEffect = c, t.lastCapturedEffect = c))), c = c.next
            }
            null === i && (t.lastUpdate = null), null === d ? t.lastCapturedUpdate = null : e.effectTag |= 32, null === i && null === d && (o = u), t.baseState = o, t.firstUpdate = i, t.firstCapturedUpdate = d, e.expirationTime = l, e.memoizedState = u
        }

        function ri(e, t, a) {
            null !== t.firstCapturedUpdate && (null !== t.lastUpdate && (t.lastUpdate.next = t.firstCapturedUpdate, t.lastUpdate = t.lastCapturedUpdate), t.firstCapturedUpdate = t.lastCapturedUpdate = null), ni(t.firstEffect, a), t.firstEffect = t.lastEffect = null, ni(t.firstCapturedEffect, a), t.firstCapturedEffect = t.lastCapturedEffect = null
        }

        function ni(e, t) {
            for (; null !== e;) {
                var a = e.callback;
                if (null !== a) {
                    e.callback = null;
                    var r = t;
                    "function" !== typeof a && i("191", a), a.call(r)
                }
                e = e.nextEffect
            }
        }

        function oi(e, t) {
            return {
                value: e,
                source: t,
                stack: ct(t)
            }
        }

        function ii(e) {
            e.effectTag |= 4
        }
        var li = void 0,
            ci = void 0,
            ui = void 0,
            di = void 0;
        li = function(e, t) {
            for (var a = t.child; null !== a;) {
                if (5 === a.tag || 6 === a.tag) e.appendChild(a.stateNode);
                else if (4 !== a.tag && null !== a.child) {
                    a.child.return = a, a = a.child;
                    continue
                }
                if (a === t) break;
                for (; null === a.sibling;) {
                    if (null === a.return || a.return === t) return;
                    a = a.return
                }
                a.sibling.return = a.return, a = a.sibling
            }
        }, ci = function() {}, ui = function(e, t, a, r, o) {
            var i = e.memoizedProps;
            if (i !== r) {
                var l = t.stateNode;
                switch (zn(vn.current), e = null, a) {
                    case "input":
                        i = bt(l, i), r = bt(l, r), e = [];
                        break;
                    case "option":
                        i = qa(l, i), r = qa(l, r), e = [];
                        break;
                    case "select":
                        i = n({}, i, {
                            value: void 0
                        }), r = n({}, r, {
                            value: void 0
                        }), e = [];
                        break;
                    case "textarea":
                        i = Ya(l, i), r = Ya(l, r), e = [];
                        break;
                    default:
                        "function" !== typeof i.onClick && "function" === typeof r.onClick && (l.onclick = pr)
                }
                dr(a, r), l = a = void 0;
                var c = null;
                for (a in i)
                    if (!r.hasOwnProperty(a) && i.hasOwnProperty(a) && null != i[a])
                        if ("style" === a) {
                            var u = i[a];
                            for (l in u) u.hasOwnProperty(l) && (c || (c = {}), c[l] = "")
                        } else "dangerouslySetInnerHTML" !== a && "children" !== a && "suppressContentEditableWarning" !== a && "suppressHydrationWarning" !== a && "autoFocus" !== a && (b.hasOwnProperty(a) ? e || (e = []) : (e = e || []).push(a, null));
                for (a in r) {
                    var d = r[a];
                    if (u = null != i ? i[a] : void 0, r.hasOwnProperty(a) && d !== u && (null != d || null != u))
                        if ("style" === a)
                            if (u) {
                                for (l in u) !u.hasOwnProperty(l) || d && d.hasOwnProperty(l) || (c || (c = {}), c[l] = "");
                                for (l in d) d.hasOwnProperty(l) && u[l] !== d[l] && (c || (c = {}), c[l] = d[l])
                            } else c || (e || (e = []), e.push(a, c)), c = d;
                    else "dangerouslySetInnerHTML" === a ? (d = d ? d.__html : void 0, u = u ? u.__html : void 0, null != d && u !== d && (e = e || []).push(a, "" + d)) : "children" === a ? u === d || "string" !== typeof d && "number" !== typeof d || (e = e || []).push(a, "" + d) : "suppressContentEditableWarning" !== a && "suppressHydrationWarning" !== a && (b.hasOwnProperty(a) ? (null != d && hr(o, a), e || u === d || (e = [])) : (e = e || []).push(a, d))
                }
                c && (e = e || []).push("style", c), o = e, (t.updateQueue = o) && ii(t)
            }
        }, di = function(e, t, a, r) {
            a !== r && ii(t)
        };
        var si = "function" === typeof WeakSet ? WeakSet : Set;

        function hi(e, t) {
            var a = t.source,
                r = t.stack;
            null === r && null !== a && (r = ct(a)), null !== a && lt(a.type), t = t.value, null !== e && 1 === e.tag && lt(e.type);
            try {
                console.error(t)
            } catch (n) {
                setTimeout(function() {
                    throw n
                })
            }
        }

        function pi(e) {
            var t = e.ref;
            if (null !== t)
                if ("function" === typeof t) try {
                    t(null)
                } catch (a) {
                    Yi(e, a)
                } else t.current = null
        }

        function fi(e, t, a) {
            if (null !== (a = null !== (a = a.updateQueue) ? a.lastEffect : null)) {
                var r = a = a.next;
                do {
                    if ((r.tag & e) !== Ln) {
                        var n = r.destroy;
                        r.destroy = void 0, void 0 !== n && n()
                    }(r.tag & t) !== Ln && (n = r.create, r.destroy = n()), r = r.next
                } while (r !== a)
            }
        }

        function gi(e) {
            switch ("function" === typeof Dr && Dr(e), e.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                    var t = e.updateQueue;
                    if (null !== t && null !== (t = t.lastEffect)) {
                        var a = t = t.next;
                        do {
                            var r = a.destroy;
                            if (void 0 !== r) {
                                var n = e;
                                try {
                                    r()
                                } catch (o) {
                                    Yi(n, o)
                                }
                            }
                            a = a.next
                        } while (a !== t)
                    }
                    break;
                case 1:
                    if (pi(e), "function" === typeof(t = e.stateNode).componentWillUnmount) try {
                        t.props = e.memoizedProps, t.state = e.memoizedState, t.componentWillUnmount()
                    } catch (o) {
                        Yi(e, o)
                    }
                    break;
                case 5:
                    pi(e);
                    break;
                case 4:
                    vi(e)
            }
        }

        function mi(e) {
            return 5 === e.tag || 3 === e.tag || 4 === e.tag
        }

        function yi(e) {
            e: {
                for (var t = e.return; null !== t;) {
                    if (mi(t)) {
                        var a = t;
                        break e
                    }
                    t = t.return
                }
                i("160"),
                a = void 0
            }
            var r = t = void 0;
            switch (a.tag) {
                case 5:
                    t = a.stateNode, r = !1;
                    break;
                case 3:
                case 4:
                    t = a.stateNode.containerInfo, r = !0;
                    break;
                default:
                    i("161")
            }
            16 & a.effectTag && (nr(t, ""), a.effectTag &= -17);e: t: for (a = e;;) {
                for (; null === a.sibling;) {
                    if (null === a.return || mi(a.return)) {
                        a = null;
                        break e
                    }
                    a = a.return
                }
                for (a.sibling.return = a.return, a = a.sibling; 5 !== a.tag && 6 !== a.tag && 18 !== a.tag;) {
                    if (2 & a.effectTag) continue t;
                    if (null === a.child || 4 === a.tag) continue t;
                    a.child.return = a, a = a.child
                }
                if (!(2 & a.effectTag)) {
                    a = a.stateNode;
                    break e
                }
            }
            for (var n = e;;) {
                if (5 === n.tag || 6 === n.tag)
                    if (a)
                        if (r) {
                            var o = t,
                                l = n.stateNode,
                                c = a;
                            8 === o.nodeType ? o.parentNode.insertBefore(l, c) : o.insertBefore(l, c)
                        } else t.insertBefore(n.stateNode, a);
                else r ? (l = t, c = n.stateNode, 8 === l.nodeType ? (o = l.parentNode).insertBefore(c, l) : (o = l).appendChild(c), null !== (l = l._reactRootContainer) && void 0 !== l || null !== o.onclick || (o.onclick = pr)) : t.appendChild(n.stateNode);
                else if (4 !== n.tag && null !== n.child) {
                    n.child.return = n, n = n.child;
                    continue
                }
                if (n === e) break;
                for (; null === n.sibling;) {
                    if (null === n.return || n.return === e) return;
                    n = n.return
                }
                n.sibling.return = n.return, n = n.sibling
            }
        }

        function vi(e) {
            for (var t = e, a = !1, r = void 0, n = void 0;;) {
                if (!a) {
                    a = t.return;
                    e: for (;;) {
                        switch (null === a && i("160"), a.tag) {
                            case 5:
                                r = a.stateNode, n = !1;
                                break e;
                            case 3:
                            case 4:
                                r = a.stateNode.containerInfo, n = !0;
                                break e
                        }
                        a = a.return
                    }
                    a = !0
                }
                if (5 === t.tag || 6 === t.tag) {
                    e: for (var o = t, l = o;;)
                        if (gi(l), null !== l.child && 4 !== l.tag) l.child.return = l, l = l.child;
                        else {
                            if (l === o) break;
                            for (; null === l.sibling;) {
                                if (null === l.return || l.return === o) break e;
                                l = l.return
                            }
                            l.sibling.return = l.return, l = l.sibling
                        }n ? (o = r, l = t.stateNode, 8 === o.nodeType ? o.parentNode.removeChild(l) : o.removeChild(l)) : r.removeChild(t.stateNode)
                }
                else if (4 === t.tag) {
                    if (null !== t.child) {
                        r = t.stateNode.containerInfo, n = !0, t.child.return = t, t = t.child;
                        continue
                    }
                } else if (gi(t), null !== t.child) {
                    t.child.return = t, t = t.child;
                    continue
                }
                if (t === e) break;
                for (; null === t.sibling;) {
                    if (null === t.return || t.return === e) return;
                    4 === (t = t.return).tag && (a = !1)
                }
                t.sibling.return = t.return, t = t.sibling
            }
        }

        function bi(e, t) {
            switch (t.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                    fi(On, Cn, t);
                    break;
                case 1:
                    break;
                case 5:
                    var a = t.stateNode;
                    if (null != a) {
                        var r = t.memoizedProps;
                        e = null !== e ? e.memoizedProps : r;
                        var n = t.type,
                            o = t.updateQueue;
                        t.updateQueue = null, null !== o && function(e, t, a, r, n) {
                            e[P] = n, "input" === a && "radio" === n.type && null != n.name && zt(e, n), sr(a, r), r = sr(a, n);
                            for (var o = 0; o < t.length; o += 2) {
                                var i = t[o],
                                    l = t[o + 1];
                                "style" === i ? cr(e, l) : "dangerouslySetInnerHTML" === i ? rr(e, l) : "children" === i ? nr(e, l) : yt(e, i, l, r)
                            }
                            switch (a) {
                                case "input":
                                    xt(e, n);
                                    break;
                                case "textarea":
                                    Ka(e, n);
                                    break;
                                case "select":
                                    t = e._wrapperState.wasMultiple, e._wrapperState.wasMultiple = !!n.multiple, null != (a = n.value) ? Qa(e, !!n.multiple, a, !1) : t !== !!n.multiple && (null != n.defaultValue ? Qa(e, !!n.multiple, n.defaultValue, !0) : Qa(e, !!n.multiple, n.multiple ? [] : "", !1))
                            }
                        }(a, o, n, e, r)
                    }
                    break;
                case 6:
                    null === t.stateNode && i("162"), t.stateNode.nodeValue = t.memoizedProps;
                    break;
                case 3:
                case 12:
                    break;
                case 13:
                    if (a = t.memoizedState, r = void 0, e = t, null === a ? r = !1 : (r = !0, e = t.child, 0 === a.timedOutAt && (a.timedOutAt = xl())), null !== e && function(e, t) {
                            for (var a = e;;) {
                                if (5 === a.tag) {
                                    var r = a.stateNode;
                                    if (t) r.style.display = "none";
                                    else {
                                        r = a.stateNode;
                                        var n = a.memoizedProps.style;
                                        n = void 0 !== n && null !== n && n.hasOwnProperty("display") ? n.display : null, r.style.display = lr("display", n)
                                    }
                                } else if (6 === a.tag) a.stateNode.nodeValue = t ? "" : a.memoizedProps;
                                else {
                                    if (13 === a.tag && null !== a.memoizedState) {
                                        (r = a.child.sibling).return = a, a = r;
                                        continue
                                    }
                                    if (null !== a.child) {
                                        a.child.return = a, a = a.child;
                                        continue
                                    }
                                }
                                if (a === e) break;
                                for (; null === a.sibling;) {
                                    if (null === a.return || a.return === e) return;
                                    a = a.return
                                }
                                a.sibling.return = a.return, a = a.sibling
                            }
                        }(e, r), null !== (a = t.updateQueue)) {
                        t.updateQueue = null;
                        var l = t.stateNode;
                        null === l && (l = t.stateNode = new si), a.forEach(function(e) {
                            var a = function(e, t) {
                                var a = e.stateNode;
                                null !== a && a.delete(t), t = Gi(t = xl(), e), null !== (e = Xi(e, t)) && (Zr(e, t), 0 !== (t = e.expirationTime) && kl(e, t))
                            }.bind(null, t, e);
                            l.has(e) || (l.add(e), e.then(a, a))
                        })
                    }
                    break;
                case 17:
                    break;
                default:
                    i("163")
            }
        }
        var wi = "function" === typeof WeakMap ? WeakMap : Map;

        function zi(e, t, a) {
            (a = Ko(a)).tag = qo, a.payload = {
                element: null
            };
            var r = t.value;
            return a.callback = function() {
                El(r), hi(e, t)
            }, a
        }

        function xi(e, t, a) {
            (a = Ko(a)).tag = qo;
            var r = e.type.getDerivedStateFromError;
            if ("function" === typeof r) {
                var n = t.value;
                a.payload = function() {
                    return r(n)
                }
            }
            var o = e.stateNode;
            return null !== o && "function" === typeof o.componentDidCatch && (a.callback = function() {
                "function" !== typeof r && (null === Fi ? Fi = new Set([this]) : Fi.add(this));
                var a = t.value,
                    n = t.stack;
                hi(e, t), this.componentDidCatch(a, {
                    componentStack: null !== n ? n : ""
                })
            }), a
        }

        function ki(e) {
            switch (e.tag) {
                case 1:
                    _r(e.type) && Pr();
                    var t = e.effectTag;
                    return 2048 & t ? (e.effectTag = -2049 & t | 64, e) : null;
                case 3:
                    return kn(), Vr(), 0 !== (64 & (t = e.effectTag)) && i("285"), e.effectTag = -2049 & t | 64, e;
                case 5:
                    return An(e), null;
                case 13:
                    return 2048 & (t = e.effectTag) ? (e.effectTag = -2049 & t | 64, e) : null;
                case 18:
                    return null;
                case 4:
                    return kn(), null;
                case 10:
                    return No(e), null;
                default:
                    return null
            }
        }
        var Mi = We.ReactCurrentDispatcher,
            Ai = We.ReactCurrentOwner,
            Li = 1073741822,
            Si = !1,
            Oi = null,
            Ci = null,
            Ti = 0,
            ji = -1,
            Ei = !1,
            _i = null,
            Pi = !1,
            Vi = null,
            Hi = null,
            Ii = null,
            Fi = null;

        function Ri() {
            if (null !== Oi)
                for (var e = Oi.return; null !== e;) {
                    var t = e;
                    switch (t.tag) {
                        case 1:
                            var a = t.type.childContextTypes;
                            null !== a && void 0 !== a && Pr();
                            break;
                        case 3:
                            kn(), Vr();
                            break;
                        case 5:
                            An(t);
                            break;
                        case 4:
                            kn();
                            break;
                        case 10:
                            No(t)
                    }
                    e = e.return
                }
            Ci = null, Ti = 0, ji = -1, Ei = !1, Oi = null
        }

        function Ni() {
            for (; null !== _i;) {
                var e = _i.effectTag;
                if (16 & e && nr(_i.stateNode, ""), 128 & e) {
                    var t = _i.alternate;
                    null !== t && (null !== (t = t.ref) && ("function" === typeof t ? t(null) : t.current = null))
                }
                switch (14 & e) {
                    case 2:
                        yi(_i), _i.effectTag &= -3;
                        break;
                    case 6:
                        yi(_i), _i.effectTag &= -3, bi(_i.alternate, _i);
                        break;
                    case 4:
                        bi(_i.alternate, _i);
                        break;
                    case 8:
                        vi(e = _i), e.return = null, e.child = null, e.memoizedState = null, e.updateQueue = null, null !== (e = e.alternate) && (e.return = null, e.child = null, e.memoizedState = null, e.updateQueue = null)
                }
                _i = _i.nextEffect
            }
        }

        function Di() {
            for (; null !== _i;) {
                if (256 & _i.effectTag) e: {
                    var e = _i.alternate,
                        t = _i;
                    switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            fi(Sn, Ln, t);
                            break e;
                        case 1:
                            if (256 & t.effectTag && null !== e) {
                                var a = e.memoizedProps,
                                    r = e.memoizedState;
                                t = (e = t.stateNode).getSnapshotBeforeUpdate(t.elementType === t.type ? a : an(t.type, a), r), e.__reactInternalSnapshotBeforeUpdate = t
                            }
                            break e;
                        case 3:
                        case 5:
                        case 6:
                        case 4:
                        case 17:
                            break e;
                        default:
                            i("163")
                    }
                }
                _i = _i.nextEffect
            }
        }

        function Ui(e, t) {
            for (; null !== _i;) {
                var a = _i.effectTag;
                if (36 & a) {
                    var r = _i.alternate,
                        n = _i,
                        o = t;
                    switch (n.tag) {
                        case 0:
                        case 11:
                        case 15:
                            fi(Tn, jn, n);
                            break;
                        case 1:
                            var l = n.stateNode;
                            if (4 & n.effectTag)
                                if (null === r) l.componentDidMount();
                                else {
                                    var c = n.elementType === n.type ? r.memoizedProps : an(n.type, r.memoizedProps);
                                    l.componentDidUpdate(c, r.memoizedState, l.__reactInternalSnapshotBeforeUpdate)
                                }
                            null !== (r = n.updateQueue) && ri(0, r, l);
                            break;
                        case 3:
                            if (null !== (r = n.updateQueue)) {
                                if (l = null, null !== n.child) switch (n.child.tag) {
                                    case 5:
                                        l = n.child.stateNode;
                                        break;
                                    case 1:
                                        l = n.child.stateNode
                                }
                                ri(0, r, l)
                            }
                            break;
                        case 5:
                            o = n.stateNode, null === r && 4 & n.effectTag && mr(n.type, n.memoizedProps) && o.focus();
                            break;
                        case 6:
                        case 4:
                        case 12:
                        case 13:
                        case 17:
                            break;
                        default:
                            i("163")
                    }
                }
                128 & a && (null !== (n = _i.ref) && (o = _i.stateNode, "function" === typeof n ? n(o) : n.current = o)), 512 & a && (Vi = e), _i = _i.nextEffect
            }
        }

        function Bi() {
            null !== Hi && zr(Hi), null !== Ii && Ii()
        }

        function Wi(e, t) {
            Pi = Si = !0, e.current === t && i("177");
            var a = e.pendingCommitExpirationTime;
            0 === a && i("261"), e.pendingCommitExpirationTime = 0;
            var r = t.expirationTime,
                n = t.childExpirationTime;
            for (function(e, t) {
                    if (e.didError = !1, 0 === t) e.earliestPendingTime = 0, e.latestPendingTime = 0, e.earliestSuspendedTime = 0, e.latestSuspendedTime = 0, e.latestPingedTime = 0;
                    else {
                        t < e.latestPingedTime && (e.latestPingedTime = 0);
                        var a = e.latestPendingTime;
                        0 !== a && (a > t ? e.earliestPendingTime = e.latestPendingTime = 0 : e.earliestPendingTime > t && (e.earliestPendingTime = e.latestPendingTime)), 0 === (a = e.earliestSuspendedTime) ? Zr(e, t) : t < e.latestSuspendedTime ? (e.earliestSuspendedTime = 0, e.latestSuspendedTime = 0, e.latestPingedTime = 0, Zr(e, t)) : t > a && Zr(e, t)
                    }
                    tn(0, e)
                }(e, n > r ? n : r), Ai.current = null, r = void 0, 1 < t.effectTag ? null !== t.lastEffect ? (t.lastEffect.nextEffect = t, r = t.firstEffect) : r = t : r = t.firstEffect, fr = ka, gr = function() {
                    var e = Va();
                    if (Ha(e)) {
                        if ("selectionStart" in e) var t = {
                            start: e.selectionStart,
                            end: e.selectionEnd
                        };
                        else e: {
                            var a = (t = (t = e.ownerDocument) && t.defaultView || window).getSelection && t.getSelection();
                            if (a && 0 !== a.rangeCount) {
                                t = a.anchorNode;
                                var r = a.anchorOffset,
                                    n = a.focusNode;
                                a = a.focusOffset;
                                try {
                                    t.nodeType, n.nodeType
                                } catch (p) {
                                    t = null;
                                    break e
                                }
                                var o = 0,
                                    i = -1,
                                    l = -1,
                                    c = 0,
                                    u = 0,
                                    d = e,
                                    s = null;
                                t: for (;;) {
                                    for (var h; d !== t || 0 !== r && 3 !== d.nodeType || (i = o + r), d !== n || 0 !== a && 3 !== d.nodeType || (l = o + a), 3 === d.nodeType && (o += d.nodeValue.length), null !== (h = d.firstChild);) s = d, d = h;
                                    for (;;) {
                                        if (d === e) break t;
                                        if (s === t && ++c === r && (i = o), s === n && ++u === a && (l = o), null !== (h = d.nextSibling)) break;
                                        s = (d = s).parentNode
                                    }
                                    d = h
                                }
                                t = -1 === i || -1 === l ? null : {
                                    start: i,
                                    end: l
                                }
                            } else t = null
                        }
                        t = t || {
                            start: 0,
                            end: 0
                        }
                    } else t = null;
                    return {
                        focusedElem: e,
                        selectionRange: t
                    }
                }(), ka = !1, _i = r; null !== _i;) {
                n = !1;
                var l = void 0;
                try {
                    Di()
                } catch (u) {
                    n = !0, l = u
                }
                n && (null === _i && i("178"), Yi(_i, l), null !== _i && (_i = _i.nextEffect))
            }
            for (_i = r; null !== _i;) {
                n = !1, l = void 0;
                try {
                    Ni()
                } catch (u) {
                    n = !0, l = u
                }
                n && (null === _i && i("178"), Yi(_i, l), null !== _i && (_i = _i.nextEffect))
            }
            for (Ia(gr), gr = null, ka = !!fr, fr = null, e.current = t, _i = r; null !== _i;) {
                n = !1, l = void 0;
                try {
                    Ui(e, a)
                } catch (u) {
                    n = !0, l = u
                }
                n && (null === _i && i("178"), Yi(_i, l), null !== _i && (_i = _i.nextEffect))
            }
            if (null !== r && null !== Vi) {
                var c = function(e, t) {
                    Ii = Hi = Vi = null;
                    var a = nl;
                    nl = !0;
                    do {
                        if (512 & t.effectTag) {
                            var r = !1,
                                n = void 0;
                            try {
                                var o = t;
                                fi(_n, Ln, o), fi(Ln, En, o)
                            } catch (c) {
                                r = !0, n = c
                            }
                            r && Yi(t, n)
                        }
                        t = t.nextEffect
                    } while (null !== t);
                    nl = a, 0 !== (a = e.expirationTime) && kl(e, a), dl || nl || Ol(1073741823, !1)
                }.bind(null, e, r);
                Hi = o.unstable_runWithPriority(o.unstable_NormalPriority, function() {
                    return wr(c)
                }), Ii = c
            }
            Si = Pi = !1, "function" === typeof Nr && Nr(t.stateNode), a = t.expirationTime, 0 === (t = (t = t.childExpirationTime) > a ? t : a) && (Fi = null),
                function(e, t) {
                    e.expirationTime = t, e.finishedWork = null
                }(e, t)
        }

        function $i(e) {
            for (;;) {
                var t = e.alternate,
                    a = e.return,
                    r = e.sibling;
                if (0 === (1024 & e.effectTag)) {
                    Oi = e;
                    e: {
                        var o = t,
                            l = Ti,
                            c = (t = e).pendingProps;
                        switch (t.tag) {
                            case 2:
                            case 16:
                                break;
                            case 15:
                            case 0:
                                break;
                            case 1:
                                _r(t.type) && Pr();
                                break;
                            case 3:
                                kn(), Vr(), (c = t.stateNode).pendingContext && (c.context = c.pendingContext, c.pendingContext = null), null !== o && null !== o.child || (bo(t), t.effectTag &= -3), ci(t);
                                break;
                            case 5:
                                An(t);
                                var u = zn(wn.current);
                                if (l = t.type, null !== o && null != t.stateNode) ui(o, t, l, c, u), o.ref !== t.ref && (t.effectTag |= 128);
                                else if (c) {
                                    var d = zn(vn.current);
                                    if (bo(t)) {
                                        o = (c = t).stateNode;
                                        var s = c.type,
                                            h = c.memoizedProps,
                                            p = u;
                                        switch (o[_] = c, o[P] = h, l = void 0, u = s) {
                                            case "iframe":
                                            case "object":
                                                Ma("load", o);
                                                break;
                                            case "video":
                                            case "audio":
                                                for (s = 0; s < te.length; s++) Ma(te[s], o);
                                                break;
                                            case "source":
                                                Ma("error", o);
                                                break;
                                            case "img":
                                            case "image":
                                            case "link":
                                                Ma("error", o), Ma("load", o);
                                                break;
                                            case "form":
                                                Ma("reset", o), Ma("submit", o);
                                                break;
                                            case "details":
                                                Ma("toggle", o);
                                                break;
                                            case "input":
                                                wt(o, h), Ma("invalid", o), hr(p, "onChange");
                                                break;
                                            case "select":
                                                o._wrapperState = {
                                                    wasMultiple: !!h.multiple
                                                }, Ma("invalid", o), hr(p, "onChange");
                                                break;
                                            case "textarea":
                                                Ga(o, h), Ma("invalid", o), hr(p, "onChange")
                                        }
                                        for (l in dr(u, h), s = null, h) h.hasOwnProperty(l) && (d = h[l], "children" === l ? "string" === typeof d ? o.textContent !== d && (s = ["children", d]) : "number" === typeof d && o.textContent !== "" + d && (s = ["children", "" + d]) : b.hasOwnProperty(l) && null != d && hr(p, l));
                                        switch (u) {
                                            case "input":
                                                Ue(o), kt(o, h, !0);
                                                break;
                                            case "textarea":
                                                Ue(o), Xa(o);
                                                break;
                                            case "select":
                                            case "option":
                                                break;
                                            default:
                                                "function" === typeof h.onClick && (o.onclick = pr)
                                        }
                                        l = s, c.updateQueue = l, (c = null !== l) && ii(t)
                                    } else {
                                        h = t, p = l, o = c, s = 9 === u.nodeType ? u : u.ownerDocument, d === Za.html && (d = Ja(p)), d === Za.html ? "script" === p ? ((o = s.createElement("div")).innerHTML = "<script><\/script>", s = o.removeChild(o.firstChild)) : "string" === typeof o.is ? s = s.createElement(p, {
                                            is: o.is
                                        }) : (s = s.createElement(p), "select" === p && (p = s, o.multiple ? p.multiple = !0 : o.size && (p.size = o.size))) : s = s.createElementNS(d, p), (o = s)[_] = h, o[P] = c, li(o, t, !1, !1), p = o;
                                        var f = u,
                                            g = sr(s = l, h = c);
                                        switch (s) {
                                            case "iframe":
                                            case "object":
                                                Ma("load", p), u = h;
                                                break;
                                            case "video":
                                            case "audio":
                                                for (u = 0; u < te.length; u++) Ma(te[u], p);
                                                u = h;
                                                break;
                                            case "source":
                                                Ma("error", p), u = h;
                                                break;
                                            case "img":
                                            case "image":
                                            case "link":
                                                Ma("error", p), Ma("load", p), u = h;
                                                break;
                                            case "form":
                                                Ma("reset", p), Ma("submit", p), u = h;
                                                break;
                                            case "details":
                                                Ma("toggle", p), u = h;
                                                break;
                                            case "input":
                                                wt(p, h), u = bt(p, h), Ma("invalid", p), hr(f, "onChange");
                                                break;
                                            case "option":
                                                u = qa(p, h);
                                                break;
                                            case "select":
                                                p._wrapperState = {
                                                    wasMultiple: !!h.multiple
                                                }, u = n({}, h, {
                                                    value: void 0
                                                }), Ma("invalid", p), hr(f, "onChange");
                                                break;
                                            case "textarea":
                                                Ga(p, h), u = Ya(p, h), Ma("invalid", p), hr(f, "onChange");
                                                break;
                                            default:
                                                u = h
                                        }
                                        dr(s, u), d = void 0;
                                        var m = s,
                                            y = p,
                                            v = u;
                                        for (d in v)
                                            if (v.hasOwnProperty(d)) {
                                                var w = v[d];
                                                "style" === d ? cr(y, w) : "dangerouslySetInnerHTML" === d ? null != (w = w ? w.__html : void 0) && rr(y, w) : "children" === d ? "string" === typeof w ? ("textarea" !== m || "" !== w) && nr(y, w) : "number" === typeof w && nr(y, "" + w) : "suppressContentEditableWarning" !== d && "suppressHydrationWarning" !== d && "autoFocus" !== d && (b.hasOwnProperty(d) ? null != w && hr(f, d) : null != w && yt(y, d, w, g))
                                            }
                                        switch (s) {
                                            case "input":
                                                Ue(p), kt(p, h, !1);
                                                break;
                                            case "textarea":
                                                Ue(p), Xa(p);
                                                break;
                                            case "option":
                                                null != h.value && p.setAttribute("value", "" + vt(h.value));
                                                break;
                                            case "select":
                                                (u = p).multiple = !!h.multiple, null != (p = h.value) ? Qa(u, !!h.multiple, p, !1) : null != h.defaultValue && Qa(u, !!h.multiple, h.defaultValue, !0);
                                                break;
                                            default:
                                                "function" === typeof u.onClick && (p.onclick = pr)
                                        }(c = mr(l, c)) && ii(t), t.stateNode = o
                                    }
                                    null !== t.ref && (t.effectTag |= 128)
                                } else null === t.stateNode && i("166");
                                break;
                            case 6:
                                o && null != t.stateNode ? di(o, t, o.memoizedProps, c) : ("string" !== typeof c && (null === t.stateNode && i("166")), o = zn(wn.current), zn(vn.current), bo(t) ? (l = (c = t).stateNode, o = c.memoizedProps, l[_] = c, (c = l.nodeValue !== o) && ii(t)) : (l = t, (c = (9 === o.nodeType ? o : o.ownerDocument).createTextNode(c))[_] = t, l.stateNode = c));
                                break;
                            case 11:
                                break;
                            case 13:
                                if (c = t.memoizedState, 0 !== (64 & t.effectTag)) {
                                    t.expirationTime = l, Oi = t;
                                    break e
                                }
                                c = null !== c, l = null !== o && null !== o.memoizedState, null !== o && !c && l && (null !== (o = o.child.sibling) && (null !== (u = t.firstEffect) ? (t.firstEffect = o, o.nextEffect = u) : (t.firstEffect = t.lastEffect = o, o.nextEffect = null), o.effectTag = 8)), (c || l) && (t.effectTag |= 4);
                                break;
                            case 7:
                            case 8:
                            case 12:
                                break;
                            case 4:
                                kn(), ci(t);
                                break;
                            case 10:
                                No(t);
                                break;
                            case 9:
                            case 14:
                                break;
                            case 17:
                                _r(t.type) && Pr();
                                break;
                            case 18:
                                break;
                            default:
                                i("156")
                        }
                        Oi = null
                    }
                    if (t = e, 1 === Ti || 1 !== t.childExpirationTime) {
                        for (c = 0, l = t.child; null !== l;)(o = l.expirationTime) > c && (c = o), (u = l.childExpirationTime) > c && (c = u), l = l.sibling;
                        t.childExpirationTime = c
                    }
                    if (null !== Oi) return Oi;
                    null !== a && 0 === (1024 & a.effectTag) && (null === a.firstEffect && (a.firstEffect = e.firstEffect), null !== e.lastEffect && (null !== a.lastEffect && (a.lastEffect.nextEffect = e.firstEffect), a.lastEffect = e.lastEffect), 1 < e.effectTag && (null !== a.lastEffect ? a.lastEffect.nextEffect = e : a.firstEffect = e, a.lastEffect = e))
                } else {
                    if (null !== (e = ki(e))) return e.effectTag &= 1023, e;
                    null !== a && (a.firstEffect = a.lastEffect = null, a.effectTag |= 1024)
                }
                if (null !== r) return r;
                if (null === a) break;
                e = a
            }
            return null
        }

        function qi(e) {
            var t = Po(e.alternate, e, Ti);
            return e.memoizedProps = e.pendingProps, null === t && (t = $i(e)), Ai.current = null, t
        }

        function Qi(e, t) {
            Si && i("243"), Bi(), Si = !0;
            var a = Mi.current;
            Mi.current = co;
            var r = e.nextExpirationTimeToWorkOn;
            r === Ti && e === Ci && null !== Oi || (Ri(), Ti = r, Oi = qr((Ci = e).current, null), e.pendingCommitExpirationTime = 0);
            for (var n = !1;;) {
                try {
                    if (t)
                        for (; null !== Oi && !Ll();) Oi = qi(Oi);
                    else
                        for (; null !== Oi;) Oi = qi(Oi)
                } catch (y) {
                    if (Fo = Io = Ho = null, Xn(), null === Oi) n = !0, El(y);
                    else {
                        null === Oi && i("271");
                        var o = Oi,
                            l = o.return;
                        if (null !== l) {
                            e: {
                                var c = e,
                                    u = l,
                                    d = o,
                                    s = y;
                                if (l = Ti, d.effectTag |= 1024, d.firstEffect = d.lastEffect = null, null !== s && "object" === typeof s && "function" === typeof s.then) {
                                    var h = s;
                                    s = u;
                                    var p = -1,
                                        f = -1;
                                    do {
                                        if (13 === s.tag) {
                                            var g = s.alternate;
                                            if (null !== g && null !== (g = g.memoizedState)) {
                                                f = 10 * (1073741822 - g.timedOutAt);
                                                break
                                            }
                                            "number" === typeof(g = s.pendingProps.maxDuration) && (0 >= g ? p = 0 : (-1 === p || g < p) && (p = g))
                                        }
                                        s = s.return
                                    } while (null !== s);
                                    s = u;
                                    do {
                                        if ((g = 13 === s.tag) && (g = void 0 !== s.memoizedProps.fallback && null === s.memoizedState), g) {
                                            if (null === (u = s.updateQueue) ? ((u = new Set).add(h), s.updateQueue = u) : u.add(h), 0 === (1 & s.mode)) {
                                                s.effectTag |= 64, d.effectTag &= -1957, 1 === d.tag && (null === d.alternate ? d.tag = 17 : ((l = Ko(1073741823)).tag = $o, Zo(d, l))), d.expirationTime = 1073741823;
                                                break e
                                            }
                                            u = l;
                                            var m = (d = c).pingCache;
                                            null === m ? (m = d.pingCache = new wi, g = new Set, m.set(h, g)) : void 0 === (g = m.get(h)) && (g = new Set, m.set(h, g)), g.has(u) || (g.add(u), d = Ki.bind(null, d, h, u), h.then(d, d)), -1 === p ? c = 1073741823 : (-1 === f && (f = 10 * (1073741822 - en(c, l)) - 5e3), c = f + p), 0 <= c && ji < c && (ji = c), s.effectTag |= 2048, s.expirationTime = l;
                                            break e
                                        }
                                        s = s.return
                                    } while (null !== s);
                                    s = Error((lt(d.type) || "A React component") + " suspended while rendering, but no fallback UI was specified.\n\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display." + ct(d))
                                }
                                Ei = !0,
                                s = oi(s, d),
                                c = u;do {
                                    switch (c.tag) {
                                        case 3:
                                            c.effectTag |= 2048, c.expirationTime = l, Jo(c, l = zi(c, s, l));
                                            break e;
                                        case 1:
                                            if (p = s, f = c.type, d = c.stateNode, 0 === (64 & c.effectTag) && ("function" === typeof f.getDerivedStateFromError || null !== d && "function" === typeof d.componentDidCatch && (null === Fi || !Fi.has(d)))) {
                                                c.effectTag |= 2048, c.expirationTime = l, Jo(c, l = xi(c, p, l));
                                                break e
                                            }
                                    }
                                    c = c.return
                                } while (null !== c)
                            }
                            Oi = $i(o);
                            continue
                        }
                        n = !0, El(y)
                    }
                }
                break
            }
            if (Si = !1, Mi.current = a, Fo = Io = Ho = null, Xn(), n) Ci = null, e.finishedWork = null;
            else if (null !== Oi) e.finishedWork = null;
            else {
                if (null === (a = e.current.alternate) && i("281"), Ci = null, Ei) {
                    if (n = e.latestPendingTime, o = e.latestSuspendedTime, l = e.latestPingedTime, 0 !== n && n < r || 0 !== o && o < r || 0 !== l && l < r) return Jr(e, r), void zl(e, a, r, e.expirationTime, -1);
                    if (!e.didError && t) return e.didError = !0, r = e.nextExpirationTimeToWorkOn = r, t = e.expirationTime = 1073741823, void zl(e, a, r, t, -1)
                }
                t && -1 !== ji ? (Jr(e, r), (t = 10 * (1073741822 - en(e, r))) < ji && (ji = t), t = 10 * (1073741822 - xl()), t = ji - t, zl(e, a, r, e.expirationTime, 0 > t ? 0 : t)) : (e.pendingCommitExpirationTime = r, e.finishedWork = a)
            }
        }

        function Yi(e, t) {
            for (var a = e.return; null !== a;) {
                switch (a.tag) {
                    case 1:
                        var r = a.stateNode;
                        if ("function" === typeof a.type.getDerivedStateFromError || "function" === typeof r.componentDidCatch && (null === Fi || !Fi.has(r))) return Zo(a, e = xi(a, e = oi(t, e), 1073741823)), void Zi(a, 1073741823);
                        break;
                    case 3:
                        return Zo(a, e = zi(a, e = oi(t, e), 1073741823)), void Zi(a, 1073741823)
                }
                a = a.return
            }
            3 === e.tag && (Zo(e, a = zi(e, a = oi(t, e), 1073741823)), Zi(e, 1073741823))
        }

        function Gi(e, t) {
            var a = o.unstable_getCurrentPriorityLevel(),
                r = void 0;
            if (0 === (1 & t.mode)) r = 1073741823;
            else if (Si && !Pi) r = Ti;
            else {
                switch (a) {
                    case o.unstable_ImmediatePriority:
                        r = 1073741823;
                        break;
                    case o.unstable_UserBlockingPriority:
                        r = 1073741822 - 10 * (1 + ((1073741822 - e + 15) / 10 | 0));
                        break;
                    case o.unstable_NormalPriority:
                        r = 1073741822 - 25 * (1 + ((1073741822 - e + 500) / 25 | 0));
                        break;
                    case o.unstable_LowPriority:
                    case o.unstable_IdlePriority:
                        r = 1;
                        break;
                    default:
                        i("313")
                }
                null !== Ci && r === Ti && --r
            }
            return a === o.unstable_UserBlockingPriority && (0 === ll || r < ll) && (ll = r), r
        }

        function Ki(e, t, a) {
            var r = e.pingCache;
            null !== r && r.delete(t), null !== Ci && Ti === a ? Ci = null : (t = e.earliestSuspendedTime, r = e.latestSuspendedTime, 0 !== t && a <= t && a >= r && (e.didError = !1, (0 === (t = e.latestPingedTime) || t > a) && (e.latestPingedTime = a), tn(a, e), 0 !== (a = e.expirationTime) && kl(e, a)))
        }

        function Xi(e, t) {
            e.expirationTime < t && (e.expirationTime = t);
            var a = e.alternate;
            null !== a && a.expirationTime < t && (a.expirationTime = t);
            var r = e.return,
                n = null;
            if (null === r && 3 === e.tag) n = e.stateNode;
            else
                for (; null !== r;) {
                    if (a = r.alternate, r.childExpirationTime < t && (r.childExpirationTime = t), null !== a && a.childExpirationTime < t && (a.childExpirationTime = t), null === r.return && 3 === r.tag) {
                        n = r.stateNode;
                        break
                    }
                    r = r.return
                }
            return n
        }

        function Zi(e, t) {
            null !== (e = Xi(e, t)) && (!Si && 0 !== Ti && t > Ti && Ri(), Zr(e, t), Si && !Pi && Ci === e || kl(e, e.expirationTime), yl > ml && (yl = 0, i("185")))
        }

        function Ji(e, t, a, r, n) {
            return o.unstable_runWithPriority(o.unstable_ImmediatePriority, function() {
                return e(t, a, r, n)
            })
        }
        var el = null,
            tl = null,
            al = 0,
            rl = void 0,
            nl = !1,
            ol = null,
            il = 0,
            ll = 0,
            cl = !1,
            ul = null,
            dl = !1,
            sl = !1,
            hl = null,
            pl = o.unstable_now(),
            fl = 1073741822 - (pl / 10 | 0),
            gl = fl,
            ml = 50,
            yl = 0,
            vl = null;

        function bl() {
            fl = 1073741822 - ((o.unstable_now() - pl) / 10 | 0)
        }

        function wl(e, t) {
            if (0 !== al) {
                if (t < al) return;
                null !== rl && o.unstable_cancelCallback(rl)
            }
            al = t, e = o.unstable_now() - pl, rl = o.unstable_scheduleCallback(Sl, {
                timeout: 10 * (1073741822 - t) - e
            })
        }

        function zl(e, t, a, r, n) {
            e.expirationTime = r, 0 !== n || Ll() ? 0 < n && (e.timeoutHandle = vr(function(e, t, a) {
                e.pendingCommitExpirationTime = a, e.finishedWork = t, bl(), gl = fl, Cl(e, a)
            }.bind(null, e, t, a), n)) : (e.pendingCommitExpirationTime = a, e.finishedWork = t)
        }

        function xl() {
            return nl ? gl : (Ml(), 0 !== il && 1 !== il || (bl(), gl = fl), gl)
        }

        function kl(e, t) {
            null === e.nextScheduledRoot ? (e.expirationTime = t, null === tl ? (el = tl = e, e.nextScheduledRoot = e) : (tl = tl.nextScheduledRoot = e).nextScheduledRoot = el) : t > e.expirationTime && (e.expirationTime = t), nl || (dl ? sl && (ol = e, il = 1073741823, Tl(e, 1073741823, !1)) : 1073741823 === t ? Ol(1073741823, !1) : wl(e, t))
        }

        function Ml() {
            var e = 0,
                t = null;
            if (null !== tl)
                for (var a = tl, r = el; null !== r;) {
                    var n = r.expirationTime;
                    if (0 === n) {
                        if ((null === a || null === tl) && i("244"), r === r.nextScheduledRoot) {
                            el = tl = r.nextScheduledRoot = null;
                            break
                        }
                        if (r === el) el = n = r.nextScheduledRoot, tl.nextScheduledRoot = n, r.nextScheduledRoot = null;
                        else {
                            if (r === tl) {
                                (tl = a).nextScheduledRoot = el, r.nextScheduledRoot = null;
                                break
                            }
                            a.nextScheduledRoot = r.nextScheduledRoot, r.nextScheduledRoot = null
                        }
                        r = a.nextScheduledRoot
                    } else {
                        if (n > e && (e = n, t = r), r === tl) break;
                        if (1073741823 === e) break;
                        a = r, r = r.nextScheduledRoot
                    }
                }
            ol = t, il = e
        }
        var Al = !1;

        function Ll() {
            return !!Al || !!o.unstable_shouldYield() && (Al = !0)
        }

        function Sl() {
            try {
                if (!Ll() && null !== el) {
                    bl();
                    var e = el;
                    do {
                        var t = e.expirationTime;
                        0 !== t && fl <= t && (e.nextExpirationTimeToWorkOn = fl), e = e.nextScheduledRoot
                    } while (e !== el)
                }
                Ol(0, !0)
            } finally {
                Al = !1
            }
        }

        function Ol(e, t) {
            if (Ml(), t)
                for (bl(), gl = fl; null !== ol && 0 !== il && e <= il && !(Al && fl > il);) Tl(ol, il, fl > il), Ml(), bl(), gl = fl;
            else
                for (; null !== ol && 0 !== il && e <= il;) Tl(ol, il, !1), Ml();
            if (t && (al = 0, rl = null), 0 !== il && wl(ol, il), yl = 0, vl = null, null !== hl)
                for (e = hl, hl = null, t = 0; t < e.length; t++) {
                    var a = e[t];
                    try {
                        a._onComplete()
                    } catch (r) {
                        cl || (cl = !0, ul = r)
                    }
                }
            if (cl) throw e = ul, ul = null, cl = !1, e
        }

        function Cl(e, t) {
            nl && i("253"), ol = e, il = t, Tl(e, t, !1), Ol(1073741823, !1)
        }

        function Tl(e, t, a) {
            if (nl && i("245"), nl = !0, a) {
                var r = e.finishedWork;
                null !== r ? jl(e, r, t) : (e.finishedWork = null, -1 !== (r = e.timeoutHandle) && (e.timeoutHandle = -1, br(r)), Qi(e, a), null !== (r = e.finishedWork) && (Ll() ? e.finishedWork = r : jl(e, r, t)))
            } else null !== (r = e.finishedWork) ? jl(e, r, t) : (e.finishedWork = null, -1 !== (r = e.timeoutHandle) && (e.timeoutHandle = -1, br(r)), Qi(e, a), null !== (r = e.finishedWork) && jl(e, r, t));
            nl = !1
        }

        function jl(e, t, a) {
            var r = e.firstBatch;
            if (null !== r && r._expirationTime >= a && (null === hl ? hl = [r] : hl.push(r), r._defer)) return e.finishedWork = t, void(e.expirationTime = 0);
            e.finishedWork = null, e === vl ? yl++ : (vl = e, yl = 0), o.unstable_runWithPriority(o.unstable_ImmediatePriority, function() {
                Wi(e, t)
            })
        }

        function El(e) {
            null === ol && i("246"), ol.expirationTime = 0, cl || (cl = !0, ul = e)
        }

        function _l(e, t) {
            var a = dl;
            dl = !0;
            try {
                return e(t)
            } finally {
                (dl = a) || nl || Ol(1073741823, !1)
            }
        }

        function Pl(e, t) {
            if (dl && !sl) {
                sl = !0;
                try {
                    return e(t)
                } finally {
                    sl = !1
                }
            }
            return e(t)
        }

        function Vl(e, t, a) {
            dl || nl || 0 === ll || (Ol(ll, !1), ll = 0);
            var r = dl;
            dl = !0;
            try {
                return o.unstable_runWithPriority(o.unstable_UserBlockingPriority, function() {
                    return e(t, a)
                })
            } finally {
                (dl = r) || nl || Ol(1073741823, !1)
            }
        }

        function Hl(e, t, a, r, n) {
            var o = t.current;
            e: if (a) {
                t: {
                    2 === ta(a = a._reactInternalFiber) && 1 === a.tag || i("170");
                    var l = a;do {
                        switch (l.tag) {
                            case 3:
                                l = l.stateNode.context;
                                break t;
                            case 1:
                                if (_r(l.type)) {
                                    l = l.stateNode.__reactInternalMemoizedMergedChildContext;
                                    break t
                                }
                        }
                        l = l.return
                    } while (null !== l);i("171"),
                    l = void 0
                }
                if (1 === a.tag) {
                    var c = a.type;
                    if (_r(c)) {
                        a = Ir(a, c, l);
                        break e
                    }
                }
                a = l
            }
            else a = Or;
            return null === t.context ? t.context = a : t.pendingContext = a, t = n, (n = Ko(r)).payload = {
                element: e
            }, null !== (t = void 0 === t ? null : t) && (n.callback = t), Bi(), Zo(o, n), Zi(o, r), r
        }

        function Il(e, t, a, r) {
            var n = t.current;
            return Hl(e, t, a, n = Gi(xl(), n), r)
        }

        function Fl(e) {
            if (!(e = e.current).child) return null;
            switch (e.child.tag) {
                case 5:
                default:
                    return e.child.stateNode
            }
        }

        function Rl(e) {
            var t = 1073741822 - 25 * (1 + ((1073741822 - xl() + 500) / 25 | 0));
            t >= Li && (t = Li - 1), this._expirationTime = Li = t, this._root = e, this._callbacks = this._next = null, this._hasChildren = this._didComplete = !1, this._children = null, this._defer = !0
        }

        function Nl() {
            this._callbacks = null, this._didCommit = !1, this._onCommit = this._onCommit.bind(this)
        }

        function Dl(e, t, a) {
            e = {
                current: t = Wr(3, null, null, t ? 3 : 0),
                containerInfo: e,
                pendingChildren: null,
                pingCache: null,
                earliestPendingTime: 0,
                latestPendingTime: 0,
                earliestSuspendedTime: 0,
                latestSuspendedTime: 0,
                latestPingedTime: 0,
                didError: !1,
                pendingCommitExpirationTime: 0,
                finishedWork: null,
                timeoutHandle: -1,
                context: null,
                pendingContext: null,
                hydrate: a,
                nextExpirationTimeToWorkOn: 0,
                expirationTime: 0,
                firstBatch: null,
                nextScheduledRoot: null
            }, this._internalRoot = t.stateNode = e
        }

        function Ul(e) {
            return !(!e || 1 !== e.nodeType && 9 !== e.nodeType && 11 !== e.nodeType && (8 !== e.nodeType || " react-mount-point-unstable " !== e.nodeValue))
        }

        function Bl(e, t, a, r, n) {
            var o = a._reactRootContainer;
            if (o) {
                if ("function" === typeof n) {
                    var i = n;
                    n = function() {
                        var e = Fl(o._internalRoot);
                        i.call(e)
                    }
                }
                null != e ? o.legacy_renderSubtreeIntoContainer(e, t, n) : o.render(t, n)
            } else {
                if (o = a._reactRootContainer = function(e, t) {
                        if (t || (t = !(!(t = e ? 9 === e.nodeType ? e.documentElement : e.firstChild : null) || 1 !== t.nodeType || !t.hasAttribute("data-reactroot"))), !t)
                            for (var a; a = e.lastChild;) e.removeChild(a);
                        return new Dl(e, !1, t)
                    }(a, r), "function" === typeof n) {
                    var l = n;
                    n = function() {
                        var e = Fl(o._internalRoot);
                        l.call(e)
                    }
                }
                Pl(function() {
                    null != e ? o.legacy_renderSubtreeIntoContainer(e, t, n) : o.render(t, n)
                })
            }
            return Fl(o._internalRoot)
        }

        function Wl(e, t) {
            var a = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
            return Ul(t) || i("200"),
                function(e, t, a) {
                    var r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
                    return {
                        $$typeof: Ye,
                        key: null == r ? null : "" + r,
                        children: e,
                        containerInfo: t,
                        implementation: a
                    }
                }(e, t, null, a)
        }
        Le = function(e, t, a) {
            switch (t) {
                case "input":
                    if (xt(e, a), t = a.name, "radio" === a.type && null != t) {
                        for (a = e; a.parentNode;) a = a.parentNode;
                        for (a = a.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < a.length; t++) {
                            var r = a[t];
                            if (r !== e && r.form === e.form) {
                                var n = F(r);
                                n || i("90"), Be(r), xt(r, n)
                            }
                        }
                    }
                    break;
                case "textarea":
                    Ka(e, a);
                    break;
                case "select":
                    null != (t = a.value) && Qa(e, !!a.multiple, t, !1)
            }
        }, Rl.prototype.render = function(e) {
            this._defer || i("250"), this._hasChildren = !0, this._children = e;
            var t = this._root._internalRoot,
                a = this._expirationTime,
                r = new Nl;
            return Hl(e, t, null, a, r._onCommit), r
        }, Rl.prototype.then = function(e) {
            if (this._didComplete) e();
            else {
                var t = this._callbacks;
                null === t && (t = this._callbacks = []), t.push(e)
            }
        }, Rl.prototype.commit = function() {
            var e = this._root._internalRoot,
                t = e.firstBatch;
            if (this._defer && null !== t || i("251"), this._hasChildren) {
                var a = this._expirationTime;
                if (t !== this) {
                    this._hasChildren && (a = this._expirationTime = t._expirationTime, this.render(this._children));
                    for (var r = null, n = t; n !== this;) r = n, n = n._next;
                    null === r && i("251"), r._next = n._next, this._next = t, e.firstBatch = this
                }
                this._defer = !1, Cl(e, a), t = this._next, this._next = null, null !== (t = e.firstBatch = t) && t._hasChildren && t.render(t._children)
            } else this._next = null, this._defer = !1
        }, Rl.prototype._onComplete = function() {
            if (!this._didComplete) {
                this._didComplete = !0;
                var e = this._callbacks;
                if (null !== e)
                    for (var t = 0; t < e.length; t++)(0, e[t])()
            }
        }, Nl.prototype.then = function(e) {
            if (this._didCommit) e();
            else {
                var t = this._callbacks;
                null === t && (t = this._callbacks = []), t.push(e)
            }
        }, Nl.prototype._onCommit = function() {
            if (!this._didCommit) {
                this._didCommit = !0;
                var e = this._callbacks;
                if (null !== e)
                    for (var t = 0; t < e.length; t++) {
                        var a = e[t];
                        "function" !== typeof a && i("191", a), a()
                    }
            }
        }, Dl.prototype.render = function(e, t) {
            var a = this._internalRoot,
                r = new Nl;
            return null !== (t = void 0 === t ? null : t) && r.then(t), Il(e, a, null, r._onCommit), r
        }, Dl.prototype.unmount = function(e) {
            var t = this._internalRoot,
                a = new Nl;
            return null !== (e = void 0 === e ? null : e) && a.then(e), Il(null, t, null, a._onCommit), a
        }, Dl.prototype.legacy_renderSubtreeIntoContainer = function(e, t, a) {
            var r = this._internalRoot,
                n = new Nl;
            return null !== (a = void 0 === a ? null : a) && n.then(a), Il(t, r, e, n._onCommit), n
        }, Dl.prototype.createBatch = function() {
            var e = new Rl(this),
                t = e._expirationTime,
                a = this._internalRoot,
                r = a.firstBatch;
            if (null === r) a.firstBatch = e, e._next = null;
            else {
                for (a = null; null !== r && r._expirationTime >= t;) a = r, r = r._next;
                e._next = r, null !== a && (a._next = e)
            }
            return e
        }, Ee = _l, _e = Vl, Pe = function() {
            nl || 0 === ll || (Ol(ll, !1), ll = 0)
        };
        var $l = {
            createPortal: Wl,
            findDOMNode: function(e) {
                if (null == e) return null;
                if (1 === e.nodeType) return e;
                var t = e._reactInternalFiber;
                return void 0 === t && ("function" === typeof e.render ? i("188") : i("268", Object.keys(e))), e = null === (e = ra(t)) ? null : e.stateNode
            },
            hydrate: function(e, t, a) {
                return Ul(t) || i("200"), Bl(null, e, t, !0, a)
            },
            render: function(e, t, a) {
                return Ul(t) || i("200"), Bl(null, e, t, !1, a)
            },
            unstable_renderSubtreeIntoContainer: function(e, t, a, r) {
                return Ul(a) || i("200"), (null == e || void 0 === e._reactInternalFiber) && i("38"), Bl(e, t, a, !1, r)
            },
            unmountComponentAtNode: function(e) {
                return Ul(e) || i("40"), !!e._reactRootContainer && (Pl(function() {
                    Bl(null, null, e, !1, function() {
                        e._reactRootContainer = null
                    })
                }), !0)
            },
            unstable_createPortal: function() {
                return Wl.apply(void 0, arguments)
            },
            unstable_batchedUpdates: _l,
            unstable_interactiveUpdates: Vl,
            flushSync: function(e, t) {
                nl && i("187");
                var a = dl;
                dl = !0;
                try {
                    return Ji(e, t)
                } finally {
                    dl = a, Ol(1073741823, !1)
                }
            },
            unstable_createRoot: function(e, t) {
                return Ul(e) || i("299", "unstable_createRoot"), new Dl(e, !0, null != t && !0 === t.hydrate)
            },
            unstable_flushControlled: function(e) {
                var t = dl;
                dl = !0;
                try {
                    Ji(e)
                } finally {
                    (dl = t) || nl || Ol(1073741823, !1)
                }
            },
            __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: {
                Events: [H, I, F, C.injectEventPluginsByName, v, W, function(e) {
                    L(e, B)
                }, Te, je, Sa, j]
            }
        };
        ! function(e) {
            var t = e.findFiberByHostInstance;
            (function(e) {
                if ("undefined" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) return !1;
                var t = __REACT_DEVTOOLS_GLOBAL_HOOK__;
                if (t.isDisabled || !t.supportsFiber) return !0;
                try {
                    var a = t.inject(e);
                    Nr = Ur(function(e) {
                        return t.onCommitFiberRoot(a, e)
                    }), Dr = Ur(function(e) {
                        return t.onCommitFiberUnmount(a, e)
                    })
                } catch (r) {}
            })(n({}, e, {
                overrideProps: null,
                currentDispatcherRef: We.ReactCurrentDispatcher,
                findHostInstanceByFiber: function(e) {
                    return null === (e = ra(e)) ? null : e.stateNode
                },
                findFiberByHostInstance: function(e) {
                    return t ? t(e) : null
                }
            }))
        }({
            findFiberByHostInstance: V,
            bundleType: 0,
            version: "16.8.6",
            rendererPackageName: "react-dom"
        });
        var ql = {
                default: $l
            },
            Ql = ql && $l || ql;
        e.exports = Ql.default || Ql
    }, function(e, t, a) {
        "use strict";
        e.exports = a(75)
    }, function(e, t, a) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = null,
                r = !1,
                n = 3,
                o = -1,
                i = -1,
                l = !1,
                c = !1;

            function u() {
                if (!l) {
                    var e = a.expirationTime;
                    c ? k() : c = !0, x(h, e)
                }
            }

            function d() {
                var e = a,
                    t = a.next;
                if (a === t) a = null;
                else {
                    var r = a.previous;
                    a = r.next = t, t.previous = r
                }
                e.next = e.previous = null, r = e.callback, t = e.expirationTime, e = e.priorityLevel;
                var o = n,
                    l = i;
                n = e, i = t;
                try {
                    var c = r()
                } finally {
                    n = o, i = l
                }
                if ("function" === typeof c)
                    if (c = {
                            callback: c,
                            priorityLevel: e,
                            expirationTime: t,
                            next: null,
                            previous: null
                        }, null === a) a = c.next = c.previous = c;
                    else {
                        r = null, e = a;
                        do {
                            if (e.expirationTime >= t) {
                                r = e;
                                break
                            }
                            e = e.next
                        } while (e !== a);
                        null === r ? r = a : r === a && (a = c, u()), (t = r.previous).next = r.previous = c, c.next = r, c.previous = t
                    }
            }

            function s() {
                if (-1 === o && null !== a && 1 === a.priorityLevel) {
                    l = !0;
                    try {
                        do {
                            d()
                        } while (null !== a && 1 === a.priorityLevel)
                    } finally {
                        l = !1, null !== a ? u() : c = !1
                    }
                }
            }

            function h(e) {
                l = !0;
                var n = r;
                r = e;
                try {
                    if (e)
                        for (; null !== a;) {
                            var o = t.unstable_now();
                            if (!(a.expirationTime <= o)) break;
                            do {
                                d()
                            } while (null !== a && a.expirationTime <= o)
                        } else if (null !== a)
                            do {
                                d()
                            } while (null !== a && !M())
                } finally {
                    l = !1, r = n, null !== a ? u() : c = !1, s()
                }
            }
            var p, f, g = Date,
                m = "function" === typeof setTimeout ? setTimeout : void 0,
                y = "function" === typeof clearTimeout ? clearTimeout : void 0,
                v = "function" === typeof requestAnimationFrame ? requestAnimationFrame : void 0,
                b = "function" === typeof cancelAnimationFrame ? cancelAnimationFrame : void 0;

            function w(e) {
                p = v(function(t) {
                    y(f), e(t)
                }), f = m(function() {
                    b(p), e(t.unstable_now())
                }, 100)
            }
            if ("object" === typeof performance && "function" === typeof performance.now) {
                var z = performance;
                t.unstable_now = function() {
                    return z.now()
                }
            } else t.unstable_now = function() {
                return g.now()
            };
            var x, k, M, A = null;
            if ("undefined" !== typeof window ? A = window : "undefined" !== typeof e && (A = e), A && A._schedMock) {
                var L = A._schedMock;
                x = L[0], k = L[1], M = L[2], t.unstable_now = L[3]
            } else if ("undefined" === typeof window || "function" !== typeof MessageChannel) {
                var S = null,
                    O = function(e) {
                        if (null !== S) try {
                            S(e)
                        } finally {
                            S = null
                        }
                    };
                x = function(e) {
                    null !== S ? setTimeout(x, 0, e) : (S = e, setTimeout(O, 0, !1))
                }, k = function() {
                    S = null
                }, M = function() {
                    return !1
                }
            } else {
                "undefined" !== typeof console && ("function" !== typeof v && console.error("This browser doesn't support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://fb.me/react-polyfills"), "function" !== typeof b && console.error("This browser doesn't support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://fb.me/react-polyfills"));
                var C = null,
                    T = !1,
                    j = -1,
                    E = !1,
                    _ = !1,
                    P = 0,
                    V = 33,
                    H = 33;
                M = function() {
                    return P <= t.unstable_now()
                };
                var I = new MessageChannel,
                    F = I.port2;
                I.port1.onmessage = function() {
                    T = !1;
                    var e = C,
                        a = j;
                    C = null, j = -1;
                    var r = t.unstable_now(),
                        n = !1;
                    if (0 >= P - r) {
                        if (!(-1 !== a && a <= r)) return E || (E = !0, w(R)), C = e, void(j = a);
                        n = !0
                    }
                    if (null !== e) {
                        _ = !0;
                        try {
                            e(n)
                        } finally {
                            _ = !1
                        }
                    }
                };
                var R = function e(t) {
                    if (null !== C) {
                        w(e);
                        var a = t - P + H;
                        a < H && V < H ? (8 > a && (a = 8), H = a < V ? V : a) : V = a, P = t + H, T || (T = !0, F.postMessage(void 0))
                    } else E = !1
                };
                x = function(e, t) {
                    C = e, j = t, _ || 0 > t ? F.postMessage(void 0) : E || (E = !0, w(R))
                }, k = function() {
                    C = null, T = !1, j = -1
                }
            }
            t.unstable_ImmediatePriority = 1, t.unstable_UserBlockingPriority = 2, t.unstable_NormalPriority = 3, t.unstable_IdlePriority = 5, t.unstable_LowPriority = 4, t.unstable_runWithPriority = function(e, a) {
                switch (e) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        break;
                    default:
                        e = 3
                }
                var r = n,
                    i = o;
                n = e, o = t.unstable_now();
                try {
                    return a()
                } finally {
                    n = r, o = i, s()
                }
            }, t.unstable_next = function(e) {
                switch (n) {
                    case 1:
                    case 2:
                    case 3:
                        var a = 3;
                        break;
                    default:
                        a = n
                }
                var r = n,
                    i = o;
                n = a, o = t.unstable_now();
                try {
                    return e()
                } finally {
                    n = r, o = i, s()
                }
            }, t.unstable_scheduleCallback = function(e, r) {
                var i = -1 !== o ? o : t.unstable_now();
                if ("object" === typeof r && null !== r && "number" === typeof r.timeout) r = i + r.timeout;
                else switch (n) {
                    case 1:
                        r = i + -1;
                        break;
                    case 2:
                        r = i + 250;
                        break;
                    case 5:
                        r = i + 1073741823;
                        break;
                    case 4:
                        r = i + 1e4;
                        break;
                    default:
                        r = i + 5e3
                }
                if (e = {
                        callback: e,
                        priorityLevel: n,
                        expirationTime: r,
                        next: null,
                        previous: null
                    }, null === a) a = e.next = e.previous = e, u();
                else {
                    i = null;
                    var l = a;
                    do {
                        if (l.expirationTime > r) {
                            i = l;
                            break
                        }
                        l = l.next
                    } while (l !== a);
                    null === i ? i = a : i === a && (a = e, u()), (r = i.previous).next = i.previous = e, e.next = i, e.previous = r
                }
                return e
            }, t.unstable_cancelCallback = function(e) {
                var t = e.next;
                if (null !== t) {
                    if (t === e) a = null;
                    else {
                        e === a && (a = t);
                        var r = e.previous;
                        r.next = t, t.previous = r
                    }
                    e.next = e.previous = null
                }
            }, t.unstable_wrapCallback = function(e) {
                var a = n;
                return function() {
                    var r = n,
                        i = o;
                    n = a, o = t.unstable_now();
                    try {
                        return e.apply(this, arguments)
                    } finally {
                        n = r, o = i, s()
                    }
                }
            }, t.unstable_getCurrentPriorityLevel = function() {
                return n
            }, t.unstable_shouldYield = function() {
                return !r && (null !== a && a.expirationTime < i || M())
            }, t.unstable_continueExecution = function() {
                null !== a && u()
            }, t.unstable_pauseExecution = function() {}, t.unstable_getFirstCallbackNode = function() {
                return a
            }
        }).call(this, a(45))
    }, function(e, t) {
        var a, r, n = e.exports = {};

        function o() {
            throw new Error("setTimeout has not been defined")
        }

        function i() {
            throw new Error("clearTimeout has not been defined")
        }

        function l(e) {
            if (a === setTimeout) return setTimeout(e, 0);
            if ((a === o || !a) && setTimeout) return a = setTimeout, setTimeout(e, 0);
            try {
                return a(e, 0)
            } catch (t) {
                try {
                    return a.call(null, e, 0)
                } catch (t) {
                    return a.call(this, e, 0)
                }
            }
        }! function() {
            try {
                a = "function" === typeof setTimeout ? setTimeout : o
            } catch (e) {
                a = o
            }
            try {
                r = "function" === typeof clearTimeout ? clearTimeout : i
            } catch (e) {
                r = i
            }
        }();
        var c, u = [],
            d = !1,
            s = -1;

        function h() {
            d && c && (d = !1, c.length ? u = c.concat(u) : s = -1, u.length && p())
        }

        function p() {
            if (!d) {
                var e = l(h);
                d = !0;
                for (var t = u.length; t;) {
                    for (c = u, u = []; ++s < t;) c && c[s].run();
                    s = -1, t = u.length
                }
                c = null, d = !1,
                    function(e) {
                        if (r === clearTimeout) return clearTimeout(e);
                        if ((r === i || !r) && clearTimeout) return r = clearTimeout, clearTimeout(e);
                        try {
                            r(e)
                        } catch (t) {
                            try {
                                return r.call(null, e)
                            } catch (t) {
                                return r.call(this, e)
                            }
                        }
                    }(e)
            }
        }

        function f(e, t) {
            this.fun = e, this.array = t
        }

        function g() {}
        n.nextTick = function(e) {
            var t = new Array(arguments.length - 1);
            if (arguments.length > 1)
                for (var a = 1; a < arguments.length; a++) t[a - 1] = arguments[a];
            u.push(new f(e, t)), 1 !== u.length || d || l(p)
        }, f.prototype.run = function() {
            this.fun.apply(null, this.array)
        }, n.title = "browser", n.browser = !0, n.env = {}, n.argv = [], n.version = "", n.versions = {}, n.on = g, n.addListener = g, n.once = g, n.off = g, n.removeListener = g, n.removeAllListeners = g, n.emit = g, n.prependListener = g, n.prependOnceListener = g, n.listeners = function(e) {
            return []
        }, n.binding = function(e) {
            throw new Error("process.binding is not supported")
        }, n.cwd = function() {
            return "/"
        }, n.chdir = function(e) {
            throw new Error("process.chdir is not supported")
        }, n.umask = function() {
            return 0
        }
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = "function" === typeof Symbol && Symbol.for,
            n = r ? Symbol.for("react.element") : 60103,
            o = r ? Symbol.for("react.portal") : 60106,
            i = r ? Symbol.for("react.fragment") : 60107,
            l = r ? Symbol.for("react.strict_mode") : 60108,
            c = r ? Symbol.for("react.profiler") : 60114,
            u = r ? Symbol.for("react.provider") : 60109,
            d = r ? Symbol.for("react.context") : 60110,
            s = r ? Symbol.for("react.async_mode") : 60111,
            h = r ? Symbol.for("react.concurrent_mode") : 60111,
            p = r ? Symbol.for("react.forward_ref") : 60112,
            f = r ? Symbol.for("react.suspense") : 60113,
            g = r ? Symbol.for("react.memo") : 60115,
            m = r ? Symbol.for("react.lazy") : 60116;

        function y(e) {
            if ("object" === typeof e && null !== e) {
                var t = e.$$typeof;
                switch (t) {
                    case n:
                        switch (e = e.type) {
                            case s:
                            case h:
                            case i:
                            case c:
                            case l:
                            case f:
                                return e;
                            default:
                                switch (e = e && e.$$typeof) {
                                    case d:
                                    case p:
                                    case u:
                                        return e;
                                    default:
                                        return t
                                }
                        }
                    case m:
                    case g:
                    case o:
                        return t
                }
            }
        }

        function v(e) {
            return y(e) === h
        }
        t.typeOf = y, t.AsyncMode = s, t.ConcurrentMode = h, t.ContextConsumer = d, t.ContextProvider = u, t.Element = n, t.ForwardRef = p, t.Fragment = i, t.Lazy = m, t.Memo = g, t.Portal = o, t.Profiler = c, t.StrictMode = l, t.Suspense = f, t.isValidElementType = function(e) {
            return "string" === typeof e || "function" === typeof e || e === i || e === h || e === c || e === l || e === f || "object" === typeof e && null !== e && (e.$$typeof === m || e.$$typeof === g || e.$$typeof === u || e.$$typeof === d || e.$$typeof === p)
        }, t.isAsyncMode = function(e) {
            return v(e) || y(e) === s
        }, t.isConcurrentMode = v, t.isContextConsumer = function(e) {
            return y(e) === d
        }, t.isContextProvider = function(e) {
            return y(e) === u
        }, t.isElement = function(e) {
            return "object" === typeof e && null !== e && e.$$typeof === n
        }, t.isForwardRef = function(e) {
            return y(e) === p
        }, t.isFragment = function(e) {
            return y(e) === i
        }, t.isLazy = function(e) {
            return y(e) === m
        }, t.isMemo = function(e) {
            return y(e) === g
        }, t.isPortal = function(e) {
            return y(e) === o
        }, t.isProfiler = function(e) {
            return y(e) === c
        }, t.isStrictMode = function(e) {
            return y(e) === l
        }, t.isSuspense = function(e) {
            return y(e) === f
        }
    }, function(e, t, a) {
        "use strict";
        var r = a(79);

        function n() {}

        function o() {}
        o.resetWarningCache = n, e.exports = function() {
            function e(e, t, a, n, o, i) {
                if (i !== r) {
                    var l = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                    throw l.name = "Invariant Violation", l
                }
            }

            function t() {
                return e
            }
            e.isRequired = e;
            var a = {
                array: e,
                bool: e,
                func: e,
                number: e,
                object: e,
                string: e,
                symbol: e,
                any: e,
                arrayOf: t,
                element: e,
                elementType: e,
                instanceOf: t,
                node: e,
                objectOf: t,
                oneOf: t,
                oneOfType: t,
                shape: t,
                exact: t,
                checkPropTypes: o,
                resetWarningCache: n
            };
            return a.PropTypes = a, a
        }
    }, function(e, t, a) {
        "use strict";
        e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CopyToClipboard = void 0;
        var r = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            },
            n = function() {
                function e(e, t) {
                    for (var a = 0; a < t.length; a++) {
                        var r = t[a];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                return function(t, a, r) {
                    return a && e(t.prototype, a), r && e(t, r), t
                }
            }(),
            o = l(a(0)),
            i = l(a(81));

        function l(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }

        function c(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" !== typeof t && "function" !== typeof t ? e : t
        }(t.CopyToClipboard = function(e) {
            function t() {
                var e, a, r;
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, t);
                for (var n = arguments.length, l = Array(n), u = 0; u < n; u++) l[u] = arguments[u];
                return a = r = c(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [this].concat(l))), r.onClick = function(e) {
                    var t = r.props,
                        a = t.text,
                        n = t.onCopy,
                        l = t.children,
                        c = t.options,
                        u = o.default.Children.only(l),
                        d = (0, i.default)(a, c);
                    n && n(a, d), u && u.props && "function" === typeof u.props.onClick && u.props.onClick(e)
                }, c(r, a)
            }
            return function(e, t) {
                if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0
                    }
                }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
            }(t, o.default.PureComponent), n(t, [{
                key: "render",
                value: function() {
                    var e = this.props,
                        t = (e.text, e.onCopy, e.options, e.children),
                        a = function(e, t) {
                            var a = {};
                            for (var r in e) t.indexOf(r) >= 0 || Object.prototype.hasOwnProperty.call(e, r) && (a[r] = e[r]);
                            return a
                        }(e, ["text", "onCopy", "options", "children"]),
                        n = o.default.Children.only(t);
                    return o.default.cloneElement(n, r({}, a, {
                        onClick: this.onClick
                    }))
                }
            }]), t
        }()).defaultProps = {
            onCopy: void 0,
            options: void 0
        }
    }, function(e, t, a) {
        "use strict";
        var r = a(82),
            n = "Copy to clipboard: #{key}, Enter";
        e.exports = function(e, t) {
            var a, o, i, l, c, u, d = !1;
            t || (t = {}), a = t.debug || !1;
            try {
                if (i = r(), l = document.createRange(), c = document.getSelection(), (u = document.createElement("span")).textContent = e, u.style.all = "unset", u.style.position = "fixed", u.style.top = 0, u.style.clip = "rect(0, 0, 0, 0)", u.style.whiteSpace = "pre", u.style.webkitUserSelect = "text", u.style.MozUserSelect = "text", u.style.msUserSelect = "text", u.style.userSelect = "text", u.addEventListener("copy", function(e) {
                        e.stopPropagation()
                    }), document.body.appendChild(u), l.selectNodeContents(u), c.addRange(l), !document.execCommand("copy")) throw new Error("copy command was unsuccessful");
                d = !0
            } catch (s) {
                a && console.error("unable to copy using execCommand: ", s), a && console.warn("trying IE specific stuff");
                try {
                    window.clipboardData.setData("text", e), d = !0
                } catch (s) {
                    a && console.error("unable to copy using clipboardData: ", s), a && console.error("falling back to prompt"), o = function(e) {
                        var t = (/mac os x/i.test(navigator.userAgent) ? "\u2318" : "Ctrl") + "+C";
                        return e.replace(/#{\s*key\s*}/g, t)
                    }("message" in t ? t.message : n), window.prompt(o, e)
                }
            } finally {
                c && ("function" == typeof c.removeRange ? c.removeRange(l) : c.removeAllRanges()), u && document.body.removeChild(u), i()
            }
            return d
        }
    }, function(e, t) {
        e.exports = function() {
            var e = document.getSelection();
            if (!e.rangeCount) return function() {};
            for (var t = document.activeElement, a = [], r = 0; r < e.rangeCount; r++) a.push(e.getRangeAt(r));
            switch (t.tagName.toUpperCase()) {
                case "INPUT":
                case "TEXTAREA":
                    t.blur();
                    break;
                default:
                    t = null
            }
            return e.removeAllRanges(),
                function() {
                    "Caret" === e.type && e.removeAllRanges(), e.rangeCount || a.forEach(function(t) {
                        e.addRange(t)
                    }), t && t.focus()
                }
        }
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = function() {
                function e(e, t) {
                    for (var a = 0; a < t.length; a++) {
                        var r = t[a];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                return function(t, a, r) {
                    return a && e(t.prototype, a), r && e(t, r), t
                }
            }(),
            n = a(0),
            o = l(a(9)),
            i = l(a(13));

        function l(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var c = "function" === typeof i.default.createPortal,
            u = "undefined" !== typeof window,
            d = function(e) {
                function t() {
                    return function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, t),
                        function(e, t) {
                            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !t || "object" !== typeof t && "function" !== typeof t ? e : t
                        }(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments))
                }
                return function(e, t) {
                    if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                }(t, n.Component), r(t, [{
                    key: "componentWillMount",
                    value: function() {
                        u && (this.props.container ? this.container = this.props.container : (this.container = document.createElement("div"), document.body.appendChild(this.container)), this.renderLayer())
                    }
                }, {
                    key: "componentDidUpdate",
                    value: function() {
                        this.renderLayer()
                    }
                }, {
                    key: "componentWillUnmount",
                    value: function() {
                        c || i.default.unmountComponentAtNode(this.container), this.props.container || document.body.removeChild(this.container)
                    }
                }, {
                    key: "renderLayer",
                    value: function() {
                        c || i.default.unstable_renderSubtreeIntoContainer(this, this.props.children, this.container)
                    }
                }, {
                    key: "render",
                    value: function() {
                        return c ? i.default.createPortal(this.props.children, this.container) : null
                    }
                }]), t
            }();
        d.propTypes = {
            children: o.default.node,
            container: o.default.object
        }, t.default = d
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function e(t, a, l, c, u, d, s) {
            if (!l) return t;
            var h = l.getBoundingClientRect();
            var p = (0, r.getArrowSpacing)(c);
            var f = a.offsetHeight + p + u;
            var g = window.innerHeight - h.bottom;
            var m = h.top;
            var y = g >= f;
            var v = m >= f;
            switch (t) {
                case "right":
                    return n(a, l, p, u) && o(l, a, c) ? document.documentElement.clientWidth - h.right < a.offsetWidth + p + u ? "left" : "right" : e("up", a, l, p, u, d, !0);
                case "left":
                    return n(a, l, p, u) && o(l, a, c) ? h.left < a.offsetWidth + p + u ? "right" : "left" : e("up", a, l, p, u, d, !0);
                case "up":
                    if (!s && d && i(c, d, u)) return e("left", a, l, p, u, d, !0);
                    if (!v) {
                        if (y) return "down";
                        if (!s && n(a, l, p, u)) return e("right", a, l, p, u, d, !0)
                    }
                    return "up";
                case "down":
                default:
                    if (!s && d && i(c, d, u)) return e("right", a, l, p, u, d, !0);
                    if (!y) {
                        if (v) return "up";
                        if (!s && n(a, l, p, u)) return e("right", a, l, p, u, d, !0)
                    }
                    return "down"
            }
        };
        var r = a(46);

        function n(e, t, a, r) {
            var n = t.getBoundingClientRect(),
                o = Math.min(n.left, document.documentElement.clientWidth - n.right);
            return e.offsetWidth + t.offsetWidth + a + r + o < document.documentElement.clientWidth
        }

        function o(e, t, a) {
            var n = e.getBoundingClientRect(),
                o = n.bottom > window.innerHeight,
                i = n.top < 0;
            if (i && o) return !0;
            if (e.offsetHeight > t.offsetHeight) {
                var l = e.offsetHeight / 2,
                    c = a.arrowSize + r.minArrowPadding,
                    u = n.bottom - window.innerHeight,
                    d = -n.top;
                return l - u >= c && l - d >= c
            }
            return !o && !i
        }

        function i(e, t, a) {
            var n = (0, r.getScrollLeft)(),
                o = t.left - n > a,
                i = t.left + 2 * e.arrowSize < n + document.documentElement.clientWidth - a;
            return !o || !i
        }
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = function() {
                function e(e, t) {
                    for (var a = 0; a < t.length; a++) {
                        var r = t[a];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                return function(t, a, r) {
                    return a && e(t.prototype, a), r && e(t, r), t
                }
            }(),
            n = a(0),
            o = c(n),
            i = c(a(9)),
            l = function(e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e)
                    for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
                return t.default = e, t
            }(a(86));

        function c(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        a(87);
        var u = "12px",
            d = "18px",
            s = "24px",
            h = "30px",
            p = function(e) {
                function t() {
                    return function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, t),
                        function(e, t) {
                            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !t || "object" !== typeof t && "function" !== typeof t ? e : t
                        }(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments))
                }
                return function(e, t) {
                    if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                }(t, n.Component), r(t, [{
                    key: "componentDidMount",
                    value: function() {
                        this.setupEvaIcons()
                    }
                }, {
                    key: "componentDidUpdate",
                    value: function() {
                        this.setupEvaIcons()
                    }
                }, {
                    key: "setupEvaIcons",
                    value: function() {
                        var e = this.props,
                            t = e.fill,
                            a = e.animation,
                            r = e.size,
                            n = this.updateDims(r),
                            o = {
                                fill: t,
                                width: n,
                                height: n,
                                animation: a
                            };
                        l.replace(o)
                    }
                }, {
                    key: "updateDims",
                    value: function(e) {
                        switch (e) {
                            case "small":
                                return u;
                            case "medium":
                                return d;
                            case "large":
                                return s;
                            case "xlarge":
                                return h;
                            default:
                                return d
                        }
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this.props,
                            t = e.name,
                            a = e.fill,
                            r = e.size,
                            n = (e.animation, this.updateDims(r));
                        return o.default.createElement("i", {
                            "data-eva": t,
                            "data-eva-fill": a,
                            "data-eva-height": n,
                            "data-eva-width": n
                        })
                    }
                }]), t
            }();
        p.propTypes = {
            animation: i.default.object,
            fill: i.default.string,
            name: i.default.string,
            size: i.default.string
        }, p.defaultProps = {
            animation: {},
            fill: "#fff",
            name: "",
            size: "medium"
        }, t.default = p
    }, function(e, t, a) {
        var r;
        "undefined" !== typeof self && self, r = function() {
            return function(e) {
                var t = {};

                function a(r) {
                    if (t[r]) return t[r].exports;
                    var n = t[r] = {
                        i: r,
                        l: !1,
                        exports: {}
                    };
                    return e[r].call(n.exports, n, n.exports, a), n.l = !0, n.exports
                }
                return a.m = e, a.c = t, a.d = function(e, t, r) {
                    a.o(e, t) || Object.defineProperty(e, t, {
                        enumerable: !0,
                        get: r
                    })
                }, a.r = function(e) {
                    "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                        value: "Module"
                    }), Object.defineProperty(e, "__esModule", {
                        value: !0
                    })
                }, a.t = function(e, t) {
                    if (1 & t && (e = a(e)), 8 & t) return e;
                    if (4 & t && "object" === typeof e && e && e.__esModule) return e;
                    var r = Object.create(null);
                    if (a.r(r), Object.defineProperty(r, "default", {
                            enumerable: !0,
                            value: e
                        }), 2 & t && "string" != typeof e)
                        for (var n in e) a.d(r, n, function(t) {
                            return e[t]
                        }.bind(null, n));
                    return r
                }, a.n = function(e) {
                    var t = e && e.__esModule ? function() {
                        return e.default
                    } : function() {
                        return e
                    };
                    return a.d(t, "a", t), t
                }, a.o = function(e, t) {
                    return Object.prototype.hasOwnProperty.call(e, t)
                }, a.p = "", a(a.s = "./package/src/index.js")
            }({
                "./node_modules/classnames/dedupe.js": function(e, t, a) {
                    var r;
                    ! function() {
                        "use strict";
                        var a = function() {
                            function e() {}

                            function t(e, t) {
                                for (var a = t.length, r = 0; r < a; ++r) n(e, t[r])
                            }
                            e.prototype = Object.create(null);
                            var a = {}.hasOwnProperty;
                            var r = /\s+/;

                            function n(e, n) {
                                if (n) {
                                    var o = typeof n;
                                    "string" === o ? function(e, t) {
                                        for (var a = t.split(r), n = a.length, o = 0; o < n; ++o) e[a[o]] = !0
                                    }(e, n) : Array.isArray(n) ? t(e, n) : "object" === o ? function(e, t) {
                                        for (var r in t) a.call(t, r) && (e[r] = !!t[r])
                                    }(e, n) : "number" === o && function(e, t) {
                                        e[t] = !0
                                    }(e, n)
                                }
                            }
                            return function() {
                                for (var a = arguments.length, r = Array(a), n = 0; n < a; n++) r[n] = arguments[n];
                                var o = new e;
                                t(o, r);
                                var i = [];
                                for (var l in o) o[l] && i.push(l);
                                return i.join(" ")
                            }
                        }();
                        "undefined" !== typeof e && e.exports ? (a.default = a, e.exports = a) : void 0 === (r = function() {
                            return a
                        }.apply(t, [])) || (e.exports = r)
                    }()
                },
                "./node_modules/css-loader/index.js!./node_modules/sass-loader/lib/loader.js!./package/src/animation.scss": function(e, t, a) {
                    (e.exports = a("./node_modules/css-loader/lib/css-base.js")(!1)).push([e.i, "/**\r\n * @license\r\n * Copyright Akveo. All Rights Reserved.\r\n * Licensed under the MIT License. See License.txt in the project root for license information.\r\n */\n.eva-animation {\n  animation-duration: 1s;\n  animation-fill-mode: both; }\n\n.eva-infinite {\n  animation-iteration-count: infinite; }\n\n.eva-icon-shake {\n  animation-name: eva-shake; }\n\n.eva-icon-zoom {\n  animation-name: eva-zoomIn; }\n\n.eva-icon-pulse {\n  animation-name: eva-pulse; }\n\n.eva-icon-flip {\n  animation-name: eva-flipInY; }\n\n.eva-hover {\n  display: inline-block; }\n\n.eva-hover:hover .eva-icon-hover-shake, .eva-parent-hover:hover .eva-icon-hover-shake {\n  animation-name: eva-shake; }\n\n.eva-hover:hover .eva-icon-hover-zoom, .eva-parent-hover:hover .eva-icon-hover-zoom {\n  animation-name: eva-zoomIn; }\n\n.eva-hover:hover .eva-icon-hover-pulse, .eva-parent-hover:hover .eva-icon-hover-pulse {\n  animation-name: eva-pulse; }\n\n.eva-hover:hover .eva-icon-hover-flip, .eva-parent-hover:hover .eva-icon-hover-flip {\n  animation-name: eva-flipInY; }\n\n@keyframes eva-flipInY {\n  from {\n    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);\n    animation-timing-function: ease-in;\n    opacity: 0; }\n  40% {\n    transform: perspective(400px) rotate3d(0, 1, 0, -20deg);\n    animation-timing-function: ease-in; }\n  60% {\n    transform: perspective(400px) rotate3d(0, 1, 0, 10deg);\n    opacity: 1; }\n  80% {\n    transform: perspective(400px) rotate3d(0, 1, 0, -5deg); }\n  to {\n    transform: perspective(400px); } }\n\n@keyframes eva-shake {\n  from,\n  to {\n    transform: translate3d(0, 0, 0); }\n  10%,\n  30%,\n  50%,\n  70%,\n  90% {\n    transform: translate3d(-3px, 0, 0); }\n  20%,\n  40%,\n  60%,\n  80% {\n    transform: translate3d(3px, 0, 0); } }\n\n@keyframes eva-pulse {\n  from {\n    transform: scale3d(1, 1, 1); }\n  50% {\n    transform: scale3d(1.2, 1.2, 1.2); }\n  to {\n    transform: scale3d(1, 1, 1); } }\n\n@keyframes eva-zoomIn {\n  from {\n    opacity: 1;\n    transform: scale3d(0.5, 0.5, 0.5); }\n  50% {\n    opacity: 1; } }\n", ""])
                },
                "./node_modules/css-loader/lib/css-base.js": function(e, t) {
                    e.exports = function(e) {
                        var t = [];
                        return t.toString = function() {
                            return this.map(function(t) {
                                var a = function(e, t) {
                                    var a = e[1] || "",
                                        r = e[3];
                                    if (!r) return a;
                                    if (t && "function" === typeof btoa) {
                                        var n = (i = r, "/*# sourceMappingURL=data:application/json;charset=utf-8;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(i)))) + " */"),
                                            o = r.sources.map(function(e) {
                                                return "/*# sourceURL=" + r.sourceRoot + e + " */"
                                            });
                                        return [a].concat(o).concat([n]).join("\n")
                                    }
                                    var i;
                                    return [a].join("\n")
                                }(t, e);
                                return t[2] ? "@media " + t[2] + "{" + a + "}" : a
                            }).join("")
                        }, t.i = function(e, a) {
                            "string" === typeof e && (e = [
                                [null, e, ""]
                            ]);
                            for (var r = {}, n = 0; n < this.length; n++) {
                                var o = this[n][0];
                                "number" === typeof o && (r[o] = !0)
                            }
                            for (n = 0; n < e.length; n++) {
                                var i = e[n];
                                "number" === typeof i[0] && r[i[0]] || (a && !i[2] ? i[2] = a : a && (i[2] = "(" + i[2] + ") and (" + a + ")"), t.push(i))
                            }
                        }, t
                    }
                },
                "./node_modules/style-loader/lib/addStyles.js": function(e, t, a) {
                    var r = {},
                        n = function(e) {
                            var t;
                            return function() {
                                return "undefined" === typeof t && (t = e.apply(this, arguments)), t
                            }
                        }(function() {
                            return window && document && document.all && !window.atob
                        }),
                        o = function(e) {
                            var t = {};
                            return function(e) {
                                if ("function" === typeof e) return e();
                                if ("undefined" === typeof t[e]) {
                                    var a = function(e) {
                                        return document.querySelector(e)
                                    }.call(this, e);
                                    if (window.HTMLIFrameElement && a instanceof window.HTMLIFrameElement) try {
                                        a = a.contentDocument.head
                                    } catch (r) {
                                        a = null
                                    }
                                    t[e] = a
                                }
                                return t[e]
                            }
                        }(),
                        i = null,
                        l = 0,
                        c = [],
                        u = a("./node_modules/style-loader/lib/urls.js");

                    function d(e, t) {
                        for (var a = 0; a < e.length; a++) {
                            var n = e[a],
                                o = r[n.id];
                            if (o) {
                                o.refs++;
                                for (var i = 0; i < o.parts.length; i++) o.parts[i](n.parts[i]);
                                for (; i < n.parts.length; i++) o.parts.push(m(n.parts[i], t))
                            } else {
                                var l = [];
                                for (i = 0; i < n.parts.length; i++) l.push(m(n.parts[i], t));
                                r[n.id] = {
                                    id: n.id,
                                    refs: 1,
                                    parts: l
                                }
                            }
                        }
                    }

                    function s(e, t) {
                        for (var a = [], r = {}, n = 0; n < e.length; n++) {
                            var o = e[n],
                                i = t.base ? o[0] + t.base : o[0],
                                l = {
                                    css: o[1],
                                    media: o[2],
                                    sourceMap: o[3]
                                };
                            r[i] ? r[i].parts.push(l) : a.push(r[i] = {
                                id: i,
                                parts: [l]
                            })
                        }
                        return a
                    }

                    function h(e, t) {
                        var a = o(e.insertInto);
                        if (!a) throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");
                        var r = c[c.length - 1];
                        if ("top" === e.insertAt) r ? r.nextSibling ? a.insertBefore(t, r.nextSibling) : a.appendChild(t) : a.insertBefore(t, a.firstChild), c.push(t);
                        else if ("bottom" === e.insertAt) a.appendChild(t);
                        else {
                            if ("object" !== typeof e.insertAt || !e.insertAt.before) throw new Error("[Style Loader]\n\n Invalid value for parameter 'insertAt' ('options.insertAt') found.\n Must be 'top', 'bottom', or Object.\n (https://github.com/webpack-contrib/style-loader#insertat)\n");
                            var n = o(e.insertInto + " " + e.insertAt.before);
                            a.insertBefore(t, n)
                        }
                    }

                    function p(e) {
                        if (null === e.parentNode) return !1;
                        e.parentNode.removeChild(e);
                        var t = c.indexOf(e);
                        t >= 0 && c.splice(t, 1)
                    }

                    function f(e) {
                        var t = document.createElement("style");
                        return void 0 === e.attrs.type && (e.attrs.type = "text/css"), g(t, e.attrs), h(e, t), t
                    }

                    function g(e, t) {
                        Object.keys(t).forEach(function(a) {
                            e.setAttribute(a, t[a])
                        })
                    }

                    function m(e, t) {
                        var a, r, n, o;
                        if (t.transform && e.css) {
                            if (!(o = t.transform(e.css))) return function() {};
                            e.css = o
                        }
                        if (t.singleton) {
                            var c = l++;
                            a = i || (i = f(t)), r = v.bind(null, a, c, !1), n = v.bind(null, a, c, !0)
                        } else e.sourceMap && "function" === typeof URL && "function" === typeof URL.createObjectURL && "function" === typeof URL.revokeObjectURL && "function" === typeof Blob && "function" === typeof btoa ? (a = function(e) {
                            var t = document.createElement("link");
                            return void 0 === e.attrs.type && (e.attrs.type = "text/css"), e.attrs.rel = "stylesheet", g(t, e.attrs), h(e, t), t
                        }(t), r = function(e, t, a) {
                            var r = a.css,
                                n = a.sourceMap,
                                o = void 0 === t.convertToAbsoluteUrls && n;
                            (t.convertToAbsoluteUrls || o) && (r = u(r));
                            n && (r += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(n)))) + " */");
                            var i = new Blob([r], {
                                    type: "text/css"
                                }),
                                l = e.href;
                            e.href = URL.createObjectURL(i), l && URL.revokeObjectURL(l)
                        }.bind(null, a, t), n = function() {
                            p(a), a.href && URL.revokeObjectURL(a.href)
                        }) : (a = f(t), r = function(e, t) {
                            var a = t.css,
                                r = t.media;
                            r && e.setAttribute("media", r);
                            if (e.styleSheet) e.styleSheet.cssText = a;
                            else {
                                for (; e.firstChild;) e.removeChild(e.firstChild);
                                e.appendChild(document.createTextNode(a))
                            }
                        }.bind(null, a), n = function() {
                            p(a)
                        });
                        return r(e),
                            function(t) {
                                if (t) {
                                    if (t.css === e.css && t.media === e.media && t.sourceMap === e.sourceMap) return;
                                    r(e = t)
                                } else n()
                            }
                    }
                    e.exports = function(e, t) {
                        if ("undefined" !== typeof DEBUG && DEBUG && "object" !== typeof document) throw new Error("The style-loader cannot be used in a non-browser environment");
                        (t = t || {}).attrs = "object" === typeof t.attrs ? t.attrs : {}, t.singleton || "boolean" === typeof t.singleton || (t.singleton = n()), t.insertInto || (t.insertInto = "head"), t.insertAt || (t.insertAt = "bottom");
                        var a = s(e, t);
                        return d(a, t),
                            function(e) {
                                for (var n = [], o = 0; o < a.length; o++) {
                                    var i = a[o];
                                    (l = r[i.id]).refs--, n.push(l)
                                }
                                e && d(s(e, t), t);
                                for (o = 0; o < n.length; o++) {
                                    var l;
                                    if (0 === (l = n[o]).refs) {
                                        for (var c = 0; c < l.parts.length; c++) l.parts[c]();
                                        delete r[l.id]
                                    }
                                }
                            }
                    };
                    var y = function() {
                        var e = [];
                        return function(t, a) {
                            return e[t] = a, e.filter(Boolean).join("\n")
                        }
                    }();

                    function v(e, t, a, r) {
                        var n = a ? "" : r.css;
                        if (e.styleSheet) e.styleSheet.cssText = y(t, n);
                        else {
                            var o = document.createTextNode(n),
                                i = e.childNodes;
                            i[t] && e.removeChild(i[t]), i.length ? e.insertBefore(o, i[t]) : e.appendChild(o)
                        }
                    }
                },
                "./node_modules/style-loader/lib/urls.js": function(e, t) {
                    e.exports = function(e) {
                        var t = "undefined" !== typeof window && window.location;
                        if (!t) throw new Error("fixUrls requires window.location");
                        if (!e || "string" !== typeof e) return e;
                        var a = t.protocol + "//" + t.host,
                            r = a + t.pathname.replace(/\/[^\/]*$/, "/");
                        return e.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi, function(e, t) {
                            var n, o = t.trim().replace(/^"(.*)"$/, function(e, t) {
                                return t
                            }).replace(/^'(.*)'$/, function(e, t) {
                                return t
                            });
                            return /^(#|data:|http:\/\/|https:\/\/|file:\/\/\/|\s*$)/i.test(o) ? e : (n = 0 === o.indexOf("//") ? o : 0 === o.indexOf("/") ? a + o : r + o.replace(/^\.\//, ""), "url(" + JSON.stringify(n) + ")")
                        })
                    }
                },
                "./package-build/eva-icons.json": function(e) {
                    e.exports = {
                        activity: '<g data-name="Layer 2"><g data-name="activity"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M14.33 20h-.21a2 2 0 0 1-1.76-1.58L9.68 6l-2.76 6.4A1 1 0 0 1 6 13H3a1 1 0 0 1 0-2h2.34l2.51-5.79a2 2 0 0 1 3.79.38L14.32 18l2.76-6.38A1 1 0 0 1 18 11h3a1 1 0 0 1 0 2h-2.34l-2.51 5.79A2 2 0 0 1 14.33 20z"/></g></g>',
                        "alert-circle": '<g data-name="Layer 2"><g data-name="alert-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 15a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm1-4a1 1 0 0 1-2 0V8a1 1 0 0 1 2 0z"/></g></g>',
                        "alert-triangle": '<g data-name="Layer 2"><g data-name="alert-triangle"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M22.56 16.3L14.89 3.58a3.43 3.43 0 0 0-5.78 0L1.44 16.3a3 3 0 0 0-.05 3A3.37 3.37 0 0 0 4.33 21h15.34a3.37 3.37 0 0 0 2.94-1.66 3 3 0 0 0-.05-3.04zM12 17a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm1-4a1 1 0 0 1-2 0V9a1 1 0 0 1 2 0z"/></g></g>',
                        archive: '<g data-name="Layer 2"><g data-name="archive"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M18 3H6a3 3 0 0 0-2 5.22V18a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V8.22A3 3 0 0 0 18 3zm-3 10.13a.87.87 0 0 1-.87.87H9.87a.87.87 0 0 1-.87-.87v-.26a.87.87 0 0 1 .87-.87h4.26a.87.87 0 0 1 .87.87zM18 7H6a1 1 0 0 1 0-2h12a1 1 0 0 1 0 2z"/></g></g>',
                        "arrow-back": '<g data-name="Layer 2"><g data-name="arrow-back"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M19 11H7.14l3.63-4.36a1 1 0 1 0-1.54-1.28l-5 6a1.19 1.19 0 0 0-.09.15c0 .05 0 .08-.07.13A1 1 0 0 0 4 12a1 1 0 0 0 .07.36c0 .05 0 .08.07.13a1.19 1.19 0 0 0 .09.15l5 6A1 1 0 0 0 10 19a1 1 0 0 0 .64-.23 1 1 0 0 0 .13-1.41L7.14 13H19a1 1 0 0 0 0-2z"/></g></g>',
                        "arrow-circle-down": '<g data-name="Layer 2"><g data-name="arrow-circle-down"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm3.69 11.86l-3 2.86a.49.49 0 0 1-.15.1.54.54 0 0 1-.16.1.94.94 0 0 1-.76 0 1 1 0 0 1-.33-.21l-3-3a1 1 0 0 1 1.42-1.42l1.29 1.3V8a1 1 0 0 1 2 0v5.66l1.31-1.25a1 1 0 0 1 1.38 1.45z"/></g></g>',
                        "arrow-circle-left": '<g data-name="Layer 2"><g data-name="arrow-circle-left"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M22 12a10 10 0 1 0-10 10 10 10 0 0 0 10-10zm-11.86 3.69l-2.86-3a.49.49 0 0 1-.1-.15.54.54 0 0 1-.1-.16.94.94 0 0 1 0-.76 1 1 0 0 1 .21-.33l3-3a1 1 0 0 1 1.42 1.42L10.41 11H16a1 1 0 0 1 0 2h-5.66l1.25 1.31a1 1 0 0 1-1.45 1.38z"/></g></g>',
                        "arrow-circle-right": '<g data-name="Layer 2"><g data-name="arrow-circle-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M2 12A10 10 0 1 0 12 2 10 10 0 0 0 2 12zm11.86-3.69l2.86 3a.49.49 0 0 1 .1.15.54.54 0 0 1 .1.16.94.94 0 0 1 0 .76 1 1 0 0 1-.21.33l-3 3a1 1 0 0 1-1.42-1.42l1.3-1.29H8a1 1 0 0 1 0-2h5.66l-1.25-1.31a1 1 0 0 1 1.45-1.38z"/></g></g>',
                        "arrow-circle-up": '<g data-name="Layer 2"><g data-name="arrow-circle-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 22A10 10 0 1 0 2 12a10 10 0 0 0 10 10zM8.31 10.14l3-2.86a.49.49 0 0 1 .15-.1.54.54 0 0 1 .16-.1.94.94 0 0 1 .76 0 1 1 0 0 1 .33.21l3 3a1 1 0 0 1-1.42 1.42L13 10.41V16a1 1 0 0 1-2 0v-5.66l-1.31 1.25a1 1 0 0 1-1.38-1.45z"/></g></g>',
                        "arrow-down": '<g data-name="Layer 2"><g data-name="arrow-downward"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M12 17a1.72 1.72 0 0 1-1.33-.64l-4.21-5.1a2.1 2.1 0 0 1-.26-2.21A1.76 1.76 0 0 1 7.79 8h8.42a1.76 1.76 0 0 1 1.59 1.05 2.1 2.1 0 0 1-.26 2.21l-4.21 5.1A1.72 1.72 0 0 1 12 17z"/></g></g>',
                        "arrow-downward": '<g data-name="Layer 2"><g data-name="arrow-down"><rect width="24" height="24" opacity="0"/><path d="M18.77 13.36a1 1 0 0 0-1.41-.13L13 16.86V5a1 1 0 0 0-2 0v11.86l-4.36-3.63a1 1 0 1 0-1.28 1.54l6 5 .15.09.13.07a1 1 0 0 0 .72 0l.13-.07.15-.09 6-5a1 1 0 0 0 .13-1.41z"/></g></g>',
                        "arrow-forward": '<g data-name="Layer 2"><g data-name="arrow-forward"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M5 13h11.86l-3.63 4.36a1 1 0 0 0 1.54 1.28l5-6a1.19 1.19 0 0 0 .09-.15c0-.05.05-.08.07-.13A1 1 0 0 0 20 12a1 1 0 0 0-.07-.36c0-.05-.05-.08-.07-.13a1.19 1.19 0 0 0-.09-.15l-5-6A1 1 0 0 0 14 5a1 1 0 0 0-.64.23 1 1 0 0 0-.13 1.41L16.86 11H5a1 1 0 0 0 0 2z"/></g></g>',
                        "arrow-ios-back": '<g data-name="Layer 2"><g data-name="arrow-ios-back"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M13.83 19a1 1 0 0 1-.78-.37l-4.83-6a1 1 0 0 1 0-1.27l5-6a1 1 0 0 1 1.54 1.28L10.29 12l4.32 5.36a1 1 0 0 1-.78 1.64z"/></g></g>',
                        "arrow-ios-downward": '<g data-name="Layer 2"><g data-name="arrow-ios-downward"><rect width="24" height="24" opacity="0"/><path d="M12 16a1 1 0 0 1-.64-.23l-6-5a1 1 0 1 1 1.28-1.54L12 13.71l5.36-4.32a1 1 0 0 1 1.41.15 1 1 0 0 1-.14 1.46l-6 4.83A1 1 0 0 1 12 16z"/></g></g>',
                        "arrow-ios-forward": '<g data-name="Layer 2"><g data-name="arrow-ios-forward"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M10 19a1 1 0 0 1-.64-.23 1 1 0 0 1-.13-1.41L13.71 12 9.39 6.63a1 1 0 0 1 .15-1.41 1 1 0 0 1 1.46.15l4.83 6a1 1 0 0 1 0 1.27l-5 6A1 1 0 0 1 10 19z"/></g></g>',
                        "arrow-ios-upward": '<g data-name="Layer 2"><g data-name="arrow-ios-upward"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 15a1 1 0 0 1-.64-.23L12 10.29l-5.37 4.32a1 1 0 0 1-1.41-.15 1 1 0 0 1 .15-1.41l6-4.83a1 1 0 0 1 1.27 0l6 5a1 1 0 0 1 .13 1.41A1 1 0 0 1 18 15z"/></g></g>',
                        "arrow-left": '<g data-name="Layer 2"><g data-name="arrow-left"><rect width="24" height="24" opacity="0"/><path d="M13.54 18a2.06 2.06 0 0 1-1.3-.46l-5.1-4.21a1.7 1.7 0 0 1 0-2.66l5.1-4.21a2.1 2.1 0 0 1 2.21-.26 1.76 1.76 0 0 1 1.05 1.59v8.42a1.76 1.76 0 0 1-1.05 1.59 2.23 2.23 0 0 1-.91.2z"/></g></g>',
                        "arrow-right": '<g data-name="Layer 2"><g data-name="arrow-right"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M10.46 18a2.23 2.23 0 0 1-.91-.2 1.76 1.76 0 0 1-1.05-1.59V7.79A1.76 1.76 0 0 1 9.55 6.2a2.1 2.1 0 0 1 2.21.26l5.1 4.21a1.7 1.7 0 0 1 0 2.66l-5.1 4.21a2.06 2.06 0 0 1-1.3.46z"/></g></g>',
                        "arrow-up": '<g data-name="Layer 2"><g data-name="arrow-up"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M16.21 16H7.79a1.76 1.76 0 0 1-1.59-1 2.1 2.1 0 0 1 .26-2.21l4.21-5.1a1.76 1.76 0 0 1 2.66 0l4.21 5.1A2.1 2.1 0 0 1 17.8 15a1.76 1.76 0 0 1-1.59 1z"/></g></g>',
                        "arrow-upward": '<g data-name="Layer 2"><g data-name="arrow-upward"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M5.23 10.64a1 1 0 0 0 1.41.13L11 7.14V19a1 1 0 0 0 2 0V7.14l4.36 3.63a1 1 0 1 0 1.28-1.54l-6-5-.15-.09-.13-.07a1 1 0 0 0-.72 0l-.13.07-.15.09-6 5a1 1 0 0 0-.13 1.41z"/></g></g>',
                        "arrowhead-down": '<g data-name="Layer 2"><g data-name="arrowhead-down"><rect width="24" height="24" opacity="0"/><path d="M17.37 12.39L12 16.71l-5.36-4.48a1 1 0 1 0-1.28 1.54l6 5a1 1 0 0 0 1.27 0l6-4.83a1 1 0 0 0 .15-1.41 1 1 0 0 0-1.41-.14z"/><path d="M11.36 11.77a1 1 0 0 0 1.27 0l6-4.83a1 1 0 0 0 .15-1.41 1 1 0 0 0-1.41-.15L12 9.71 6.64 5.23a1 1 0 0 0-1.28 1.54z"/></g></g>',
                        "arrowhead-left": '<g data-name="Layer 2"><g data-name="arrowhead-left"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M11.64 5.23a1 1 0 0 0-1.41.13l-5 6a1 1 0 0 0 0 1.27l4.83 6a1 1 0 0 0 .78.37 1 1 0 0 0 .78-1.63L7.29 12l4.48-5.37a1 1 0 0 0-.13-1.4z"/><path d="M14.29 12l4.48-5.37a1 1 0 0 0-1.54-1.28l-5 6a1 1 0 0 0 0 1.27l4.83 6a1 1 0 0 0 .78.37 1 1 0 0 0 .78-1.63z"/></g></g>',
                        "arrowhead-right": '<g data-name="Layer 2"><g data-name="arrowhead-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M18.78 11.37l-4.78-6a1 1 0 0 0-1.41-.15 1 1 0 0 0-.15 1.41L16.71 12l-4.48 5.37a1 1 0 0 0 .13 1.41A1 1 0 0 0 13 19a1 1 0 0 0 .77-.36l5-6a1 1 0 0 0 .01-1.27z"/><path d="M7 5.37a1 1 0 0 0-1.61 1.26L9.71 12l-4.48 5.36a1 1 0 0 0 .13 1.41A1 1 0 0 0 6 19a1 1 0 0 0 .77-.36l5-6a1 1 0 0 0 0-1.27z"/></g></g>',
                        "arrowhead-up": '<g data-name="Layer 2"><g data-name="arrowhead-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M6.63 11.61L12 7.29l5.37 4.48A1 1 0 0 0 18 12a1 1 0 0 0 .77-.36 1 1 0 0 0-.13-1.41l-6-5a1 1 0 0 0-1.27 0l-6 4.83a1 1 0 0 0-.15 1.41 1 1 0 0 0 1.41.14z"/><path d="M12.64 12.23a1 1 0 0 0-1.27 0l-6 4.83a1 1 0 0 0-.15 1.41 1 1 0 0 0 1.41.15L12 14.29l5.37 4.48A1 1 0 0 0 18 19a1 1 0 0 0 .77-.36 1 1 0 0 0-.13-1.41z"/></g></g>',
                        at: '<g data-name="Layer 2"><g data-name="at"><rect width="24" height="24" opacity="0"/><path d="M13 2a10 10 0 0 0-5 19.1 10.15 10.15 0 0 0 4 .9 10 10 0 0 0 6.08-2.06 1 1 0 0 0 .19-1.4 1 1 0 0 0-1.41-.19A8 8 0 1 1 12.77 4 8.17 8.17 0 0 1 20 12.22v.68a1.71 1.71 0 0 1-1.78 1.7 1.82 1.82 0 0 1-1.62-1.88V8.4a1 1 0 0 0-1-1 1 1 0 0 0-1 .87 5 5 0 0 0-3.44-1.36A5.09 5.09 0 1 0 15.31 15a3.6 3.6 0 0 0 5.55.61A3.67 3.67 0 0 0 22 12.9v-.68A10.2 10.2 0 0 0 13 2zm-1.82 13.09A3.09 3.09 0 1 1 14.27 12a3.1 3.1 0 0 1-3.09 3.09z"/></g></g>',
                        "attach-2": '<g data-name="Layer 2"><g data-name="attach-2"><rect width="24" height="24" opacity="0"/><path d="M12 22a5.86 5.86 0 0 1-6-5.7V6.13A4.24 4.24 0 0 1 10.33 2a4.24 4.24 0 0 1 4.34 4.13v10.18a2.67 2.67 0 0 1-5.33 0V6.92a1 1 0 0 1 1-1 1 1 0 0 1 1 1v9.39a.67.67 0 0 0 1.33 0V6.13A2.25 2.25 0 0 0 10.33 4 2.25 2.25 0 0 0 8 6.13V16.3a3.86 3.86 0 0 0 4 3.7 3.86 3.86 0 0 0 4-3.7V6.13a1 1 0 1 1 2 0V16.3a5.86 5.86 0 0 1-6 5.7z"/></g></g>',
                        attach: '<g data-name="Layer 2"><g data-name="attach"><rect width="24" height="24" opacity="0"/><path d="M9.29 21a6.23 6.23 0 0 1-4.43-1.88 6 6 0 0 1-.22-8.49L12 3.2A4.11 4.11 0 0 1 15 2a4.48 4.48 0 0 1 3.19 1.35 4.36 4.36 0 0 1 .15 6.13l-7.4 7.43a2.54 2.54 0 0 1-1.81.75 2.72 2.72 0 0 1-1.95-.82 2.68 2.68 0 0 1-.08-3.77l6.83-6.86a1 1 0 0 1 1.37 1.41l-6.83 6.86a.68.68 0 0 0 .08.95.78.78 0 0 0 .53.23.56.56 0 0 0 .4-.16l7.39-7.43a2.36 2.36 0 0 0-.15-3.31 2.38 2.38 0 0 0-3.27-.15L6.06 12a4 4 0 0 0 .22 5.67 4.22 4.22 0 0 0 3 1.29 3.67 3.67 0 0 0 2.61-1.06l7.39-7.43a1 1 0 1 1 1.42 1.41l-7.39 7.43A5.65 5.65 0 0 1 9.29 21z"/></g></g>',
                        award: '<g data-name="Layer 2"><g data-name="award"><rect width="24" height="24" opacity="0"/><path d="M19 20.75l-2.31-9A5.94 5.94 0 0 0 18 8 6 6 0 0 0 6 8a5.94 5.94 0 0 0 1.34 3.77L5 20.75a1 1 0 0 0 1.48 1.11l5.33-3.13 5.68 3.14A.91.91 0 0 0 18 22a1 1 0 0 0 1-1.25zM12 4a4 4 0 1 1-4 4 4 4 0 0 1 4-4z"/></g></g>',
                        backspace: '<g data-name="Layer 2"><g data-name="backspace"><rect width="24" height="24" opacity="0"/><path d="M20.14 4h-9.77a3 3 0 0 0-2 .78l-.1.11-6 7.48a1 1 0 0 0 .11 1.37l6 5.48a3 3 0 0 0 2 .78h9.77A1.84 1.84 0 0 0 22 18.18V5.82A1.84 1.84 0 0 0 20.14 4zm-3.43 9.29a1 1 0 0 1 0 1.42 1 1 0 0 1-1.42 0L14 13.41l-1.29 1.3a1 1 0 0 1-1.42 0 1 1 0 0 1 0-1.42l1.3-1.29-1.3-1.29a1 1 0 0 1 1.42-1.42l1.29 1.3 1.29-1.3a1 1 0 0 1 1.42 1.42L15.41 12z"/></g></g>',
                        "bar-chart-2": '<g data-name="Layer 2"><g data-name="bar-chart-2"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M12 8a1 1 0 0 0-1 1v11a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z"/><path d="M19 4a1 1 0 0 0-1 1v15a1 1 0 0 0 2 0V5a1 1 0 0 0-1-1z"/><path d="M5 12a1 1 0 0 0-1 1v7a1 1 0 0 0 2 0v-7a1 1 0 0 0-1-1z"/></g></g>',
                        "bar-chart": '<g data-name="Layer 2"><g data-name="bar-chart"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M12 4a1 1 0 0 0-1 1v15a1 1 0 0 0 2 0V5a1 1 0 0 0-1-1z"/><path d="M19 12a1 1 0 0 0-1 1v7a1 1 0 0 0 2 0v-7a1 1 0 0 0-1-1z"/><path d="M5 8a1 1 0 0 0-1 1v11a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z"/></g></g>',
                        battery: '<g data-name="Layer 2"><g data-name="battery"><rect width="24" height="24" opacity="0"/><path d="M15.83 6H4.17A2.31 2.31 0 0 0 2 8.43v7.14A2.31 2.31 0 0 0 4.17 18h11.66A2.31 2.31 0 0 0 18 15.57V8.43A2.31 2.31 0 0 0 15.83 6z"/><path d="M21 9a1 1 0 0 0-1 1v4a1 1 0 0 0 2 0v-4a1 1 0 0 0-1-1z"/></g></g>',
                        behance: '<g data-name="Layer 2"><g data-name="behance"><rect width="24" height="24" opacity="0"/><path d="M14.76 11.19a1 1 0 0 0-1 1.09h2.06a1 1 0 0 0-1.06-1.09z"/><path d="M9.49 12.3H8.26v1.94h1c1 0 1.44-.33 1.44-1s-.46-.94-1.21-.94z"/><path d="M10.36 10.52c0-.53-.35-.85-.95-.85H8.26v1.74h.85c.89 0 1.25-.32 1.25-.89z"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zM9.7 15.2H7V8.7h2.7c1.17 0 1.94.61 1.94 1.6a1.4 1.4 0 0 1-1.12 1.43A1.52 1.52 0 0 1 12 13.37c0 1.16-1 1.83-2.3 1.83zm3.55-6h3v.5h-3zM17 13.05h-3.3v.14a1.07 1.07 0 0 0 1.09 1.19.9.9 0 0 0 1-.63H17a2 2 0 0 1-2.17 1.55 2.15 2.15 0 0 1-2.36-2.3v-.44a2.11 2.11 0 0 1 2.28-2.25A2.12 2.12 0 0 1 17 12.58z"/></g></g>',
                        "bell-off": '<g data-name="Layer 2"><g data-name="bell-off"><rect width="24" height="24" opacity="0"/><path d="M15.88 18.71l-.59-.59L14 16.78l-.07-.07L6.58 9.4 5.31 8.14a5.68 5.68 0 0 0 0 .59v4.67l-1.8 1.81A1.64 1.64 0 0 0 4.64 18H8v.34A3.84 3.84 0 0 0 12 22a3.88 3.88 0 0 0 4-3.22zM14 18.34A1.88 1.88 0 0 1 12 20a1.88 1.88 0 0 1-2-1.66V18h4z"/><path d="M7.13 4.3l1.46 1.46 9.53 9.53 2 2 .31.3a1.58 1.58 0 0 0 .45-.6 1.62 1.62 0 0 0-.35-1.78l-1.8-1.81V8.94a6.86 6.86 0 0 0-5.83-6.88 6.71 6.71 0 0 0-5.32 1.61 6.88 6.88 0 0 0-.58.54z"/><path d="M20.71 19.29L19.41 18l-2-2-9.52-9.53L6.42 5 4.71 3.29a1 1 0 0 0-1.42 1.42L5.53 7l1.75 1.7 7.31 7.3.07.07L16 17.41l.59.59 2.7 2.71a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        bell: '<g data-name="Layer 2"><g data-name="bell"><rect width="24" height="24" opacity="0"/><path d="M20.52 15.21l-1.8-1.81V8.94a6.86 6.86 0 0 0-5.82-6.88 6.74 6.74 0 0 0-7.62 6.67v4.67l-1.8 1.81A1.64 1.64 0 0 0 4.64 18H8v.34A3.84 3.84 0 0 0 12 22a3.84 3.84 0 0 0 4-3.66V18h3.36a1.64 1.64 0 0 0 1.16-2.79zM14 18.34A1.88 1.88 0 0 1 12 20a1.88 1.88 0 0 1-2-1.66V18h4z"/></g></g>',
                        bluetooth: '<g data-name="Layer 2"><g data-name="bluetooth"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M13.63 12l4-3.79a1.14 1.14 0 0 0-.13-1.77l-4.67-3.23a1.17 1.17 0 0 0-1.21-.08 1.15 1.15 0 0 0-.62 1v6.2l-3.19-4a1 1 0 0 0-1.56 1.3L9.72 12l-3.5 4.43a1 1 0 0 0 .16 1.4A1 1 0 0 0 7 18a1 1 0 0 0 .78-.38L11 13.56v6.29A1.16 1.16 0 0 0 12.16 21a1.16 1.16 0 0 0 .67-.21l4.64-3.18a1.17 1.17 0 0 0 .49-.85 1.15 1.15 0 0 0-.34-.91zM13 5.76l2.5 1.73L13 9.85zm0 12.49v-4.07l2.47 2.38z"/></g></g>',
                        "book-open": '<g data-name="Layer 2"><g data-name="book-open"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M21 4.34a1.24 1.24 0 0 0-1.08-.23L13 5.89v14.27l7.56-1.94A1.25 1.25 0 0 0 21.5 17V5.32a1.25 1.25 0 0 0-.5-.98z"/><path d="M11 5.89L4.06 4.11A1.27 1.27 0 0 0 3 4.34a1.25 1.25 0 0 0-.48 1V17a1.25 1.25 0 0 0 .94 1.21L11 20.16z"/></g></g>',
                        book: '<g data-name="Layer 2"><g data-name="book"><rect width="24" height="24" opacity="0"/><path d="M19 3H7a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zM7 19a1 1 0 0 1 0-2h11v2z"/></g></g>',
                        bookmark: '<g data-name="Layer 2"><g data-name="bookmark"><rect width="24" height="24" opacity="0"/><path d="M6 21a1 1 0 0 1-.49-.13A1 1 0 0 1 5 20V5.33A2.28 2.28 0 0 1 7.2 3h9.6A2.28 2.28 0 0 1 19 5.33V20a1 1 0 0 1-.5.86 1 1 0 0 1-1 0l-5.67-3.21-5.33 3.2A1 1 0 0 1 6 21z"/></g></g>',
                        briefcase: '<g data-name="Layer 2"><g data-name="briefcase"><rect width="24" height="24" opacity="0"/><path d="M7 21h10V7h-1V5.5A2.5 2.5 0 0 0 13.5 3h-3A2.5 2.5 0 0 0 8 5.5V7H7zm3-15.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5V7h-4z"/><path d="M19 7v14a3 3 0 0 0 3-3v-8a3 3 0 0 0-3-3z"/><path d="M5 7a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3z"/></g></g>',
                        browser: '<g data-name="Layer 2"><g data-name="browser"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm-6 3a1 1 0 1 1-1 1 1 1 0 0 1 1-1zM8 6a1 1 0 1 1-1 1 1 1 0 0 1 1-1zm11 12a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-7h14z"/></g></g>',
                        brush: '<g data-name="Layer 2"><g data-name="brush"><rect width="24" height="24" opacity="0"/><path d="M7.12 12.55a4 4 0 0 0-3.07 3.86v3.11a.47.47 0 0 0 .48.48l3.24-.06a3.78 3.78 0 0 0 3.44-2.2 3.65 3.65 0 0 0-4.09-5.19z"/><path d="M19.26 4.46a2.14 2.14 0 0 0-2.88.21L10 11.08a.47.47 0 0 0 0 .66L12.25 14a.47.47 0 0 0 .66 0l6.49-6.47a2.06 2.06 0 0 0 .6-1.47 2 2 0 0 0-.74-1.6z"/></g></g>',
                        bulb: '<g data-name="Layer 2"><g data-name="bulb"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 7a5 5 0 0 0-3 9v4a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-4a5 5 0 0 0-3-9z"/><path d="M12 6a1 1 0 0 0 1-1V3a1 1 0 0 0-2 0v2a1 1 0 0 0 1 1z"/><path d="M21 11h-2a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2z"/><path d="M5 11H3a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2z"/><path d="M7.66 6.42L6.22 5a1 1 0 0 0-1.39 1.47l1.44 1.39a1 1 0 0 0 .73.28 1 1 0 0 0 .72-.31 1 1 0 0 0-.06-1.41z"/><path d="M19.19 5.05a1 1 0 0 0-1.41 0l-1.44 1.37a1 1 0 0 0 0 1.41 1 1 0 0 0 .72.31 1 1 0 0 0 .69-.28l1.44-1.39a1 1 0 0 0 0-1.42z"/></g></g>',
                        calendar: '<g data-name="Layer 2"><g data-name="calendar"><rect width="24" height="24" opacity="0"/><path d="M18 4h-1V3a1 1 0 0 0-2 0v1H9V3a1 1 0 0 0-2 0v1H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3zM8 17a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm8 0h-4a1 1 0 0 1 0-2h4a1 1 0 0 1 0 2zm3-6H5V7a1 1 0 0 1 1-1h1v1a1 1 0 0 0 2 0V6h6v1a1 1 0 0 0 2 0V6h1a1 1 0 0 1 1 1z"/></g></g>',
                        camera: '<g data-name="Layer 2"><g data-name="camera"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="14" r="1.5"/><path d="M19 7h-3V5.5A2.5 2.5 0 0 0 13.5 3h-3A2.5 2.5 0 0 0 8 5.5V7H5a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3v-8a3 3 0 0 0-3-3zm-9-1.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5V7h-4zm2 12a3.5 3.5 0 1 1 3.5-3.5 3.5 3.5 0 0 1-3.5 3.5z"/></g></g>',
                        car: '<g data-name="Layer 2"><g data-name="car"><rect width="24" height="24" opacity="0"/><path d="M21.6 11.22L17 7.52V5a1.91 1.91 0 0 0-1.81-2H3.79A1.91 1.91 0 0 0 2 5v10a2 2 0 0 0 1.2 1.88 3 3 0 1 0 5.6.12h6.36a3 3 0 1 0 5.64 0h.2a1 1 0 0 0 1-1v-4a1 1 0 0 0-.4-.78zM20 12.48V15h-3v-4.92zM7 18a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm12 0a1 1 0 1 1-1-1 1 1 0 0 1 1 1z"/></g></g>',
                        cast: '<g data-name="Layer 2"><g data-name="cast"><polyline points="24 24 0 24 0 0" opacity="0"/><path d="M18.4 3H5.6A2.7 2.7 0 0 0 3 5.78V7a1 1 0 0 0 2 0V5.78A.72.72 0 0 1 5.6 5h12.8a.72.72 0 0 1 .6.78v12.44a.72.72 0 0 1-.6.78H17a1 1 0 0 0 0 2h1.4a2.7 2.7 0 0 0 2.6-2.78V5.78A2.7 2.7 0 0 0 18.4 3z"/><path d="M3.86 14A1 1 0 0 0 3 15.17a1 1 0 0 0 1.14.83 2.49 2.49 0 0 1 2.12.72 2.52 2.52 0 0 1 .51 2.84 1 1 0 0 0 .48 1.33 1.06 1.06 0 0 0 .42.09 1 1 0 0 0 .91-.58A4.52 4.52 0 0 0 3.86 14z"/><path d="M3.86 10.08a1 1 0 0 0 .28 2 6 6 0 0 1 5.09 1.71 6 6 0 0 1 1.53 5.95 1 1 0 0 0 .68 1.26.9.9 0 0 0 .28 0 1 1 0 0 0 1-.72 8 8 0 0 0-8.82-10.2z"/><circle cx="4" cy="19" r="1"/></g></g>',
                        charging: '<g data-name="Layer 2"><g data-name="charging"><rect width="24" height="24" opacity="0"/><path d="M11.28 13H7a1 1 0 0 1-.86-.5 1 1 0 0 1 0-1L9.28 6H4.17A2.31 2.31 0 0 0 2 8.43v7.14A2.31 2.31 0 0 0 4.17 18h4.25z"/><path d="M15.83 6h-4.25l-2.86 5H13a1 1 0 0 1 .86.5 1 1 0 0 1 0 1L10.72 18h5.11A2.31 2.31 0 0 0 18 15.57V8.43A2.31 2.31 0 0 0 15.83 6z"/><path d="M21 9a1 1 0 0 0-1 1v4a1 1 0 0 0 2 0v-4a1 1 0 0 0-1-1z"/></g></g>',
                        "checkmark-circle-2": '<g data-name="Layer 2"><g data-name="checkmark-circle-2"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm4.3 7.61l-4.57 6a1 1 0 0 1-.79.39 1 1 0 0 1-.79-.38l-2.44-3.11a1 1 0 0 1 1.58-1.23l1.63 2.08 3.78-5a1 1 0 1 1 1.6 1.22z"/></g></g>',
                        "checkmark-circle": '<g data-name="Layer 2"><g data-name="checkmark-circle"><rect width="24" height="24" opacity="0"/><path d="M9.71 11.29a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 16a1 1 0 0 0 .72-.34l7-8a1 1 0 0 0-1.5-1.32L12 13.54z"/><path d="M21 11a1 1 0 0 0-1 1 8 8 0 0 1-8 8A8 8 0 0 1 6.33 6.36 7.93 7.93 0 0 1 12 4a8.79 8.79 0 0 1 1.9.22 1 1 0 1 0 .47-1.94A10.54 10.54 0 0 0 12 2a10 10 0 0 0-7 17.09A9.93 9.93 0 0 0 12 22a10 10 0 0 0 10-10 1 1 0 0 0-1-1z"/></g></g>',
                        "checkmark-square-2": '<g data-name="Layer 2"><g data-name="checkmark-square-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm-1.7 6.61l-4.57 6a1 1 0 0 1-.79.39 1 1 0 0 1-.79-.38l-2.44-3.11a1 1 0 0 1 1.58-1.23l1.63 2.08 3.78-5a1 1 0 1 1 1.6 1.22z"/></g></g>',
                        "checkmark-square": '<g data-name="Layer 2"><g data-name="checkmark-square"><rect width="24" height="24" opacity="0"/><path d="M20 11.83a1 1 0 0 0-1 1v5.57a.6.6 0 0 1-.6.6H5.6a.6.6 0 0 1-.6-.6V5.6a.6.6 0 0 1 .6-.6h9.57a1 1 0 1 0 0-2H5.6A2.61 2.61 0 0 0 3 5.6v12.8A2.61 2.61 0 0 0 5.6 21h12.8a2.61 2.61 0 0 0 2.6-2.6v-5.57a1 1 0 0 0-1-1z"/><path d="M10.72 11a1 1 0 0 0-1.44 1.38l2.22 2.33a1 1 0 0 0 .72.31 1 1 0 0 0 .72-.3l6.78-7a1 1 0 1 0-1.44-1.4l-6.05 6.26z"/></g></g>',
                        checkmark: '<g data-name="Layer 2"><g data-name="checkmark"><rect width="24" height="24" opacity="0"/><path d="M9.86 18a1 1 0 0 1-.73-.32l-4.86-5.17a1 1 0 1 1 1.46-1.37l4.12 4.39 8.41-9.2a1 1 0 1 1 1.48 1.34l-9.14 10a1 1 0 0 1-.73.33z"/></g></g>',
                        "chevron-down": '<g data-name="Layer 2"><g data-name="chevron-down"><rect width="24" height="24" opacity="0"/><path d="M12 15.5a1 1 0 0 1-.71-.29l-4-4a1 1 0 1 1 1.42-1.42L12 13.1l3.3-3.18a1 1 0 1 1 1.38 1.44l-4 3.86a1 1 0 0 1-.68.28z"/></g></g>',
                        "chevron-left": '<g data-name="Layer 2"><g data-name="chevron-left"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M13.36 17a1 1 0 0 1-.72-.31l-3.86-4a1 1 0 0 1 0-1.4l4-4a1 1 0 1 1 1.42 1.42L10.9 12l3.18 3.3a1 1 0 0 1 0 1.41 1 1 0 0 1-.72.29z"/></g></g>',
                        "chevron-right": '<g data-name="Layer 2"><g data-name="chevron-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M10.5 17a1 1 0 0 1-.71-.29 1 1 0 0 1 0-1.42L13.1 12 9.92 8.69a1 1 0 0 1 0-1.41 1 1 0 0 1 1.42 0l3.86 4a1 1 0 0 1 0 1.4l-4 4a1 1 0 0 1-.7.32z"/></g></g>',
                        "chevron-up": '<g data-name="Layer 2"><g data-name="chevron-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M16 14.5a1 1 0 0 1-.71-.29L12 10.9l-3.3 3.18a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.42l4-3.86a1 1 0 0 1 1.4 0l4 4a1 1 0 0 1 0 1.42 1 1 0 0 1-.69.28z"/></g></g>',
                        clipboard: '<g data-name="Layer 2"><g data-name="clipboard"><rect width="24" height="24" opacity="0"/><path d="M18 4v3a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V4a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3z"/><rect x="7" y="2" width="10" height="6" rx="1" ry="1"/></g></g>',
                        clock: '<g data-name="Layer 2"><g data-name="clock"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm4 11h-4a1 1 0 0 1-1-1V8a1 1 0 0 1 2 0v3h3a1 1 0 0 1 0 2z"/></g></g>',
                        "close-circle": '<g data-name="Layer 2"><g data-name="close-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm2.71 11.29a1 1 0 0 1 0 1.42 1 1 0 0 1-1.42 0L12 13.41l-1.29 1.3a1 1 0 0 1-1.42 0 1 1 0 0 1 0-1.42l1.3-1.29-1.3-1.29a1 1 0 0 1 1.42-1.42l1.29 1.3 1.29-1.3a1 1 0 0 1 1.42 1.42L13.41 12z"/></g></g>',
                        "close-square": '<g data-name="Layer 2"><g data-name="close-square"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm-3.29 10.29a1 1 0 0 1 0 1.42 1 1 0 0 1-1.42 0L12 13.41l-1.29 1.3a1 1 0 0 1-1.42 0 1 1 0 0 1 0-1.42l1.3-1.29-1.3-1.29a1 1 0 0 1 1.42-1.42l1.29 1.3 1.29-1.3a1 1 0 0 1 1.42 1.42L13.41 12z"/></g></g>',
                        close: '<g data-name="Layer 2"><g data-name="close"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29-4.3 4.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l4.29-4.3 4.29 4.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        "cloud-download": '<g data-name="Layer 2"><g data-name="cloud-download"><rect width="24" height="24" opacity="0"/><path d="M21.9 11c0-.11-.06-.22-.09-.33a4.17 4.17 0 0 0-.18-.57c-.05-.12-.12-.24-.18-.37s-.15-.3-.24-.44S21 9.08 21 9s-.2-.25-.31-.37-.21-.2-.32-.3L20 8l-.36-.24a3.68 3.68 0 0 0-.44-.23l-.39-.18a4.13 4.13 0 0 0-.5-.15 3 3 0 0 0-.41-.09h-.18A6 6 0 0 0 6.33 7h-.18a3 3 0 0 0-.41.09 4.13 4.13 0 0 0-.5.15l-.39.18a3.68 3.68 0 0 0-.44.23L4.05 8l-.37.31c-.11.1-.22.19-.32.3s-.21.25-.31.37-.18.23-.26.36-.16.29-.24.44-.13.25-.18.37a4.17 4.17 0 0 0-.18.57c0 .11-.07.22-.09.33A5.23 5.23 0 0 0 2 12a5.5 5.5 0 0 0 .09.91c0 .1.05.19.07.29a5.58 5.58 0 0 0 .18.58l.12.29a5 5 0 0 0 .3.56l.14.22a.56.56 0 0 0 .05.08L3 15a5 5 0 0 0 4 2 2 2 0 0 1 .59-1.41A2 2 0 0 1 9 15a1.92 1.92 0 0 1 1 .27V12a2 2 0 0 1 4 0v3.37a2 2 0 0 1 1-.27 2.05 2.05 0 0 1 1.44.61A2 2 0 0 1 17 17a5 5 0 0 0 4-2l.05-.05a.56.56 0 0 0 .05-.08l.14-.22a5 5 0 0 0 .3-.56l.12-.29a5.58 5.58 0 0 0 .18-.58c0-.1.05-.19.07-.29A5.5 5.5 0 0 0 22 12a5.23 5.23 0 0 0-.1-1z"/><path d="M14.31 16.38L13 17.64V12a1 1 0 0 0-2 0v5.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 21a1 1 0 0 0 .69-.28l3-2.9a1 1 0 1 0-1.38-1.44z"/><rect width="24" height="24" opacity="0"/><path d="M21.9 11c0-.11-.06-.22-.09-.33a4.17 4.17 0 0 0-.18-.57c-.05-.12-.12-.24-.18-.37s-.15-.3-.24-.44S21 9.08 21 9s-.2-.25-.31-.37-.21-.2-.32-.3L20 8l-.36-.24a3.68 3.68 0 0 0-.44-.23l-.39-.18a4.13 4.13 0 0 0-.5-.15 3 3 0 0 0-.41-.09h-.18A6 6 0 0 0 6.33 7h-.18a3 3 0 0 0-.41.09 4.13 4.13 0 0 0-.5.15l-.39.18a3.68 3.68 0 0 0-.44.23L4.05 8l-.37.31c-.11.1-.22.19-.32.3s-.21.25-.31.37-.18.23-.26.36-.16.29-.24.44-.13.25-.18.37a4.17 4.17 0 0 0-.18.57c0 .11-.07.22-.09.33A5.23 5.23 0 0 0 2 12a5.5 5.5 0 0 0 .09.91c0 .1.05.19.07.29a5.58 5.58 0 0 0 .18.58l.12.29a5 5 0 0 0 .3.56l.14.22a.56.56 0 0 0 .05.08L3 15a5 5 0 0 0 4 2 2 2 0 0 1 .59-1.41A2 2 0 0 1 9 15a1.92 1.92 0 0 1 1 .27V12a2 2 0 0 1 4 0v3.37a2 2 0 0 1 1-.27 2.05 2.05 0 0 1 1.44.61A2 2 0 0 1 17 17a5 5 0 0 0 4-2l.05-.05a.56.56 0 0 0 .05-.08l.14-.22a5 5 0 0 0 .3-.56l.12-.29a5.58 5.58 0 0 0 .18-.58c0-.1.05-.19.07-.29A5.5 5.5 0 0 0 22 12a5.23 5.23 0 0 0-.1-1z"/><path d="M14.31 16.38L13 17.64V12a1 1 0 0 0-2 0v5.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 21a1 1 0 0 0 .69-.28l3-2.9a1 1 0 1 0-1.38-1.44z"/></g></g>',
                        "cloud-upload": '<g data-name="Layer 2"><g data-name="cloud-upload"><rect width="24" height="24" opacity="0"/><path d="M21.9 12c0-.11-.06-.22-.09-.33a4.17 4.17 0 0 0-.18-.57c-.05-.12-.12-.24-.18-.37s-.15-.3-.24-.44S21 10.08 21 10s-.2-.25-.31-.37-.21-.2-.32-.3L20 9l-.36-.24a3.68 3.68 0 0 0-.44-.23l-.39-.18a4.13 4.13 0 0 0-.5-.15 3 3 0 0 0-.41-.09L17.67 8A6 6 0 0 0 6.33 8l-.18.05a3 3 0 0 0-.41.09 4.13 4.13 0 0 0-.5.15l-.39.18a3.68 3.68 0 0 0-.44.23l-.36.3-.37.31c-.11.1-.22.19-.32.3s-.21.25-.31.37-.18.23-.26.36-.16.29-.24.44-.13.25-.18.37a4.17 4.17 0 0 0-.18.57c0 .11-.07.22-.09.33A5.23 5.23 0 0 0 2 13a5.5 5.5 0 0 0 .09.91c0 .1.05.19.07.29a5.58 5.58 0 0 0 .18.58l.12.29a5 5 0 0 0 .3.56l.14.22a.56.56 0 0 0 .05.08L3 16a5 5 0 0 0 4 2h3v-1.37a2 2 0 0 1-1 .27 2.05 2.05 0 0 1-1.44-.61 2 2 0 0 1 .05-2.83l3-2.9A2 2 0 0 1 12 10a2 2 0 0 1 1.41.59l3 3a2 2 0 0 1 0 2.82A2 2 0 0 1 15 17a1.92 1.92 0 0 1-1-.27V18h3a5 5 0 0 0 4-2l.05-.05a.56.56 0 0 0 .05-.08l.14-.22a5 5 0 0 0 .3-.56l.12-.29a5.58 5.58 0 0 0 .18-.58c0-.1.05-.19.07-.29A5.5 5.5 0 0 0 22 13a5.23 5.23 0 0 0-.1-1z"/><path d="M12.71 11.29a1 1 0 0 0-1.4 0l-3 2.9a1 1 0 1 0 1.38 1.44L11 14.36V20a1 1 0 0 0 2 0v-5.59l1.29 1.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        "code-download": '<g data-name="Layer 2"><g data-name="code-download"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M4.29 12l4.48-5.36a1 1 0 1 0-1.54-1.28l-5 6a1 1 0 0 0 0 1.27l4.83 6a1 1 0 0 0 .78.37 1 1 0 0 0 .78-1.63z"/><path d="M21.78 11.37l-4.78-6a1 1 0 0 0-1.56 1.26L19.71 12l-4.48 5.37a1 1 0 0 0 .13 1.41A1 1 0 0 0 16 19a1 1 0 0 0 .77-.36l5-6a1 1 0 0 0 .01-1.27z"/><path d="M15.72 11.41a1 1 0 0 0-1.41 0L13 12.64V8a1 1 0 0 0-2 0v4.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 16a1 1 0 0 0 .69-.28l3-2.9a1 1 0 0 0 .03-1.41z"/></g></g>',
                        code: '<g data-name="Layer 2"><g data-name="code"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M8.64 5.23a1 1 0 0 0-1.41.13l-5 6a1 1 0 0 0 0 1.27l4.83 6a1 1 0 0 0 .78.37 1 1 0 0 0 .78-1.63L4.29 12l4.48-5.36a1 1 0 0 0-.13-1.41z"/><path d="M21.78 11.37l-4.78-6a1 1 0 0 0-1.41-.15 1 1 0 0 0-.15 1.41L19.71 12l-4.48 5.37a1 1 0 0 0 .13 1.41A1 1 0 0 0 16 19a1 1 0 0 0 .77-.36l5-6a1 1 0 0 0 .01-1.27z"/></g></g>',
                        collapse: '<g data-name="Layer 2"><g data-name="collapse"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M19 9h-2.58l3.29-3.29a1 1 0 1 0-1.42-1.42L15 7.57V5a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h5a1 1 0 0 0 0-2z"/><path d="M10 13H5a1 1 0 0 0 0 2h2.57l-3.28 3.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L9 16.42V19a1 1 0 0 0 1 1 1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1z"/></g></g>',
                        "color-palette": '<g data-name="Layer 2"><g data-name="color-palette"><rect width="24" height="24" opacity="0"/><path d="M19.54 5.08A10.61 10.61 0 0 0 11.91 2a10 10 0 0 0-.05 20 2.58 2.58 0 0 0 2.53-1.89 2.52 2.52 0 0 0-.57-2.28.5.5 0 0 1 .37-.83h1.65A6.15 6.15 0 0 0 22 11.33a8.48 8.48 0 0 0-2.46-6.25zm-12.7 9.66a1.5 1.5 0 1 1 .4-2.08 1.49 1.49 0 0 1-.4 2.08zM8.3 9.25a1.5 1.5 0 1 1-.55-2 1.5 1.5 0 0 1 .55 2zM11 7a1.5 1.5 0 1 1 1.5-1.5A1.5 1.5 0 0 1 11 7zm5.75.8a1.5 1.5 0 1 1 .55-2 1.5 1.5 0 0 1-.55 2z"/></g></g>',
                        "color-picker": '<g data-name="Layer 2"><g data-name="color-picker"><rect width="24" height="24" opacity="0"/><path d="M19.4 7.34L16.66 4.6A1.92 1.92 0 0 0 14 4.53l-2 2-1.29-1.24a1 1 0 0 0-1.42 1.42L10.53 8 5 13.53a2 2 0 0 0-.57 1.21L4 18.91a1 1 0 0 0 .29.8A1 1 0 0 0 5 20h.09l4.17-.38a2 2 0 0 0 1.21-.57l5.58-5.58 1.24 1.24a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42l-1.24-1.24 2-2a1.92 1.92 0 0 0-.07-2.71zm-13 7.6L12 9.36l2.69 2.7-2.79 2.79"/></g></g>',
                        compass: '<g data-name="Layer 2"><g data-name="compass"><rect width="24" height="24" opacity="0"/><polygon points="10.8 13.21 12.49 12.53 13.2 10.79 11.51 11.47 10.8 13.21"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm3.93 7.42l-1.75 4.26a1 1 0 0 1-.55.55l-4.21 1.7A1 1 0 0 1 9 16a1 1 0 0 1-.71-.31h-.05a1 1 0 0 1-.18-1l1.75-4.26a1 1 0 0 1 .55-.55l4.21-1.7a1 1 0 0 1 1.1.25 1 1 0 0 1 .26.99z"/></g></g>',
                        copy: '<g data-name="Layer 2"><g data-name="copy"><rect width="24" height="24" opacity="0"/><path d="M18 9h-3V5.67A2.68 2.68 0 0 0 12.33 3H5.67A2.68 2.68 0 0 0 3 5.67v6.66A2.68 2.68 0 0 0 5.67 15H9v3a3 3 0 0 0 3 3h6a3 3 0 0 0 3-3v-6a3 3 0 0 0-3-3zm-9 3v1H5.67a.67.67 0 0 1-.67-.67V5.67A.67.67 0 0 1 5.67 5h6.66a.67.67 0 0 1 .67.67V9h-1a3 3 0 0 0-3 3z"/></g></g>',
                        "corner-down-left": '<g data-name="Layer 2"><g data-name="corner-down-left"><rect x=".05" y=".05" width="24" height="24" transform="rotate(-89.76 12.05 12.05)" opacity="0"/><path d="M20 6a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 1-.29.71A1 1 0 0 1 17 12H8.08l2.69-3.39a1 1 0 0 0-1.52-1.17l-4 5a1 1 0 0 0 0 1.25l4 5a1 1 0 0 0 .78.37 1 1 0 0 0 .62-.22 1 1 0 0 0 .15-1.41l-2.66-3.36h8.92a3 3 0 0 0 3-3z"/></g></g>',
                        "corner-down-right": '<g data-name="Layer 2"><g data-name="corner-down-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M19.78 12.38l-4-5a1 1 0 0 0-1.56 1.24l2.7 3.38H8a1 1 0 0 1-1-1V6a1 1 0 0 0-2 0v5a3 3 0 0 0 3 3h8.92l-2.7 3.38a1 1 0 0 0 .16 1.4A1 1 0 0 0 15 19a1 1 0 0 0 .78-.38l4-5a1 1 0 0 0 0-1.24z"/></g></g>',
                        "corner-left-down": '<g data-name="Layer 2"><g data-name="corner-left-down"><rect width="24" height="24" opacity="0"/><path d="M18 5h-5a3 3 0 0 0-3 3v8.92l-3.38-2.7a1 1 0 0 0-1.24 1.56l5 4a1 1 0 0 0 1.24 0l5-4a1 1 0 1 0-1.24-1.56L12 16.92V8a1 1 0 0 1 1-1h5a1 1 0 0 0 0-2z"/></g></g>',
                        "corner-left-up": '<g data-name="Layer 2"><g data-name="corner-left-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 17h-5a1 1 0 0 1-1-1V7.08l3.38 2.7A1 1 0 0 0 16 10a1 1 0 0 0 .78-.38 1 1 0 0 0-.16-1.4l-5-4a1 1 0 0 0-1.24 0l-5 4a1 1 0 0 0 1.24 1.56L10 7.08V16a3 3 0 0 0 3 3h5a1 1 0 0 0 0-2z"/></g></g>',
                        "corner-right-down": '<g data-name="Layer 2"><g data-name="corner-right-down"><rect width="24" height="24" opacity="0"/><path d="M18.78 14.38a1 1 0 0 0-1.4-.16L14 16.92V8a3 3 0 0 0-3-3H6a1 1 0 0 0 0 2h5a1 1 0 0 1 1 1v8.92l-3.38-2.7a1 1 0 0 0-1.24 1.56l5 4a1 1 0 0 0 1.24 0l5-4a1 1 0 0 0 .16-1.4z"/></g></g>',
                        "corner-right-up": '<g data-name="Layer 2"><g data-name="corner-right-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18.62 8.22l-5-4a1 1 0 0 0-1.24 0l-5 4a1 1 0 0 0 1.24 1.56L12 7.08V16a1 1 0 0 1-1 1H6a1 1 0 0 0 0 2h5a3 3 0 0 0 3-3V7.08l3.38 2.7A1 1 0 0 0 18 10a1 1 0 0 0 .78-.38 1 1 0 0 0-.16-1.4z"/></g></g>',
                        "corner-up-left": '<g data-name="Layer 2"><g data-name="corner-up-left"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M16 10H7.08l2.7-3.38a1 1 0 1 0-1.56-1.24l-4 5a1 1 0 0 0 0 1.24l4 5A1 1 0 0 0 9 17a1 1 0 0 0 .62-.22 1 1 0 0 0 .16-1.4L7.08 12H16a1 1 0 0 1 1 1v5a1 1 0 0 0 2 0v-5a3 3 0 0 0-3-3z"/></g></g>',
                        "corner-up-right": '<g data-name="Layer 2"><g data-name="corner-up-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M19.78 10.38l-4-5a1 1 0 0 0-1.56 1.24l2.7 3.38H8a3 3 0 0 0-3 3v5a1 1 0 0 0 2 0v-5a1 1 0 0 1 1-1h8.92l-2.7 3.38a1 1 0 0 0 .16 1.4A1 1 0 0 0 15 17a1 1 0 0 0 .78-.38l4-5a1 1 0 0 0 0-1.24z"/></g></g>',
                        "credit-card": '<g data-name="Layer 2"><g data-name="credit-card"><rect width="24" height="24" opacity="0"/><path d="M19 5H5a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V8a3 3 0 0 0-3-3zm-8 10H7a1 1 0 0 1 0-2h4a1 1 0 0 1 0 2zm6 0h-2a1 1 0 0 1 0-2h2a1 1 0 0 1 0 2zm3-6H4V8a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1z"/></g></g>',
                        crop: '<g data-name="Layer 2"><g data-name="crop"><rect width="24" height="24" opacity="0"/><path d="M21 16h-3V8.56A2.56 2.56 0 0 0 15.44 6H8V3a1 1 0 0 0-2 0v3H3a1 1 0 0 0 0 2h3v7.44A2.56 2.56 0 0 0 8.56 18H16v3a1 1 0 0 0 2 0v-3h3a1 1 0 0 0 0-2zM8.56 16a.56.56 0 0 1-.56-.56V8h7.44a.56.56 0 0 1 .56.56V16z"/></g></g>',
                        cube: '<g data-name="Layer 2"><g data-name="cube"><rect width="24" height="24" opacity="0"/><path d="M11.25 11.83L3 8.36v7.73a1.69 1.69 0 0 0 1 1.52L11.19 21h.06z"/><path d="M12 10.5l8.51-3.57a1.62 1.62 0 0 0-.51-.38l-7.2-3.37a1.87 1.87 0 0 0-1.6 0L4 6.55a1.62 1.62 0 0 0-.51.38z"/><path d="M12.75 11.83V21h.05l7.2-3.39a1.69 1.69 0 0 0 1-1.51V8.36z"/></g></g>',
                        "diagonal-arrow-left-down": '<g data-name="Layer 2"><g data-name="diagonal-arrow-left-down"><rect width="24" height="24" opacity="0"/><path d="M17.71 6.29a1 1 0 0 0-1.42 0L8 14.59V9a1 1 0 0 0-2 0v8a1 1 0 0 0 1 1h8a1 1 0 0 0 0-2H9.41l8.3-8.29a1 1 0 0 0 0-1.42z"/></g></g>',
                        "diagonal-arrow-left-up": '<g data-name="Layer 2"><g data-name="diagonal-arrow-left-up"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M17.71 16.29L9.42 8H15a1 1 0 0 0 0-2H7.05a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1H7a1 1 0 0 0 1-1V9.45l8.26 8.26a1 1 0 0 0 1.42 0 1 1 0 0 0 .03-1.42z"/></g></g>',
                        "diagonal-arrow-right-down": '<g data-name="Layer 2"><g data-name="diagonal-arrow-right-down"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M17 8a1 1 0 0 0-1 1v5.59l-8.29-8.3a1 1 0 0 0-1.42 1.42l8.3 8.29H9a1 1 0 0 0 0 2h8a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1z"/></g></g>',
                        "diagonal-arrow-right-up": '<g data-name="Layer 2"><g data-name="diagonal-arrow-right-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 7.05a1 1 0 0 0-1-1L9 6a1 1 0 0 0 0 2h5.56l-8.27 8.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L16 9.42V15a1 1 0 0 0 1 1 1 1 0 0 0 1-1z"/></g></g>',
                        "done-all": '<g data-name="Layer 2"><g data-name="done-all"><rect width="24" height="24" opacity="0"/><path d="M16.62 6.21a1 1 0 0 0-1.41.17l-7 9-3.43-4.18a1 1 0 1 0-1.56 1.25l4.17 5.18a1 1 0 0 0 .78.37 1 1 0 0 0 .83-.38l7.83-10a1 1 0 0 0-.21-1.41z"/><path d="M21.62 6.21a1 1 0 0 0-1.41.17l-7 9-.61-.75-1.26 1.62 1.1 1.37a1 1 0 0 0 .78.37 1 1 0 0 0 .78-.38l7.83-10a1 1 0 0 0-.21-1.4z"/><path d="M8.71 13.06L10 11.44l-.2-.24a1 1 0 0 0-1.43-.2 1 1 0 0 0-.15 1.41z"/></g></g>',
                        download: '<g data-name="Layer 2"><g data-name="download"><rect width="24" height="24" opacity="0"/><rect x="4" y="18" width="16" height="2" rx="1" ry="1"/><rect x="3" y="17" width="4" height="2" rx="1" ry="1" transform="rotate(-90 5 18)"/><rect x="17" y="17" width="4" height="2" rx="1" ry="1" transform="rotate(-90 19 18)"/><path d="M12 15a1 1 0 0 1-.58-.18l-4-2.82a1 1 0 0 1-.24-1.39 1 1 0 0 1 1.4-.24L12 12.76l3.4-2.56a1 1 0 0 1 1.2 1.6l-4 3a1 1 0 0 1-.6.2z"/><path d="M12 13a1 1 0 0 1-1-1V4a1 1 0 0 1 2 0v8a1 1 0 0 1-1 1z"/></g></g>',
                        "droplet-off": '<g data-name="Layer 2"><g data-name="droplet-off"><rect width="24" height="24" opacity="0"/><path d="M19 16.14A7.73 7.73 0 0 0 17.34 8l-4.56-4.69a1 1 0 0 0-.71-.31 1 1 0 0 0-.72.3L8.74 5.92z"/><path d="M6 8.82a7.73 7.73 0 0 0 .64 9.9A7.44 7.44 0 0 0 11.92 21a7.34 7.34 0 0 0 4.64-1.6z"/><path d="M20.71 19.29l-16-16a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        droplet: '<g data-name="Layer 2"><g data-name="droplet"><rect x=".1" y=".1" width="24" height="24" transform="rotate(.48 11.987 11.887)" opacity="0"/><path d="M12 21.1a7.4 7.4 0 0 1-5.28-2.28 7.73 7.73 0 0 1 .1-10.77l4.64-4.65a.94.94 0 0 1 .71-.3 1 1 0 0 1 .71.31l4.56 4.72a7.73 7.73 0 0 1-.09 10.77A7.33 7.33 0 0 1 12 21.1z"/></g></g>',
                        "edit-2": '<g data-name="Layer 2"><g data-name="edit-2"><rect width="24" height="24" opacity="0"/><path d="M19 20H5a1 1 0 0 0 0 2h14a1 1 0 0 0 0-2z"/><path d="M5 18h.09l4.17-.38a2 2 0 0 0 1.21-.57l9-9a1.92 1.92 0 0 0-.07-2.71L16.66 2.6A2 2 0 0 0 14 2.53l-9 9a2 2 0 0 0-.57 1.21L4 16.91a1 1 0 0 0 .29.8A1 1 0 0 0 5 18zM15.27 4L18 6.73l-2 1.95L13.32 6z"/></g></g>',
                        edit: '<g data-name="Layer 2"><g data-name="edit"><rect width="24" height="24" opacity="0"/><path d="M19.4 7.34L16.66 4.6A2 2 0 0 0 14 4.53l-9 9a2 2 0 0 0-.57 1.21L4 18.91a1 1 0 0 0 .29.8A1 1 0 0 0 5 20h.09l4.17-.38a2 2 0 0 0 1.21-.57l9-9a1.92 1.92 0 0 0-.07-2.71zM16 10.68L13.32 8l1.95-2L18 8.73z"/></g></g>',
                        email: '<g data-name="Layer 2"><g data-name="email"><rect width="24" height="24" opacity="0"/><path d="M19 4H5a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3zm0 2l-6.5 4.47a1 1 0 0 1-1 0L5 6z"/></g></g>',
                        expand: '<g data-name="Layer 2"><g data-name="expand"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20 5a1 1 0 0 0-1-1h-5a1 1 0 0 0 0 2h2.57l-3.28 3.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L18 7.42V10a1 1 0 0 0 1 1 1 1 0 0 0 1-1z"/><path d="M10.71 13.29a1 1 0 0 0-1.42 0L6 16.57V14a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h5a1 1 0 0 0 0-2H7.42l3.29-3.29a1 1 0 0 0 0-1.42z"/></g></g>',
                        "external-link": '<g data-name="Layer 2"><g data-name="external-link"><rect width="24" height="24" opacity="0"/><path d="M20 11a1 1 0 0 0-1 1v6a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h6a1 1 0 0 0 0-2H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-6a1 1 0 0 0-1-1z"/><path d="M16 5h1.58l-6.29 6.28a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L19 6.42V8a1 1 0 0 0 1 1 1 1 0 0 0 1-1V4a1 1 0 0 0-1-1h-4a1 1 0 0 0 0 2z"/></g></g>',
                        "eye-off-2": '<g data-name="Layer 2"><g data-name="eye-off-2"><rect width="24" height="24" opacity="0"/><path d="M17.81 13.39A8.93 8.93 0 0 0 21 7.62a1 1 0 1 0-2-.24 7.07 7.07 0 0 1-14 0 1 1 0 1 0-2 .24 8.93 8.93 0 0 0 3.18 5.77l-2.3 2.32a1 1 0 0 0 1.41 1.41l2.61-2.6a9.06 9.06 0 0 0 3.1.92V19a1 1 0 0 0 2 0v-3.56a9.06 9.06 0 0 0 3.1-.92l2.61 2.6a1 1 0 0 0 1.41-1.41z"/></g></g>',
                        "eye-off": '<g data-name="Layer 2"><g data-name="eye-off"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="12" r="1.5"/><path d="M15.29 18.12L14 16.78l-.07-.07-1.27-1.27a4.07 4.07 0 0 1-.61.06A3.5 3.5 0 0 1 8.5 12a4.07 4.07 0 0 1 .06-.61l-2-2L5 7.87a15.89 15.89 0 0 0-2.87 3.63 1 1 0 0 0 0 1c.63 1.09 4 6.5 9.89 6.5h.25a9.48 9.48 0 0 0 3.23-.67z"/><path d="M8.59 5.76l2.8 2.8A4.07 4.07 0 0 1 12 8.5a3.5 3.5 0 0 1 3.5 3.5 4.07 4.07 0 0 1-.06.61l2.68 2.68.84.84a15.89 15.89 0 0 0 2.91-3.63 1 1 0 0 0 0-1c-.64-1.11-4.16-6.68-10.14-6.5a9.48 9.48 0 0 0-3.23.67z"/><path d="M20.71 19.29L19.41 18l-2-2-9.52-9.53L6.42 5 4.71 3.29a1 1 0 0 0-1.42 1.42L5.53 7l1.75 1.7 7.31 7.3.07.07L16 17.41l.59.59 2.7 2.71a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        eye: '<g data-name="Layer 2"><g data-name="eye"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="12" r="1.5"/><path d="M21.87 11.5c-.64-1.11-4.16-6.68-10.14-6.5-5.53.14-8.73 5-9.6 6.5a1 1 0 0 0 0 1c.63 1.09 4 6.5 9.89 6.5h.25c5.53-.14 8.74-5 9.6-6.5a1 1 0 0 0 0-1zm-9.87 4a3.5 3.5 0 1 1 3.5-3.5 3.5 3.5 0 0 1-3.5 3.5z"/></g></g>',
                        facebook: '<g data-name="Layer 2"><g data-name="facebook"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M17 3.5a.5.5 0 0 0-.5-.5H14a4.77 4.77 0 0 0-5 4.5v2.7H6.5a.5.5 0 0 0-.5.5v2.6a.5.5 0 0 0 .5.5H9v6.7a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-6.7h2.62a.5.5 0 0 0 .49-.37l.72-2.6a.5.5 0 0 0-.48-.63H13V7.5a1 1 0 0 1 1-.9h2.5a.5.5 0 0 0 .5-.5z"/></g></g>',
                        "file-add": '<g data-name="Layer 2"><g data-name="file-add"><rect width="24" height="24" opacity="0"/><path d="M19.74 7.33l-4.44-5a1 1 0 0 0-.74-.33h-8A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V8a1 1 0 0 0-.26-.67zM14 15h-1v1a1 1 0 0 1-2 0v-1h-1a1 1 0 0 1 0-2h1v-1a1 1 0 0 1 2 0v1h1a1 1 0 0 1 0 2zm.71-7a.79.79 0 0 1-.71-.85V4l3.74 4z"/></g></g>',
                        "file-remove": '<g data-name="Layer 2"><g data-name="file-remove"><rect width="24" height="24" opacity="0"/><path d="M19.74 7.33l-4.44-5a1 1 0 0 0-.74-.33h-8A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V8a1 1 0 0 0-.26-.67zM14 15h-4a1 1 0 0 1 0-2h4a1 1 0 0 1 0 2zm.71-7a.79.79 0 0 1-.71-.85V4l3.74 4z"/></g></g>',
                        "file-text": '<g data-name="Layer 2"><g data-name="file-text"><rect width="24" height="24" opacity="0"/><path d="M19.74 7.33l-4.44-5a1 1 0 0 0-.74-.33h-8A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V8a1 1 0 0 0-.26-.67zM9 12h3a1 1 0 0 1 0 2H9a1 1 0 0 1 0-2zm6 6H9a1 1 0 0 1 0-2h6a1 1 0 0 1 0 2zm-.29-10a.79.79 0 0 1-.71-.85V4l3.74 4z"/></g></g>',
                        file: '<g data-name="Layer 2"><g data-name="file"><rect width="24" height="24" opacity="0"/><path d="M19.74 7.33l-4.44-5a1 1 0 0 0-.74-.33h-8A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V8a1 1 0 0 0-.26-.67zM14 4l3.74 4h-3a.79.79 0 0 1-.74-.85z"/></g></g>',
                        film: '<g data-name="Layer 2"><g data-name="film"><rect width="24" height="24" opacity="0"/><path d="M18.26 3H5.74A2.74 2.74 0 0 0 3 5.74v12.52A2.74 2.74 0 0 0 5.74 21h12.52A2.74 2.74 0 0 0 21 18.26V5.74A2.74 2.74 0 0 0 18.26 3zM7 11H5V9h2zm-2 2h2v2H5zm14-2h-2V9h2zm-2 2h2v2h-2zm2-7.26V7h-2V5h1.26a.74.74 0 0 1 .74.74zM5.74 5H7v2H5V5.74A.74.74 0 0 1 5.74 5zM5 18.26V17h2v2H5.74a.74.74 0 0 1-.74-.74zm14 0a.74.74 0 0 1-.74.74H17v-2h2z"/></g></g>',
                        flag: '<g data-name="Layer 2"><g data-name="flag"><polyline points="24 24 0 24 0 0" opacity="0"/><path d="M19.27 4.68a1.79 1.79 0 0 0-1.6-.25 7.53 7.53 0 0 1-2.17.28 8.54 8.54 0 0 1-3.13-.78A10.15 10.15 0 0 0 8.5 3c-2.89 0-4 1-4.2 1.14a1 1 0 0 0-.3.72V20a1 1 0 0 0 2 0v-4.3a6.28 6.28 0 0 1 2.5-.41 8.54 8.54 0 0 1 3.13.78 10.15 10.15 0 0 0 3.87.93 7.66 7.66 0 0 0 3.5-.7 1.74 1.74 0 0 0 1-1.55V6.11a1.77 1.77 0 0 0-.73-1.43z"/></g></g>',
                        "flash-off": '<g data-name="Layer 2"><g data-name="flash-off"><rect width="24" height="24" opacity="0"/><path d="M17.33 14.5l2.5-3.74A1 1 0 0 0 19 9.2h-5.89l.77-7.09a1 1 0 0 0-.65-1 1 1 0 0 0-1.17.38L8.94 6.11z"/><path d="M6.67 9.5l-2.5 3.74A1 1 0 0 0 5 14.8h5.89l-.77 7.09a1 1 0 0 0 .65 1.05 1 1 0 0 0 .34.06 1 1 0 0 0 .83-.44l3.12-4.67z"/><path d="M20.71 19.29l-16-16a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        flash: '<g data-name="Layer 2"><g data-name="flash"><rect width="24" height="24" opacity="0"/><path d="M11.11 23a1 1 0 0 1-.34-.06 1 1 0 0 1-.65-1.05l.77-7.09H5a1 1 0 0 1-.83-1.56l7.89-11.8a1 1 0 0 1 1.17-.38 1 1 0 0 1 .65 1l-.77 7.14H19a1 1 0 0 1 .83 1.56l-7.89 11.8a1 1 0 0 1-.83.44z"/></g></g>',
                        "flip-2": '<g data-name="Layer 2"><g data-name="flip-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M6.09 19h12l-1.3 1.29a1 1 0 0 0 1.42 1.42l3-3a1 1 0 0 0 0-1.42l-3-3a1 1 0 0 0-1.42 0 1 1 0 0 0 0 1.42l1.3 1.29h-12a1.56 1.56 0 0 1-1.59-1.53V13a1 1 0 0 0-2 0v2.47A3.56 3.56 0 0 0 6.09 19z"/><path d="M5.79 9.71a1 1 0 1 0 1.42-1.42L5.91 7h12a1.56 1.56 0 0 1 1.59 1.53V11a1 1 0 0 0 2 0V8.53A3.56 3.56 0 0 0 17.91 5h-12l1.3-1.29a1 1 0 0 0 0-1.42 1 1 0 0 0-1.42 0l-3 3a1 1 0 0 0 0 1.42z"/></g></g>',
                        flip: '<g data-name="Layer 2"><g data-name="flip-in"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M5 6.09v12l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3a1 1 0 0 0 1.42 0l3-3a1 1 0 0 0 0-1.42 1 1 0 0 0-1.42 0L7 18.09v-12A1.56 1.56 0 0 1 8.53 4.5H11a1 1 0 0 0 0-2H8.53A3.56 3.56 0 0 0 5 6.09z"/><path d="M14.29 5.79a1 1 0 0 0 1.42 1.42L17 5.91v12a1.56 1.56 0 0 1-1.53 1.59H13a1 1 0 0 0 0 2h2.47A3.56 3.56 0 0 0 19 17.91v-12l1.29 1.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42l-3-3a1 1 0 0 0-1.42 0z"/></g></g>',
                        "folder-add": '<g data-name="Layer 2"><g data-name="folder-add"><rect width="24" height="24" opacity="0"/><path d="M19.5 7.05h-7L9.87 3.87a1 1 0 0 0-.77-.37H4.5A2.47 2.47 0 0 0 2 5.93v12.14a2.47 2.47 0 0 0 2.5 2.43h15a2.47 2.47 0 0 0 2.5-2.43V9.48a2.47 2.47 0 0 0-2.5-2.43zM14 15h-1v1a1 1 0 0 1-2 0v-1h-1a1 1 0 0 1 0-2h1v-1a1 1 0 0 1 2 0v1h1a1 1 0 0 1 0 2z"/></g></g>',
                        "folder-remove": '<g data-name="Layer 2"><g data-name="folder-remove"><rect width="24" height="24" opacity="0"/><path d="M19.5 7.05h-7L9.87 3.87a1 1 0 0 0-.77-.37H4.5A2.47 2.47 0 0 0 2 5.93v12.14a2.47 2.47 0 0 0 2.5 2.43h15a2.47 2.47 0 0 0 2.5-2.43V9.48a2.47 2.47 0 0 0-2.5-2.43zM14 15h-4a1 1 0 0 1 0-2h4a1 1 0 0 1 0 2z"/></g></g>',
                        folder: '<g data-name="Layer 2"><g data-name="folder"><rect width="24" height="24" opacity="0"/><path d="M19.5 20.5h-15A2.47 2.47 0 0 1 2 18.07V5.93A2.47 2.47 0 0 1 4.5 3.5h4.6a1 1 0 0 1 .77.37l2.6 3.18h7A2.47 2.47 0 0 1 22 9.48v8.59a2.47 2.47 0 0 1-2.5 2.43z"/></g></g>',
                        funnel: '<g data-name="Layer 2"><g data-name="funnel"><rect width="24" height="24" opacity="0"/><path d="M13.9 22a1 1 0 0 1-.6-.2l-4-3.05a1 1 0 0 1-.39-.8v-3.27l-4.8-9.22A1 1 0 0 1 5 4h14a1 1 0 0 1 .86.49 1 1 0 0 1 0 1l-5 9.21V21a1 1 0 0 1-.55.9 1 1 0 0 1-.41.1z"/></g></g>',
                        gift: '<g data-name="Layer 2"><g data-name="gift"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M4.64 15.27v4.82a.92.92 0 0 0 .92.91h5.62v-5.73z"/><path d="M12.82 21h5.62a.92.92 0 0 0 .92-.91v-4.82h-6.54z"/><path d="M20.1 7.09h-1.84a2.82 2.82 0 0 0 .29-1.23A2.87 2.87 0 0 0 15.68 3 4.21 4.21 0 0 0 12 5.57 4.21 4.21 0 0 0 8.32 3a2.87 2.87 0 0 0-2.87 2.86 2.82 2.82 0 0 0 .29 1.23H3.9c-.5 0-.9.59-.9 1.31v3.93c0 .72.4 1.31.9 1.31h7.28V7.09h1.64v6.55h7.28c.5 0 .9-.59.9-1.31V8.4c0-.72-.4-1.31-.9-1.31zm-11.78 0a1.23 1.23 0 1 1 0-2.45c1.4 0 2.19 1.44 2.58 2.45zm7.36 0H13.1c.39-1 1.18-2.45 2.58-2.45a1.23 1.23 0 1 1 0 2.45z"/></g></g>',
                        github: '<g data-name="Layer 2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 1A10.89 10.89 0 0 0 1 11.77 10.79 10.79 0 0 0 8.52 22c.55.1.75-.23.75-.52v-1.83c-3.06.65-3.71-1.44-3.71-1.44a2.86 2.86 0 0 0-1.22-1.58c-1-.66.08-.65.08-.65a2.31 2.31 0 0 1 1.68 1.11 2.37 2.37 0 0 0 3.2.89 2.33 2.33 0 0 1 .7-1.44c-2.44-.27-5-1.19-5-5.32a4.15 4.15 0 0 1 1.11-2.91 3.78 3.78 0 0 1 .11-2.84s.93-.29 3 1.1a10.68 10.68 0 0 1 5.5 0c2.1-1.39 3-1.1 3-1.1a3.78 3.78 0 0 1 .11 2.84A4.15 4.15 0 0 1 19 11.2c0 4.14-2.58 5.05-5 5.32a2.5 2.5 0 0 1 .75 2v2.95c0 .35.2.63.75.52A10.8 10.8 0 0 0 23 11.77 10.89 10.89 0 0 0 12 1" data-name="github"/></g>',
                        "globe-2": '<g data-name="Layer 2"><g data-name="globe-2"><rect width="24" height="24" opacity="0"/><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 2a8.19 8.19 0 0 1 1.79.21 2.61 2.61 0 0 1-.78 1c-.22.17-.46.31-.7.46a4.56 4.56 0 0 0-1.85 1.67 6.49 6.49 0 0 0-.62 3.3c0 1.36 0 2.16-.95 2.87-1.37 1.07-3.46.47-4.76-.07A8.33 8.33 0 0 1 4 12a8 8 0 0 1 8-8zm4.89 14.32a6.79 6.79 0 0 0-.63-1.14c-.11-.16-.22-.32-.32-.49-.39-.68-.25-1 .38-2l.1-.17a4.77 4.77 0 0 0 .58-2.43 5.42 5.42 0 0 1 .09-1c.16-.73 1.71-.93 2.67-1a7.94 7.94 0 0 1-2.86 8.28z"/></g></g>',
                        "globe-3": '<g data-name="Layer 2"><g data-name="globe-3"><rect width="24" height="24" opacity="0"/><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zM5 15.8a8.42 8.42 0 0 0 2 .27 5 5 0 0 0 3.14-1c1.71-1.34 1.71-3.06 1.71-4.44a4.76 4.76 0 0 1 .37-2.34 2.86 2.86 0 0 1 1.12-.91 9.75 9.75 0 0 0 .92-.61 4.55 4.55 0 0 0 1.4-1.87A8 8 0 0 1 19 8.12c-1.43.2-3.46.67-3.86 2.53A7 7 0 0 0 15 12a2.93 2.93 0 0 1-.29 1.47l-.1.17c-.65 1.08-1.38 2.31-.39 4 .12.21.25.41.38.61a2.29 2.29 0 0 1 .52 1.08A7.89 7.89 0 0 1 12 20a8 8 0 0 1-7-4.2z"/></g></g>',
                        globe: '<g data-name="Layer 2"><g data-name="globe"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M22 12A10 10 0 0 0 12 2a10 10 0 0 0 0 20 10 10 0 0 0 10-10zm-2.07-1H17a12.91 12.91 0 0 0-2.33-6.54A8 8 0 0 1 19.93 11zM9.08 13H15a11.44 11.44 0 0 1-3 6.61A11 11 0 0 1 9.08 13zm0-2A11.4 11.4 0 0 1 12 4.4a11.19 11.19 0 0 1 3 6.6zm.36-6.57A13.18 13.18 0 0 0 7.07 11h-3a8 8 0 0 1 5.37-6.57zM4.07 13h3a12.86 12.86 0 0 0 2.35 6.56A8 8 0 0 1 4.07 13zm10.55 6.55A13.14 13.14 0 0 0 17 13h2.95a8 8 0 0 1-5.33 6.55z"/></g></g>',
                        google: '<g data-name="Layer 2"><g data-name="google"><polyline points="0 0 24 0 24 24 0 24" opacity="0"/><path d="M17.5 14a5.51 5.51 0 0 1-4.5 3.93 6.15 6.15 0 0 1-7-5.45A6 6 0 0 1 12 6a6.12 6.12 0 0 1 2.27.44.5.5 0 0 0 .64-.21l1.44-2.65a.52.52 0 0 0-.23-.7A10 10 0 0 0 2 12.29 10.12 10.12 0 0 0 11.57 22 10 10 0 0 0 22 12.52v-2a.51.51 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h5"/></g></g>',
                        grid: '<g data-name="Layer 2"><g data-name="grid"><rect width="24" height="24" opacity="0"/><path d="M9 3H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"/><path d="M19 3h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"/><path d="M9 13H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2z"/><path d="M19 13h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2z"/></g></g>',
                        "hard-drive": '<g data-name="Layer 2"><g data-name="hard-drive"><rect width="24" height="24" opacity="0"/><path d="M20.79 11.34l-3.34-6.68A3 3 0 0 0 14.76 3H9.24a3 3 0 0 0-2.69 1.66l-3.34 6.68a2 2 0 0 0-.21.9V18a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-5.76a2 2 0 0 0-.21-.9zM8 17a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm8 0h-4a1 1 0 0 1 0-2h4a1 1 0 0 1 0 2zM5.62 11l2.72-5.45a1 1 0 0 1 .9-.55h5.52a1 1 0 0 1 .9.55L18.38 11z"/></g></g>',
                        hash: '<g data-name="Layer 2"><g data-name="hash"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20 14h-4.3l.73-4H20a1 1 0 0 0 0-2h-3.21l.69-3.81A1 1 0 0 0 16.64 3a1 1 0 0 0-1.22.82L14.67 8h-3.88l.69-3.81A1 1 0 0 0 10.64 3a1 1 0 0 0-1.22.82L8.67 8H4a1 1 0 0 0 0 2h4.3l-.73 4H4a1 1 0 0 0 0 2h3.21l-.69 3.81A1 1 0 0 0 7.36 21a1 1 0 0 0 1.22-.82L9.33 16h3.88l-.69 3.81a1 1 0 0 0 .84 1.19 1 1 0 0 0 1.22-.82l.75-4.18H20a1 1 0 0 0 0-2zM9.7 14l.73-4h3.87l-.73 4z"/></g></g>',
                        headphones: '<g data-name="Layer 2"><g data-name="headphones"><rect width="24" height="24" opacity="0"/><path d="M12 2A10.2 10.2 0 0 0 2 12.37V17a4 4 0 1 0 4-4 3.91 3.91 0 0 0-2 .56v-1.19A8.2 8.2 0 0 1 12 4a8.2 8.2 0 0 1 8 8.37v1.19a3.91 3.91 0 0 0-2-.56 4 4 0 1 0 4 4v-4.63A10.2 10.2 0 0 0 12 2z"/></g></g>',
                        heart: '<g data-name="Layer 2"><g data-name="heart"><rect width="24" height="24" opacity="0"/><path d="M12 21a1 1 0 0 1-.71-.29l-7.77-7.78a5.26 5.26 0 0 1 0-7.4 5.24 5.24 0 0 1 7.4 0L12 6.61l1.08-1.08a5.24 5.24 0 0 1 7.4 0 5.26 5.26 0 0 1 0 7.4l-7.77 7.78A1 1 0 0 1 12 21z"/></g></g>',
                        home: '<g data-name="Layer 2"><g data-name="home"><rect width="24" height="24" opacity="0"/><rect x="10" y="14" width="4" height="7"/><path d="M20.42 10.18L12.71 2.3a1 1 0 0 0-1.42 0l-7.71 7.89A2 2 0 0 0 3 11.62V20a2 2 0 0 0 1.89 2H8v-9a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v9h3.11A2 2 0 0 0 21 20v-8.38a2.07 2.07 0 0 0-.58-1.44z"/></g></g>',
                        "image-2": '<g data-name="Layer 2"><g data-name="image-2"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zM8 7a1.5 1.5 0 1 1-1.5 1.5A1.5 1.5 0 0 1 8 7zm11 10.83A1.09 1.09 0 0 1 18 19H6l7.57-6.82a.69.69 0 0 1 .93 0l4.5 4.48z"/></g></g>',
                        image: '<g data-name="Layer 2"><g data-name="image"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zM6 5h12a1 1 0 0 1 1 1v8.36l-3.2-2.73a2.77 2.77 0 0 0-3.52 0L5 17.7V6a1 1 0 0 1 1-1z"/><circle cx="8" cy="8.5" r="1.5"/></g></g>',
                        inbox: '<g data-name="Layer 2"><g data-name="inbox"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20.79 11.34l-3.34-6.68A3 3 0 0 0 14.76 3H9.24a3 3 0 0 0-2.69 1.66l-3.34 6.68a2 2 0 0 0-.21.9V18a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-5.76a2 2 0 0 0-.21-.9zM8.34 5.55a1 1 0 0 1 .9-.55h5.52a1 1 0 0 1 .9.55L18.38 11H16a1 1 0 0 0-1 1v2a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-2a1 1 0 0 0-1-1H5.62z"/></g></g>',
                        info: '<g data-name="Layer 2"><g data-name="info"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm1 14a1 1 0 0 1-2 0v-5a1 1 0 0 1 2 0zm-1-7a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        keypad: '<g data-name="Layer 2"><g data-name="keypad"><rect width="24" height="24" opacity="0"/><path d="M5 2a3 3 0 1 0 3 3 3 3 0 0 0-3-3z"/><path d="M12 2a3 3 0 1 0 3 3 3 3 0 0 0-3-3z"/><path d="M19 8a3 3 0 1 0-3-3 3 3 0 0 0 3 3z"/><path d="M5 9a3 3 0 1 0 3 3 3 3 0 0 0-3-3z"/><path d="M12 9a3 3 0 1 0 3 3 3 3 0 0 0-3-3z"/><path d="M19 9a3 3 0 1 0 3 3 3 3 0 0 0-3-3z"/><path d="M5 16a3 3 0 1 0 3 3 3 3 0 0 0-3-3z"/><path d="M12 16a3 3 0 1 0 3 3 3 3 0 0 0-3-3z"/><path d="M19 16a3 3 0 1 0 3 3 3 3 0 0 0-3-3z"/></g></g>',
                        layers: '<g data-name="Layer 2"><g data-name="layers"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M3.24 7.29l8.52 4.63a.51.51 0 0 0 .48 0l8.52-4.63a.44.44 0 0 0-.05-.81L12.19 3a.5.5 0 0 0-.38 0L3.29 6.48a.44.44 0 0 0-.05.81z"/><path d="M20.71 10.66l-1.83-.78-6.64 3.61a.51.51 0 0 1-.48 0L5.12 9.88l-1.83.78a.48.48 0 0 0 0 .85l8.52 4.9a.46.46 0 0 0 .48 0l8.52-4.9a.48.48 0 0 0-.1-.85z"/><path d="M20.71 15.1l-1.56-.68-6.91 3.76a.51.51 0 0 1-.48 0l-6.91-3.76-1.56.68a.49.49 0 0 0 0 .87l8.52 5a.51.51 0 0 0 .48 0l8.52-5a.49.49 0 0 0-.1-.87z"/></g></g>',
                        layout: '<g data-name="Layer 2"><g data-name="layout"><rect width="24" height="24" opacity="0"/><path d="M21 8V6a3 3 0 0 0-3-3H6a3 3 0 0 0-3 3v2z"/><path d="M3 10v8a3 3 0 0 0 3 3h5V10z"/><path d="M13 10v11h5a3 3 0 0 0 3-3v-8z"/></g></g>',
                        "link-2": '<g data-name="Layer 2"><g data-name="link-2"><rect width="24" height="24" opacity="0"/><path d="M13.29 9.29l-4 4a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l4-4a1 1 0 0 0-1.42-1.42z"/><path d="M12.28 17.4L11 18.67a4.2 4.2 0 0 1-5.58.4 4 4 0 0 1-.27-5.93l1.42-1.43a1 1 0 0 0 0-1.42 1 1 0 0 0-1.42 0l-1.27 1.28a6.15 6.15 0 0 0-.67 8.07 6.06 6.06 0 0 0 9.07.6l1.42-1.42a1 1 0 0 0-1.42-1.42z"/><path d="M19.66 3.22a6.18 6.18 0 0 0-8.13.68L10.45 5a1.09 1.09 0 0 0-.17 1.61 1 1 0 0 0 1.42 0L13 5.3a4.17 4.17 0 0 1 5.57-.4 4 4 0 0 1 .27 5.95l-1.42 1.43a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l1.42-1.42a6.06 6.06 0 0 0-.6-9.06z"/></g></g>',
                        link: '<g data-name="Layer 2"><g data-name="link"><rect width="24" height="24" opacity="0"/><path d="M8 12a1 1 0 0 0 1 1h6a1 1 0 0 0 0-2H9a1 1 0 0 0-1 1z"/><path d="M9 16H7.21A4.13 4.13 0 0 1 3 12.37 4 4 0 0 1 7 8h2a1 1 0 0 0 0-2H7.21a6.15 6.15 0 0 0-6.16 5.21A6 6 0 0 0 7 18h2a1 1 0 0 0 0-2z"/><path d="M23 11.24A6.16 6.16 0 0 0 16.76 6h-1.51C14.44 6 14 6.45 14 7a1 1 0 0 0 1 1h1.79A4.13 4.13 0 0 1 21 11.63 4 4 0 0 1 17 16h-2a1 1 0 0 0 0 2h2a6 6 0 0 0 6-6.76z"/></g></g>',
                        linkedin: '<g data-name="Layer 2"><g data-name="linkedin"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M15.15 8.4a5.83 5.83 0 0 0-5.85 5.82v5.88a.9.9 0 0 0 .9.9h2.1a.9.9 0 0 0 .9-.9v-5.88a1.94 1.94 0 0 1 2.15-1.93 2 2 0 0 1 1.75 2v5.81a.9.9 0 0 0 .9.9h2.1a.9.9 0 0 0 .9-.9v-5.88a5.83 5.83 0 0 0-5.85-5.82z"/><rect x="3" y="9.3" width="4.5" height="11.7" rx=".9" ry=".9"/><circle cx="5.25" cy="5.25" r="2.25"/></g></g>',
                        list: '<g data-name="Layer 2"><g data-name="list"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><circle cx="4" cy="7" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="17" r="1"/><rect x="7" y="11" width="14" height="2" rx=".94" ry=".94"/><rect x="7" y="16" width="14" height="2" rx=".94" ry=".94"/><rect x="7" y="6" width="14" height="2" rx=".94" ry=".94"/></g></g>',
                        lock: '<g data-name="Layer 2"><g data-name="lock"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="15" r="1"/><path d="M17 8h-1V6.11a4 4 0 1 0-8 0V8H7a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-8a3 3 0 0 0-3-3zm-7-1.89A2.06 2.06 0 0 1 12 4a2.06 2.06 0 0 1 2 2.11V8h-4zM12 18a3 3 0 1 1 3-3 3 3 0 0 1-3 3z"/></g></g>',
                        "log-in": '<g data-name="Layer 2"><g data-name="log-in"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M19 4h-2a1 1 0 0 0 0 2h1v12h-1a1 1 0 0 0 0 2h2a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1z"/><path d="M11.8 7.4a1 1 0 0 0-1.6 1.2L12 11H4a1 1 0 0 0 0 2h8.09l-1.72 2.44a1 1 0 0 0 .24 1.4 1 1 0 0 0 .58.18 1 1 0 0 0 .81-.42l2.82-4a1 1 0 0 0 0-1.18z"/></g></g>',
                        "log-out": '<g data-name="Layer 2"><g data-name="log-out"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M7 6a1 1 0 0 0 0-2H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h2a1 1 0 0 0 0-2H6V6z"/><path d="M20.82 11.42l-2.82-4a1 1 0 0 0-1.39-.24 1 1 0 0 0-.24 1.4L18.09 11H10a1 1 0 0 0 0 2h8l-1.8 2.4a1 1 0 0 0 .2 1.4 1 1 0 0 0 .6.2 1 1 0 0 0 .8-.4l3-4a1 1 0 0 0 .02-1.18z"/></g></g>',
                        map: '<g data-name="Layer 2"><g data-name="map"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20.41 5.89l-4-1.8H15.59L12 5.7 8.41 4.09h-.05L8.24 4h-.6l-4 1.8a1 1 0 0 0-.64 1V19a1 1 0 0 0 .46.84A1 1 0 0 0 4 20a1 1 0 0 0 .41-.09L8 18.3l3.59 1.61h.05a.85.85 0 0 0 .72 0h.05L16 18.3l3.59 1.61A1 1 0 0 0 20 20a1 1 0 0 0 .54-.16A1 1 0 0 0 21 19V6.8a1 1 0 0 0-.59-.91zM9 6.55l2 .89v10l-2-.89zm10 10.9l-2-.89v-10l2 .89z"/></g></g>',
                        maximize: '<g data-name="Layer 2"><g data-name="maximize"><rect width="24" height="24" opacity="0"/><path d="M20.71 19.29l-3.4-3.39A7.92 7.92 0 0 0 19 11a8 8 0 1 0-8 8 7.92 7.92 0 0 0 4.9-1.69l3.39 3.4a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM13 12h-1v1a1 1 0 0 1-2 0v-1H9a1 1 0 0 1 0-2h1V9a1 1 0 0 1 2 0v1h1a1 1 0 0 1 0 2z"/></g></g>',
                        "menu-2": '<g data-name="Layer 2"><g data-name="menu-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><circle cx="4" cy="12" r="1"/><rect x="7" y="11" width="14" height="2" rx=".94" ry=".94"/><rect x="3" y="16" width="18" height="2" rx=".94" ry=".94"/><rect x="3" y="6" width="18" height="2" rx=".94" ry=".94"/></g></g>',
                        "menu-arrow": '<g data-name="Layer 2"><g data-name="menu-arrow"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20.05 11H5.91l1.3-1.29a1 1 0 0 0-1.42-1.42l-3 3a1 1 0 0 0 0 1.42l3 3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L5.91 13h14.14a1 1 0 0 0 .95-.95V12a1 1 0 0 0-.95-1z"/><rect x="3" y="17" width="18" height="2" rx=".95" ry=".95"/><rect x="3" y="5" width="18" height="2" rx=".95" ry=".95"/></g></g>',
                        menu: '<g data-name="Layer 2"><g data-name="menu"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><rect x="3" y="11" width="18" height="2" rx=".95" ry=".95"/><rect x="3" y="16" width="18" height="2" rx=".95" ry=".95"/><rect x="3" y="6" width="18" height="2" rx=".95" ry=".95"/></g></g>',
                        "message-circle": '<g data-name="Layer 2"><g data-name="message-circle"><rect width="24" height="24" opacity="0"/><path d="M19.07 4.93a10 10 0 0 0-16.28 11 1.06 1.06 0 0 1 .09.64L2 20.8a1 1 0 0 0 .27.91A1 1 0 0 0 3 22h.2l4.28-.86a1.26 1.26 0 0 1 .64.09 10 10 0 0 0 11-16.28zM8 13a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm4 0a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm4 0a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "message-square": '<g data-name="Layer 2"><g data-name="message-square"><rect width="24" height="24" opacity="0"/><path d="M19 3H5a3 3 0 0 0-3 3v15a1 1 0 0 0 .51.87A1 1 0 0 0 3 22a1 1 0 0 0 .51-.14L8 19.14a1 1 0 0 1 .55-.14H19a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zM8 12a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm4 0a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm4 0a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "mic-off": '<g data-name="Layer 2"><g data-name="mic-off"><rect width="24" height="24" opacity="0"/><path d="M15.58 12.75A4 4 0 0 0 16 11V6a4 4 0 0 0-7.92-.75"/><path d="M19 11a1 1 0 0 0-2 0 4.86 4.86 0 0 1-.69 2.48L17.78 15A7 7 0 0 0 19 11z"/><path d="M12 15h.16L8 10.83V11a4 4 0 0 0 4 4z"/><path d="M20.71 19.29l-16-16a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M15 20h-2v-2.08a7 7 0 0 0 1.65-.44l-1.6-1.6A4.57 4.57 0 0 1 12 16a5 5 0 0 1-5-5 1 1 0 0 0-2 0 7 7 0 0 0 6 6.92V20H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2z"/></g></g>',
                        mic: '<g data-name="Layer 2"><g data-name="mic"><rect width="24" height="24" opacity="0"/><path d="M12 15a4 4 0 0 0 4-4V6a4 4 0 0 0-8 0v5a4 4 0 0 0 4 4z"/><path d="M19 11a1 1 0 0 0-2 0 5 5 0 0 1-10 0 1 1 0 0 0-2 0 7 7 0 0 0 6 6.92V20H8.89a.89.89 0 0 0-.89.89v.22a.89.89 0 0 0 .89.89h6.22a.89.89 0 0 0 .89-.89v-.22a.89.89 0 0 0-.89-.89H13v-2.08A7 7 0 0 0 19 11z"/></g></g>',
                        minimize: '<g data-name="Layer 2"><g data-name="minimize"><rect width="24" height="24" opacity="0"/><path d="M20.71 19.29l-3.4-3.39A7.92 7.92 0 0 0 19 11a8 8 0 1 0-8 8 7.92 7.92 0 0 0 4.9-1.69l3.39 3.4a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM13 12H9a1 1 0 0 1 0-2h4a1 1 0 0 1 0 2z"/></g></g>',
                        "minus-circle": '<g data-name="Layer 2"><g data-name="minus-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm3 11H9a1 1 0 0 1 0-2h6a1 1 0 0 1 0 2z"/></g></g>',
                        "minus-square": '<g data-name="Layer 2"><g data-name="minus-square"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm-3 10H9a1 1 0 0 1 0-2h6a1 1 0 0 1 0 2z"/></g></g>',
                        minus: '<g data-name="Layer 2"><g data-name="minus"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M19 13H5a1 1 0 0 1 0-2h14a1 1 0 0 1 0 2z"/></g></g>',
                        monitor: '<g data-name="Layer 2"><g data-name="monitor"><rect width="24" height="24" opacity="0"/><path d="M19 3H5a3 3 0 0 0-3 3v5h20V6a3 3 0 0 0-3-3z"/><path d="M2 14a3 3 0 0 0 3 3h6v2H7a1 1 0 0 0 0 2h10a1 1 0 0 0 0-2h-4v-2h6a3 3 0 0 0 3-3v-1H2z"/></g></g>',
                        moon: '<g data-name="Layer 2"><g data-name="moon"><rect width="24" height="24" opacity="0"/><path d="M12.3 22h-.1a10.31 10.31 0 0 1-7.34-3.15 10.46 10.46 0 0 1-.26-14 10.13 10.13 0 0 1 4-2.74 1 1 0 0 1 1.06.22 1 1 0 0 1 .24 1 8.4 8.4 0 0 0 1.94 8.81 8.47 8.47 0 0 0 8.83 1.94 1 1 0 0 1 1.27 1.29A10.16 10.16 0 0 1 19.6 19a10.28 10.28 0 0 1-7.3 3z"/></g></g>',
                        "more-horizontal": '<g data-name="Layer 2"><g data-name="more-horizotnal"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/><circle cx="5" cy="12" r="2"/></g></g>',
                        "more-vertical": '<g data-name="Layer 2"><g data-name="more-vertical"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="5" r="2"/><circle cx="12" cy="19" r="2"/></g></g>',
                        move: '<g data-name="Layer 2"><g data-name="move"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M21.71 11.31l-3-3a1 1 0 0 0-1.42 1.42L18.58 11H13V5.41l1.29 1.3A1 1 0 0 0 15 7a1 1 0 0 0 .71-.29 1 1 0 0 0 0-1.42l-3-3A1 1 0 0 0 12 2a1 1 0 0 0-.7.29l-3 3a1 1 0 0 0 1.41 1.42L11 5.42V11H5.41l1.3-1.29a1 1 0 0 0-1.42-1.42l-3 3A1 1 0 0 0 2 12a1 1 0 0 0 .29.71l3 3A1 1 0 0 0 6 16a1 1 0 0 0 .71-.29 1 1 0 0 0 0-1.42L5.42 13H11v5.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 22a1 1 0 0 0 .7-.29l3-3a1 1 0 0 0-1.42-1.42L13 18.58V13h5.59l-1.3 1.29a1 1 0 0 0 0 1.42A1 1 0 0 0 18 16a1 1 0 0 0 .71-.29l3-3A1 1 0 0 0 22 12a1 1 0 0 0-.29-.69z"/></g></g>',
                        music: '<g data-name="Layer 2"><g data-name="music"><rect width="24" height="24" opacity="0"/><path d="M19 15V4a1 1 0 0 0-.38-.78 1 1 0 0 0-.84-.2l-9 2A1 1 0 0 0 8 6v8.34a3.49 3.49 0 1 0 2 3.18 4.36 4.36 0 0 0 0-.52V6.8l7-1.55v7.09a3.49 3.49 0 1 0 2 3.17 4.57 4.57 0 0 0 0-.51z"/></g></g>',
                        "navigation-2": '<g data-name="Layer 2"><g data-name="navigation-2"><rect width="24" height="24" opacity="0"/><path d="M13.67 22h-.06a1 1 0 0 1-.92-.8l-1.54-7.57a1 1 0 0 0-.78-.78L2.8 11.31a1 1 0 0 1-.12-1.93l16-5.33A1 1 0 0 1 20 5.32l-5.33 16a1 1 0 0 1-1 .68z"/></g></g>',
                        navigation: '<g data-name="Layer 2"><g data-name="navigation"><rect width="24" height="24" opacity="0"/><path d="M20 20a.94.94 0 0 1-.55-.17l-6.9-4.56a1 1 0 0 0-1.1 0l-6.9 4.56a1 1 0 0 1-1.44-1.28l8-16a1 1 0 0 1 1.78 0l8 16a1 1 0 0 1-.23 1.2A1 1 0 0 1 20 20z"/></g></g>',
                        npm: '<g data-name="Layer 2"><g data-name="npm"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h7V11h4v10h1a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3z"/></g></g>',
                        "options-2": '<g data-name="Layer 2"><g data-name="options-2"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M19 9a3 3 0 0 0-2.82 2H3a1 1 0 0 0 0 2h13.18A3 3 0 1 0 19 9z"/><path d="M3 7h1.18a3 3 0 0 0 5.64 0H21a1 1 0 0 0 0-2H9.82a3 3 0 0 0-5.64 0H3a1 1 0 0 0 0 2z"/><path d="M21 17h-7.18a3 3 0 0 0-5.64 0H3a1 1 0 0 0 0 2h5.18a3 3 0 0 0 5.64 0H21a1 1 0 0 0 0-2z"/></g></g>',
                        options: '<g data-name="Layer 2"><g data-name="options"><rect width="24" height="24" opacity="0"/><path d="M7 14.18V3a1 1 0 0 0-2 0v11.18a3 3 0 0 0 0 5.64V21a1 1 0 0 0 2 0v-1.18a3 3 0 0 0 0-5.64z"/><path d="M21 13a3 3 0 0 0-2-2.82V3a1 1 0 0 0-2 0v7.18a3 3 0 0 0 0 5.64V21a1 1 0 0 0 2 0v-5.18A3 3 0 0 0 21 13z"/><path d="M15 5a3 3 0 1 0-4 2.82V21a1 1 0 0 0 2 0V7.82A3 3 0 0 0 15 5z"/></g></g>',
                        pantone: '<g data-name="Layer 2"><g data-name="pantone"><rect width="24" height="24" opacity="0"/><path d="M20 13.18h-2.7l-1.86 2L11.88 19l-1.41 1.52L10 21h10a1 1 0 0 0 1-1v-5.82a1 1 0 0 0-1-1z"/><path d="M18.19 9.3l-4.14-3.86a.89.89 0 0 0-.71-.26 1 1 0 0 0-.7.31l-.82.89v10.71a5.23 5.23 0 0 1-.06.57l6.48-6.95a1 1 0 0 0-.05-1.41z"/><path d="M10.82 4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v13.09a3.91 3.91 0 0 0 7.82 0zm-2 13.09a1.91 1.91 0 0 1-3.82 0V15h3.82zm0-4.09H5v-3h3.82zm0-5H5V5h3.82z"/></g></g>',
                        "paper-plane": '<g data-name="Layer 2"><g data-name="paper-plane"><rect width="24" height="24" opacity="0"/><path d="M21 4a1.31 1.31 0 0 0-.06-.27v-.09a1 1 0 0 0-.2-.3 1 1 0 0 0-.29-.19h-.09a.86.86 0 0 0-.31-.15H20a1 1 0 0 0-.3 0l-18 6a1 1 0 0 0 0 1.9l8.53 2.84 2.84 8.53a1 1 0 0 0 1.9 0l6-18A1 1 0 0 0 21 4zm-4.7 2.29l-5.57 5.57L5.16 10zM14 18.84l-1.86-5.57 5.57-5.57z"/></g></g>',
                        "pause-circle": '<g data-name="Layer 2"><g data-name="pause-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm-2 13a1 1 0 0 1-2 0V9a1 1 0 0 1 2 0zm6 0a1 1 0 0 1-2 0V9a1 1 0 0 1 2 0z"/></g></g>',
                        people: '<g data-name="Layer 2"><g data-name="people"><rect width="24" height="24" opacity="0"/><path d="M9 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4z"/><path d="M17 13a3 3 0 1 0-3-3 3 3 0 0 0 3 3z"/><path d="M21 20a1 1 0 0 0 1-1 5 5 0 0 0-8.06-3.95A7 7 0 0 0 2 20a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1"/></g></g>',
                        percent: '<g data-name="Layer 2"><g data-name="percent"><rect width="24" height="24" opacity="0"/><path d="M8 11a3.5 3.5 0 1 0-3.5-3.5A3.5 3.5 0 0 0 8 11zm0-5a1.5 1.5 0 1 1-1.5 1.5A1.5 1.5 0 0 1 8 6z"/><path d="M16 14a3.5 3.5 0 1 0 3.5 3.5A3.5 3.5 0 0 0 16 14zm0 5a1.5 1.5 0 1 1 1.5-1.5A1.5 1.5 0 0 1 16 19z"/><path d="M19.74 4.26a.89.89 0 0 0-1.26 0L4.26 18.48a.91.91 0 0 0-.26.63.89.89 0 0 0 1.52.63L19.74 5.52a.89.89 0 0 0 0-1.26z"/></g></g>',
                        "person-add": '<g data-name="Layer 2"><g data-name="person-add"><rect width="24" height="24" opacity="0"/><path d="M21 6h-1V5a1 1 0 0 0-2 0v1h-1a1 1 0 0 0 0 2h1v1a1 1 0 0 0 2 0V8h1a1 1 0 0 0 0-2z"/><path d="M10 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4z"/><path d="M16 21a1 1 0 0 0 1-1 7 7 0 0 0-14 0 1 1 0 0 0 1 1"/></g></g>',
                        "person-delete": '<g data-name="Layer 2"><g data-name="person-delete"><rect width="24" height="24" opacity="0"/><path d="M20.47 7.5l.73-.73a1 1 0 0 0-1.47-1.47L19 6l-.73-.73a1 1 0 0 0-1.47 1.5l.73.73-.73.73a1 1 0 0 0 1.47 1.47L19 9l.73.73a1 1 0 0 0 1.47-1.5z"/><path d="M10 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4z"/><path d="M16 21a1 1 0 0 0 1-1 7 7 0 0 0-14 0 1 1 0 0 0 1 1z"/></g></g>',
                        "person-done": '<g data-name="Layer 2"><g data-name="person-done"><rect width="24" height="24" opacity="0"/><path d="M21.66 4.25a1 1 0 0 0-1.41.09l-1.87 2.15-.63-.71a1 1 0 0 0-1.5 1.33l1.39 1.56a1 1 0 0 0 .75.33 1 1 0 0 0 .74-.34l2.61-3a1 1 0 0 0-.08-1.41z"/><path d="M10 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4z"/><path d="M16 21a1 1 0 0 0 1-1 7 7 0 0 0-14 0 1 1 0 0 0 1 1"/></g></g>',
                        "person-remove": '<g data-name="Layer 2"><g data-name="person-remove"><rect width="24" height="24" opacity="0"/><path d="M21 6h-4a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2z"/><path d="M10 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4z"/><path d="M16 21a1 1 0 0 0 1-1 7 7 0 0 0-14 0 1 1 0 0 0 1 1"/></g></g>',
                        person: '<g data-name="Layer 2"><g data-name="person"><rect width="24" height="24" opacity="0"/><path d="M12 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4z"/><path d="M18 21a1 1 0 0 0 1-1 7 7 0 0 0-14 0 1 1 0 0 0 1 1z"/></g></g>',
                        "phone-call": '<g data-name="Layer 2"><g data-name="phone-call"><rect width="24" height="24" opacity="0"/><path d="M13 8a3 3 0 0 1 3 3 1 1 0 0 0 2 0 5 5 0 0 0-5-5 1 1 0 0 0 0 2z"/><path d="M13 4a7 7 0 0 1 7 7 1 1 0 0 0 2 0 9 9 0 0 0-9-9 1 1 0 0 0 0 2z"/><path d="M21.75 15.91a1 1 0 0 0-.72-.65l-6-1.37a1 1 0 0 0-.92.26c-.14.13-.15.14-.8 1.38a9.91 9.91 0 0 1-4.87-4.89C9.71 10 9.72 10 9.85 9.85a1 1 0 0 0 .26-.92L8.74 3a1 1 0 0 0-.65-.72 3.79 3.79 0 0 0-.72-.18A3.94 3.94 0 0 0 6.6 2 4.6 4.6 0 0 0 2 6.6 15.42 15.42 0 0 0 17.4 22a4.6 4.6 0 0 0 4.6-4.6 4.77 4.77 0 0 0-.06-.76 4.34 4.34 0 0 0-.19-.73z"/></g></g>',
                        "phone-missed": '<g data-name="Layer 2"><g data-name="phone-missed"><rect width="24" height="24" opacity="0"/><path d="M21.94 16.64a4.34 4.34 0 0 0-.19-.73 1 1 0 0 0-.72-.65l-6-1.37a1 1 0 0 0-.92.26c-.14.13-.15.14-.8 1.38a10 10 0 0 1-4.88-4.89C9.71 10 9.72 10 9.85 9.85a1 1 0 0 0 .26-.92L8.74 3a1 1 0 0 0-.65-.72 3.79 3.79 0 0 0-.72-.18A3.94 3.94 0 0 0 6.6 2 4.6 4.6 0 0 0 2 6.6 15.42 15.42 0 0 0 17.4 22a4.6 4.6 0 0 0 4.6-4.6 4.77 4.77 0 0 0-.06-.76z"/><path d="M15.8 8.7a1.05 1.05 0 0 0 1.47 0L18 8l.73.73a1 1 0 0 0 1.47-1.5l-.73-.73.73-.73a1 1 0 0 0-1.47-1.47L18 5l-.73-.73a1 1 0 0 0-1.47 1.5l.73.73-.73.73a1.05 1.05 0 0 0 0 1.47z"/></g></g>',
                        "phone-off": '<g data-name="Layer 2"><g data-name="phone-off"><rect width="24" height="24" opacity="0"/><path d="M9.27 12.06a10.37 10.37 0 0 1-.8-1.42C9.71 10 9.72 10 9.85 9.85a1 1 0 0 0 .26-.92L8.74 3a1 1 0 0 0-.65-.72 3.79 3.79 0 0 0-.72-.18A3.94 3.94 0 0 0 6.6 2 4.6 4.6 0 0 0 2 6.6a15.33 15.33 0 0 0 3.27 9.46z"/><path d="M21.94 16.64a4.34 4.34 0 0 0-.19-.73 1 1 0 0 0-.72-.65l-6-1.37a1 1 0 0 0-.92.26c-.14.13-.15.14-.8 1.38a10.88 10.88 0 0 1-1.41-.8l-4 4A15.33 15.33 0 0 0 17.4 22a4.6 4.6 0 0 0 4.6-4.6 4.77 4.77 0 0 0-.06-.76z"/><path d="M19.74 4.26a.89.89 0 0 0-1.26 0L4.26 18.48a.91.91 0 0 0-.26.63.89.89 0 0 0 1.52.63L19.74 5.52a.89.89 0 0 0 0-1.26z"/></g></g>',
                        phone: '<g data-name="Layer 2"><g data-name="phone"><rect width="24" height="24" opacity="0"/><path d="M17.4 22A15.42 15.42 0 0 1 2 6.6 4.6 4.6 0 0 1 6.6 2a3.94 3.94 0 0 1 .77.07 3.79 3.79 0 0 1 .72.18 1 1 0 0 1 .65.75l1.37 6a1 1 0 0 1-.26.92c-.13.14-.14.15-1.37.79a9.91 9.91 0 0 0 4.87 4.89c.65-1.24.66-1.25.8-1.38a1 1 0 0 1 .92-.26l6 1.37a1 1 0 0 1 .72.65 4.34 4.34 0 0 1 .19.73 4.77 4.77 0 0 1 .06.76A4.6 4.6 0 0 1 17.4 22z"/></g></g>',
                        "pie-chart-2": '<g data-name="Layer 2"><g data-name="pie-chart-2"><rect width="24" height="24" opacity="0"/><path d="M14.5 10.33h6.67A.83.83 0 0 0 22 9.5 7.5 7.5 0 0 0 14.5 2a.83.83 0 0 0-.83.83V9.5a.83.83 0 0 0 .83.83zm.83-6.6a5.83 5.83 0 0 1 4.94 4.94h-4.94z"/><path d="M21.08 12h-8.15a.91.91 0 0 1-.91-.91V2.92A.92.92 0 0 0 11 2a10 10 0 1 0 11 11 .92.92 0 0 0-.92-1z"/></g></g>',
                        "pie-chart": '<g data-name="Layer 2"><g data-name="pie-chart"><rect width="24" height="24" opacity="0"/><path d="M14.5 10.33h6.67A.83.83 0 0 0 22 9.5 7.5 7.5 0 0 0 14.5 2a.83.83 0 0 0-.83.83V9.5a.83.83 0 0 0 .83.83z"/><path d="M21.08 12h-8.15a.91.91 0 0 1-.91-.91V2.92A.92.92 0 0 0 11 2a10 10 0 1 0 11 11 .92.92 0 0 0-.92-1z"/></g></g>',
                        pin: '<g data-name="Layer 2"><g data-name="pin"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="9.5" r="1.5"/><path d="M12 2a8 8 0 0 0-8 7.92c0 5.48 7.05 11.58 7.35 11.84a1 1 0 0 0 1.3 0C13 21.5 20 15.4 20 9.92A8 8 0 0 0 12 2zm0 11a3.5 3.5 0 1 1 3.5-3.5A3.5 3.5 0 0 1 12 13z"/></g></g>',
                        "play-circle": '<g data-name="Layer 2"><g data-name="play-circle"><rect width="24" height="24" opacity="0"/><polygon points="11.5 14.6 14.31 12 11.5 9.4 11.5 14.6"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm4 11.18l-3.64 3.37a1.74 1.74 0 0 1-1.16.45 1.68 1.68 0 0 1-.69-.15 1.6 1.6 0 0 1-1-1.48V8.63a1.6 1.6 0 0 1 1-1.48 1.7 1.7 0 0 1 1.85.3L16 10.82a1.6 1.6 0 0 1 0 2.36z"/></g></g>',
                        "plus-circle": '<g data-name="Layer 2"><g data-name="plus-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm3 11h-2v2a1 1 0 0 1-2 0v-2H9a1 1 0 0 1 0-2h2V9a1 1 0 0 1 2 0v2h2a1 1 0 0 1 0 2z"/></g></g>',
                        "plus-square": '<g data-name="Layer 2"><g data-name="plus-square"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm-3 10h-2v2a1 1 0 0 1-2 0v-2H9a1 1 0 0 1 0-2h2V9a1 1 0 0 1 2 0v2h2a1 1 0 0 1 0 2z"/></g></g>',
                        plus: '<g data-name="Layer 2"><g data-name="plus"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M19 11h-6V5a1 1 0 0 0-2 0v6H5a1 1 0 0 0 0 2h6v6a1 1 0 0 0 2 0v-6h6a1 1 0 0 0 0-2z"/></g></g>',
                        power: '<g data-name="Layer 2"><g data-name="power"><rect width="24" height="24" opacity="0"/><path d="M12 13a1 1 0 0 0 1-1V2a1 1 0 0 0-2 0v10a1 1 0 0 0 1 1z"/><path d="M16.59 3.11a1 1 0 0 0-.92 1.78 8 8 0 1 1-7.34 0 1 1 0 1 0-.92-1.78 10 10 0 1 0 9.18 0z"/></g></g>',
                        pricetags: '<g data-name="Layer 2"><g data-name="pricetags"><rect width="24" height="24" opacity="0"/><path d="M21.47 11.58l-6.42-6.41a1 1 0 0 0-.61-.29L5.09 4a1 1 0 0 0-.8.29 1 1 0 0 0-.29.8l.88 9.35a1 1 0 0 0 .29.61l6.41 6.42a1.84 1.84 0 0 0 1.29.53 1.82 1.82 0 0 0 1.28-.53l7.32-7.32a1.82 1.82 0 0 0 0-2.57zm-9.91 0a1.5 1.5 0 1 1 0-2.12 1.49 1.49 0 0 1 0 2.1z"/></g></g>',
                        printer: '<g data-name="Layer 2"><g data-name="printer"><rect width="24" height="24" opacity="0"/><path d="M19.36 7H18V5a1.92 1.92 0 0 0-1.83-2H7.83A1.92 1.92 0 0 0 6 5v2H4.64A2.66 2.66 0 0 0 2 9.67v6.66A2.66 2.66 0 0 0 4.64 19h.86a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2h.86A2.66 2.66 0 0 0 22 16.33V9.67A2.66 2.66 0 0 0 19.36 7zM8 5h8v2H8zm-.5 14v-4h9v4z"/></g></g>',
                        "question-mark-circle": '<g data-name="Layer 2"><g data-name="menu-arrow-circle"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 16a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm1-5.16V14a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1 1.5 1.5 0 1 0-1.5-1.5 1 1 0 0 1-2 0 3.5 3.5 0 1 1 4.5 3.34z"/></g></g>',
                        "question-mark": '<g data-name="Layer 2"><g data-name="menu-arrow"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M17 9A5 5 0 0 0 7 9a1 1 0 0 0 2 0 3 3 0 1 1 3 3 1 1 0 0 0-1 1v2a1 1 0 0 0 2 0v-1.1A5 5 0 0 0 17 9z"/><circle cx="12" cy="19" r="1"/></g></g>',
                        "radio-button-off": '<g data-name="Layer 2"><g data-name="radio-button-off"><rect width="24" height="24" opacity="0"/><path d="M12 22a10 10 0 1 1 10-10 10 10 0 0 1-10 10zm0-18a8 8 0 1 0 8 8 8 8 0 0 0-8-8z"/></g></g>',
                        "radio-button-on": '<g data-name="Layer 2"><g data-name="radio-button-on"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M12 7a5 5 0 1 0 5 5 5 5 0 0 0-5-5z"/></g></g>',
                        radio: '<g data-name="Layer 2"><g data-name="radio"><rect width="24" height="24" opacity="0"/><path d="M12 8a3 3 0 0 0-1 5.83 1 1 0 0 0 0 .17v6a1 1 0 0 0 2 0v-6a1 1 0 0 0 0-.17A3 3 0 0 0 12 8z"/><path d="M3.5 11a6.87 6.87 0 0 1 2.64-5.23 1 1 0 1 0-1.28-1.54A8.84 8.84 0 0 0 1.5 11a8.84 8.84 0 0 0 3.36 6.77 1 1 0 1 0 1.28-1.54A6.87 6.87 0 0 1 3.5 11z"/><path d="M16.64 6.24a1 1 0 0 0-1.28 1.52A4.28 4.28 0 0 1 17 11a4.28 4.28 0 0 1-1.64 3.24A1 1 0 0 0 16 16a1 1 0 0 0 .64-.24A6.2 6.2 0 0 0 19 11a6.2 6.2 0 0 0-2.36-4.76z"/><path d="M8.76 6.36a1 1 0 0 0-1.4-.12A6.2 6.2 0 0 0 5 11a6.2 6.2 0 0 0 2.36 4.76 1 1 0 0 0 1.4-.12 1 1 0 0 0-.12-1.4A4.28 4.28 0 0 1 7 11a4.28 4.28 0 0 1 1.64-3.24 1 1 0 0 0 .12-1.4z"/><path d="M19.14 4.23a1 1 0 1 0-1.28 1.54A6.87 6.87 0 0 1 20.5 11a6.87 6.87 0 0 1-2.64 5.23 1 1 0 0 0 1.28 1.54A8.84 8.84 0 0 0 22.5 11a8.84 8.84 0 0 0-3.36-6.77z"/></g></g>',
                        recording: '<g data-name="Layer 2"><g data-name="recording"><rect width="24" height="24" opacity="0"/><path d="M18 8a4 4 0 0 0-4 4 3.91 3.91 0 0 0 .56 2H9.44a3.91 3.91 0 0 0 .56-2 4 4 0 1 0-4 4h12a4 4 0 0 0 0-8z"/></g></g>',
                        refresh: '<g data-name="Layer 2"><g data-name="refresh"><rect width="24" height="24" opacity="0"/><path d="M20.3 13.43a1 1 0 0 0-1.25.65A7.14 7.14 0 0 1 12.18 19 7.1 7.1 0 0 1 5 12a7.1 7.1 0 0 1 7.18-7 7.26 7.26 0 0 1 4.65 1.67l-2.17-.36a1 1 0 0 0-1.15.83 1 1 0 0 0 .83 1.15l4.24.7h.17a1 1 0 0 0 .34-.06.33.33 0 0 0 .1-.06.78.78 0 0 0 .2-.11l.09-.11c0-.05.09-.09.13-.15s0-.1.05-.14a1.34 1.34 0 0 0 .07-.18l.75-4a1 1 0 0 0-2-.38l-.27 1.45A9.21 9.21 0 0 0 12.18 3 9.1 9.1 0 0 0 3 12a9.1 9.1 0 0 0 9.18 9A9.12 9.12 0 0 0 21 14.68a1 1 0 0 0-.7-1.25z"/></g></g>',
                        repeat: '<g data-name="Layer 2"><g data-name="repeat"><rect width="24" height="24" opacity="0"/><path d="M17.91 5h-12l1.3-1.29a1 1 0 0 0-1.42-1.42l-3 3a1 1 0 0 0 0 1.42l3 3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L5.91 7h12a1.56 1.56 0 0 1 1.59 1.53V11a1 1 0 0 0 2 0V8.53A3.56 3.56 0 0 0 17.91 5z"/><path d="M18.21 14.29a1 1 0 0 0-1.42 1.42l1.3 1.29h-12a1.56 1.56 0 0 1-1.59-1.53V13a1 1 0 0 0-2 0v2.47A3.56 3.56 0 0 0 6.09 19h12l-1.3 1.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l3-3a1 1 0 0 0 0-1.42z"/></g></g>',
                        "rewind-left": '<g data-name="Layer 2"><g data-name="rewind-left"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18.45 6.2a2.1 2.1 0 0 0-2.21.26l-4.74 3.92V7.79a1.76 1.76 0 0 0-1.05-1.59 2.1 2.1 0 0 0-2.21.26l-5.1 4.21a1.7 1.7 0 0 0 0 2.66l5.1 4.21a2.06 2.06 0 0 0 1.3.46 2.23 2.23 0 0 0 .91-.2 1.76 1.76 0 0 0 1.05-1.59v-2.59l4.74 3.92a2.06 2.06 0 0 0 1.3.46 2.23 2.23 0 0 0 .91-.2 1.76 1.76 0 0 0 1.05-1.59V7.79a1.76 1.76 0 0 0-1.05-1.59z"/></g></g>',
                        "rewind-right": '<g data-name="Layer 2"><g data-name="rewind-right"><rect width="24" height="24" opacity="0"/><path d="M20.86 10.67l-5.1-4.21a2.1 2.1 0 0 0-2.21-.26 1.76 1.76 0 0 0-1.05 1.59v2.59L7.76 6.46a2.1 2.1 0 0 0-2.21-.26 1.76 1.76 0 0 0-1 1.59v8.42a1.76 1.76 0 0 0 1 1.59 2.23 2.23 0 0 0 .91.2 2.06 2.06 0 0 0 1.3-.46l4.74-3.92v2.59a1.76 1.76 0 0 0 1.05 1.59 2.23 2.23 0 0 0 .91.2 2.06 2.06 0 0 0 1.3-.46l5.1-4.21a1.7 1.7 0 0 0 0-2.66z"/></g></g>',
                        save: '<g data-name="Layer 2"><g data-name="save"><rect width="24" height="24" opacity="0"/><rect x="10" y="17" width="4" height="4"/><path d="M20.12 8.71l-4.83-4.83A3 3 0 0 0 13.17 3H10v6h5a1 1 0 0 1 0 2H9a1 1 0 0 1-1-1V3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h2v-4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v4h2a3 3 0 0 0 3-3v-7.17a3 3 0 0 0-.88-2.12z"/></g></g>',
                        scissors: '<g data-name="Layer 2"><g data-name="scissors"><rect width="24" height="24" opacity="0"/><path d="M20.21 5.71a1 1 0 1 0-1.42-1.42l-6.28 6.31-3.3-3.31A3 3 0 0 0 9.5 6a3 3 0 1 0-3 3 3 3 0 0 0 1.29-.3L11.1 12l-3.29 3.3A3 3 0 0 0 6.5 15a3 3 0 1 0 3 3 3 3 0 0 0-.29-1.26zM6.5 7a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm0 12a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M15.21 13.29a1 1 0 0 0-1.42 1.42l5 5a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        search: '<g data-name="Layer 2"><g data-name="search"><rect width="24" height="24" opacity="0"/><path d="M20.71 19.29l-3.4-3.39A7.92 7.92 0 0 0 19 11a8 8 0 1 0-8 8 7.92 7.92 0 0 0 4.9-1.69l3.39 3.4a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM5 11a6 6 0 1 1 6 6 6 6 0 0 1-6-6z"/></g></g>',
                        "settings-2": '<g data-name="Layer 2"><g data-name="settings-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><circle cx="12" cy="12" r="1.5"/><path d="M20.32 9.37h-1.09c-.14 0-.24-.11-.3-.26a.34.34 0 0 1 0-.37l.81-.74a1.63 1.63 0 0 0 .5-1.18 1.67 1.67 0 0 0-.5-1.19L18.4 4.26a1.67 1.67 0 0 0-2.37 0l-.77.74a.38.38 0 0 1-.41 0 .34.34 0 0 1-.22-.29V3.68A1.68 1.68 0 0 0 13 2h-1.94a1.69 1.69 0 0 0-1.69 1.68v1.09c0 .14-.11.24-.26.3a.34.34 0 0 1-.37 0L8 4.26a1.72 1.72 0 0 0-1.19-.5 1.65 1.65 0 0 0-1.18.5L4.26 5.6a1.67 1.67 0 0 0 0 2.4l.74.74a.38.38 0 0 1 0 .41.34.34 0 0 1-.29.22H3.68A1.68 1.68 0 0 0 2 11.05v1.89a1.69 1.69 0 0 0 1.68 1.69h1.09c.14 0 .24.11.3.26a.34.34 0 0 1 0 .37l-.81.74a1.72 1.72 0 0 0-.5 1.19 1.66 1.66 0 0 0 .5 1.19l1.34 1.36a1.67 1.67 0 0 0 2.37 0l.77-.74a.38.38 0 0 1 .41 0 .34.34 0 0 1 .22.29v1.09A1.68 1.68 0 0 0 11.05 22h1.89a1.69 1.69 0 0 0 1.69-1.68v-1.09c0-.14.11-.24.26-.3a.34.34 0 0 1 .37 0l.76.77a1.72 1.72 0 0 0 1.19.5 1.65 1.65 0 0 0 1.18-.5l1.34-1.34a1.67 1.67 0 0 0 0-2.37l-.73-.73a.34.34 0 0 1 0-.37.34.34 0 0 1 .29-.22h1.09A1.68 1.68 0 0 0 22 13v-1.94a1.69 1.69 0 0 0-1.68-1.69zM12 15.5a3.5 3.5 0 1 1 3.5-3.5 3.5 3.5 0 0 1-3.5 3.5z"/></g></g>',
                        settings: '<g data-name="Layer 2"><g data-name="settings"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="12" r="1.5"/><path d="M21.89 10.32L21.1 7.8a2.26 2.26 0 0 0-2.88-1.51l-.34.11a1.74 1.74 0 0 1-1.59-.26l-.11-.08a1.76 1.76 0 0 1-.69-1.43v-.28a2.37 2.37 0 0 0-.68-1.68 2.26 2.26 0 0 0-1.6-.67h-2.55a2.32 2.32 0 0 0-2.29 2.33v.24a1.94 1.94 0 0 1-.73 1.51l-.13.1a1.93 1.93 0 0 1-1.78.29 2.14 2.14 0 0 0-1.68.12 2.18 2.18 0 0 0-1.12 1.33l-.82 2.6a2.34 2.34 0 0 0 1.48 2.94h.16a1.83 1.83 0 0 1 1.12 1.22l.06.16a2.06 2.06 0 0 1-.23 1.86 2.37 2.37 0 0 0 .49 3.3l2.07 1.57a2.25 2.25 0 0 0 1.35.43A2 2 0 0 0 9 22a2.25 2.25 0 0 0 1.47-1l.23-.33a1.8 1.8 0 0 1 1.43-.77 1.75 1.75 0 0 1 1.5.78l.12.17a2.24 2.24 0 0 0 3.22.53L19 19.86a2.38 2.38 0 0 0 .5-3.23l-.26-.38A2 2 0 0 1 19 14.6a1.89 1.89 0 0 1 1.21-1.28l.2-.07a2.36 2.36 0 0 0 1.48-2.93zM12 15.5a3.5 3.5 0 1 1 3.5-3.5 3.5 3.5 0 0 1-3.5 3.5z"/></g></g>',
                        shake: '<g data-name="Layer 2"><g data-name="shake"><rect width="24" height="24" opacity="0"/><path d="M5.5 18a1 1 0 0 1-.64-.24A8.81 8.81 0 0 1 1.5 11a8.81 8.81 0 0 1 3.36-6.76 1 1 0 1 1 1.28 1.52A6.9 6.9 0 0 0 3.5 11a6.9 6.9 0 0 0 2.64 5.24 1 1 0 0 1 .13 1.4 1 1 0 0 1-.77.36z"/><path d="M12 7a4.09 4.09 0 0 1 1 .14V3a1 1 0 0 0-2 0v4.14A4.09 4.09 0 0 1 12 7z"/><path d="M12 15a4.09 4.09 0 0 1-1-.14V20a1 1 0 0 0 2 0v-5.14a4.09 4.09 0 0 1-1 .14z"/><path d="M16 16a1 1 0 0 1-.77-.36 1 1 0 0 1 .13-1.4A4.28 4.28 0 0 0 17 11a4.28 4.28 0 0 0-1.64-3.24 1 1 0 1 1 1.28-1.52A6.2 6.2 0 0 1 19 11a6.2 6.2 0 0 1-2.36 4.76A1 1 0 0 1 16 16z"/><path d="M8 16a1 1 0 0 1-.64-.24A6.2 6.2 0 0 1 5 11a6.2 6.2 0 0 1 2.36-4.76 1 1 0 1 1 1.28 1.52A4.28 4.28 0 0 0 7 11a4.28 4.28 0 0 0 1.64 3.24 1 1 0 0 1 .13 1.4A1 1 0 0 1 8 16z"/><path d="M18.5 18a1 1 0 0 1-.77-.36 1 1 0 0 1 .13-1.4A6.9 6.9 0 0 0 20.5 11a6.9 6.9 0 0 0-2.64-5.24 1 1 0 1 1 1.28-1.52A8.81 8.81 0 0 1 22.5 11a8.81 8.81 0 0 1-3.36 6.76 1 1 0 0 1-.64.24z"/><path d="M12 12a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm0-1zm0 0zm0 0zm0 0zm0 0zm0 0zm0 0z"/></g></g>',
                        share: '<g data-name="Layer 2"><g data-name="share"><rect width="24" height="24" opacity="0"/><path d="M18 15a3 3 0 0 0-2.1.86L8 12.34V12v-.33l7.9-3.53A3 3 0 1 0 15 6v.34L7.1 9.86a3 3 0 1 0 0 4.28l7.9 3.53V18a3 3 0 1 0 3-3z"/></g></g>',
                        "shield-off": '<g data-name="Layer 2"><g data-name="shield-off"><rect width="24" height="24" opacity="0"/><path d="M3.73 6.56A2 2 0 0 0 3 8.09v.14a15.17 15.17 0 0 0 7.72 13.2l.3.17a2 2 0 0 0 2 0l.3-.17a15.22 15.22 0 0 0 3-2.27z"/><path d="M18.84 16A15.08 15.08 0 0 0 21 8.23v-.14a2 2 0 0 0-1-1.75L13 2.4a2 2 0 0 0-2 0L7.32 4.49z"/><path d="M4.71 3.29a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        shield: '<g data-name="Layer 2"><g data-name="shield"><rect width="24" height="24" opacity="0"/><path d="M12 21.85a2 2 0 0 1-1-.25l-.3-.17A15.17 15.17 0 0 1 3 8.23v-.14a2 2 0 0 1 1-1.75l7-3.94a2 2 0 0 1 2 0l7 3.94a2 2 0 0 1 1 1.75v.14a15.17 15.17 0 0 1-7.72 13.2l-.3.17a2 2 0 0 1-.98.25z"/></g></g>',
                        "shopping-bag": '<g data-name="Layer 2"><g data-name="shopping-bag"><rect width="24" height="24" opacity="0"/><path d="M20.12 6.71l-2.83-2.83A3 3 0 0 0 15.17 3H8.83a3 3 0 0 0-2.12.88L3.88 6.71A3 3 0 0 0 3 8.83V18a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V8.83a3 3 0 0 0-.88-2.12zM12 16a4 4 0 0 1-4-4 1 1 0 0 1 2 0 2 2 0 0 0 4 0 1 1 0 0 1 2 0 4 4 0 0 1-4 4zM6.41 7l1.71-1.71A1.05 1.05 0 0 1 8.83 5h6.34a1.05 1.05 0 0 1 .71.29L17.59 7z"/></g></g>',
                        "shopping-cart": '<g data-name="Layer 2"><g data-name="shopping-cart"><rect width="24" height="24" opacity="0"/><path d="M21.08 7a2 2 0 0 0-1.7-1H6.58L6 3.74A1 1 0 0 0 5 3H3a1 1 0 0 0 0 2h1.24L7 15.26A1 1 0 0 0 8 16h9a1 1 0 0 0 .89-.55l3.28-6.56A2 2 0 0 0 21.08 7z"/><circle cx="7.5" cy="19.5" r="1.5"/><circle cx="17.5" cy="19.5" r="1.5"/></g></g>',
                        "shuffle-2": '<g data-name="Layer 2"><g data-name="shuffle-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18.71 14.29a1 1 0 0 0-1.42 1.42l.29.29H16a4 4 0 0 1 0-8h1.59l-.3.29a1 1 0 0 0 0 1.42A1 1 0 0 0 18 10a1 1 0 0 0 .71-.29l2-2A1 1 0 0 0 21 7a1 1 0 0 0-.29-.71l-2-2a1 1 0 0 0-1.42 1.42l.29.29H16a6 6 0 0 0-5 2.69A6 6 0 0 0 6 6H4a1 1 0 0 0 0 2h2a4 4 0 0 1 0 8H4a1 1 0 0 0 0 2h2a6 6 0 0 0 5-2.69A6 6 0 0 0 16 18h1.59l-.3.29a1 1 0 0 0 0 1.42A1 1 0 0 0 18 20a1 1 0 0 0 .71-.29l2-2A1 1 0 0 0 21 17a1 1 0 0 0-.29-.71z"/></g></g>',
                        shuffle: '<g data-name="Layer 2"><g data-name="shuffle"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 9.31a1 1 0 0 0 1 1 1 1 0 0 0 1-1V5a1 1 0 0 0-1-1h-4.3a1 1 0 0 0-1 1 1 1 0 0 0 1 1h1.89L12 10.59 6.16 4.76a1 1 0 0 0-1.41 1.41L10.58 12l-6.29 6.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L18 7.42z"/><path d="M19 13.68a1 1 0 0 0-1 1v1.91l-2.78-2.79a1 1 0 0 0-1.42 1.42L16.57 18h-1.88a1 1 0 0 0 0 2H19a1 1 0 0 0 1-1.11v-4.21a1 1 0 0 0-1-1z"/></g></g>',
                        "skip-back": '<g data-name="Layer 2"><g data-name="skip-back"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M16.45 6.2a2.1 2.1 0 0 0-2.21.26l-5.1 4.21-.14.15V7a1 1 0 0 0-2 0v10a1 1 0 0 0 2 0v-3.82l.14.15 5.1 4.21a2.06 2.06 0 0 0 1.3.46 2.23 2.23 0 0 0 .91-.2 1.76 1.76 0 0 0 1.05-1.59V7.79a1.76 1.76 0 0 0-1.05-1.59z"/></g></g>',
                        "skip-forward": '<g data-name="Layer 2"><g data-name="skip-forward"><rect width="24" height="24" opacity="0"/><path d="M16 6a1 1 0 0 0-1 1v3.82l-.14-.15-5.1-4.21a2.1 2.1 0 0 0-2.21-.26 1.76 1.76 0 0 0-1 1.59v8.42a1.76 1.76 0 0 0 1 1.59 2.23 2.23 0 0 0 .91.2 2.06 2.06 0 0 0 1.3-.46l5.1-4.21.14-.15V17a1 1 0 0 0 2 0V7a1 1 0 0 0-1-1z"/></g></g>',
                        slash: '<g data-name="Layer 2"><g data-name="slash"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm8 10a7.92 7.92 0 0 1-1.69 4.9L7.1 5.69A7.92 7.92 0 0 1 12 4a8 8 0 0 1 8 8zM4 12a7.92 7.92 0 0 1 1.69-4.9L16.9 18.31A7.92 7.92 0 0 1 12 20a8 8 0 0 1-8-8z"/></g></g>',
                        smartphone: '<g data-name="Layer 2"><g data-name="smartphone"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M17 2H7a3 3 0 0 0-3 3v14a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V5a3 3 0 0 0-3-3zm-5 16a1.5 1.5 0 1 1 1.5-1.5A1.5 1.5 0 0 1 12 18zm2.5-10h-5a1 1 0 0 1 0-2h5a1 1 0 0 1 0 2z"/></g></g>',
                        speaker: '<g data-name="Layer 2"><g data-name="speaker"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><circle cx="12" cy="15.5" r="1.5"/><circle cx="12" cy="8" r="1"/><path d="M17 2H7a3 3 0 0 0-3 3v14a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V5a3 3 0 0 0-3-3zm-5 3a3 3 0 1 1-3 3 3 3 0 0 1 3-3zm0 14a3.5 3.5 0 1 1 3.5-3.5A3.5 3.5 0 0 1 12 19z"/></g></g>',
                        square: '<g data-name="Layer 2"><g data-name="square"><rect width="24" height="24" opacity="0"/><path d="M18 21H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1z"/></g></g>',
                        star: '<g data-name="Layer 2"><g data-name="star"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M17.56 21a1 1 0 0 1-.46-.11L12 18.22l-5.1 2.67a1 1 0 0 1-1.45-1.06l1-5.63-4.12-4a1 1 0 0 1-.25-1 1 1 0 0 1 .81-.68l5.7-.83 2.51-5.13a1 1 0 0 1 1.8 0l2.54 5.12 5.7.83a1 1 0 0 1 .81.68 1 1 0 0 1-.25 1l-4.12 4 1 5.63a1 1 0 0 1-.4 1 1 1 0 0 1-.62.18z"/></g></g>',
                        "stop-circle": '<g data-name="Layer 2"><g data-name="stop-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm4 12.75A1.25 1.25 0 0 1 14.75 16h-5.5A1.25 1.25 0 0 1 8 14.75v-5.5A1.25 1.25 0 0 1 9.25 8h5.5A1.25 1.25 0 0 1 16 9.25z"/><rect x="10" y="10" width="4" height="4"/></g></g>',
                        sun: '<g data-name="Layer 2"><g data-name="sun"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 6a1 1 0 0 0 1-1V3a1 1 0 0 0-2 0v2a1 1 0 0 0 1 1z"/><path d="M21 11h-2a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2z"/><path d="M6 12a1 1 0 0 0-1-1H3a1 1 0 0 0 0 2h2a1 1 0 0 0 1-1z"/><path d="M6.22 5a1 1 0 0 0-1.39 1.47l1.44 1.39a1 1 0 0 0 .73.28 1 1 0 0 0 .72-.31 1 1 0 0 0 0-1.41z"/><path d="M17 8.14a1 1 0 0 0 .69-.28l1.44-1.39A1 1 0 0 0 17.78 5l-1.44 1.42a1 1 0 0 0 0 1.41 1 1 0 0 0 .66.31z"/><path d="M12 18a1 1 0 0 0-1 1v2a1 1 0 0 0 2 0v-2a1 1 0 0 0-1-1z"/><path d="M17.73 16.14a1 1 0 0 0-1.39 1.44L17.78 19a1 1 0 0 0 .69.28 1 1 0 0 0 .72-.3 1 1 0 0 0 0-1.42z"/><path d="M6.27 16.14l-1.44 1.39a1 1 0 0 0 0 1.42 1 1 0 0 0 .72.3 1 1 0 0 0 .67-.25l1.44-1.39a1 1 0 0 0-1.39-1.44z"/><path d="M12 8a4 4 0 1 0 4 4 4 4 0 0 0-4-4z"/></g></g>',
                        swap: '<g data-name="Layer 2"><g data-name="swap"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M4 9h13l-1.6 1.2a1 1 0 0 0-.2 1.4 1 1 0 0 0 .8.4 1 1 0 0 0 .6-.2l4-3a1 1 0 0 0 0-1.59l-3.86-3a1 1 0 0 0-1.23 1.58L17.08 7H4a1 1 0 0 0 0 2z"/><path d="M20 16H7l1.6-1.2a1 1 0 0 0-1.2-1.6l-4 3a1 1 0 0 0 0 1.59l3.86 3a1 1 0 0 0 .61.21 1 1 0 0 0 .79-.39 1 1 0 0 0-.17-1.4L6.92 18H20a1 1 0 0 0 0-2z"/></g></g>',
                        sync: '<g data-name="Layer 2"><g data-name="sync"><rect width="24" height="24" opacity="0"/><path d="M21.66 10.37a.62.62 0 0 0 .07-.19l.75-4a1 1 0 0 0-2-.36l-.37 2a9.22 9.22 0 0 0-16.58.84 1 1 0 0 0 .55 1.3 1 1 0 0 0 1.31-.55A7.08 7.08 0 0 1 12.07 5a7.17 7.17 0 0 1 6.24 3.58l-1.65-.27a1 1 0 1 0-.32 2l4.25.71h.16a.93.93 0 0 0 .34-.06.33.33 0 0 0 .1-.06.78.78 0 0 0 .2-.11l.08-.1a1.07 1.07 0 0 0 .14-.16.58.58 0 0 0 .05-.16z"/><path d="M19.88 14.07a1 1 0 0 0-1.31.56A7.08 7.08 0 0 1 11.93 19a7.17 7.17 0 0 1-6.24-3.58l1.65.27h.16a1 1 0 0 0 .16-2L3.41 13a.91.91 0 0 0-.33 0H3a1.15 1.15 0 0 0-.32.14 1 1 0 0 0-.18.18l-.09.1a.84.84 0 0 0-.07.19.44.44 0 0 0-.07.17l-.75 4a1 1 0 0 0 .8 1.22h.18a1 1 0 0 0 1-.82l.37-2a9.22 9.22 0 0 0 16.58-.83 1 1 0 0 0-.57-1.28z"/></g></g>',
                        text: '<g data-name="Layer 2"><g data-name="text"><rect width="24" height="24" opacity="0"/><path d="M20 4H4a1 1 0 0 0-1 1v3a1 1 0 0 0 2 0V6h6v13H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2h-2V6h6v2a1 1 0 0 0 2 0V5a1 1 0 0 0-1-1z"/></g></g>',
                        "thermometer-minus": '<g data-name="Layer 2"><g data-name="thermometer-minus"><rect width="24" height="24" opacity="0"/><rect x="2" y="5" width="6" height="2" rx="1" ry="1"/><path d="M14 22a5 5 0 0 1-3-9V5a3 3 0 0 1 3-3 3 3 0 0 1 3 3v8a5 5 0 0 1-3 9zm1-12.46V5a.93.93 0 0 0-.29-.69A1 1 0 0 0 14 4a1 1 0 0 0-1 1v4.54z"/></g></g>',
                        "thermometer-plus": '<g data-name="Layer 2"><g data-name="thermometer-plus"><rect width="24" height="24" opacity="0"/><rect x="2" y="5" width="6" height="2" rx="1" ry="1"/><rect x="2" y="5" width="6" height="2" rx="1" ry="1" transform="rotate(-90 5 6)"/><path d="M14 22a5 5 0 0 1-3-9V5a3 3 0 0 1 3-3 3 3 0 0 1 3 3v8a5 5 0 0 1-3 9zm1-12.46V5a.93.93 0 0 0-.29-.69A1 1 0 0 0 14 4a1 1 0 0 0-1 1v4.54z"/></g></g>',
                        thermometer: '<g data-name="Layer 2"><g data-name="thermometer"><rect width="24" height="24" opacity="0"/><path d="M12 22a5 5 0 0 1-3-9V5a3 3 0 0 1 3-3 3 3 0 0 1 3 3v8a5 5 0 0 1-3 9zm1-12.46V5a.93.93 0 0 0-.29-.69A1 1 0 0 0 12 4a1 1 0 0 0-1 1v4.54z"/></g></g>',
                        "toggle-left": '<g data-name="Layer 2"><g data-name="toggle-left"><rect x=".02" y=".02" width="23.97" height="23.97" transform="rotate(179.92 12.002 11.998)" opacity="0"/><path d="M15 5H9a7 7 0 0 0 0 14h6a7 7 0 0 0 0-14zM9 15a3 3 0 1 1 3-3 3 3 0 0 1-3 3z"/><path d="M9 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/></g></g>',
                        "toggle-right": '<g data-name="Layer 2"><g data-name="toggle-right"><rect width="24" height="24" opacity="0"/><circle cx="15" cy="12" r="1"/><path d="M15 5H9a7 7 0 0 0 0 14h6a7 7 0 0 0 0-14zm0 10a3 3 0 1 1 3-3 3 3 0 0 1-3 3z"/></g></g>',
                        "trash-2": '<g data-name="Layer 2"><g data-name="trash-2"><rect width="24" height="24" opacity="0"/><path d="M21 6h-5V4.33A2.42 2.42 0 0 0 13.5 2h-3A2.42 2.42 0 0 0 8 4.33V6H3a1 1 0 0 0 0 2h1v11a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V8h1a1 1 0 0 0 0-2zM10 16a1 1 0 0 1-2 0v-4a1 1 0 0 1 2 0zm0-11.67c0-.16.21-.33.5-.33h3c.29 0 .5.17.5.33V6h-4zM16 16a1 1 0 0 1-2 0v-4a1 1 0 0 1 2 0z"/></g></g>',
                        trash: '<g data-name="Layer 2"><g data-name="trash"><rect width="24" height="24" opacity="0"/><path d="M21 6h-5V4.33A2.42 2.42 0 0 0 13.5 2h-3A2.42 2.42 0 0 0 8 4.33V6H3a1 1 0 0 0 0 2h1v11a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V8h1a1 1 0 0 0 0-2zM10 4.33c0-.16.21-.33.5-.33h3c.29 0 .5.17.5.33V6h-4z"/></g></g>',
                        "trending-down": '<g data-name="Layer 2"><g data-name="trending-down"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M21 12a1 1 0 0 0-2 0v2.3l-4.24-5a1 1 0 0 0-1.27-.21L9.22 11.7 4.77 6.36a1 1 0 1 0-1.54 1.28l5 6a1 1 0 0 0 1.28.22l4.28-2.57 4 4.71H15a1 1 0 0 0 0 2h5a1.1 1.1 0 0 0 .36-.07l.14-.08a1.19 1.19 0 0 0 .15-.09.75.75 0 0 0 .14-.17 1.1 1.1 0 0 0 .09-.14.64.64 0 0 0 .05-.17A.78.78 0 0 0 21 17z"/></g></g>',
                        "trending-up": '<g data-name="Layer 2"><g data-name="trending-up"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M21 7a.78.78 0 0 0 0-.21.64.64 0 0 0-.05-.17 1.1 1.1 0 0 0-.09-.14.75.75 0 0 0-.14-.17l-.12-.07a.69.69 0 0 0-.19-.1h-.2A.7.7 0 0 0 20 6h-5a1 1 0 0 0 0 2h2.83l-4 4.71-4.32-2.57a1 1 0 0 0-1.28.22l-5 6a1 1 0 0 0 .13 1.41A1 1 0 0 0 4 18a1 1 0 0 0 .77-.36l4.45-5.34 4.27 2.56a1 1 0 0 0 1.27-.21L19 9.7V12a1 1 0 0 0 2 0V7z"/></g></g>',
                        tv: '<g data-name="Layer 2"><g data-name="tv"><rect width="24" height="24" opacity="0"/><path d="M18 6h-3.59l2.3-2.29a1 1 0 1 0-1.42-1.42L12 5.59l-3.29-3.3a1 1 0 1 0-1.42 1.42L9.59 6H6a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V9a3 3 0 0 0-3-3zm1 13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1z"/></g></g>',
                        twitter: '<g data-name="Layer 2"><g data-name="twitter"><polyline points="0 0 24 0 24 24 0 24" opacity="0"/><path d="M8.08 20A11.07 11.07 0 0 0 19.52 9 8.09 8.09 0 0 0 21 6.16a.44.44 0 0 0-.62-.51 1.88 1.88 0 0 1-2.16-.38 3.89 3.89 0 0 0-5.58-.17A4.13 4.13 0 0 0 11.49 9C8.14 9.2 5.84 7.61 4 5.43a.43.43 0 0 0-.75.24 9.68 9.68 0 0 0 4.6 10.05A6.73 6.73 0 0 1 3.38 18a.45.45 0 0 0-.14.84A11 11 0 0 0 8.08 20"/></g></g>',
                        umbrella: '<g data-name="Layer 2"><g data-name="umbrella"><rect width="24" height="24" opacity="0"/><path d="M12 2A10 10 0 0 0 2 12a1 1 0 0 0 1 1h8v6a3 3 0 0 0 6 0 1 1 0 0 0-2 0 1 1 0 0 1-2 0v-6h8a1 1 0 0 0 1-1A10 10 0 0 0 12 2z"/></g></g>',
                        undo: '<g data-name="Layer 2"><g data-name="undo"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M20.22 21a1 1 0 0 1-1-.76 8.91 8.91 0 0 0-7.8-6.69v1.12a1.78 1.78 0 0 1-1.09 1.64A2 2 0 0 1 8.18 16l-5.06-4.41a1.76 1.76 0 0 1 0-2.68l5.06-4.42a2 2 0 0 1 2.18-.3 1.78 1.78 0 0 1 1.09 1.64V7A10.89 10.89 0 0 1 21.5 17.75a10.29 10.29 0 0 1-.31 2.49 1 1 0 0 1-1 .76z"/></g></g>',
                        unlock: '<g data-name="Layer 2"><g data-name="unlock"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="15" r="1"/><path d="M17 8h-7V6a2 2 0 0 1 4 0 1 1 0 0 0 2 0 4 4 0 0 0-8 0v2H7a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-8a3 3 0 0 0-3-3zm-5 10a3 3 0 1 1 3-3 3 3 0 0 1-3 3z"/></g></g>',
                        upload: '<g data-name="Layer 2"><g data-name="upload"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><rect x="4" y="4" width="16" height="2" rx="1" ry="1" transform="rotate(180 12 5)"/><rect x="17" y="5" width="4" height="2" rx="1" ry="1" transform="rotate(90 19 6)"/><rect x="3" y="5" width="4" height="2" rx="1" ry="1" transform="rotate(90 5 6)"/><path d="M8 14a1 1 0 0 1-.8-.4 1 1 0 0 1 .2-1.4l4-3a1 1 0 0 1 1.18 0l4 2.82a1 1 0 0 1 .24 1.39 1 1 0 0 1-1.4.24L12 11.24 8.6 13.8a1 1 0 0 1-.6.2z"/><path d="M12 21a1 1 0 0 1-1-1v-8a1 1 0 0 1 2 0v8a1 1 0 0 1-1 1z"/></g></g>',
                        "video-off": '<g data-name="Layer 2"><g data-name="video-off"><rect width="24" height="24" opacity="0"/><path d="M14.22 17.05L4.88 7.71 3.12 6 3 5.8A3 3 0 0 0 2 8v8a3 3 0 0 0 3 3h9a2.94 2.94 0 0 0 1.66-.51z"/><path d="M21 7.15a1.7 1.7 0 0 0-1.85.3l-2.15 2V8a3 3 0 0 0-3-3H7.83l1.29 1.29 6.59 6.59 2 2 2 2a1.73 1.73 0 0 0 .6.11 1.68 1.68 0 0 0 .69-.15 1.6 1.6 0 0 0 1-1.48V8.63a1.6 1.6 0 0 0-1-1.48z"/><path d="M17 15.59l-2-2L8.41 7l-2-2-1.7-1.71a1 1 0 0 0-1.42 1.42l.54.53L5.59 7l9.34 9.34 1.46 1.46 2.9 2.91a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        video: '<g data-name="Layer 2"><g data-name="video"><rect width="24" height="24" opacity="0"/><path d="M21 7.15a1.7 1.7 0 0 0-1.85.3l-2.15 2V8a3 3 0 0 0-3-3H5a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h9a3 3 0 0 0 3-3v-1.45l2.16 2a1.74 1.74 0 0 0 1.16.45 1.68 1.68 0 0 0 .69-.15 1.6 1.6 0 0 0 1-1.48V8.63A1.6 1.6 0 0 0 21 7.15z"/></g></g>',
                        "volume-down": '<g data-name="Layer 2"><g data-name="volume-down"><rect width="24" height="24" opacity="0"/><path d="M20.78 8.37a1 1 0 1 0-1.56 1.26 4 4 0 0 1 0 4.74A1 1 0 0 0 20 16a1 1 0 0 0 .78-.37 6 6 0 0 0 0-7.26z"/><path d="M16.47 3.12a1 1 0 0 0-1 0L9 7.57H4a1 1 0 0 0-1 1v6.86a1 1 0 0 0 1 1h5l6.41 4.4A1.06 1.06 0 0 0 16 21a1 1 0 0 0 1-1V4a1 1 0 0 0-.53-.88z"/></g></g>',
                        "volume-mute": '<g data-name="Layer 2"><g data-name="volume-mute"><rect width="24" height="24" opacity="0"/><path d="M17 21a1.06 1.06 0 0 1-.57-.17L10 16.43H5a1 1 0 0 1-1-1V8.57a1 1 0 0 1 1-1h5l6.41-4.4A1 1 0 0 1 18 4v16a1 1 0 0 1-1 1z"/></g></g>',
                        "volume-off": '<g data-name="Layer 2"><g data-name="volume-off"><rect width="24" height="24" opacity="0"/><path d="M16.91 14.08l1.44 1.44a6 6 0 0 0-.07-7.15 1 1 0 1 0-1.56 1.26 4 4 0 0 1 .19 4.45z"/><path d="M21 12a6.51 6.51 0 0 1-1.78 4.39l1.42 1.42A8.53 8.53 0 0 0 23 12a8.75 8.75 0 0 0-3.36-6.77 1 1 0 1 0-1.28 1.54A6.8 6.8 0 0 1 21 12z"/><path d="M15 12.17V4a1 1 0 0 0-1.57-.83L9 6.2z"/><path d="M4.74 7.57H2a1 1 0 0 0-1 1v6.86a1 1 0 0 0 1 1h5l6.41 4.4A1.06 1.06 0 0 0 14 21a1 1 0 0 0 1-1v-2.17z"/><path d="M4.71 3.29a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        "volume-up": '<g data-name="Layer 2"><g data-name="volume-up"><rect width="24" height="24" opacity="0"/><path d="M18.28 8.37a1 1 0 1 0-1.56 1.26 4 4 0 0 1 0 4.74A1 1 0 0 0 17.5 16a1 1 0 0 0 .78-.37 6 6 0 0 0 0-7.26z"/><path d="M19.64 5.23a1 1 0 1 0-1.28 1.54A6.8 6.8 0 0 1 21 12a6.8 6.8 0 0 1-2.64 5.23 1 1 0 0 0-.13 1.41A1 1 0 0 0 19 19a1 1 0 0 0 .64-.23A8.75 8.75 0 0 0 23 12a8.75 8.75 0 0 0-3.36-6.77z"/><path d="M14.47 3.12a1 1 0 0 0-1 0L7 7.57H2a1 1 0 0 0-1 1v6.86a1 1 0 0 0 1 1h5l6.41 4.4A1.06 1.06 0 0 0 14 21a1 1 0 0 0 1-1V4a1 1 0 0 0-.53-.88z"/></g></g>',
                        "wifi-off": '<g data-name="Layer 2"><g data-name="wifi-off"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="19" r="1"/><path d="M12.44 11l-1.9-1.89-2.46-2.44-1.55-1.55-1.82-1.83a1 1 0 0 0-1.42 1.42l1.38 1.37 1.46 1.46 2.23 2.24 1.55 1.54 2.74 2.74 2.79 2.8 3.85 3.85a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M21.72 7.93A13.93 13.93 0 0 0 12 4a14.1 14.1 0 0 0-4.44.73l1.62 1.62a11.89 11.89 0 0 1 11.16 3 1 1 0 0 0 .69.28 1 1 0 0 0 .72-.31 1 1 0 0 0-.03-1.39z"/><path d="M3.82 6.65a14.32 14.32 0 0 0-1.54 1.28 1 1 0 0 0 1.38 1.44 13.09 13.09 0 0 1 1.6-1.29z"/><path d="M17 13.14a1 1 0 0 0 .71.3 1 1 0 0 0 .72-1.69A9 9 0 0 0 12 9h-.16l2.35 2.35A7 7 0 0 1 17 13.14z"/><path d="M7.43 10.26a8.8 8.8 0 0 0-1.9 1.49A1 1 0 0 0 7 13.14a7.3 7.3 0 0 1 2-1.41z"/><path d="M8.53 15.4a1 1 0 1 0 1.39 1.44 3.06 3.06 0 0 1 3.84-.25l-2.52-2.52a5 5 0 0 0-2.71 1.33z"/></g></g>',
                        wifi: '<g data-name="Layer 2"><g data-name="wifi"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="19" r="1"/><path d="M12 14a5 5 0 0 0-3.47 1.4 1 1 0 1 0 1.39 1.44 3.08 3.08 0 0 1 4.16 0 1 1 0 1 0 1.39-1.44A5 5 0 0 0 12 14z"/><path d="M12 9a9 9 0 0 0-6.47 2.75A1 1 0 0 0 7 13.14a7 7 0 0 1 10.08 0 1 1 0 0 0 .71.3 1 1 0 0 0 .72-1.69A9 9 0 0 0 12 9z"/><path d="M21.72 7.93a14 14 0 0 0-19.44 0 1 1 0 0 0 1.38 1.44 12 12 0 0 1 16.68 0 1 1 0 0 0 .69.28 1 1 0 0 0 .72-.31 1 1 0 0 0-.03-1.41z"/></g></g>',
                        "activity-outline": '<g data-name="Layer 2"><g data-name="activity"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M14.33 20h-.21a2 2 0 0 1-1.76-1.58L9.68 6l-2.76 6.4A1 1 0 0 1 6 13H3a1 1 0 0 1 0-2h2.34l2.51-5.79a2 2 0 0 1 3.79.38L14.32 18l2.76-6.38A1 1 0 0 1 18 11h3a1 1 0 0 1 0 2h-2.34l-2.51 5.79A2 2 0 0 1 14.33 20z"/></g></g>',
                        "alert-circle-outline": '<g data-name="Layer 2"><g data-name="alert-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><circle cx="12" cy="16" r="1"/><path d="M12 7a1 1 0 0 0-1 1v5a1 1 0 0 0 2 0V8a1 1 0 0 0-1-1z"/></g></g>',
                        "alert-triangle-outline": '<g data-name="Layer 2"><g data-name="alert-triangle"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M22.56 16.3L14.89 3.58a3.43 3.43 0 0 0-5.78 0L1.44 16.3a3 3 0 0 0-.05 3A3.37 3.37 0 0 0 4.33 21h15.34a3.37 3.37 0 0 0 2.94-1.66 3 3 0 0 0-.05-3.04zm-1.7 2.05a1.31 1.31 0 0 1-1.19.65H4.33a1.31 1.31 0 0 1-1.19-.65 1 1 0 0 1 0-1l7.68-12.73a1.48 1.48 0 0 1 2.36 0l7.67 12.72a1 1 0 0 1 .01 1.01z"/><circle cx="12" cy="16" r="1"/><path d="M12 8a1 1 0 0 0-1 1v4a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z"/></g></g>',
                        "archive-outline": '<g data-name="Layer 2"><g data-name="archive"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M21 6a3 3 0 0 0-3-3H6a3 3 0 0 0-2 5.22V18a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V8.22A3 3 0 0 0 21 6zM6 5h12a1 1 0 0 1 0 2H6a1 1 0 0 1 0-2zm12 13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V9h12z"/><rect x="9" y="12" width="6" height="2" rx=".87" ry=".87"/></g></g>',
                        "arrow-back-outline": '<g data-name="Layer 2"><g data-name="arrow-back"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M19 11H7.14l3.63-4.36a1 1 0 1 0-1.54-1.28l-5 6a1.19 1.19 0 0 0-.09.15c0 .05 0 .08-.07.13A1 1 0 0 0 4 12a1 1 0 0 0 .07.36c0 .05 0 .08.07.13a1.19 1.19 0 0 0 .09.15l5 6A1 1 0 0 0 10 19a1 1 0 0 0 .64-.23 1 1 0 0 0 .13-1.41L7.14 13H19a1 1 0 0 0 0-2z"/></g></g>',
                        "arrow-circle-down-outline": '<g data-name="Layer 2"><g data-name="arrow-circle-down"><rect width="24" height="24" opacity="0"/><path d="M14.31 12.41L13 13.66V8a1 1 0 0 0-2 0v5.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3a1 1 0 0 0 .33.21.94.94 0 0 0 .76 0 .54.54 0 0 0 .16-.1.49.49 0 0 0 .15-.1l3-2.86a1 1 0 0 0-1.38-1.45z"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/></g></g>',
                        "arrow-circle-left-outline": '<g data-name="Layer 2"><g data-name="arrow-circle-left"><rect width="24" height="24" opacity="0"/><path d="M16 11h-5.66l1.25-1.31a1 1 0 0 0-1.45-1.38l-2.86 3a1 1 0 0 0-.09.13.72.72 0 0 0-.11.19.88.88 0 0 0-.06.28L7 12a1 1 0 0 0 .08.38 1 1 0 0 0 .21.32l3 3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L10.41 13H16a1 1 0 0 0 0-2z"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/></g></g>',
                        "arrow-circle-right-outline": '<g data-name="Layer 2"><g data-name="arrow-circle-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M17 12v-.09a.88.88 0 0 0-.06-.28.72.72 0 0 0-.11-.19 1 1 0 0 0-.09-.13l-2.86-3a1 1 0 0 0-1.45 1.38L13.66 11H8a1 1 0 0 0 0 2h5.59l-1.3 1.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l3-3a1 1 0 0 0 .21-.32A1 1 0 0 0 17 12z"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/></g></g>',
                        "arrow-circle-up-outline": '<g data-name="Layer 2"><g data-name="arrow-circle-up"><rect width="24" height="24" opacity="0"/><path d="M12.71 7.29a1 1 0 0 0-.32-.21A1 1 0 0 0 12 7h-.1a.82.82 0 0 0-.27.06.72.72 0 0 0-.19.11 1 1 0 0 0-.13.09l-3 2.86a1 1 0 0 0 1.38 1.45L11 10.34V16a1 1 0 0 0 2 0v-5.59l1.29 1.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/></g></g>',
                        "arrow-down-outline": '<g data-name="Layer 2"><g data-name="arrow-down"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M12 17a1.72 1.72 0 0 1-1.33-.64l-4.21-5.1a2.1 2.1 0 0 1-.26-2.21A1.76 1.76 0 0 1 7.79 8h8.42a1.76 1.76 0 0 1 1.59 1.05 2.1 2.1 0 0 1-.26 2.21l-4.21 5.1A1.72 1.72 0 0 1 12 17zm-3.91-7L12 14.82 16 10z"/></g></g>',
                        "arrow-downward-outline": '<g data-name="Layer 2"><g data-name="arrow-downward"><rect width="24" height="24" opacity="0"/><path d="M18.77 13.36a1 1 0 0 0-1.41-.13L13 16.86V5a1 1 0 0 0-2 0v11.86l-4.36-3.63a1 1 0 1 0-1.28 1.54l6 5 .15.09.13.07a1 1 0 0 0 .72 0l.13-.07.15-.09 6-5a1 1 0 0 0 .13-1.41z"/></g></g>',
                        "arrow-forward-outline": '<g data-name="Layer 2"><g data-name="arrow-forward"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M5 13h11.86l-3.63 4.36a1 1 0 0 0 1.54 1.28l5-6a1.19 1.19 0 0 0 .09-.15c0-.05.05-.08.07-.13A1 1 0 0 0 20 12a1 1 0 0 0-.07-.36c0-.05-.05-.08-.07-.13a1.19 1.19 0 0 0-.09-.15l-5-6A1 1 0 0 0 14 5a1 1 0 0 0-.64.23 1 1 0 0 0-.13 1.41L16.86 11H5a1 1 0 0 0 0 2z"/></g></g>',
                        "arrow-ios-back-outline": '<g data-name="Layer 2"><g data-name="arrow-ios-back"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M13.83 19a1 1 0 0 1-.78-.37l-4.83-6a1 1 0 0 1 0-1.27l5-6a1 1 0 0 1 1.54 1.28L10.29 12l4.32 5.36a1 1 0 0 1-.78 1.64z"/></g></g>',
                        "arrow-ios-downward-outline": '<g data-name="Layer 2"><g data-name="arrow-ios-downward"><rect width="24" height="24" opacity="0"/><path d="M12 16a1 1 0 0 1-.64-.23l-6-5a1 1 0 1 1 1.28-1.54L12 13.71l5.36-4.32a1 1 0 0 1 1.41.15 1 1 0 0 1-.14 1.46l-6 4.83A1 1 0 0 1 12 16z"/></g></g>',
                        "arrow-ios-forward-outline": '<g data-name="Layer 2"><g data-name="arrow-ios-forward"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M10 19a1 1 0 0 1-.64-.23 1 1 0 0 1-.13-1.41L13.71 12 9.39 6.63a1 1 0 0 1 .15-1.41 1 1 0 0 1 1.46.15l4.83 6a1 1 0 0 1 0 1.27l-5 6A1 1 0 0 1 10 19z"/></g></g>',
                        "arrow-ios-upward-outline": '<g data-name="Layer 2"><g data-name="arrow-ios-upward"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 15a1 1 0 0 1-.64-.23L12 10.29l-5.37 4.32a1 1 0 0 1-1.41-.15 1 1 0 0 1 .15-1.41l6-4.83a1 1 0 0 1 1.27 0l6 5a1 1 0 0 1 .13 1.41A1 1 0 0 1 18 15z"/></g></g>',
                        "arrow-left-outline": '<g data-name="Layer 2"><g data-name="arrow-left"><rect width="24" height="24" opacity="0"/><path d="M13.54 18a2.06 2.06 0 0 1-1.3-.46l-5.1-4.21a1.7 1.7 0 0 1 0-2.66l5.1-4.21a2.1 2.1 0 0 1 2.21-.26 1.76 1.76 0 0 1 1.05 1.59v8.42a1.76 1.76 0 0 1-1.05 1.59 2.23 2.23 0 0 1-.91.2zm-4.86-6l4.82 4V8.09z"/></g></g>',
                        "arrow-right-outline": '<g data-name="Layer 2"><g data-name="arrow-right"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M10.46 18a2.23 2.23 0 0 1-.91-.2 1.76 1.76 0 0 1-1.05-1.59V7.79A1.76 1.76 0 0 1 9.55 6.2a2.1 2.1 0 0 1 2.21.26l5.1 4.21a1.7 1.7 0 0 1 0 2.66l-5.1 4.21a2.06 2.06 0 0 1-1.3.46zm0-10v7.9l4.86-3.9z"/></g></g>',
                        "arrow-up-outline": '<g data-name="Layer 2"><g data-name="arrow-up"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M16.21 16H7.79a1.76 1.76 0 0 1-1.59-1 2.1 2.1 0 0 1 .26-2.21l4.21-5.1a1.76 1.76 0 0 1 2.66 0l4.21 5.1A2.1 2.1 0 0 1 17.8 15a1.76 1.76 0 0 1-1.59 1zM8 14h7.9L12 9.18z"/></g></g>',
                        "arrow-upward-outline": '<g data-name="Layer 2"><g data-name="arrow-upward"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M5.23 10.64a1 1 0 0 0 1.41.13L11 7.14V19a1 1 0 0 0 2 0V7.14l4.36 3.63a1 1 0 1 0 1.28-1.54l-6-5-.15-.09-.13-.07a1 1 0 0 0-.72 0l-.13.07-.15.09-6 5a1 1 0 0 0-.13 1.41z"/></g></g>',
                        "arrowhead-down-outline": '<g data-name="Layer 2"><g data-name="arrowhead-down"><rect width="24" height="24" opacity="0"/><path d="M17.37 12.39L12 16.71l-5.36-4.48a1 1 0 1 0-1.28 1.54l6 5a1 1 0 0 0 1.27 0l6-4.83a1 1 0 0 0 .15-1.41 1 1 0 0 0-1.41-.14z"/><path d="M11.36 11.77a1 1 0 0 0 1.27 0l6-4.83a1 1 0 0 0 .15-1.41 1 1 0 0 0-1.41-.15L12 9.71 6.64 5.23a1 1 0 0 0-1.28 1.54z"/></g></g>',
                        "arrowhead-left-outline": '<g data-name="Layer 2"><g data-name="arrowhead-left"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M11.64 5.23a1 1 0 0 0-1.41.13l-5 6a1 1 0 0 0 0 1.27l4.83 6a1 1 0 0 0 .78.37 1 1 0 0 0 .78-1.63L7.29 12l4.48-5.37a1 1 0 0 0-.13-1.4z"/><path d="M14.29 12l4.48-5.37a1 1 0 0 0-1.54-1.28l-5 6a1 1 0 0 0 0 1.27l4.83 6a1 1 0 0 0 .78.37 1 1 0 0 0 .78-1.63z"/></g></g>',
                        "arrowhead-right-outline": '<g data-name="Layer 2"><g data-name="arrowhead-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M18.78 11.37l-4.78-6a1 1 0 0 0-1.41-.15 1 1 0 0 0-.15 1.41L16.71 12l-4.48 5.37a1 1 0 0 0 .13 1.41A1 1 0 0 0 13 19a1 1 0 0 0 .77-.36l5-6a1 1 0 0 0 .01-1.27z"/><path d="M7 5.37a1 1 0 0 0-1.61 1.26L9.71 12l-4.48 5.36a1 1 0 0 0 .13 1.41A1 1 0 0 0 6 19a1 1 0 0 0 .77-.36l5-6a1 1 0 0 0 0-1.27z"/></g></g>',
                        "arrowhead-up-outline": '<g data-name="Layer 2"><g data-name="arrowhead-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M6.63 11.61L12 7.29l5.37 4.48A1 1 0 0 0 18 12a1 1 0 0 0 .77-.36 1 1 0 0 0-.13-1.41l-6-5a1 1 0 0 0-1.27 0l-6 4.83a1 1 0 0 0-.15 1.41 1 1 0 0 0 1.41.14z"/><path d="M12.64 12.23a1 1 0 0 0-1.27 0l-6 4.83a1 1 0 0 0-.15 1.41 1 1 0 0 0 1.41.15L12 14.29l5.37 4.48A1 1 0 0 0 18 19a1 1 0 0 0 .77-.36 1 1 0 0 0-.13-1.41z"/></g></g>',
                        "at-outline": '<g data-name="Layer 2"><g data-name="at"><rect width="24" height="24" opacity="0"/><path d="M13 2a10 10 0 0 0-5 19.1 10.15 10.15 0 0 0 4 .9 10 10 0 0 0 6.08-2.06 1 1 0 0 0 .19-1.4 1 1 0 0 0-1.41-.19A8 8 0 1 1 12.77 4 8.17 8.17 0 0 1 20 12.22v.68a1.71 1.71 0 0 1-1.78 1.7 1.82 1.82 0 0 1-1.62-1.88V8.4a1 1 0 0 0-1-1 1 1 0 0 0-1 .87 5 5 0 0 0-3.44-1.36A5.09 5.09 0 1 0 15.31 15a3.6 3.6 0 0 0 5.55.61A3.67 3.67 0 0 0 22 12.9v-.68A10.2 10.2 0 0 0 13 2zm-1.82 13.09A3.09 3.09 0 1 1 14.27 12a3.1 3.1 0 0 1-3.09 3.09z"/></g></g>',
                        "attach-2-outline": '<g data-name="Layer 2"><g data-name="attach-2"><rect width="24" height="24" opacity="0"/><path d="M12 22a5.86 5.86 0 0 1-6-5.7V6.13A4.24 4.24 0 0 1 10.33 2a4.24 4.24 0 0 1 4.34 4.13v10.18a2.67 2.67 0 0 1-5.33 0V6.92a1 1 0 0 1 1-1 1 1 0 0 1 1 1v9.39a.67.67 0 0 0 1.33 0V6.13A2.25 2.25 0 0 0 10.33 4 2.25 2.25 0 0 0 8 6.13V16.3a3.86 3.86 0 0 0 4 3.7 3.86 3.86 0 0 0 4-3.7V6.13a1 1 0 1 1 2 0V16.3a5.86 5.86 0 0 1-6 5.7z"/></g></g>',
                        "attach-outline": '<g data-name="Layer 2"><g data-name="attach"><rect width="24" height="24" opacity="0"/><path d="M9.29 21a6.23 6.23 0 0 1-4.43-1.88 6 6 0 0 1-.22-8.49L12 3.2A4.11 4.11 0 0 1 15 2a4.48 4.48 0 0 1 3.19 1.35 4.36 4.36 0 0 1 .15 6.13l-7.4 7.43a2.54 2.54 0 0 1-1.81.75 2.72 2.72 0 0 1-1.95-.82 2.68 2.68 0 0 1-.08-3.77l6.83-6.86a1 1 0 0 1 1.37 1.41l-6.83 6.86a.68.68 0 0 0 .08.95.78.78 0 0 0 .53.23.56.56 0 0 0 .4-.16l7.39-7.43a2.36 2.36 0 0 0-.15-3.31 2.38 2.38 0 0 0-3.27-.15L6.06 12a4 4 0 0 0 .22 5.67 4.22 4.22 0 0 0 3 1.29 3.67 3.67 0 0 0 2.61-1.06l7.39-7.43a1 1 0 1 1 1.42 1.41l-7.39 7.43A5.65 5.65 0 0 1 9.29 21z"/></g></g>',
                        "award-outline": '<g data-name="Layer 2"><g data-name="award"><rect width="24" height="24" opacity="0"/><path d="M19 20.75l-2.31-9A5.94 5.94 0 0 0 18 8 6 6 0 0 0 6 8a5.94 5.94 0 0 0 1.34 3.77L5 20.75a1 1 0 0 0 1.48 1.11l5.33-3.13 5.68 3.14A.91.91 0 0 0 18 22a1 1 0 0 0 1-1.25zM12 4a4 4 0 1 1-4 4 4 4 0 0 1 4-4zm.31 12.71a1 1 0 0 0-1 0l-3.75 2.2L9 13.21a5.94 5.94 0 0 0 5.92 0L16.45 19z"/></g></g>',
                        "backspace-outline": '<g data-name="Layer 2"><g data-name="backspace"><rect width="24" height="24" opacity="0"/><path d="M20.14 4h-9.77a3 3 0 0 0-2 .78l-.1.11-6 7.48a1 1 0 0 0 .11 1.37l6 5.48a3 3 0 0 0 2 .78h9.77A1.84 1.84 0 0 0 22 18.18V5.82A1.84 1.84 0 0 0 20.14 4zM20 18h-9.63a1 1 0 0 1-.67-.26l-5.33-4.85 5.38-6.67a1 1 0 0 1 .62-.22H20z"/><path d="M11.29 14.71a1 1 0 0 0 1.42 0l1.29-1.3 1.29 1.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L15.41 12l1.3-1.29a1 1 0 0 0-1.42-1.42L14 10.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l1.3 1.29-1.3 1.29a1 1 0 0 0 0 1.42z"/></g></g>',
                        "bar-chart-2-outline": '<g data-name="Layer 2"><g data-name="bar-chart-2"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M12 8a1 1 0 0 0-1 1v11a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z"/><path d="M19 4a1 1 0 0 0-1 1v15a1 1 0 0 0 2 0V5a1 1 0 0 0-1-1z"/><path d="M5 12a1 1 0 0 0-1 1v7a1 1 0 0 0 2 0v-7a1 1 0 0 0-1-1z"/></g></g>',
                        "bar-chart-outline": '<g data-name="Layer 2"><g data-name="bar-chart"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M12 4a1 1 0 0 0-1 1v15a1 1 0 0 0 2 0V5a1 1 0 0 0-1-1z"/><path d="M19 12a1 1 0 0 0-1 1v7a1 1 0 0 0 2 0v-7a1 1 0 0 0-1-1z"/><path d="M5 8a1 1 0 0 0-1 1v11a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z"/></g></g>',
                        "battery-outline": '<g data-name="Layer 2"><g data-name="battery"><rect width="24" height="24" opacity="0"/><path d="M15.83 6H4.17A2.31 2.31 0 0 0 2 8.43v7.14A2.31 2.31 0 0 0 4.17 18h11.66A2.31 2.31 0 0 0 18 15.57V8.43A2.31 2.31 0 0 0 15.83 6zm.17 9.57a.52.52 0 0 1-.17.43H4.18a.5.5 0 0 1-.18-.43V8.43A.53.53 0 0 1 4.17 8h11.65a.5.5 0 0 1 .18.43z"/><path d="M21 9a1 1 0 0 0-1 1v4a1 1 0 0 0 2 0v-4a1 1 0 0 0-1-1z"/></g></g>',
                        "behance-outline": '<g data-name="Layer 2"><g data-name="behance"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M10.52 11.78a1.4 1.4 0 0 0 1.12-1.43c0-1-.77-1.6-1.94-1.6H7v6.5h2.7c1.3-.05 2.3-.72 2.3-1.88a1.52 1.52 0 0 0-1.48-1.59zM8.26 9.67h1.15c.6 0 .95.32.95.85s-.38.89-1.25.89h-.85zm1 4.57h-1V12.3h1.23c.75 0 1.17.38 1.17 1s-.42.94-1.44.94z"/><path d="M14.75 10.3a2.11 2.11 0 0 0-2.28 2.25V13a2.15 2.15 0 0 0 2.34 2.31A2 2 0 0 0 17 13.75h-1.21a.9.9 0 0 1-1 .63 1.07 1.07 0 0 1-1.09-1.19v-.14H17v-.47a2.12 2.12 0 0 0-2.25-2.28zm1 2h-2.02a1 1 0 0 1 1-1.09 1 1 0 0 1 1 1.09z"/><rect x="13.25" y="9.2" width="3" height=".5"/></g></g>',
                        "bell-off-outline": '<g data-name="Layer 2"><g data-name="bell-off"><rect width="24" height="24" opacity="0"/><path d="M8.9 5.17A4.67 4.67 0 0 1 12.64 4a4.86 4.86 0 0 1 4.08 4.9v4.5a1.92 1.92 0 0 0 .1.59l3.6 3.6a1.58 1.58 0 0 0 .45-.6 1.62 1.62 0 0 0-.35-1.78l-1.8-1.81V8.94a6.86 6.86 0 0 0-5.82-6.88 6.71 6.71 0 0 0-5.32 1.61 6.88 6.88 0 0 0-.58.54l1.47 1.43a4.79 4.79 0 0 1 .43-.47z"/><path d="M14 16.86l-.83-.86H5.51l1.18-1.18a2 2 0 0 0 .59-1.42v-3.29l-2-2a5.68 5.68 0 0 0 0 .59v4.7l-1.8 1.81A1.63 1.63 0 0 0 4.64 18H8v.34A3.84 3.84 0 0 0 12 22a3.88 3.88 0 0 0 4-3.22l-.83-.78zM12 20a1.88 1.88 0 0 1-2-1.66V18h4v.34A1.88 1.88 0 0 1 12 20z"/><path d="M20.71 19.29L19.41 18l-2-2-9.52-9.53L6.42 5 4.71 3.29a1 1 0 0 0-1.42 1.42L5.53 7l1.75 1.7 7.31 7.3.07.07L16 17.41l.59.59 2.7 2.71a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        "bell-outline": '<g data-name="Layer 2"><g data-name="bell"><rect width="24" height="24" opacity="0"/><path d="M20.52 15.21l-1.8-1.81V8.94a6.86 6.86 0 0 0-5.82-6.88 6.74 6.74 0 0 0-7.62 6.67v4.67l-1.8 1.81A1.64 1.64 0 0 0 4.64 18H8v.34A3.84 3.84 0 0 0 12 22a3.84 3.84 0 0 0 4-3.66V18h3.36a1.64 1.64 0 0 0 1.16-2.79zM14 18.34A1.88 1.88 0 0 1 12 20a1.88 1.88 0 0 1-2-1.66V18h4zM5.51 16l1.18-1.18a2 2 0 0 0 .59-1.42V8.73A4.73 4.73 0 0 1 8.9 5.17 4.67 4.67 0 0 1 12.64 4a4.86 4.86 0 0 1 4.08 4.9v4.5a2 2 0 0 0 .58 1.42L18.49 16z"/></g></g>',
                        "bluetooth-outline": '<g data-name="Layer 2"><g data-name="bluetooth"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M13.63 12l4-3.79a1.14 1.14 0 0 0-.13-1.77l-4.67-3.23a1.17 1.17 0 0 0-1.21-.08 1.15 1.15 0 0 0-.62 1v6.2l-3.19-4a1 1 0 0 0-1.56 1.3L9.72 12l-3.5 4.43a1 1 0 0 0 .16 1.4A1 1 0 0 0 7 18a1 1 0 0 0 .78-.38L11 13.56v6.29A1.16 1.16 0 0 0 12.16 21a1.16 1.16 0 0 0 .67-.21l4.64-3.18a1.17 1.17 0 0 0 .49-.85 1.15 1.15 0 0 0-.34-.91zM13 5.76l2.5 1.73L13 9.85zm0 12.49v-4.07l2.47 2.38z"/></g></g>',
                        "book-open-outline": '<g data-name="Layer 2"><g data-name="book-open"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20.62 4.22a1 1 0 0 0-.84-.2L12 5.77 4.22 4A1 1 0 0 0 3 5v12.2a1 1 0 0 0 .78 1l8 1.8h.44l8-1.8a1 1 0 0 0 .78-1V5a1 1 0 0 0-.38-.78zM5 6.25l6 1.35v10.15L5 16.4zM19 16.4l-6 1.35V7.6l6-1.35z"/></g></g>',
                        "book-outline": '<g data-name="Layer 2"><g data-name="book"><rect width="24" height="24" opacity="0"/><path d="M19 3H7a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zM7 5h11v10H7a3 3 0 0 0-1 .18V6a1 1 0 0 1 1-1zm0 14a1 1 0 0 1 0-2h11v2z"/></g></g>',
                        "bookmark-outline": '<g data-name="Layer 2"><g data-name="bookmark"><rect width="24" height="24" opacity="0"/><path d="M6.09 21.06a1 1 0 0 1-1-1L4.94 5.4a2.26 2.26 0 0 1 2.18-2.35L16.71 3a2.27 2.27 0 0 1 2.23 2.31l.14 14.66a1 1 0 0 1-.49.87 1 1 0 0 1-1 0l-5.7-3.16-5.29 3.23a1.2 1.2 0 0 1-.51.15zm5.76-5.55a1.11 1.11 0 0 1 .5.12l4.71 2.61-.12-12.95c0-.2-.13-.34-.21-.33l-9.6.09c-.08 0-.19.13-.19.33l.12 12.9 4.28-2.63a1.06 1.06 0 0 1 .51-.14z"/></g></g>',
                        "briefcase-outline": '<g data-name="Layer 2"><g data-name="briefcase"><rect width="24" height="24" opacity="0"/><path d="M19 7h-3V5.5A2.5 2.5 0 0 0 13.5 3h-3A2.5 2.5 0 0 0 8 5.5V7H5a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3v-8a3 3 0 0 0-3-3zm-4 2v10H9V9zm-5-3.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5V7h-4zM4 18v-8a1 1 0 0 1 1-1h2v10H5a1 1 0 0 1-1-1zm16 0a1 1 0 0 1-1 1h-2V9h2a1 1 0 0 1 1 1z"/></g></g>',
                        "browser-outline": '<g data-name="Layer 2"><g data-name="browser"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm1 15a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-7h14zM5 9V6a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3z"/><circle cx="8" cy="7.03" r="1"/><circle cx="12" cy="7.03" r="1"/></g></g>',
                        "brush-outline": '<g data-name="Layer 2"><g data-name="brush"><rect width="24" height="24" opacity="0"/><path d="M20 6.83a2.76 2.76 0 0 0-.82-2 2.89 2.89 0 0 0-4 0l-6.6 6.6h-.22a4.42 4.42 0 0 0-4.3 4.31L4 19a1 1 0 0 0 .29.73A1.05 1.05 0 0 0 5 20l3.26-.06a4.42 4.42 0 0 0 4.31-4.3v-.23l6.61-6.6A2.74 2.74 0 0 0 20 6.83zM8.25 17.94L6 18v-2.23a2.4 2.4 0 0 1 2.4-2.36 2.15 2.15 0 0 1 2.15 2.19 2.4 2.4 0 0 1-2.3 2.34zm9.52-10.55l-5.87 5.87a4.55 4.55 0 0 0-.52-.64 3.94 3.94 0 0 0-.64-.52l5.87-5.86a.84.84 0 0 1 1.16 0 .81.81 0 0 1 .23.59.79.79 0 0 1-.23.56z"/></g></g>',
                        "bulb-outline": '<g data-name="Layer 2"><g data-name="bulb"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 7a5 5 0 0 0-3 9v4a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-4a5 5 0 0 0-3-9zm1.5 7.59a1 1 0 0 0-.5.87V20h-2v-4.54a1 1 0 0 0-.5-.87A3 3 0 0 1 9 12a3 3 0 0 1 6 0 3 3 0 0 1-1.5 2.59z"/><path d="M12 6a1 1 0 0 0 1-1V3a1 1 0 0 0-2 0v2a1 1 0 0 0 1 1z"/><path d="M21 11h-2a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2z"/><path d="M5 11H3a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2z"/><path d="M7.66 6.42L6.22 5a1 1 0 0 0-1.39 1.47l1.44 1.39a1 1 0 0 0 .73.28 1 1 0 0 0 .72-.31 1 1 0 0 0-.06-1.41z"/><path d="M19.19 5.05a1 1 0 0 0-1.41 0l-1.44 1.37a1 1 0 0 0 0 1.41 1 1 0 0 0 .72.31 1 1 0 0 0 .69-.28l1.44-1.39a1 1 0 0 0 0-1.42z"/></g></g>',
                        "calendar-outline": '<g data-name="Layer 2"><g data-name="calendar"><rect width="24" height="24" opacity="0"/><path d="M18 4h-1V3a1 1 0 0 0-2 0v1H9V3a1 1 0 0 0-2 0v1H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3zM6 6h1v1a1 1 0 0 0 2 0V6h6v1a1 1 0 0 0 2 0V6h1a1 1 0 0 1 1 1v4H5V7a1 1 0 0 1 1-1zm12 14H6a1 1 0 0 1-1-1v-6h14v6a1 1 0 0 1-1 1z"/><circle cx="8" cy="16" r="1"/><path d="M16 15h-4a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2z"/></g></g>',
                        "camera-outline": '<g data-name="Layer 2"><g data-name="camera"><rect width="24" height="24" opacity="0"/><path d="M19 7h-3V5.5A2.5 2.5 0 0 0 13.5 3h-3A2.5 2.5 0 0 0 8 5.5V7H5a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3v-8a3 3 0 0 0-3-3zm-9-1.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5V7h-4zM20 18a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1z"/><path d="M12 10.5a3.5 3.5 0 1 0 3.5 3.5 3.5 3.5 0 0 0-3.5-3.5zm0 5a1.5 1.5 0 1 1 1.5-1.5 1.5 1.5 0 0 1-1.5 1.5z"/></g></g>',
                        "car-outline": '<g data-name="Layer 2"><g data-name="car"><rect width="24" height="24" opacity="0"/><path d="M21.6 11.22L17 7.52V5a1.91 1.91 0 0 0-1.81-2H3.79A1.91 1.91 0 0 0 2 5v10a2 2 0 0 0 1.2 1.88 3 3 0 1 0 5.6.12h6.36a3 3 0 1 0 5.64 0h.2a1 1 0 0 0 1-1v-4a1 1 0 0 0-.4-.78zM20 12.48V15h-3v-4.92zM7 18a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm5-3H4V5h11v10zm7 3a1 1 0 1 1-1-1 1 1 0 0 1 1 1z"/></g></g>',
                        "cast-outline": '<g data-name="Layer 2"><g data-name="cast"><polyline points="24 24 0 24 0 0" opacity="0"/><path d="M18.4 3H5.6A2.7 2.7 0 0 0 3 5.78V7a1 1 0 0 0 2 0V5.78A.72.72 0 0 1 5.6 5h12.8a.72.72 0 0 1 .6.78v12.44a.72.72 0 0 1-.6.78H17a1 1 0 0 0 0 2h1.4a2.7 2.7 0 0 0 2.6-2.78V5.78A2.7 2.7 0 0 0 18.4 3z"/><path d="M3.86 14A1 1 0 0 0 3 15.17a1 1 0 0 0 1.14.83 2.49 2.49 0 0 1 2.12.72 2.52 2.52 0 0 1 .51 2.84 1 1 0 0 0 .48 1.33 1.06 1.06 0 0 0 .42.09 1 1 0 0 0 .91-.58A4.52 4.52 0 0 0 3.86 14z"/><path d="M3.86 10.08a1 1 0 0 0 .28 2 6 6 0 0 1 5.09 1.71 6 6 0 0 1 1.53 5.95 1 1 0 0 0 .68 1.26.9.9 0 0 0 .28 0 1 1 0 0 0 1-.72 8 8 0 0 0-8.82-10.2z"/><circle cx="4" cy="19" r="1"/></g></g>',
                        "charging-outline": '<g data-name="Layer 2"><g data-name="charging"><rect width="24" height="24" opacity="0"/><path d="M21 9a1 1 0 0 0-1 1v4a1 1 0 0 0 2 0v-4a1 1 0 0 0-1-1z"/><path d="M15.83 6h-3.1l-1.14 2h4.23a.5.5 0 0 1 .18.43v7.14a.52.52 0 0 1-.17.43H13l-1.15 2h4A2.31 2.31 0 0 0 18 15.57V8.43A2.31 2.31 0 0 0 15.83 6z"/><path d="M4 15.57V8.43A.53.53 0 0 1 4.17 8H7l1.13-2h-4A2.31 2.31 0 0 0 2 8.43v7.14A2.31 2.31 0 0 0 4.17 18h3.1l1.14-2H4.18a.5.5 0 0 1-.18-.43z"/><path d="M9 20a1 1 0 0 1-.87-1.5l3.15-5.5H7a1 1 0 0 1-.86-.5 1 1 0 0 1 0-1l4-7a1 1 0 0 1 1.74 1L8.72 11H13a1 1 0 0 1 .86.5 1 1 0 0 1 0 1l-4 7A1 1 0 0 1 9 20z"/></g></g>',
                        "checkmark-circle-2-outline": '<g data-name="Layer 2"><g data-name="checkmark-circle-2"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M14.7 8.39l-3.78 5-1.63-2.11a1 1 0 0 0-1.58 1.23l2.43 3.11a1 1 0 0 0 .79.38 1 1 0 0 0 .79-.39l4.57-6a1 1 0 1 0-1.6-1.22z"/></g></g>',
                        "checkmark-circle-outline": '<g data-name="Layer 2"><g data-name="checkmark-circle"><rect width="24" height="24" opacity="0"/><path d="M9.71 11.29a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 16a1 1 0 0 0 .72-.34l7-8a1 1 0 0 0-1.5-1.32L12 13.54z"/><path d="M21 11a1 1 0 0 0-1 1 8 8 0 0 1-8 8A8 8 0 0 1 6.33 6.36 7.93 7.93 0 0 1 12 4a8.79 8.79 0 0 1 1.9.22 1 1 0 1 0 .47-1.94A10.54 10.54 0 0 0 12 2a10 10 0 0 0-7 17.09A9.93 9.93 0 0 0 12 22a10 10 0 0 0 10-10 1 1 0 0 0-1-1z"/></g></g>',
                        "checkmark-outline": '<g data-name="Layer 2"><g data-name="checkmark"><rect width="24" height="24" opacity="0"/><path d="M9.86 18a1 1 0 0 1-.73-.32l-4.86-5.17a1 1 0 1 1 1.46-1.37l4.12 4.39 8.41-9.2a1 1 0 1 1 1.48 1.34l-9.14 10a1 1 0 0 1-.73.33z"/></g></g>',
                        "checkmark-square-2-outline": '<g data-name="Layer 2"><g data-name="checkmark-square-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm1 15a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1z"/><path d="M14.7 8.39l-3.78 5-1.63-2.11a1 1 0 0 0-1.58 1.23l2.43 3.11a1 1 0 0 0 .79.38 1 1 0 0 0 .79-.39l4.57-6a1 1 0 1 0-1.6-1.22z"/></g></g>',
                        "checkmark-square-outline": '<g data-name="Layer 2"><g data-name="checkmark-square"><rect width="24" height="24" opacity="0"/><path d="M20 11.83a1 1 0 0 0-1 1v5.57a.6.6 0 0 1-.6.6H5.6a.6.6 0 0 1-.6-.6V5.6a.6.6 0 0 1 .6-.6h9.57a1 1 0 1 0 0-2H5.6A2.61 2.61 0 0 0 3 5.6v12.8A2.61 2.61 0 0 0 5.6 21h12.8a2.61 2.61 0 0 0 2.6-2.6v-5.57a1 1 0 0 0-1-1z"/><path d="M10.72 11a1 1 0 0 0-1.44 1.38l2.22 2.33a1 1 0 0 0 .72.31 1 1 0 0 0 .72-.3l6.78-7a1 1 0 1 0-1.44-1.4l-6.05 6.26z"/></g></g>',
                        "chevron-down-outline": '<g data-name="Layer 2"><g data-name="chevron-down"><rect width="24" height="24" opacity="0"/><path d="M12 15.5a1 1 0 0 1-.71-.29l-4-4a1 1 0 1 1 1.42-1.42L12 13.1l3.3-3.18a1 1 0 1 1 1.38 1.44l-4 3.86a1 1 0 0 1-.68.28z"/></g></g>',
                        "chevron-left-outline": '<g data-name="Layer 2"><g data-name="chevron-left"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M13.36 17a1 1 0 0 1-.72-.31l-3.86-4a1 1 0 0 1 0-1.4l4-4a1 1 0 1 1 1.42 1.42L10.9 12l3.18 3.3a1 1 0 0 1 0 1.41 1 1 0 0 1-.72.29z"/></g></g>',
                        "chevron-right-outline": '<g data-name="Layer 2"><g data-name="chevron-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M10.5 17a1 1 0 0 1-.71-.29 1 1 0 0 1 0-1.42L13.1 12 9.92 8.69a1 1 0 0 1 0-1.41 1 1 0 0 1 1.42 0l3.86 4a1 1 0 0 1 0 1.4l-4 4a1 1 0 0 1-.7.32z"/></g></g>',
                        "chevron-up-outline": '<g data-name="Layer 2"><g data-name="chevron-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M16 14.5a1 1 0 0 1-.71-.29L12 10.9l-3.3 3.18a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.42l4-3.86a1 1 0 0 1 1.4 0l4 4a1 1 0 0 1 0 1.42 1 1 0 0 1-.69.28z"/></g></g>',
                        "clipboard-outline": '<g data-name="Layer 2"><g data-name="clipboard"><rect width="24" height="24" opacity="0"/><path d="M18 5V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v1a3 3 0 0 0-3 3v11a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V8a3 3 0 0 0-3-3zM8 4h8v4H8V4zm11 15a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1v1a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7a1 1 0 0 1 1 1z"/></g></g>',
                        "clock-outline": '<g data-name="Layer 2"><g data-name="clock"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M16 11h-3V8a1 1 0 0 0-2 0v4a1 1 0 0 0 1 1h4a1 1 0 0 0 0-2z"/></g></g>',
                        "close-circle-outline": '<g data-name="Layer 2"><g data-name="close-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M14.71 9.29a1 1 0 0 0-1.42 0L12 10.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l1.3 1.29-1.3 1.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l1.29-1.3 1.29 1.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L13.41 12l1.3-1.29a1 1 0 0 0 0-1.42z"/></g></g>',
                        "close-outline": '<g data-name="Layer 2"><g data-name="close"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29-4.3 4.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l4.29-4.3 4.29 4.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        "close-square-outline": '<g data-name="Layer 2"><g data-name="close-square"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm1 15a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1z"/><path d="M14.71 9.29a1 1 0 0 0-1.42 0L12 10.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l1.3 1.29-1.3 1.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l1.29-1.3 1.29 1.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L13.41 12l1.3-1.29a1 1 0 0 0 0-1.42z"/></g></g>',
                        "cloud-download-outline": '<g data-name="Layer 2"><g data-name="cloud-download"><rect width="24" height="24" opacity="0"/><path d="M14.31 16.38L13 17.64V12a1 1 0 0 0-2 0v5.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 21a1 1 0 0 0 .69-.28l3-2.9a1 1 0 1 0-1.38-1.44z"/><path d="M17.67 7A6 6 0 0 0 6.33 7a5 5 0 0 0-3.08 8.27A1 1 0 1 0 4.75 14 3 3 0 0 1 7 9h.1a1 1 0 0 0 1-.8 4 4 0 0 1 7.84 0 1 1 0 0 0 1 .8H17a3 3 0 0 1 2.25 5 1 1 0 0 0 .09 1.42 1 1 0 0 0 .66.25 1 1 0 0 0 .75-.34A5 5 0 0 0 17.67 7z"/></g></g>',
                        "cloud-upload-outline": '<g data-name="Layer 2"><g data-name="cloud-upload"><rect width="24" height="24" opacity="0"/><path d="M12.71 11.29a1 1 0 0 0-1.4 0l-3 2.9a1 1 0 1 0 1.38 1.44L11 14.36V20a1 1 0 0 0 2 0v-5.59l1.29 1.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M17.67 7A6 6 0 0 0 6.33 7a5 5 0 0 0-3.08 8.27A1 1 0 1 0 4.75 14 3 3 0 0 1 7 9h.1a1 1 0 0 0 1-.8 4 4 0 0 1 7.84 0 1 1 0 0 0 1 .8H17a3 3 0 0 1 2.25 5 1 1 0 0 0 .09 1.42 1 1 0 0 0 .66.25 1 1 0 0 0 .75-.34A5 5 0 0 0 17.67 7z"/></g></g>',
                        "code-download-outline": '<g data-name="Layer 2"><g data-name="code-download"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M4.29 12l4.48-5.36a1 1 0 1 0-1.54-1.28l-5 6a1 1 0 0 0 0 1.27l4.83 6a1 1 0 0 0 .78.37 1 1 0 0 0 .78-1.63z"/><path d="M21.78 11.37l-4.78-6a1 1 0 0 0-1.56 1.26L19.71 12l-4.48 5.37a1 1 0 0 0 .13 1.41A1 1 0 0 0 16 19a1 1 0 0 0 .77-.36l5-6a1 1 0 0 0 .01-1.27z"/><path d="M15.72 11.41a1 1 0 0 0-1.41 0L13 12.64V8a1 1 0 0 0-2 0v4.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 16a1 1 0 0 0 .69-.28l3-2.9a1 1 0 0 0 .03-1.41z"/></g></g>',
                        "code-outline": '<g data-name="Layer 2"><g data-name="code"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M8.64 5.23a1 1 0 0 0-1.41.13l-5 6a1 1 0 0 0 0 1.27l4.83 6a1 1 0 0 0 .78.37 1 1 0 0 0 .78-1.63L4.29 12l4.48-5.36a1 1 0 0 0-.13-1.41z"/><path d="M21.78 11.37l-4.78-6a1 1 0 0 0-1.41-.15 1 1 0 0 0-.15 1.41L19.71 12l-4.48 5.37a1 1 0 0 0 .13 1.41A1 1 0 0 0 16 19a1 1 0 0 0 .77-.36l5-6a1 1 0 0 0 .01-1.27z"/></g></g>',
                        "collapse-outline": '<g data-name="Layer 2"><g data-name="collapse"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M19 9h-2.58l3.29-3.29a1 1 0 1 0-1.42-1.42L15 7.57V5a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h5a1 1 0 0 0 0-2z"/><path d="M10 13H5a1 1 0 0 0 0 2h2.57l-3.28 3.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L9 16.42V19a1 1 0 0 0 1 1 1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1z"/></g></g>',
                        "color-palette-outline": '<g data-name="Layer 2"><g data-name="color-palette"><rect width="24" height="24" opacity="0"/><path d="M19.54 5.08A10.61 10.61 0 0 0 11.91 2a10 10 0 0 0-.05 20 2.58 2.58 0 0 0 2.53-1.89 2.52 2.52 0 0 0-.57-2.28.5.5 0 0 1 .37-.83h1.65A6.15 6.15 0 0 0 22 11.33a8.48 8.48 0 0 0-2.46-6.25zM15.88 15h-1.65a2.49 2.49 0 0 0-1.87 4.15.49.49 0 0 1 .12.49c-.05.21-.28.34-.59.36a8 8 0 0 1-7.82-9.11A8.1 8.1 0 0 1 11.92 4H12a8.47 8.47 0 0 1 6.1 2.48 6.5 6.5 0 0 1 1.9 4.77A4.17 4.17 0 0 1 15.88 15z"/><circle cx="12" cy="6.5" r="1.5"/><path d="M15.25 7.2a1.5 1.5 0 1 0 2.05.55 1.5 1.5 0 0 0-2.05-.55z"/><path d="M8.75 7.2a1.5 1.5 0 1 0 .55 2.05 1.5 1.5 0 0 0-.55-2.05z"/><path d="M6.16 11.26a1.5 1.5 0 1 0 2.08.4 1.49 1.49 0 0 0-2.08-.4z"/></g></g>',
                        "color-picker-outline": '<g data-name="Layer 2"><g data-name="color-picker"><rect width="24" height="24" opacity="0"/><path d="M19.4 7.34L16.66 4.6A1.92 1.92 0 0 0 14 4.53l-2 2-1.29-1.24a1 1 0 0 0-1.42 1.42L10.53 8 5 13.53a2 2 0 0 0-.57 1.21L4 18.91a1 1 0 0 0 .29.8A1 1 0 0 0 5 20h.09l4.17-.38a2 2 0 0 0 1.21-.57l5.58-5.58 1.24 1.24a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42l-1.24-1.24 2-2a1.92 1.92 0 0 0-.07-2.71zM9.08 17.62l-3 .28.27-3L12 9.36l2.69 2.7zm7-7L13.36 8l1.91-2L18 8.73z"/></g></g>',
                        "compass-outline": '<g data-name="Layer 2"><g data-name="compass"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M15.68 8.32a1 1 0 0 0-1.1-.25l-4.21 1.7a1 1 0 0 0-.55.55l-1.75 4.26a1 1 0 0 0 .18 1h.05A1 1 0 0 0 9 16a1 1 0 0 0 .38-.07l4.21-1.7a1 1 0 0 0 .55-.55l1.75-4.26a1 1 0 0 0-.21-1.1zm-4.88 4.89l.71-1.74 1.69-.68-.71 1.74z"/></g></g>',
                        "copy-outline": '<g data-name="Layer 2"><g data-name="copy"><rect width="24" height="24" opacity="0"/><path d="M18 21h-6a3 3 0 0 1-3-3v-6a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3zm-6-10a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1z"/><path d="M9.73 15H5.67A2.68 2.68 0 0 1 3 12.33V5.67A2.68 2.68 0 0 1 5.67 3h6.66A2.68 2.68 0 0 1 15 5.67V9.4h-2V5.67a.67.67 0 0 0-.67-.67H5.67a.67.67 0 0 0-.67.67v6.66a.67.67 0 0 0 .67.67h4.06z"/></g></g>',
                        "corner-down-left-outline": '<g data-name="Layer 2"><g data-name="corner-down-left"><rect x=".05" y=".05" width="24" height="24" transform="rotate(-89.76 12.05 12.05)" opacity="0"/><path d="M20 6a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 1-.29.71A1 1 0 0 1 17 12H8.08l2.69-3.39a1 1 0 0 0-1.52-1.17l-4 5a1 1 0 0 0 0 1.25l4 5a1 1 0 0 0 .78.37 1 1 0 0 0 .62-.22 1 1 0 0 0 .15-1.41l-2.66-3.36h8.92a3 3 0 0 0 3-3z"/></g></g>',
                        "corner-down-right-outline": '<g data-name="Layer 2"><g data-name="corner-down-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M19.78 12.38l-4-5a1 1 0 0 0-1.56 1.24l2.7 3.38H8a1 1 0 0 1-1-1V6a1 1 0 0 0-2 0v5a3 3 0 0 0 3 3h8.92l-2.7 3.38a1 1 0 0 0 .16 1.4A1 1 0 0 0 15 19a1 1 0 0 0 .78-.38l4-5a1 1 0 0 0 0-1.24z"/></g></g>',
                        "corner-left-down-outline": '<g data-name="Layer 2"><g data-name="corner-left-down"><rect width="24" height="24" opacity="0"/><path d="M18 5h-5a3 3 0 0 0-3 3v8.92l-3.38-2.7a1 1 0 0 0-1.24 1.56l5 4a1 1 0 0 0 1.24 0l5-4a1 1 0 1 0-1.24-1.56L12 16.92V8a1 1 0 0 1 1-1h5a1 1 0 0 0 0-2z"/></g></g>',
                        "corner-left-up-outline": '<g data-name="Layer 2"><g data-name="corner-left-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 17h-5a1 1 0 0 1-1-1V7.08l3.38 2.7A1 1 0 0 0 16 10a1 1 0 0 0 .78-.38 1 1 0 0 0-.16-1.4l-5-4a1 1 0 0 0-1.24 0l-5 4a1 1 0 0 0 1.24 1.56L10 7.08V16a3 3 0 0 0 3 3h5a1 1 0 0 0 0-2z"/></g></g>',
                        "corner-right-down-outline": '<g data-name="Layer 2"><g data-name="corner-right-down"><rect width="24" height="24" opacity="0"/><path d="M18.78 14.38a1 1 0 0 0-1.4-.16L14 16.92V8a3 3 0 0 0-3-3H6a1 1 0 0 0 0 2h5a1 1 0 0 1 1 1v8.92l-3.38-2.7a1 1 0 0 0-1.24 1.56l5 4a1 1 0 0 0 1.24 0l5-4a1 1 0 0 0 .16-1.4z"/></g></g>',
                        "corner-right-up-outline": '<g data-name="Layer 2"><g data-name="corner-right-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18.62 8.22l-5-4a1 1 0 0 0-1.24 0l-5 4a1 1 0 0 0 1.24 1.56L12 7.08V16a1 1 0 0 1-1 1H6a1 1 0 0 0 0 2h5a3 3 0 0 0 3-3V7.08l3.38 2.7A1 1 0 0 0 18 10a1 1 0 0 0 .78-.38 1 1 0 0 0-.16-1.4z"/></g></g>',
                        "corner-up-left-outline": '<g data-name="Layer 2"><g data-name="corner-up-left"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M16 10H7.08l2.7-3.38a1 1 0 1 0-1.56-1.24l-4 5a1 1 0 0 0 0 1.24l4 5A1 1 0 0 0 9 17a1 1 0 0 0 .62-.22 1 1 0 0 0 .16-1.4L7.08 12H16a1 1 0 0 1 1 1v5a1 1 0 0 0 2 0v-5a3 3 0 0 0-3-3z"/></g></g>',
                        "corner-up-right-outline": '<g data-name="Layer 2"><g data-name="corner-up-right"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M19.78 10.38l-4-5a1 1 0 0 0-1.56 1.24l2.7 3.38H8a3 3 0 0 0-3 3v5a1 1 0 0 0 2 0v-5a1 1 0 0 1 1-1h8.92l-2.7 3.38a1 1 0 0 0 .16 1.4A1 1 0 0 0 15 17a1 1 0 0 0 .78-.38l4-5a1 1 0 0 0 0-1.24z"/></g></g>',
                        "credit-card-outline": '<g data-name="Layer 2"><g data-name="credit-card"><rect width="24" height="24" opacity="0"/><path d="M19 5H5a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V8a3 3 0 0 0-3-3zM4 8a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v1H4zm16 8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-5h16z"/><path d="M7 15h4a1 1 0 0 0 0-2H7a1 1 0 0 0 0 2z"/><path d="M15 15h2a1 1 0 0 0 0-2h-2a1 1 0 0 0 0 2z"/></g></g>',
                        "crop-outline": '<g data-name="Layer 2"><g data-name="crop"><rect width="24" height="24" opacity="0"/><path d="M21 16h-3V8.56A2.56 2.56 0 0 0 15.44 6H8V3a1 1 0 0 0-2 0v3H3a1 1 0 0 0 0 2h3v7.44A2.56 2.56 0 0 0 8.56 18H16v3a1 1 0 0 0 2 0v-3h3a1 1 0 0 0 0-2zM8.56 16a.56.56 0 0 1-.56-.56V8h7.44a.56.56 0 0 1 .56.56V16z"/></g></g>',
                        "cube-outline": '<g data-name="Layer 2"><g data-name="cube"><rect width="24" height="24" opacity="0"/><path d="M20.66 7.26c0-.07-.1-.14-.15-.21l-.09-.1a2.5 2.5 0 0 0-.86-.68l-6.4-3a2.7 2.7 0 0 0-2.26 0l-6.4 3a2.6 2.6 0 0 0-.86.68L3.52 7a1 1 0 0 0-.15.2A2.39 2.39 0 0 0 3 8.46v7.06a2.49 2.49 0 0 0 1.46 2.26l6.4 3a2.7 2.7 0 0 0 2.27 0l6.4-3A2.49 2.49 0 0 0 21 15.54V8.46a2.39 2.39 0 0 0-.34-1.2zm-8.95-2.2a.73.73 0 0 1 .58 0l5.33 2.48L12 10.15 6.38 7.54zM5.3 16a.47.47 0 0 1-.3-.43V9.1l6 2.79v6.72zm13.39 0L13 18.61v-6.72l6-2.79v6.44a.48.48 0 0 1-.31.46z"/></g></g>',
                        "diagonal-arrow-left-down-outline": '<g data-name="Layer 2"><g data-name="diagonal-arrow-left-down"><rect width="24" height="24" opacity="0"/><path d="M17.71 6.29a1 1 0 0 0-1.42 0L8 14.59V9a1 1 0 0 0-2 0v8a1 1 0 0 0 1 1h8a1 1 0 0 0 0-2H9.41l8.3-8.29a1 1 0 0 0 0-1.42z"/></g></g>',
                        "diagonal-arrow-left-up-outline": '<g data-name="Layer 2"><g data-name="diagonal-arrow-left-up"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M17.71 16.29L9.42 8H15a1 1 0 0 0 0-2H7.05a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1H7a1 1 0 0 0 1-1V9.45l8.26 8.26a1 1 0 0 0 1.42 0 1 1 0 0 0 .03-1.42z"/></g></g>',
                        "diagonal-arrow-right-down-outline": '<g data-name="Layer 2"><g data-name="diagonal-arrow-right-down"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M17 8a1 1 0 0 0-1 1v5.59l-8.29-8.3a1 1 0 0 0-1.42 1.42l8.3 8.29H9a1 1 0 0 0 0 2h8a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1z"/></g></g>',
                        "diagonal-arrow-right-up-outline": '<g data-name="Layer 2"><g data-name="diagonal-arrow-right-up"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 7.05a1 1 0 0 0-1-1L9 6a1 1 0 0 0 0 2h5.56l-8.27 8.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L16 9.42V15a1 1 0 0 0 1 1 1 1 0 0 0 1-1z"/></g></g>',
                        "done-all-outline": '<g data-name="Layer 2"><g data-name="done-all"><rect width="24" height="24" opacity="0"/><path d="M16.62 6.21a1 1 0 0 0-1.41.17l-7 9-3.43-4.18a1 1 0 1 0-1.56 1.25l4.17 5.18a1 1 0 0 0 .78.37 1 1 0 0 0 .83-.38l7.83-10a1 1 0 0 0-.21-1.41z"/><path d="M21.62 6.21a1 1 0 0 0-1.41.17l-7 9-.61-.75-1.26 1.62 1.1 1.37a1 1 0 0 0 .78.37 1 1 0 0 0 .78-.38l7.83-10a1 1 0 0 0-.21-1.4z"/><path d="M8.71 13.06L10 11.44l-.2-.24a1 1 0 0 0-1.43-.2 1 1 0 0 0-.15 1.41z"/></g></g>',
                        "download-outline": '<g data-name="Layer 2"><g data-name="download"><rect width="24" height="24" opacity="0"/><rect x="4" y="18" width="16" height="2" rx="1" ry="1"/><rect x="3" y="17" width="4" height="2" rx="1" ry="1" transform="rotate(-90 5 18)"/><rect x="17" y="17" width="4" height="2" rx="1" ry="1" transform="rotate(-90 19 18)"/><path d="M12 15a1 1 0 0 1-.58-.18l-4-2.82a1 1 0 0 1-.24-1.39 1 1 0 0 1 1.4-.24L12 12.76l3.4-2.56a1 1 0 0 1 1.2 1.6l-4 3a1 1 0 0 1-.6.2z"/><path d="M12 13a1 1 0 0 1-1-1V4a1 1 0 0 1 2 0v8a1 1 0 0 1-1 1z"/></g></g>',
                        "droplet-off-outline": '<g data-name="Layer 2"><g data-name="droplet-off-outline"><rect width="24" height="24" opacity="0"/><path d="M12 19a5.4 5.4 0 0 1-3.88-1.64 5.73 5.73 0 0 1-.69-7.11L6 8.82a7.74 7.74 0 0 0 .7 9.94A7.37 7.37 0 0 0 12 21a7.36 7.36 0 0 0 4.58-1.59L15.15 18A5.43 5.43 0 0 1 12 19z"/><path d="M12 5.43l3.88 4a5.71 5.71 0 0 1 1.49 5.15L19 16.15A7.72 7.72 0 0 0 17.31 8l-4.6-4.7A1 1 0 0 0 12 3a1 1 0 0 0-.72.3L8.73 5.9l1.42 1.42z"/><path d="M20.71 19.29l-16-16a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        "droplet-outline": '<g data-name="Layer 2"><g data-name="droplet-outline"><rect x=".1" y=".1" width="24" height="24" transform="rotate(.48 11.987 11.887)" opacity="0"/><path d="M12 21.1a7.4 7.4 0 0 1-5.28-2.28 7.73 7.73 0 0 1 .1-10.77l4.64-4.65a.94.94 0 0 1 .71-.3 1 1 0 0 1 .71.31l4.56 4.72a7.73 7.73 0 0 1-.09 10.77A7.33 7.33 0 0 1 12 21.1zm.13-15.57L8.24 9.45a5.74 5.74 0 0 0-.07 8A5.43 5.43 0 0 0 12 19.1a5.42 5.42 0 0 0 3.9-1.61 5.72 5.72 0 0 0 .06-8z"/></g></g>',
                        "edit-2-outline": '<g data-name="Layer 2"><g data-name="edit-2"><rect width="24" height="24" opacity="0"/><path d="M19 20H5a1 1 0 0 0 0 2h14a1 1 0 0 0 0-2z"/><path d="M5 18h.09l4.17-.38a2 2 0 0 0 1.21-.57l9-9a1.92 1.92 0 0 0-.07-2.71L16.66 2.6A2 2 0 0 0 14 2.53l-9 9a2 2 0 0 0-.57 1.21L4 16.91a1 1 0 0 0 .29.8A1 1 0 0 0 5 18zM15.27 4L18 6.73l-2 1.95L13.32 6zm-8.9 8.91L12 7.32l2.7 2.7-5.6 5.6-3 .28z"/></g></g>',
                        "edit-outline": '<g data-name="Layer 2"><g data-name="edit"><rect width="24" height="24" opacity="0"/><path d="M19.4 7.34L16.66 4.6A2 2 0 0 0 14 4.53l-9 9a2 2 0 0 0-.57 1.21L4 18.91a1 1 0 0 0 .29.8A1 1 0 0 0 5 20h.09l4.17-.38a2 2 0 0 0 1.21-.57l9-9a1.92 1.92 0 0 0-.07-2.71zM9.08 17.62l-3 .28.27-3L12 9.32l2.7 2.7zM16 10.68L13.32 8l1.95-2L18 8.73z"/></g></g>',
                        "email-outline": '<g data-name="Layer 2"><g data-name="email"><rect width="24" height="24" opacity="0"/><path d="M19 4H5a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3zm-.67 2L12 10.75 5.67 6zM19 18H5a1 1 0 0 1-1-1V7.25l7.4 5.55a1 1 0 0 0 .6.2 1 1 0 0 0 .6-.2L20 7.25V17a1 1 0 0 1-1 1z"/></g></g>',
                        "expand-outline": '<g data-name="Layer 2"><g data-name="expand"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20 5a1 1 0 0 0-1-1h-5a1 1 0 0 0 0 2h2.57l-3.28 3.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L18 7.42V10a1 1 0 0 0 1 1 1 1 0 0 0 1-1z"/><path d="M10.71 13.29a1 1 0 0 0-1.42 0L6 16.57V14a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h5a1 1 0 0 0 0-2H7.42l3.29-3.29a1 1 0 0 0 0-1.42z"/></g></g>',
                        "external-link-outline": '<g data-name="Layer 2"><g data-name="external-link"><rect width="24" height="24" opacity="0"/><path d="M20 11a1 1 0 0 0-1 1v6a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h6a1 1 0 0 0 0-2H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-6a1 1 0 0 0-1-1z"/><path d="M16 5h1.58l-6.29 6.28a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L19 6.42V8a1 1 0 0 0 1 1 1 1 0 0 0 1-1V4a1 1 0 0 0-1-1h-4a1 1 0 0 0 0 2z"/></g></g>',
                        "eye-off-2-outline": '<g data-name="Layer 2"><g data-name="eye-off-2"><rect width="24" height="24" opacity="0"/><path d="M17.81 13.39A8.93 8.93 0 0 0 21 7.62a1 1 0 1 0-2-.24 7.07 7.07 0 0 1-14 0 1 1 0 1 0-2 .24 8.93 8.93 0 0 0 3.18 5.77l-2.3 2.32a1 1 0 0 0 1.41 1.41l2.61-2.6a9.06 9.06 0 0 0 3.1.92V19a1 1 0 0 0 2 0v-3.56a9.06 9.06 0 0 0 3.1-.92l2.61 2.6a1 1 0 0 0 1.41-1.41z"/></g></g>',
                        "eye-off-outline": '<g data-name="Layer 2"><g data-name="eye-off"><rect width="24" height="24" opacity="0"/><path d="M4.71 3.29a1 1 0 0 0-1.42 1.42l5.63 5.63a3.5 3.5 0 0 0 4.74 4.74l5.63 5.63a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM12 13.5a1.5 1.5 0 0 1-1.5-1.5v-.07l1.56 1.56z"/><path d="M12.22 17c-4.3.1-7.12-3.59-8-5a13.7 13.7 0 0 1 2.24-2.72L5 7.87a15.89 15.89 0 0 0-2.87 3.63 1 1 0 0 0 0 1c.63 1.09 4 6.5 9.89 6.5h.25a9.48 9.48 0 0 0 3.23-.67l-1.58-1.58a7.74 7.74 0 0 1-1.7.25z"/><path d="M21.87 11.5c-.64-1.11-4.17-6.68-10.14-6.5a9.48 9.48 0 0 0-3.23.67l1.58 1.58a7.74 7.74 0 0 1 1.7-.25c4.29-.11 7.11 3.59 8 5a13.7 13.7 0 0 1-2.29 2.72L19 16.13a15.89 15.89 0 0 0 2.91-3.63 1 1 0 0 0-.04-1z"/></g></g>',
                        "eye-outline": '<g data-name="Layer 2"><g data-name="eye"><rect width="24" height="24" opacity="0"/><path d="M21.87 11.5c-.64-1.11-4.16-6.68-10.14-6.5-5.53.14-8.73 5-9.6 6.5a1 1 0 0 0 0 1c.63 1.09 4 6.5 9.89 6.5h.25c5.53-.14 8.74-5 9.6-6.5a1 1 0 0 0 0-1zM12.22 17c-4.31.1-7.12-3.59-8-5 1-1.61 3.61-4.9 7.61-5 4.29-.11 7.11 3.59 8 5-1.03 1.61-3.61 4.9-7.61 5z"/><path d="M12 8.5a3.5 3.5 0 1 0 3.5 3.5A3.5 3.5 0 0 0 12 8.5zm0 5a1.5 1.5 0 1 1 1.5-1.5 1.5 1.5 0 0 1-1.5 1.5z"/></g></g>',
                        "facebook-outline": '<g data-name="Layer 2"><g data-name="facebook"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M13 22H9a1 1 0 0 1-1-1v-6.2H6a1 1 0 0 1-1-1v-3.6a1 1 0 0 1 1-1h2V7.5A5.77 5.77 0 0 1 14 2h3a1 1 0 0 1 1 1v3.6a1 1 0 0 1-1 1h-3v1.6h3a1 1 0 0 1 .8.39 1 1 0 0 1 .16.88l-1 3.6a1 1 0 0 1-1 .73H14V21a1 1 0 0 1-1 1zm-3-2h2v-6.2a1 1 0 0 1 1-1h2.24l.44-1.6H13a1 1 0 0 1-1-1V7.5a2 2 0 0 1 2-1.9h2V4h-2a3.78 3.78 0 0 0-4 3.5v2.7a1 1 0 0 1-1 1H7v1.6h2a1 1 0 0 1 1 1z"/></g></g>',
                        "file-add-outline": '<g data-name="Layer 2"><g data-name="file-add"><rect width="24" height="24" opacity="0"/><path d="M19.74 8.33l-5.44-6a1 1 0 0 0-.74-.33h-7A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V9a1 1 0 0 0-.26-.67zM14 5l2.74 3h-2a.79.79 0 0 1-.74-.85zm3.44 15H6.56a.53.53 0 0 1-.56-.5v-15a.53.53 0 0 1 .56-.5H12v3.15A2.79 2.79 0 0 0 14.71 10H18v9.5a.53.53 0 0 1-.56.5z"/><path d="M14 13h-1v-1a1 1 0 0 0-2 0v1h-1a1 1 0 0 0 0 2h1v1a1 1 0 0 0 2 0v-1h1a1 1 0 0 0 0-2z"/></g></g>',
                        "file-outline": '<g data-name="Layer 2"><g data-name="file"><rect width="24" height="24" opacity="0"/><path d="M19.74 8.33l-5.44-6a1 1 0 0 0-.74-.33h-7A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V9a1 1 0 0 0-.26-.67zM17.65 9h-3.94a.79.79 0 0 1-.71-.85V4h.11zm-.21 11H6.56a.53.53 0 0 1-.56-.5v-15a.53.53 0 0 1 .56-.5H11v4.15A2.79 2.79 0 0 0 13.71 11H18v8.5a.53.53 0 0 1-.56.5z"/></g></g>',
                        "file-remove-outline": '<g data-name="Layer 2"><g data-name="file-remove"><rect width="24" height="24" opacity="0"/><path d="M19.74 8.33l-5.44-6a1 1 0 0 0-.74-.33h-7A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V9a1 1 0 0 0-.26-.67zM14 5l2.74 3h-2a.79.79 0 0 1-.74-.85zm3.44 15H6.56a.53.53 0 0 1-.56-.5v-15a.53.53 0 0 1 .56-.5H12v3.15A2.79 2.79 0 0 0 14.71 10H18v9.5a.53.53 0 0 1-.56.5z"/><path d="M14 13h-4a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2z"/></g></g>',
                        "file-text-outline": '<g data-name="Layer 2"><g data-name="file-text"><rect width="24" height="24" opacity="0"/><path d="M15 16H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2z"/><path d="M9 14h3a1 1 0 0 0 0-2H9a1 1 0 0 0 0 2z"/><path d="M19.74 8.33l-5.44-6a1 1 0 0 0-.74-.33h-7A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V9a1 1 0 0 0-.26-.67zM14 5l2.74 3h-2a.79.79 0 0 1-.74-.85zm3.44 15H6.56a.53.53 0 0 1-.56-.5v-15a.53.53 0 0 1 .56-.5H12v3.15A2.79 2.79 0 0 0 14.71 10H18v9.5a.53.53 0 0 1-.56.5z"/></g></g>',
                        "film-outline": '<g data-name="Layer 2"><g data-name="film"><rect width="24" height="24" opacity="0"/><path d="M18.26 3H5.74A2.74 2.74 0 0 0 3 5.74v12.52A2.74 2.74 0 0 0 5.74 21h12.52A2.74 2.74 0 0 0 21 18.26V5.74A2.74 2.74 0 0 0 18.26 3zM7 11H5V9h2zm-2 2h2v2H5zm4-8h6v14H9zm10 6h-2V9h2zm-2 2h2v2h-2zm2-7.26V7h-2V5h1.26a.74.74 0 0 1 .74.74zM5.74 5H7v2H5V5.74A.74.74 0 0 1 5.74 5zM5 18.26V17h2v2H5.74a.74.74 0 0 1-.74-.74zm14 0a.74.74 0 0 1-.74.74H17v-2h2z"/></g></g>',
                        "flag-outline": '<g data-name="Layer 2"><g data-name="flag"><polyline points="24 24 0 24 0 0" opacity="0"/><path d="M19.27 4.68a1.79 1.79 0 0 0-1.6-.25 7.53 7.53 0 0 1-2.17.28 8.54 8.54 0 0 1-3.13-.78A10.15 10.15 0 0 0 8.5 3c-2.89 0-4 1-4.2 1.14a1 1 0 0 0-.3.72V20a1 1 0 0 0 2 0v-4.3a6.28 6.28 0 0 1 2.5-.41 8.54 8.54 0 0 1 3.13.78 10.15 10.15 0 0 0 3.87.93 7.66 7.66 0 0 0 3.5-.7 1.74 1.74 0 0 0 1-1.55V6.11a1.77 1.77 0 0 0-.73-1.43zM18 14.59a6.32 6.32 0 0 1-2.5.41 8.36 8.36 0 0 1-3.13-.79 10.34 10.34 0 0 0-3.87-.92 9.51 9.51 0 0 0-2.5.29V5.42A6.13 6.13 0 0 1 8.5 5a8.36 8.36 0 0 1 3.13.79 10.34 10.34 0 0 0 3.87.92 9.41 9.41 0 0 0 2.5-.3z"/></g></g>',
                        "flash-off-outline": '<g data-name="Layer 2"><g data-name="flash-off"><rect width="24" height="24" opacity="0"/><path d="M20.71 19.29l-16-16a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M12.54 18.06l.27-2.42L10 12.8H6.87l1.24-1.86L6.67 9.5l-2.5 3.74A1 1 0 0 0 5 14.8h5.89l-.77 7.09a1 1 0 0 0 .65 1.05 1 1 0 0 0 .34.06 1 1 0 0 0 .83-.44l3.12-4.67-1.44-1.44z"/><path d="M11.46 5.94l-.27 2.42L14 11.2h3.1l-1.24 1.86 1.44 1.44 2.5-3.74A1 1 0 0 0 19 9.2h-5.89l.77-7.09a1 1 0 0 0-.65-1 1 1 0 0 0-1.17.38L8.94 6.11l1.44 1.44z"/></g></g>',
                        "flash-outline": '<g data-name="Layer 2"><g data-name="flash"><rect width="24" height="24" opacity="0"/><path d="M11.11 23a1 1 0 0 1-.34-.06 1 1 0 0 1-.65-1.05l.77-7.09H5a1 1 0 0 1-.83-1.56l7.89-11.8a1 1 0 0 1 1.17-.38 1 1 0 0 1 .65 1l-.77 7.14H19a1 1 0 0 1 .83 1.56l-7.89 11.8a1 1 0 0 1-.83.44zM6.87 12.8H12a1 1 0 0 1 .74.33 1 1 0 0 1 .25.78l-.45 4.15 4.59-6.86H12a1 1 0 0 1-1-1.11l.45-4.15z"/></g></g>',
                        "flip-2-outline": '<g data-name="Layer 2"><g data-name="flip-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M6.09 19h12l-1.3 1.29a1 1 0 0 0 1.42 1.42l3-3a1 1 0 0 0 0-1.42l-3-3a1 1 0 0 0-1.42 0 1 1 0 0 0 0 1.42l1.3 1.29h-12a1.56 1.56 0 0 1-1.59-1.53V13a1 1 0 0 0-2 0v2.47A3.56 3.56 0 0 0 6.09 19z"/><path d="M5.79 9.71a1 1 0 1 0 1.42-1.42L5.91 7h12a1.56 1.56 0 0 1 1.59 1.53V11a1 1 0 0 0 2 0V8.53A3.56 3.56 0 0 0 17.91 5h-12l1.3-1.29a1 1 0 0 0 0-1.42 1 1 0 0 0-1.42 0l-3 3a1 1 0 0 0 0 1.42z"/></g></g>',
                        "flip-outline": '<g data-name="Layer 2"><g data-name="flip-in"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M5 6.09v12l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3a1 1 0 0 0 1.42 0l3-3a1 1 0 0 0 0-1.42 1 1 0 0 0-1.42 0L7 18.09v-12A1.56 1.56 0 0 1 8.53 4.5H11a1 1 0 0 0 0-2H8.53A3.56 3.56 0 0 0 5 6.09z"/><path d="M14.29 5.79a1 1 0 0 0 1.42 1.42L17 5.91v12a1.56 1.56 0 0 1-1.53 1.59H13a1 1 0 0 0 0 2h2.47A3.56 3.56 0 0 0 19 17.91v-12l1.29 1.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42l-3-3a1 1 0 0 0-1.42 0z"/></g></g>',
                        "folder-add-outline": '<g data-name="Layer 2"><g data-name="folder-add"><rect width="24" height="24" opacity="0"/><path d="M14 13h-1v-1a1 1 0 0 0-2 0v1h-1a1 1 0 0 0 0 2h1v1a1 1 0 0 0 2 0v-1h1a1 1 0 0 0 0-2z"/><path d="M19.5 7.05h-7L9.87 3.87a1 1 0 0 0-.77-.37H4.5A2.47 2.47 0 0 0 2 5.93v12.14a2.47 2.47 0 0 0 2.5 2.43h15a2.47 2.47 0 0 0 2.5-2.43V9.48a2.47 2.47 0 0 0-2.5-2.43zm.5 11a.46.46 0 0 1-.5.43h-15a.46.46 0 0 1-.5-.43V5.93a.46.46 0 0 1 .5-.43h4.13l2.6 3.18a1 1 0 0 0 .77.37h7.5a.46.46 0 0 1 .5.43z"/></g></g>',
                        "folder-outline": '<g data-name="Layer 2"><g data-name="folder"><rect width="24" height="24" opacity="0"/><path d="M19.5 20.5h-15A2.47 2.47 0 0 1 2 18.07V5.93A2.47 2.47 0 0 1 4.5 3.5h4.6a1 1 0 0 1 .77.37l2.6 3.18h7A2.47 2.47 0 0 1 22 9.48v8.59a2.47 2.47 0 0 1-2.5 2.43zM4 13.76v4.31a.46.46 0 0 0 .5.43h15a.46.46 0 0 0 .5-.43V9.48a.46.46 0 0 0-.5-.43H12a1 1 0 0 1-.77-.37L8.63 5.5H4.5a.46.46 0 0 0-.5.43z"/></g></g>',
                        "folder-remove-outline": '<g data-name="Layer 2"><g data-name="folder-remove"><rect width="24" height="24" opacity="0"/><path d="M14 13h-4a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2z"/><path d="M19.5 7.05h-7L9.87 3.87a1 1 0 0 0-.77-.37H4.5A2.47 2.47 0 0 0 2 5.93v12.14a2.47 2.47 0 0 0 2.5 2.43h15a2.47 2.47 0 0 0 2.5-2.43V9.48a2.47 2.47 0 0 0-2.5-2.43zm.5 11a.46.46 0 0 1-.5.43h-15a.46.46 0 0 1-.5-.43V5.93a.46.46 0 0 1 .5-.43h4.13l2.6 3.18a1 1 0 0 0 .77.37h7.5a.46.46 0 0 1 .5.43z"/></g></g>',
                        "funnel-outline": '<g data-name="Layer 2"><g data-name="funnel"><rect width="24" height="24" opacity="0"/><path d="M13.9 22a1 1 0 0 1-.6-.2l-4-3.05a1 1 0 0 1-.39-.8v-3.27l-4.8-9.22A1 1 0 0 1 5 4h14a1 1 0 0 1 .86.49 1 1 0 0 1 0 1l-5 9.21V21a1 1 0 0 1-.55.9 1 1 0 0 1-.41.1zm-3-4.54l2 1.53v-4.55A1 1 0 0 1 13 14l4.3-8H6.64l4.13 8a1 1 0 0 1 .11.46z"/></g></g>',
                        "gift-outline": '<g data-name="Layer 2"><g data-name="gift"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M19.2 7h-.39A3 3 0 0 0 19 6a3.08 3.08 0 0 0-3.14-3A4.46 4.46 0 0 0 12 5.4 4.46 4.46 0 0 0 8.14 3 3.08 3.08 0 0 0 5 6a3 3 0 0 0 .19 1H4.8A2 2 0 0 0 3 9.2v3.6A2.08 2.08 0 0 0 4.5 15v4.37A1.75 1.75 0 0 0 6.31 21h11.38a1.75 1.75 0 0 0 1.81-1.67V15a2.08 2.08 0 0 0 1.5-2.2V9.2A2 2 0 0 0 19.2 7zM19 9.2v3.6a.56.56 0 0 1 0 .2h-6V9h6a.56.56 0 0 1 0 .2zM15.86 5A1.08 1.08 0 0 1 17 6a1.08 1.08 0 0 1-1.14 1H13.4a2.93 2.93 0 0 1 2.46-2zM7 6a1.08 1.08 0 0 1 1.14-1 2.93 2.93 0 0 1 2.45 2H8.14A1.08 1.08 0 0 1 7 6zM5 9.2A.56.56 0 0 1 5 9h6v4H5a.56.56 0 0 1 0-.2zM6.5 15H11v4H6.5zm6.5 4v-4h4.5v4z"/></g></g>',
                        "github-outline": '<g data-name="Layer 2"><rect width="24" height="24" opacity="0"/><path d="M16.24 22a1 1 0 0 1-1-1v-2.6a2.15 2.15 0 0 0-.54-1.66 1 1 0 0 1 .61-1.67C17.75 14.78 20 14 20 9.77a4 4 0 0 0-.67-2.22 2.75 2.75 0 0 1-.41-2.06 3.71 3.71 0 0 0 0-1.41 7.65 7.65 0 0 0-2.09 1.09 1 1 0 0 1-.84.15 10.15 10.15 0 0 0-5.52 0 1 1 0 0 1-.84-.15 7.4 7.4 0 0 0-2.11-1.09 3.52 3.52 0 0 0 0 1.41 2.84 2.84 0 0 1-.43 2.08 4.07 4.07 0 0 0-.67 2.23c0 3.89 1.88 4.93 4.7 5.29a1 1 0 0 1 .82.66 1 1 0 0 1-.21 1 2.06 2.06 0 0 0-.55 1.56V21a1 1 0 0 1-2 0v-.57a6 6 0 0 1-5.27-2.09 3.9 3.9 0 0 0-1.16-.88 1 1 0 1 1 .5-1.94 4.93 4.93 0 0 1 2 1.36c1 1 2 1.88 3.9 1.52a3.89 3.89 0 0 1 .23-1.58c-2.06-.52-5-2-5-7a6 6 0 0 1 1-3.33.85.85 0 0 0 .13-.62 5.69 5.69 0 0 1 .33-3.21 1 1 0 0 1 .63-.57c.34-.1 1.56-.3 3.87 1.2a12.16 12.16 0 0 1 5.69 0c2.31-1.5 3.53-1.31 3.86-1.2a1 1 0 0 1 .63.57 5.71 5.71 0 0 1 .33 3.22.75.75 0 0 0 .11.57 6 6 0 0 1 1 3.34c0 5.07-2.92 6.54-5 7a4.28 4.28 0 0 1 .22 1.67V21a1 1 0 0 1-.94 1z"/></g>',
                        "globe-2-outline": '<g data-name="Layer 2"><g data-name="globe-2"><rect width="24" height="24" opacity="0"/><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 2a8.19 8.19 0 0 1 1.79.21 2.61 2.61 0 0 1-.78 1c-.22.17-.46.31-.7.46a4.56 4.56 0 0 0-1.85 1.67 6.49 6.49 0 0 0-.62 3.3c0 1.36 0 2.16-.95 2.87-1.37 1.07-3.46.47-4.76-.07A8.33 8.33 0 0 1 4 12a8 8 0 0 1 8-8zM5 15.8a8.42 8.42 0 0 0 2 .27 5 5 0 0 0 3.14-1c1.71-1.34 1.71-3.06 1.71-4.44a4.76 4.76 0 0 1 .37-2.34 2.86 2.86 0 0 1 1.12-.91 9.75 9.75 0 0 0 .92-.61 4.55 4.55 0 0 0 1.4-1.87A8 8 0 0 1 19 8.12c-1.43.2-3.46.67-3.86 2.53A7 7 0 0 0 15 12a2.93 2.93 0 0 1-.29 1.47l-.1.17c-.65 1.08-1.38 2.31-.39 4 .12.21.25.41.38.61a2.29 2.29 0 0 1 .52 1.08A7.89 7.89 0 0 1 12 20a8 8 0 0 1-7-4.2zm11.93 2.52a6.79 6.79 0 0 0-.63-1.14c-.11-.16-.22-.32-.32-.49-.39-.68-.25-1 .38-2l.1-.17a4.77 4.77 0 0 0 .54-2.43 5.42 5.42 0 0 1 .09-1c.16-.73 1.71-.93 2.67-1a7.94 7.94 0 0 1-2.86 8.28z"/></g></g>',
                        "globe-outline": '<g data-name="Layer 2"><g data-name="globe"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M22 12A10 10 0 0 0 12 2a10 10 0 0 0 0 20 10 10 0 0 0 10-10zm-2.07-1H17a12.91 12.91 0 0 0-2.33-6.54A8 8 0 0 1 19.93 11zM9.08 13H15a11.44 11.44 0 0 1-3 6.61A11 11 0 0 1 9.08 13zm0-2A11.4 11.4 0 0 1 12 4.4a11.19 11.19 0 0 1 3 6.6zm.36-6.57A13.18 13.18 0 0 0 7.07 11h-3a8 8 0 0 1 5.37-6.57zM4.07 13h3a12.86 12.86 0 0 0 2.35 6.56A8 8 0 0 1 4.07 13zm10.55 6.55A13.14 13.14 0 0 0 17 13h2.95a8 8 0 0 1-5.33 6.55z"/></g></g>',
                        "google-outline": '<g data-name="Layer 2"><g data-name="google"><polyline points="0 0 24 0 24 24 0 24" opacity="0"/><path d="M12 22h-.43A10.16 10.16 0 0 1 2 12.29a10 10 0 0 1 14.12-9.41 1.48 1.48 0 0 1 .77.86 1.47 1.47 0 0 1-.1 1.16L15.5 7.28a1.44 1.44 0 0 1-1.83.64A4.5 4.5 0 0 0 8.77 9a4.41 4.41 0 0 0-1.16 3.34 4.36 4.36 0 0 0 1.66 3 4.52 4.52 0 0 0 3.45 1 3.89 3.89 0 0 0 2.63-1.57h-2.9A1.45 1.45 0 0 1 11 13.33v-2.68a1.45 1.45 0 0 1 1.45-1.45h8.1A1.46 1.46 0 0 1 22 10.64v1.88A10 10 0 0 1 12 22zm0-18a8 8 0 0 0-8 8.24A8.12 8.12 0 0 0 11.65 20 8 8 0 0 0 20 12.42V11.2h-7v1.58h5.31l-.41 1.3a6 6 0 0 1-4.9 4.25A6.58 6.58 0 0 1 8 17a6.33 6.33 0 0 1-.72-9.3A6.52 6.52 0 0 1 14 5.91l.77-1.43A7.9 7.9 0 0 0 12 4z"/></g></g>',
                        "grid-outline": '<g data-name="Layer 2"><g data-name="grid"><rect width="24" height="24" opacity="0"/><path d="M9 3H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zM5 9V5h4v4z"/><path d="M19 3h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm-4 6V5h4v4z"/><path d="M9 13H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2zm-4 6v-4h4v4z"/><path d="M19 13h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2zm-4 6v-4h4v4z"/></g></g>',
                        "hard-drive-outline": '<g data-name="Layer 2"><g data-name="hard-drive"><rect width="24" height="24" opacity="0"/><path d="M20.79 11.34l-3.34-6.68A3 3 0 0 0 14.76 3H9.24a3 3 0 0 0-2.69 1.66l-3.34 6.68a2 2 0 0 0-.21.9V18a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-5.76a2 2 0 0 0-.21-.9zM8.34 5.55a1 1 0 0 1 .9-.55h5.52a1 1 0 0 1 .9.55L18.38 11H5.62zM18 19H6a1 1 0 0 1-1-1v-5h14v5a1 1 0 0 1-1 1z"/><path d="M16 15h-4a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2z"/><circle cx="8" cy="16" r="1"/></g></g>',
                        "hash-outline": '<g data-name="Layer 2"><g data-name="hash"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20 14h-4.3l.73-4H20a1 1 0 0 0 0-2h-3.21l.69-3.81A1 1 0 0 0 16.64 3a1 1 0 0 0-1.22.82L14.67 8h-3.88l.69-3.81A1 1 0 0 0 10.64 3a1 1 0 0 0-1.22.82L8.67 8H4a1 1 0 0 0 0 2h4.3l-.73 4H4a1 1 0 0 0 0 2h3.21l-.69 3.81A1 1 0 0 0 7.36 21a1 1 0 0 0 1.22-.82L9.33 16h3.88l-.69 3.81a1 1 0 0 0 .84 1.19 1 1 0 0 0 1.22-.82l.75-4.18H20a1 1 0 0 0 0-2zM9.7 14l.73-4h3.87l-.73 4z"/></g></g>',
                        "headphones-outline": '<g data-name="Layer 2"><g data-name="headphones"><rect width="24" height="24" opacity="0"/><path d="M12 2A10.2 10.2 0 0 0 2 12.37V17a4 4 0 1 0 4-4 3.91 3.91 0 0 0-2 .56v-1.19A8.2 8.2 0 0 1 12 4a8.2 8.2 0 0 1 8 8.37v1.19a3.91 3.91 0 0 0-2-.56 4 4 0 1 0 4 4v-4.63A10.2 10.2 0 0 0 12 2zM6 15a2 2 0 1 1-2 2 2 2 0 0 1 2-2zm12 4a2 2 0 1 1 2-2 2 2 0 0 1-2 2z"/></g></g>',
                        "heart-outline": '<g data-name="Layer 2"><g data-name="heart"><rect width="24" height="24" opacity="0"/><path d="M12 21a1 1 0 0 1-.71-.29l-7.77-7.78a5.26 5.26 0 0 1 0-7.4 5.24 5.24 0 0 1 7.4 0L12 6.61l1.08-1.08a5.24 5.24 0 0 1 7.4 0 5.26 5.26 0 0 1 0 7.4l-7.77 7.78A1 1 0 0 1 12 21zM7.22 6a3.2 3.2 0 0 0-2.28.94 3.24 3.24 0 0 0 0 4.57L12 18.58l7.06-7.07a3.24 3.24 0 0 0 0-4.57 3.32 3.32 0 0 0-4.56 0l-1.79 1.8a1 1 0 0 1-1.42 0L9.5 6.94A3.2 3.2 0 0 0 7.22 6z"/></g></g>',
                        "home-outline": '<g data-name="Layer 2"><g data-name="home"><rect width="24" height="24" opacity="0"/><path d="M20.42 10.18L12.71 2.3a1 1 0 0 0-1.42 0l-7.71 7.89A2 2 0 0 0 3 11.62V20a2 2 0 0 0 1.89 2h14.22A2 2 0 0 0 21 20v-8.38a2.07 2.07 0 0 0-.58-1.44zM10 20v-6h4v6zm9 0h-3v-7a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v7H5v-8.42l7-7.15 7 7.19z"/></g></g>',
                        "image-outline": '<g data-name="Layer 2"><g data-name="image"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zM6 5h12a1 1 0 0 1 1 1v8.36l-3.2-2.73a2.77 2.77 0 0 0-3.52 0L5 17.7V6a1 1 0 0 1 1-1zm12 14H6.56l7-5.84a.78.78 0 0 1 .93 0L19 17v1a1 1 0 0 1-1 1z"/><circle cx="8" cy="8.5" r="1.5"/></g></g>',
                        "inbox-outline": '<g data-name="Layer 2"><g data-name="inbox"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20.79 11.34l-3.34-6.68A3 3 0 0 0 14.76 3H9.24a3 3 0 0 0-2.69 1.66l-3.34 6.68a2 2 0 0 0-.21.9V18a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-5.76a2 2 0 0 0-.21-.9zM8.34 5.55a1 1 0 0 1 .9-.55h5.52a1 1 0 0 1 .9.55L18.38 11H16a1 1 0 0 0-1 1v3H9v-3a1 1 0 0 0-1-1H5.62zM18 19H6a1 1 0 0 1-1-1v-5h2v3a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-3h2v5a1 1 0 0 1-1 1z"/></g></g>',
                        "info-outline": '<g data-name="Layer 2"><g data-name="info"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><circle cx="12" cy="8" r="1"/><path d="M12 10a1 1 0 0 0-1 1v5a1 1 0 0 0 2 0v-5a1 1 0 0 0-1-1z"/></g></g>',
                        "keypad-outline": '<g data-name="Layer 2"><g data-name="keypad"><rect width="24" height="24" opacity="0"/><path d="M5 2a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M12 2a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M19 8a3 3 0 1 0-3-3 3 3 0 0 0 3 3zm0-4a1 1 0 1 1-1 1 1 1 0 0 1 1-1z"/><path d="M5 9a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M12 9a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M19 9a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M5 16a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M12 16a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M19 16a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "layers-outline": '<g data-name="Layer 2"><g data-name="layers"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M21 11.35a1 1 0 0 0-.61-.86l-2.15-.92 2.26-1.3a1 1 0 0 0 .5-.92 1 1 0 0 0-.61-.86l-8-3.41a1 1 0 0 0-.78 0l-8 3.41a1 1 0 0 0-.61.86 1 1 0 0 0 .5.92l2.26 1.3-2.15.92a1 1 0 0 0-.61.86 1 1 0 0 0 .5.92l2.26 1.3-2.15.92a1 1 0 0 0-.61.86 1 1 0 0 0 .5.92l8 4.6a1 1 0 0 0 1 0l8-4.6a1 1 0 0 0 .5-.92 1 1 0 0 0-.61-.86l-2.15-.92 2.26-1.3a1 1 0 0 0 .5-.92zm-9-6.26l5.76 2.45L12 10.85 6.24 7.54zm-.5 7.78a1 1 0 0 0 1 0l3.57-2 1.69.72L12 14.85l-5.76-3.31 1.69-.72zm6.26 2.67L12 18.85l-5.76-3.31 1.69-.72 3.57 2.05a1 1 0 0 0 1 0l3.57-2.05z"/></g></g>',
                        "layout-outline": '<g data-name="Layer 2"><g data-name="layout"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zM6 5h12a1 1 0 0 1 1 1v2H5V6a1 1 0 0 1 1-1zM5 18v-8h6v9H6a1 1 0 0 1-1-1zm13 1h-5v-9h6v8a1 1 0 0 1-1 1z"/></g></g>',
                        "link-2-outline": '<g data-name="Layer 2"><g data-name="link-2"><rect width="24" height="24" opacity="0"/><path d="M13.29 9.29l-4 4a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l4-4a1 1 0 0 0-1.42-1.42z"/><path d="M12.28 17.4L11 18.67a4.2 4.2 0 0 1-5.58.4 4 4 0 0 1-.27-5.93l1.42-1.43a1 1 0 0 0 0-1.42 1 1 0 0 0-1.42 0l-1.27 1.28a6.15 6.15 0 0 0-.67 8.07 6.06 6.06 0 0 0 9.07.6l1.42-1.42a1 1 0 0 0-1.42-1.42z"/><path d="M19.66 3.22a6.18 6.18 0 0 0-8.13.68L10.45 5a1.09 1.09 0 0 0-.17 1.61 1 1 0 0 0 1.42 0L13 5.3a4.17 4.17 0 0 1 5.57-.4 4 4 0 0 1 .27 5.95l-1.42 1.43a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l1.42-1.42a6.06 6.06 0 0 0-.6-9.06z"/></g></g>',
                        "link-outline": '<g data-name="Layer 2"><g data-name="link"><rect width="24" height="24" opacity="0"/><path d="M8 12a1 1 0 0 0 1 1h6a1 1 0 0 0 0-2H9a1 1 0 0 0-1 1z"/><path d="M9 16H7.21A4.13 4.13 0 0 1 3 12.37 4 4 0 0 1 7 8h2a1 1 0 0 0 0-2H7.21a6.15 6.15 0 0 0-6.16 5.21A6 6 0 0 0 7 18h2a1 1 0 0 0 0-2z"/><path d="M23 11.24A6.16 6.16 0 0 0 16.76 6h-1.51C14.44 6 14 6.45 14 7a1 1 0 0 0 1 1h1.79A4.13 4.13 0 0 1 21 11.63 4 4 0 0 1 17 16h-2a1 1 0 0 0 0 2h2a6 6 0 0 0 6-6.76z"/></g></g>',
                        "linkedin-outline": '<g data-name="Layer 2"><g data-name="linkedin"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20 22h-1.67a2 2 0 0 1-2-2v-5.37a.92.92 0 0 0-.69-.93.84.84 0 0 0-.67.19.85.85 0 0 0-.3.65V20a2 2 0 0 1-2 2H11a2 2 0 0 1-2-2v-5.46a6.5 6.5 0 1 1 13 0V20a2 2 0 0 1-2 2zm-4.5-10.31a3.73 3.73 0 0 1 .47 0 2.91 2.91 0 0 1 2.36 2.9V20H20v-5.46a4.5 4.5 0 1 0-9 0V20h1.67v-5.46a2.85 2.85 0 0 1 2.83-2.85z"/><path d="M6 22H4a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2zM4 10v10h2V10z"/><path d="M5 7a3 3 0 1 1 3-3 3 3 0 0 1-3 3zm0-4a1 1 0 1 0 1 1 1 1 0 0 0-1-1z"/></g></g>',
                        "list-outline": '<g data-name="Layer 2"><g data-name="list"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><circle cx="4" cy="7" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="17" r="1"/><rect x="7" y="11" width="14" height="2" rx=".94" ry=".94"/><rect x="7" y="16" width="14" height="2" rx=".94" ry=".94"/><rect x="7" y="6" width="14" height="2" rx=".94" ry=".94"/></g></g>',
                        "loader-outline": '<g data-name="Layer 2"><g data-name="loader"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 2a1 1 0 0 0-1 1v2a1 1 0 0 0 2 0V3a1 1 0 0 0-1-1z"/><path d="M21 11h-2a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2z"/><path d="M6 12a1 1 0 0 0-1-1H3a1 1 0 0 0 0 2h2a1 1 0 0 0 1-1z"/><path d="M6.22 5a1 1 0 0 0-1.39 1.47l1.44 1.39a1 1 0 0 0 .73.28 1 1 0 0 0 .72-.31 1 1 0 0 0 0-1.41z"/><path d="M17 8.14a1 1 0 0 0 .69-.28l1.44-1.39A1 1 0 0 0 17.78 5l-1.44 1.42a1 1 0 0 0 0 1.41 1 1 0 0 0 .66.31z"/><path d="M12 18a1 1 0 0 0-1 1v2a1 1 0 0 0 2 0v-2a1 1 0 0 0-1-1z"/><path d="M17.73 16.14a1 1 0 0 0-1.39 1.44L17.78 19a1 1 0 0 0 .69.28 1 1 0 0 0 .72-.3 1 1 0 0 0 0-1.42z"/><path d="M6.27 16.14l-1.44 1.39a1 1 0 0 0 0 1.42 1 1 0 0 0 .72.3 1 1 0 0 0 .67-.25l1.44-1.39a1 1 0 0 0-1.39-1.44z"/></g></g>',
                        "lock-outline": '<g data-name="Layer 2"><g data-name="lock"><rect width="24" height="24" opacity="0"/><path d="M17 8h-1V6.11a4 4 0 1 0-8 0V8H7a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-8a3 3 0 0 0-3-3zm-7-1.89A2.06 2.06 0 0 1 12 4a2.06 2.06 0 0 1 2 2.11V8h-4zM18 19a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1z"/><path d="M12 12a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "log-in-outline": '<g data-name="Layer 2"><g data-name="log-in"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M19 4h-2a1 1 0 0 0 0 2h1v12h-1a1 1 0 0 0 0 2h2a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1z"/><path d="M11.8 7.4a1 1 0 0 0-1.6 1.2L12 11H4a1 1 0 0 0 0 2h8.09l-1.72 2.44a1 1 0 0 0 .24 1.4 1 1 0 0 0 .58.18 1 1 0 0 0 .81-.42l2.82-4a1 1 0 0 0 0-1.18z"/></g></g>',
                        "log-out-outline": '<g data-name="Layer 2"><g data-name="log-out"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M7 6a1 1 0 0 0 0-2H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h2a1 1 0 0 0 0-2H6V6z"/><path d="M20.82 11.42l-2.82-4a1 1 0 0 0-1.39-.24 1 1 0 0 0-.24 1.4L18.09 11H10a1 1 0 0 0 0 2h8l-1.8 2.4a1 1 0 0 0 .2 1.4 1 1 0 0 0 .6.2 1 1 0 0 0 .8-.4l3-4a1 1 0 0 0 .02-1.18z"/></g></g>',
                        "map-outline": '<g data-name="Layer 2"><g data-name="map"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20.41 5.89l-4-1.8H15.59L12 5.7 8.41 4.09h-.05L8.24 4h-.6l-4 1.8a1 1 0 0 0-.64 1V19a1 1 0 0 0 .46.84A1 1 0 0 0 4 20a1 1 0 0 0 .41-.09L8 18.3l3.59 1.61h.05a.85.85 0 0 0 .72 0h.05L16 18.3l3.59 1.61A1 1 0 0 0 20 20a1 1 0 0 0 .54-.16A1 1 0 0 0 21 19V6.8a1 1 0 0 0-.59-.91zM5 7.44l2-.89v10l-2 .89zm4-.89l2 .89v10l-2-.89zm4 .89l2-.89v10l-2 .89zm6 10l-2-.89v-10l2 .89z"/></g></g>',
                        "maximize-outline": '<g data-name="Layer 2"><g data-name="maximize"><rect width="24" height="24" opacity="0"/><path d="M20.71 19.29l-3.4-3.39A7.92 7.92 0 0 0 19 11a8 8 0 1 0-8 8 7.92 7.92 0 0 0 4.9-1.69l3.39 3.4a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM5 11a6 6 0 1 1 6 6 6 6 0 0 1-6-6z"/><path d="M13 10h-1V9a1 1 0 0 0-2 0v1H9a1 1 0 0 0 0 2h1v1a1 1 0 0 0 2 0v-1h1a1 1 0 0 0 0-2z"/></g></g>',
                        "menu-2-outline": '<g data-name="Layer 2"><g data-name="menu-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><circle cx="4" cy="12" r="1"/><rect x="7" y="11" width="14" height="2" rx=".94" ry=".94"/><rect x="3" y="16" width="18" height="2" rx=".94" ry=".94"/><rect x="3" y="6" width="18" height="2" rx=".94" ry=".94"/></g></g>',
                        "menu-arrow-outline": '<g data-name="Layer 2"><g data-name="menu-arrow"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M20.05 11H5.91l1.3-1.29a1 1 0 0 0-1.42-1.42l-3 3a1 1 0 0 0 0 1.42l3 3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L5.91 13h14.14a1 1 0 0 0 .95-.95V12a1 1 0 0 0-.95-1z"/><rect x="3" y="17" width="18" height="2" rx=".95" ry=".95"/><rect x="3" y="5" width="18" height="2" rx=".95" ry=".95"/></g></g>',
                        "menu-outline": '<g data-name="Layer 2"><g data-name="menu"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><rect x="3" y="11" width="18" height="2" rx=".95" ry=".95"/><rect x="3" y="16" width="18" height="2" rx=".95" ry=".95"/><rect x="3" y="6" width="18" height="2" rx=".95" ry=".95"/></g></g>',
                        "message-circle-outline": '<g data-name="Layer 2"><g data-name="message-circle"><circle cx="12" cy="12" r="1"/><circle cx="16" cy="12" r="1"/><circle cx="8" cy="12" r="1"/><path d="M19.07 4.93a10 10 0 0 0-16.28 11 1.06 1.06 0 0 1 .09.64L2 20.8a1 1 0 0 0 .27.91A1 1 0 0 0 3 22h.2l4.28-.86a1.26 1.26 0 0 1 .64.09 10 10 0 0 0 11-16.28zm.83 8.36a8 8 0 0 1-11 6.08 3.26 3.26 0 0 0-1.25-.26 3.43 3.43 0 0 0-.56.05l-2.82.57.57-2.82a3.09 3.09 0 0 0-.21-1.81 8 8 0 0 1 6.08-11 8 8 0 0 1 9.19 9.19z"/><rect width="24" height="24" opacity="0"/></g></g>',
                        "message-square-outline": '<g data-name="Layer 2"><g data-name="message-square"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="11" r="1"/><circle cx="16" cy="11" r="1"/><circle cx="8" cy="11" r="1"/><path d="M19 3H5a3 3 0 0 0-3 3v15a1 1 0 0 0 .51.87A1 1 0 0 0 3 22a1 1 0 0 0 .51-.14L8 19.14a1 1 0 0 1 .55-.14H19a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm1 13a1 1 0 0 1-1 1H8.55a3 3 0 0 0-1.55.43l-3 1.8V6a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1z"/></g></g>',
                        "mic-off-outline": '<g data-name="Layer 2"><g data-name="mic-off"><rect width="24" height="24" opacity="0"/><path d="M10 6a2 2 0 0 1 4 0v5a1 1 0 0 1 0 .16l1.6 1.59A4 4 0 0 0 16 11V6a4 4 0 0 0-7.92-.75L10 7.17z"/><path d="M19 11a1 1 0 0 0-2 0 4.86 4.86 0 0 1-.69 2.48L17.78 15A7 7 0 0 0 19 11z"/><path d="M12 15h.16L8 10.83V11a4 4 0 0 0 4 4z"/><path d="M20.71 19.29l-16-16a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M15 20h-2v-2.08a7 7 0 0 0 1.65-.44l-1.6-1.6A4.57 4.57 0 0 1 12 16a5 5 0 0 1-5-5 1 1 0 0 0-2 0 7 7 0 0 0 6 6.92V20H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2z"/></g></g>',
                        "mic-outline": '<g data-name="Layer 2"><g data-name="mic"><rect width="24" height="24" opacity="0"/><path d="M12 15a4 4 0 0 0 4-4V6a4 4 0 0 0-8 0v5a4 4 0 0 0 4 4zm-2-9a2 2 0 0 1 4 0v5a2 2 0 0 1-4 0z"/><path d="M19 11a1 1 0 0 0-2 0 5 5 0 0 1-10 0 1 1 0 0 0-2 0 7 7 0 0 0 6 6.92V20H8.89a.89.89 0 0 0-.89.89v.22a.89.89 0 0 0 .89.89h6.22a.89.89 0 0 0 .89-.89v-.22a.89.89 0 0 0-.89-.89H13v-2.08A7 7 0 0 0 19 11z"/></g></g>',
                        "minimize-outline": '<g data-name="Layer 2"><g data-name="minimize"><rect width="24" height="24" opacity="0"/><path d="M20.71 19.29l-3.4-3.39A7.92 7.92 0 0 0 19 11a8 8 0 1 0-8 8 7.92 7.92 0 0 0 4.9-1.69l3.39 3.4a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM5 11a6 6 0 1 1 6 6 6 6 0 0 1-6-6z"/><path d="M13 10H9a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2z"/></g></g>',
                        "minus-circle-outline": '<g data-name="Layer 2"><g data-name="minus-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M15 11H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2z"/></g></g>',
                        "minus-outline": '<g data-name="Layer 2"><g data-name="minus"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M19 13H5a1 1 0 0 1 0-2h14a1 1 0 0 1 0 2z"/></g></g>',
                        "minus-square-outline": '<g data-name="Layer 2"><g data-name="minus-square"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm1 15a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1z"/><path d="M15 11H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2z"/></g></g>',
                        "monitor-outline": '<g data-name="Layer 2"><g data-name="monitor"><rect width="24" height="24" opacity="0"/><path d="M19 3H5a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h6v2H7a1 1 0 0 0 0 2h10a1 1 0 0 0 0-2h-4v-2h6a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm1 11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1z"/></g></g>',
                        "moon-outline": '<g data-name="Layer 2"><g data-name="moon"><rect width="24" height="24" opacity="0"/><path d="M12.3 22h-.1a10.31 10.31 0 0 1-7.34-3.15 10.46 10.46 0 0 1-.26-14 10.13 10.13 0 0 1 4-2.74 1 1 0 0 1 1.06.22 1 1 0 0 1 .24 1 8.4 8.4 0 0 0 1.94 8.81 8.47 8.47 0 0 0 8.83 1.94 1 1 0 0 1 1.27 1.29A10.16 10.16 0 0 1 19.6 19a10.28 10.28 0 0 1-7.3 3zM7.46 4.92a7.93 7.93 0 0 0-1.37 1.22 8.44 8.44 0 0 0 .2 11.32A8.29 8.29 0 0 0 12.22 20h.08a8.34 8.34 0 0 0 6.78-3.49A10.37 10.37 0 0 1 7.46 4.92z"/></g></g>',
                        "more-horizontal-outline": '<g data-name="Layer 2"><g data-name="more-horizotnal"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/><circle cx="5" cy="12" r="2"/></g></g>',
                        "more-vertical-outline": '<g data-name="Layer 2"><g data-name="more-vertical"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="5" r="2"/><circle cx="12" cy="19" r="2"/></g></g>',
                        "move-outline": '<g data-name="Layer 2"><g data-name="move"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M21.71 11.31l-3-3a1 1 0 0 0-1.42 1.42L18.58 11H13V5.41l1.29 1.3A1 1 0 0 0 15 7a1 1 0 0 0 .71-.29 1 1 0 0 0 0-1.42l-3-3A1 1 0 0 0 12 2a1 1 0 0 0-.7.29l-3 3a1 1 0 0 0 1.41 1.42L11 5.42V11H5.41l1.3-1.29a1 1 0 0 0-1.42-1.42l-3 3A1 1 0 0 0 2 12a1 1 0 0 0 .29.71l3 3A1 1 0 0 0 6 16a1 1 0 0 0 .71-.29 1 1 0 0 0 0-1.42L5.42 13H11v5.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 22a1 1 0 0 0 .7-.29l3-3a1 1 0 0 0-1.42-1.42L13 18.58V13h5.59l-1.3 1.29a1 1 0 0 0 0 1.42A1 1 0 0 0 18 16a1 1 0 0 0 .71-.29l3-3A1 1 0 0 0 22 12a1 1 0 0 0-.29-.69z"/></g></g>',
                        "music-outline": '<g data-name="Layer 2"><g data-name="music"><rect width="24" height="24" opacity="0"/><path d="M19 15V4a1 1 0 0 0-.38-.78 1 1 0 0 0-.84-.2l-9 2A1 1 0 0 0 8 6v8.34a3.49 3.49 0 1 0 2 3.18 4.36 4.36 0 0 0 0-.52V6.8l7-1.55v7.09a3.49 3.49 0 1 0 2 3.17 4.57 4.57 0 0 0 0-.51zM6.54 19A1.49 1.49 0 1 1 8 17.21a1.53 1.53 0 0 1 0 .3A1.49 1.49 0 0 1 6.54 19zm9-2A1.5 1.5 0 1 1 17 15.21a1.53 1.53 0 0 1 0 .3A1.5 1.5 0 0 1 15.51 17z"/></g></g>',
                        "navigation-2-outline": '<g data-name="Layer 2"><g data-name="navigation-2"><rect width="24" height="24" opacity="0"/><path d="M13.67 22h-.06a1 1 0 0 1-.92-.8L11 13l-8.2-1.69a1 1 0 0 1-.12-1.93l16-5.33A1 1 0 0 1 20 5.32l-5.33 16a1 1 0 0 1-1 .68zm-6.8-11.9l5.19 1.06a1 1 0 0 1 .79.78l1.05 5.19 3.52-10.55z"/></g></g>',
                        "navigation-outline": '<g data-name="Layer 2"><g data-name="navigation"><rect width="24" height="24" opacity="0"/><path d="M20 20a.94.94 0 0 1-.55-.17L12 14.9l-7.45 4.93a1 1 0 0 1-1.44-1.28l8-16a1 1 0 0 1 1.78 0l8 16a1 1 0 0 1-.23 1.2A1 1 0 0 1 20 20zm-8-7.3a1 1 0 0 1 .55.17l4.88 3.23L12 5.24 6.57 16.1l4.88-3.23a1 1 0 0 1 .55-.17z"/></g></g>',
                        "npm-outline": '<g data-name="Layer 2"><g data-name="npm"><rect width="24" height="24" opacity="0"/><path d="M18 21H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1z"/><rect x="12" y="9" width="4" height="10"/></g></g>',
                        "options-2-outline": '<g data-name="Layer 2"><g data-name="options-2"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M19 9a3 3 0 0 0-2.82 2H3a1 1 0 0 0 0 2h13.18A3 3 0 1 0 19 9zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M3 7h1.18a3 3 0 0 0 5.64 0H21a1 1 0 0 0 0-2H9.82a3 3 0 0 0-5.64 0H3a1 1 0 0 0 0 2zm4-2a1 1 0 1 1-1 1 1 1 0 0 1 1-1z"/><path d="M21 17h-7.18a3 3 0 0 0-5.64 0H3a1 1 0 0 0 0 2h5.18a3 3 0 0 0 5.64 0H21a1 1 0 0 0 0-2zm-10 2a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "options-outline": '<g data-name="Layer 2"><g data-name="options"><rect width="24" height="24" opacity="0"/><path d="M7 14.18V3a1 1 0 0 0-2 0v11.18a3 3 0 0 0 0 5.64V21a1 1 0 0 0 2 0v-1.18a3 3 0 0 0 0-5.64zM6 18a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M21 13a3 3 0 0 0-2-2.82V3a1 1 0 0 0-2 0v7.18a3 3 0 0 0 0 5.64V21a1 1 0 0 0 2 0v-5.18A3 3 0 0 0 21 13zm-3 1a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M15 5a3 3 0 1 0-4 2.82V21a1 1 0 0 0 2 0V7.82A3 3 0 0 0 15 5zm-3 1a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "pantone-outline": '<g data-name="Layer 2"><g data-name="pantone"><rect width="24" height="24" opacity="0"/><path d="M20 13.18h-4.06l2.3-2.47a1 1 0 0 0 0-1.41l-4.19-3.86a.93.93 0 0 0-.71-.26 1 1 0 0 0-.7.31l-1.82 2V4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v13.09A3.91 3.91 0 0 0 6.91 21H20a1 1 0 0 0 1-1v-5.82a1 1 0 0 0-1-1zm-6.58-5.59l2.67 2.49-5.27 5.66v-5.36zM8.82 10v3H5v-3zm0-5v3H5V5zM5 17.09V15h3.82v2.09a1.91 1.91 0 0 1-3.82 0zM19 19h-8.49l3.56-3.82H19z"/></g></g>',
                        "paper-plane-outline": '<g data-name="Layer 2"><g data-name="paper-plane"><rect width="24" height="24" opacity="0"/><path d="M21 4a1.31 1.31 0 0 0-.06-.27v-.09a1 1 0 0 0-.2-.3 1 1 0 0 0-.29-.19h-.09a.86.86 0 0 0-.31-.15H20a1 1 0 0 0-.3 0l-18 6a1 1 0 0 0 0 1.9l8.53 2.84 2.84 8.53a1 1 0 0 0 1.9 0l6-18A1 1 0 0 0 21 4zm-4.7 2.29l-5.57 5.57L5.16 10zM14 18.84l-1.86-5.57 5.57-5.57z"/></g></g>',
                        "pause-circle-outline": '<g data-name="Layer 2"><g data-name="pause-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M15 8a1 1 0 0 0-1 1v6a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z"/><path d="M9 8a1 1 0 0 0-1 1v6a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z"/></g></g>',
                        "people-outline": '<g data-name="Layer 2"><g data-name="people"><rect width="24" height="24" opacity="0"/><path d="M9 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0-6a2 2 0 1 1-2 2 2 2 0 0 1 2-2z"/><path d="M17 13a3 3 0 1 0-3-3 3 3 0 0 0 3 3zm0-4a1 1 0 1 1-1 1 1 1 0 0 1 1-1z"/><path d="M17 14a5 5 0 0 0-3.06 1.05A7 7 0 0 0 2 20a1 1 0 0 0 2 0 5 5 0 0 1 10 0 1 1 0 0 0 2 0 6.9 6.9 0 0 0-.86-3.35A3 3 0 0 1 20 19a1 1 0 0 0 2 0 5 5 0 0 0-5-5z"/></g></g>',
                        "percent-outline": '<g data-name="Layer 2"><g data-name="percent"><rect width="24" height="24" opacity="0"/><path d="M8 11a3.5 3.5 0 1 0-3.5-3.5A3.5 3.5 0 0 0 8 11zm0-5a1.5 1.5 0 1 1-1.5 1.5A1.5 1.5 0 0 1 8 6z"/><path d="M16 14a3.5 3.5 0 1 0 3.5 3.5A3.5 3.5 0 0 0 16 14zm0 5a1.5 1.5 0 1 1 1.5-1.5A1.5 1.5 0 0 1 16 19z"/><path d="M19.74 4.26a.89.89 0 0 0-1.26 0L4.26 18.48a.91.91 0 0 0-.26.63.89.89 0 0 0 1.52.63L19.74 5.52a.89.89 0 0 0 0-1.26z"/></g></g>',
                        "person-add-outline": '<g data-name="Layer 2"><g data-name="person-add"><rect width="24" height="24" opacity="0"/><path d="M21 6h-1V5a1 1 0 0 0-2 0v1h-1a1 1 0 0 0 0 2h1v1a1 1 0 0 0 2 0V8h1a1 1 0 0 0 0-2z"/><path d="M10 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0-6a2 2 0 1 1-2 2 2 2 0 0 1 2-2z"/><path d="M10 13a7 7 0 0 0-7 7 1 1 0 0 0 2 0 5 5 0 0 1 10 0 1 1 0 0 0 2 0 7 7 0 0 0-7-7z"/></g></g>',
                        "person-delete-outline": '<g data-name="Layer 2"><g data-name="person-delete"><rect width="24" height="24" opacity="0"/><path d="M20.47 7.5l.73-.73a1 1 0 0 0-1.47-1.47L19 6l-.73-.73a1 1 0 0 0-1.47 1.5l.73.73-.73.73a1 1 0 0 0 1.47 1.47L19 9l.73.73a1 1 0 0 0 1.47-1.5z"/><path d="M10 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0-6a2 2 0 1 1-2 2 2 2 0 0 1 2-2z"/><path d="M10 13a7 7 0 0 0-7 7 1 1 0 0 0 2 0 5 5 0 0 1 10 0 1 1 0 0 0 2 0 7 7 0 0 0-7-7z"/></g></g>',
                        "person-done-outline": '<g data-name="Layer 2"><g data-name="person-done"><rect width="24" height="24" opacity="0"/><path d="M21.66 4.25a1 1 0 0 0-1.41.09l-1.87 2.15-.63-.71a1 1 0 0 0-1.5 1.33l1.39 1.56a1 1 0 0 0 .75.33 1 1 0 0 0 .74-.34l2.61-3a1 1 0 0 0-.08-1.41z"/><path d="M10 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0-6a2 2 0 1 1-2 2 2 2 0 0 1 2-2z"/><path d="M10 13a7 7 0 0 0-7 7 1 1 0 0 0 2 0 5 5 0 0 1 10 0 1 1 0 0 0 2 0 7 7 0 0 0-7-7z"/></g></g>',
                        "person-outline": '<g data-name="Layer 2"><g data-name="person"><rect width="24" height="24" opacity="0"/><path d="M12 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0-6a2 2 0 1 1-2 2 2 2 0 0 1 2-2z"/><path d="M12 13a7 7 0 0 0-7 7 1 1 0 0 0 2 0 5 5 0 0 1 10 0 1 1 0 0 0 2 0 7 7 0 0 0-7-7z"/></g></g>',
                        "person-remove-outline": '<g data-name="Layer 2"><g data-name="person-remove"><rect width="24" height="24" opacity="0"/><path d="M21 6h-4a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2z"/><path d="M10 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0-6a2 2 0 1 1-2 2 2 2 0 0 1 2-2z"/><path d="M10 13a7 7 0 0 0-7 7 1 1 0 0 0 2 0 5 5 0 0 1 10 0 1 1 0 0 0 2 0 7 7 0 0 0-7-7z"/></g></g>',
                        "phone-call-outline": '<g data-name="Layer 2"><g data-name="phone-call"><rect width="24" height="24" opacity="0"/><path d="M13 8a3 3 0 0 1 3 3 1 1 0 0 0 2 0 5 5 0 0 0-5-5 1 1 0 0 0 0 2z"/><path d="M13 4a7 7 0 0 1 7 7 1 1 0 0 0 2 0 9 9 0 0 0-9-9 1 1 0 0 0 0 2z"/><path d="M21.75 15.91a1 1 0 0 0-.72-.65l-6-1.37a1 1 0 0 0-.92.26c-.14.13-.15.14-.8 1.38a9.91 9.91 0 0 1-4.87-4.89C9.71 10 9.72 10 9.85 9.85a1 1 0 0 0 .26-.92L8.74 3a1 1 0 0 0-.65-.72 3.79 3.79 0 0 0-.72-.18A3.94 3.94 0 0 0 6.6 2 4.6 4.6 0 0 0 2 6.6 15.42 15.42 0 0 0 17.4 22a4.6 4.6 0 0 0 4.6-4.6 4.77 4.77 0 0 0-.06-.76 4.34 4.34 0 0 0-.19-.73zM17.4 20A13.41 13.41 0 0 1 4 6.6 2.61 2.61 0 0 1 6.6 4h.33L8 8.64l-.54.28c-.86.45-1.54.81-1.18 1.59a11.85 11.85 0 0 0 7.18 7.21c.84.34 1.17-.29 1.62-1.16l.29-.55L20 17.07v.33a2.61 2.61 0 0 1-2.6 2.6z"/></g></g>',
                        "phone-missed-outline": '<g data-name="Layer 2"><g data-name="phone-missed"><rect width="24" height="24" opacity="0"/><path d="M21.94 16.64a4.34 4.34 0 0 0-.19-.73 1 1 0 0 0-.72-.65l-6-1.37a1 1 0 0 0-.92.26c-.14.13-.15.14-.8 1.38a10 10 0 0 1-4.88-4.89C9.71 10 9.72 10 9.85 9.85a1 1 0 0 0 .26-.92L8.74 3a1 1 0 0 0-.65-.72 3.79 3.79 0 0 0-.72-.18A3.94 3.94 0 0 0 6.6 2 4.6 4.6 0 0 0 2 6.6 15.42 15.42 0 0 0 17.4 22a4.6 4.6 0 0 0 4.6-4.6 4.77 4.77 0 0 0-.06-.76zM17.4 20A13.41 13.41 0 0 1 4 6.6 2.61 2.61 0 0 1 6.6 4h.33L8 8.64l-.55.29c-.87.45-1.5.78-1.17 1.58a11.85 11.85 0 0 0 7.18 7.21c.84.34 1.17-.29 1.62-1.16l.29-.55L20 17.07v.33a2.61 2.61 0 0 1-2.6 2.6z"/><path d="M15.8 8.7a1.05 1.05 0 0 0 1.47 0L18 8l.73.73a1 1 0 0 0 1.47-1.5l-.73-.73.73-.73a1 1 0 0 0-1.47-1.47L18 5l-.73-.73a1 1 0 0 0-1.47 1.5l.73.73-.73.73a1.05 1.05 0 0 0 0 1.47z"/></g></g>',
                        "phone-off-outline": '<g data-name="Layer 2"><g data-name="phone-off"><rect width="24" height="24" opacity="0"/><path d="M19.74 4.26a.89.89 0 0 0-1.26 0L4.26 18.48a.91.91 0 0 0-.26.63.89.89 0 0 0 1.52.63L19.74 5.52a.89.89 0 0 0 0-1.26z"/><path d="M6.7 14.63A13.29 13.29 0 0 1 4 6.6 2.61 2.61 0 0 1 6.6 4h.33L8 8.64l-.55.29c-.87.45-1.5.78-1.17 1.58a11.57 11.57 0 0 0 1.57 3l1.43-1.42a10.37 10.37 0 0 1-.8-1.42C9.71 10 9.72 10 9.85 9.85a1 1 0 0 0 .26-.92L8.74 3a1 1 0 0 0-.65-.72 3.79 3.79 0 0 0-.72-.18A3.94 3.94 0 0 0 6.6 2 4.6 4.6 0 0 0 2 6.6a15.33 15.33 0 0 0 3.27 9.46z"/><path d="M21.94 16.64a4.34 4.34 0 0 0-.19-.73 1 1 0 0 0-.72-.65l-6-1.37a1 1 0 0 0-.92.26c-.14.13-.15.14-.8 1.38a10.88 10.88 0 0 1-1.41-.8l-1.43 1.43a11.52 11.52 0 0 0 2.94 1.56c.84.34 1.17-.29 1.62-1.16l.29-.55L20 17.07v.33a2.61 2.61 0 0 1-2.6 2.6 13.29 13.29 0 0 1-8-2.7l-1.46 1.43A15.33 15.33 0 0 0 17.4 22a4.6 4.6 0 0 0 4.6-4.6 4.77 4.77 0 0 0-.06-.76z"/></g></g>',
                        "phone-outline": '<g data-name="Layer 2"><g data-name="phone"><rect width="24" height="24" opacity="0"/><path d="M17.4 22A15.42 15.42 0 0 1 2 6.6 4.6 4.6 0 0 1 6.6 2a3.94 3.94 0 0 1 .77.07 3.79 3.79 0 0 1 .72.18 1 1 0 0 1 .65.75l1.37 6a1 1 0 0 1-.26.92c-.13.14-.14.15-1.37.79a9.91 9.91 0 0 0 4.87 4.89c.65-1.24.66-1.25.8-1.38a1 1 0 0 1 .92-.26l6 1.37a1 1 0 0 1 .72.65 4.34 4.34 0 0 1 .19.73 4.77 4.77 0 0 1 .06.76A4.6 4.6 0 0 1 17.4 22zM6.6 4A2.61 2.61 0 0 0 4 6.6 13.41 13.41 0 0 0 17.4 20a2.61 2.61 0 0 0 2.6-2.6v-.33L15.36 16l-.29.55c-.45.87-.78 1.5-1.62 1.16a11.85 11.85 0 0 1-7.18-7.21c-.36-.78.32-1.14 1.18-1.59L8 8.64 6.93 4z"/></g></g>',
                        "pie-chart-outline": '<g data-name="Layer 2"><g data-name="pie-chart"><rect width="24" height="24" opacity="0"/><path d="M13 2a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1 9 9 0 0 0-9-9zm1 8V4.07A7 7 0 0 1 19.93 10z"/><path d="M20.82 14.06a1 1 0 0 0-1.28.61A8 8 0 1 1 9.33 4.46a1 1 0 0 0-.66-1.89 10 10 0 1 0 12.76 12.76 1 1 0 0 0-.61-1.27z"/></g></g>',
                        "pin-outline": '<g data-name="Layer 2"><g data-name="pin"><rect width="24" height="24" opacity="0"/><path d="M12 2a8 8 0 0 0-8 7.92c0 5.48 7.05 11.58 7.35 11.84a1 1 0 0 0 1.3 0C13 21.5 20 15.4 20 9.92A8 8 0 0 0 12 2zm0 17.65c-1.67-1.59-6-6-6-9.73a6 6 0 0 1 12 0c0 3.7-4.33 8.14-6 9.73z"/><path d="M12 6a3.5 3.5 0 1 0 3.5 3.5A3.5 3.5 0 0 0 12 6zm0 5a1.5 1.5 0 1 1 1.5-1.5A1.5 1.5 0 0 1 12 11z"/></g></g>',
                        "play-circle-outline": '<g data-name="Layer 2"><g data-name="play-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M12.34 7.45a1.7 1.7 0 0 0-1.85-.3 1.6 1.6 0 0 0-1 1.48v6.74a1.6 1.6 0 0 0 1 1.48 1.68 1.68 0 0 0 .69.15 1.74 1.74 0 0 0 1.16-.45L16 13.18a1.6 1.6 0 0 0 0-2.36zm-.84 7.15V9.4l2.81 2.6z"/></g></g>',
                        "plus-circle-outline": '<g data-name="Layer 2"><g data-name="plus-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M15 11h-2V9a1 1 0 0 0-2 0v2H9a1 1 0 0 0 0 2h2v2a1 1 0 0 0 2 0v-2h2a1 1 0 0 0 0-2z"/></g></g>',
                        "plus-outline": '<g data-name="Layer 2"><g data-name="plus"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M19 11h-6V5a1 1 0 0 0-2 0v6H5a1 1 0 0 0 0 2h6v6a1 1 0 0 0 2 0v-6h6a1 1 0 0 0 0-2z"/></g></g>',
                        "plus-square-outline": '<g data-name="Layer 2"><g data-name="plus-square"><rect width="24" height="24" opacity="0"/><path d="M18 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm1 15a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1z"/><path d="M15 11h-2V9a1 1 0 0 0-2 0v2H9a1 1 0 0 0 0 2h2v2a1 1 0 0 0 2 0v-2h2a1 1 0 0 0 0-2z"/></g></g>',
                        "power-outline": '<g data-name="Layer 2"><g data-name="power"><rect width="24" height="24" opacity="0"/><path d="M12 13a1 1 0 0 0 1-1V2a1 1 0 0 0-2 0v10a1 1 0 0 0 1 1z"/><path d="M16.59 3.11a1 1 0 0 0-.92 1.78 8 8 0 1 1-7.34 0 1 1 0 1 0-.92-1.78 10 10 0 1 0 9.18 0z"/></g></g>',
                        "pricetags-outline": '<g data-name="Layer 2"><g data-name="pricetags"><rect width="24" height="24" opacity="0"/><path d="M12.87 22a1.84 1.84 0 0 1-1.29-.53l-6.41-6.42a1 1 0 0 1-.29-.61L4 5.09a1 1 0 0 1 .29-.8 1 1 0 0 1 .8-.29l9.35.88a1 1 0 0 1 .61.29l6.42 6.41a1.82 1.82 0 0 1 0 2.57l-7.32 7.32a1.82 1.82 0 0 1-1.28.53zm-6-8.11l6 6 7.05-7.05-6-6-7.81-.73z"/><circle cx="10.5" cy="10.5" r="1.5"/></g></g>',
                        "printer-outline": '<g data-name="Layer 2"><g data-name="printer"><rect width="24" height="24" opacity="0"/><path d="M19.36 7H18V5a1.92 1.92 0 0 0-1.83-2H7.83A1.92 1.92 0 0 0 6 5v2H4.64A2.66 2.66 0 0 0 2 9.67v6.66A2.66 2.66 0 0 0 4.64 19h.86a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2h.86A2.66 2.66 0 0 0 22 16.33V9.67A2.66 2.66 0 0 0 19.36 7zM8 5h8v2H8zm-.5 14v-4h9v4zM20 16.33a.66.66 0 0 1-.64.67h-.86v-2a2 2 0 0 0-2-2h-9a2 2 0 0 0-2 2v2h-.86a.66.66 0 0 1-.64-.67V9.67A.66.66 0 0 1 4.64 9h14.72a.66.66 0 0 1 .64.67z"/></g></g>',
                        "question-mark-circle-outline": '<g data-name="Layer 2"><g data-name="menu-arrow-circle"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M12 6a3.5 3.5 0 0 0-3.5 3.5 1 1 0 0 0 2 0A1.5 1.5 0 1 1 12 11a1 1 0 0 0-1 1v2a1 1 0 0 0 2 0v-1.16A3.49 3.49 0 0 0 12 6z"/><circle cx="12" cy="17" r="1"/></g></g>',
                        "question-mark-outline": '<g data-name="Layer 2"><g data-name="question-mark"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M17 9A5 5 0 0 0 7 9a1 1 0 0 0 2 0 3 3 0 1 1 3 3 1 1 0 0 0-1 1v2a1 1 0 0 0 2 0v-1.1A5 5 0 0 0 17 9z"/><circle cx="12" cy="19" r="1"/></g></g>',
                        "radio-button-off-outline": '<g data-name="Layer 2"><g data-name="radio-button-off"><rect width="24" height="24" opacity="0"/><path d="M12 22a10 10 0 1 1 10-10 10 10 0 0 1-10 10zm0-18a8 8 0 1 0 8 8 8 8 0 0 0-8-8z"/></g></g>',
                        "radio-button-on-outline": '<g data-name="Layer 2"><g data-name="radio-button-on"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M12 7a5 5 0 1 0 5 5 5 5 0 0 0-5-5zm0 8a3 3 0 1 1 3-3 3 3 0 0 1-3 3z"/></g></g>',
                        "radio-outline": '<g data-name="Layer 2"><g data-name="radio"><rect width="24" height="24" opacity="0"/><path d="M12 8a3 3 0 0 0-1 5.83 1 1 0 0 0 0 .17v6a1 1 0 0 0 2 0v-6a1 1 0 0 0 0-.17A3 3 0 0 0 12 8zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M3.5 11a6.87 6.87 0 0 1 2.64-5.23 1 1 0 1 0-1.28-1.54A8.84 8.84 0 0 0 1.5 11a8.84 8.84 0 0 0 3.36 6.77 1 1 0 1 0 1.28-1.54A6.87 6.87 0 0 1 3.5 11z"/><path d="M16.64 6.24a1 1 0 0 0-1.28 1.52A4.28 4.28 0 0 1 17 11a4.28 4.28 0 0 1-1.64 3.24A1 1 0 0 0 16 16a1 1 0 0 0 .64-.24A6.2 6.2 0 0 0 19 11a6.2 6.2 0 0 0-2.36-4.76z"/><path d="M8.76 6.36a1 1 0 0 0-1.4-.12A6.2 6.2 0 0 0 5 11a6.2 6.2 0 0 0 2.36 4.76 1 1 0 0 0 1.4-.12 1 1 0 0 0-.12-1.4A4.28 4.28 0 0 1 7 11a4.28 4.28 0 0 1 1.64-3.24 1 1 0 0 0 .12-1.4z"/><path d="M19.14 4.23a1 1 0 1 0-1.28 1.54A6.87 6.87 0 0 1 20.5 11a6.87 6.87 0 0 1-2.64 5.23 1 1 0 0 0 1.28 1.54A8.84 8.84 0 0 0 22.5 11a8.84 8.84 0 0 0-3.36-6.77z"/></g></g>',
                        "recording-outline": '<g data-name="Layer 2"><g data-name="recording"><rect width="24" height="24" opacity="0"/><path d="M18 8a4 4 0 0 0-4 4 3.91 3.91 0 0 0 .56 2H9.44a3.91 3.91 0 0 0 .56-2 4 4 0 1 0-4 4h12a4 4 0 0 0 0-8zM4 12a2 2 0 1 1 2 2 2 2 0 0 1-2-2zm14 2a2 2 0 1 1 2-2 2 2 0 0 1-2 2z"/></g></g>',
                        "refresh-outline": '<g data-name="Layer 2"><g data-name="refresh"><rect width="24" height="24" opacity="0"/><path d="M20.3 13.43a1 1 0 0 0-1.25.65A7.14 7.14 0 0 1 12.18 19 7.1 7.1 0 0 1 5 12a7.1 7.1 0 0 1 7.18-7 7.26 7.26 0 0 1 4.65 1.67l-2.17-.36a1 1 0 0 0-1.15.83 1 1 0 0 0 .83 1.15l4.24.7h.17a1 1 0 0 0 .34-.06.33.33 0 0 0 .1-.06.78.78 0 0 0 .2-.11l.09-.11c0-.05.09-.09.13-.15s0-.1.05-.14a1.34 1.34 0 0 0 .07-.18l.75-4a1 1 0 0 0-2-.38l-.27 1.45A9.21 9.21 0 0 0 12.18 3 9.1 9.1 0 0 0 3 12a9.1 9.1 0 0 0 9.18 9A9.12 9.12 0 0 0 21 14.68a1 1 0 0 0-.7-1.25z"/></g></g>',
                        "repeat-outline": '<g data-name="Layer 2"><g data-name="repeat"><rect width="24" height="24" opacity="0"/><path d="M17.91 5h-12l1.3-1.29a1 1 0 0 0-1.42-1.42l-3 3a1 1 0 0 0 0 1.42l3 3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L5.91 7h12a1.56 1.56 0 0 1 1.59 1.53V11a1 1 0 0 0 2 0V8.53A3.56 3.56 0 0 0 17.91 5z"/><path d="M18.21 14.29a1 1 0 0 0-1.42 1.42l1.3 1.29h-12a1.56 1.56 0 0 1-1.59-1.53V13a1 1 0 0 0-2 0v2.47A3.56 3.56 0 0 0 6.09 19h12l-1.3 1.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l3-3a1 1 0 0 0 0-1.42z"/></g></g>',
                        "rewind-left-outline": '<g data-name="Layer 2"><g data-name="rewind-left"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18.45 6.2a2.1 2.1 0 0 0-2.21.26l-4.74 3.92V7.79a1.76 1.76 0 0 0-1.05-1.59 2.1 2.1 0 0 0-2.21.26l-5.1 4.21a1.7 1.7 0 0 0 0 2.66l5.1 4.21a2.06 2.06 0 0 0 1.3.46 2.23 2.23 0 0 0 .91-.2 1.76 1.76 0 0 0 1.05-1.59v-2.59l4.74 3.92a2.06 2.06 0 0 0 1.3.46 2.23 2.23 0 0 0 .91-.2 1.76 1.76 0 0 0 1.05-1.59V7.79a1.76 1.76 0 0 0-1.05-1.59zM9.5 16l-4.82-4L9.5 8.09zm8 0l-4.82-4 4.82-3.91z"/></g></g>',
                        "rewind-right-outline": '<g data-name="Layer 2"><g data-name="rewind-right"><rect width="24" height="24" opacity="0"/><path d="M20.86 10.67l-5.1-4.21a2.1 2.1 0 0 0-2.21-.26 1.76 1.76 0 0 0-1.05 1.59v2.59L7.76 6.46a2.1 2.1 0 0 0-2.21-.26 1.76 1.76 0 0 0-1 1.59v8.42a1.76 1.76 0 0 0 1 1.59 2.23 2.23 0 0 0 .91.2 2.06 2.06 0 0 0 1.3-.46l4.74-3.92v2.59a1.76 1.76 0 0 0 1.05 1.59 2.23 2.23 0 0 0 .91.2 2.06 2.06 0 0 0 1.3-.46l5.1-4.21a1.7 1.7 0 0 0 0-2.66zM6.5 15.91V8l4.82 4zm8 0V8l4.82 4z"/></g></g>',
                        "save-outline": '<g data-name="Layer 2"><g data-name="save"><rect width="24" height="24" opacity="0"/><path d="M20.12 8.71l-4.83-4.83A3 3 0 0 0 13.17 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-7.17a3 3 0 0 0-.88-2.12zM10 19v-2h4v2zm9-1a1 1 0 0 1-1 1h-2v-3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h2v5a1 1 0 0 0 1 1h4a1 1 0 0 0 0-2h-3V5h3.17a1.05 1.05 0 0 1 .71.29l4.83 4.83a1 1 0 0 1 .29.71z"/></g></g>',
                        "scissors-outline": '<g data-name="Layer 2"><g data-name="scissors"><rect width="24" height="24" opacity="0"/><path d="M20.21 5.71a1 1 0 1 0-1.42-1.42l-6.28 6.31-3.3-3.31A3 3 0 0 0 9.5 6a3 3 0 1 0-3 3 3 3 0 0 0 1.29-.3L11.1 12l-3.29 3.3A3 3 0 0 0 6.5 15a3 3 0 1 0 3 3 3 3 0 0 0-.29-1.26zM6.5 7a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm0 12a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/><path d="M15.21 13.29a1 1 0 0 0-1.42 1.42l5 5a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/></g></g>',
                        "search-outline": '<g data-name="Layer 2"><g data-name="search"><rect width="24" height="24" opacity="0"/><path d="M20.71 19.29l-3.4-3.39A7.92 7.92 0 0 0 19 11a8 8 0 1 0-8 8 7.92 7.92 0 0 0 4.9-1.69l3.39 3.4a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM5 11a6 6 0 1 1 6 6 6 6 0 0 1-6-6z"/></g></g>',
                        "settings-2-outline": '<g data-name="Layer 2"><g data-name="settings-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12.94 22h-1.89a1.68 1.68 0 0 1-1.68-1.68v-1.09a.34.34 0 0 0-.22-.29.38.38 0 0 0-.41 0l-.74.8a1.67 1.67 0 0 1-2.37 0L4.26 18.4a1.66 1.66 0 0 1-.5-1.19 1.72 1.72 0 0 1 .5-1.21l.74-.74a.34.34 0 0 0 0-.37c-.06-.15-.16-.26-.3-.26H3.68A1.69 1.69 0 0 1 2 12.94v-1.89a1.68 1.68 0 0 1 1.68-1.68h1.09a.34.34 0 0 0 .29-.22.38.38 0 0 0 0-.41L4.26 8a1.67 1.67 0 0 1 0-2.37L5.6 4.26a1.65 1.65 0 0 1 1.18-.5 1.72 1.72 0 0 1 1.22.5l.74.74a.34.34 0 0 0 .37 0c.15-.06.26-.16.26-.3V3.68A1.69 1.69 0 0 1 11.06 2H13a1.68 1.68 0 0 1 1.68 1.68v1.09a.34.34 0 0 0 .22.29.38.38 0 0 0 .41 0l.69-.8a1.67 1.67 0 0 1 2.37 0l1.37 1.34a1.67 1.67 0 0 1 .5 1.19 1.63 1.63 0 0 1-.5 1.21l-.74.74a.34.34 0 0 0 0 .37c.06.15.16.26.3.26h1.09A1.69 1.69 0 0 1 22 11.06V13a1.68 1.68 0 0 1-1.68 1.68h-1.09a.34.34 0 0 0-.29.22.34.34 0 0 0 0 .37l.77.77a1.67 1.67 0 0 1 0 2.37l-1.31 1.33a1.65 1.65 0 0 1-1.18.5 1.72 1.72 0 0 1-1.19-.5l-.77-.74a.34.34 0 0 0-.37 0c-.15.06-.26.16-.26.3v1.09A1.69 1.69 0 0 1 12.94 22zm-1.57-2h1.26v-.77a2.33 2.33 0 0 1 1.46-2.14 2.36 2.36 0 0 1 2.59.47l.54.54.88-.88-.54-.55a2.34 2.34 0 0 1-.48-2.56 2.33 2.33 0 0 1 2.14-1.45H20v-1.29h-.77a2.33 2.33 0 0 1-2.14-1.46 2.36 2.36 0 0 1 .47-2.59l.54-.54-.88-.88-.55.54a2.39 2.39 0 0 1-4-1.67V4h-1.3v.77a2.33 2.33 0 0 1-1.46 2.14 2.36 2.36 0 0 1-2.59-.47l-.54-.54-.88.88.54.55a2.39 2.39 0 0 1-1.67 4H4v1.26h.77a2.33 2.33 0 0 1 2.14 1.46 2.36 2.36 0 0 1-.47 2.59l-.54.54.88.88.55-.54a2.39 2.39 0 0 1 4 1.67z" data-name="&lt;Group&gt;"/><path d="M12 15.5a3.5 3.5 0 1 1 3.5-3.5 3.5 3.5 0 0 1-3.5 3.5zm0-5a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5z"/></g></g>',
                        "settings-outline": '<g data-name="Layer 2"><g data-name="settings"><rect width="24" height="24" opacity="0"/><path d="M8.61 22a2.25 2.25 0 0 1-1.35-.46L5.19 20a2.37 2.37 0 0 1-.49-3.22 2.06 2.06 0 0 0 .23-1.86l-.06-.16a1.83 1.83 0 0 0-1.12-1.22h-.16a2.34 2.34 0 0 1-1.48-2.94L2.93 8a2.18 2.18 0 0 1 1.12-1.41 2.14 2.14 0 0 1 1.68-.12 1.93 1.93 0 0 0 1.78-.29l.13-.1a1.94 1.94 0 0 0 .73-1.51v-.24A2.32 2.32 0 0 1 10.66 2h2.55a2.26 2.26 0 0 1 1.6.67 2.37 2.37 0 0 1 .68 1.68v.28a1.76 1.76 0 0 0 .69 1.43l.11.08a1.74 1.74 0 0 0 1.59.26l.34-.11A2.26 2.26 0 0 1 21.1 7.8l.79 2.52a2.36 2.36 0 0 1-1.46 2.93l-.2.07A1.89 1.89 0 0 0 19 14.6a2 2 0 0 0 .25 1.65l.26.38a2.38 2.38 0 0 1-.5 3.23L17 21.41a2.24 2.24 0 0 1-3.22-.53l-.12-.17a1.75 1.75 0 0 0-1.5-.78 1.8 1.8 0 0 0-1.43.77l-.23.33A2.25 2.25 0 0 1 9 22a2 2 0 0 1-.39 0zM4.4 11.62a3.83 3.83 0 0 1 2.38 2.5v.12a4 4 0 0 1-.46 3.62.38.38 0 0 0 0 .51L8.47 20a.25.25 0 0 0 .37-.07l.23-.33a3.77 3.77 0 0 1 6.2 0l.12.18a.3.3 0 0 0 .18.12.25.25 0 0 0 .19-.05l2.06-1.56a.36.36 0 0 0 .07-.49l-.26-.38A4 4 0 0 1 17.1 14a3.92 3.92 0 0 1 2.49-2.61l.2-.07a.34.34 0 0 0 .19-.44l-.78-2.49a.35.35 0 0 0-.2-.19.21.21 0 0 0-.19 0l-.34.11a3.74 3.74 0 0 1-3.43-.57L15 7.65a3.76 3.76 0 0 1-1.49-3v-.31a.37.37 0 0 0-.1-.26.31.31 0 0 0-.21-.08h-2.54a.31.31 0 0 0-.29.33v.25a3.9 3.9 0 0 1-1.52 3.09l-.13.1a3.91 3.91 0 0 1-3.63.59.22.22 0 0 0-.14 0 .28.28 0 0 0-.12.15L4 11.12a.36.36 0 0 0 .22.45z" data-name="&lt;Group&gt;"/><path d="M12 15.5a3.5 3.5 0 1 1 3.5-3.5 3.5 3.5 0 0 1-3.5 3.5zm0-5a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5z"/></g></g>',
                        "shake-outline": '<g data-name="Layer 2"><g data-name="shake"><rect width="24" height="24" opacity="0"/><path d="M5.5 18a1 1 0 0 1-.64-.24A8.81 8.81 0 0 1 1.5 11a8.81 8.81 0 0 1 3.36-6.76 1 1 0 1 1 1.28 1.52A6.9 6.9 0 0 0 3.5 11a6.9 6.9 0 0 0 2.64 5.24 1 1 0 0 1 .13 1.4 1 1 0 0 1-.77.36z"/><path d="M12 7a4.09 4.09 0 0 1 1 .14V3a1 1 0 0 0-2 0v4.14A4.09 4.09 0 0 1 12 7z"/><path d="M12 15a4.09 4.09 0 0 1-1-.14V20a1 1 0 0 0 2 0v-5.14a4.09 4.09 0 0 1-1 .14z"/><path d="M16 16a1 1 0 0 1-.77-.36 1 1 0 0 1 .13-1.4A4.28 4.28 0 0 0 17 11a4.28 4.28 0 0 0-1.64-3.24 1 1 0 1 1 1.28-1.52A6.2 6.2 0 0 1 19 11a6.2 6.2 0 0 1-2.36 4.76A1 1 0 0 1 16 16z"/><path d="M8 16a1 1 0 0 1-.64-.24A6.2 6.2 0 0 1 5 11a6.2 6.2 0 0 1 2.36-4.76 1 1 0 1 1 1.28 1.52A4.28 4.28 0 0 0 7 11a4.28 4.28 0 0 0 1.64 3.24 1 1 0 0 1 .13 1.4A1 1 0 0 1 8 16z"/><path d="M18.5 18a1 1 0 0 1-.77-.36 1 1 0 0 1 .13-1.4A6.9 6.9 0 0 0 20.5 11a6.9 6.9 0 0 0-2.64-5.24 1 1 0 1 1 1.28-1.52A8.81 8.81 0 0 1 22.5 11a8.81 8.81 0 0 1-3.36 6.76 1 1 0 0 1-.64.24z"/><path d="M12 12a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm0-1zm0 0zm0 0zm0 0zm0 0zm0 0zm0 0z"/></g></g>',
                        "share-outline": '<g data-name="Layer 2"><g data-name="share"><rect width="24" height="24" opacity="0"/><path d="M18 15a3 3 0 0 0-2.1.86L8 12.34V12v-.33l7.9-3.53A3 3 0 1 0 15 6v.34L7.1 9.86a3 3 0 1 0 0 4.28l7.9 3.53V18a3 3 0 1 0 3-3zm0-10a1 1 0 1 1-1 1 1 1 0 0 1 1-1zM5 13a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm13 6a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "shield-off-outline": '<g data-name="Layer 2"><g data-name="shield-off"><rect width="24" height="24" opacity="0"/><path d="M4.71 3.29a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M12.3 19.68l-.3.17-.3-.17A13.15 13.15 0 0 1 5 8.23v-.14L5.16 8 3.73 6.56A2 2 0 0 0 3 8.09v.14a15.17 15.17 0 0 0 7.72 13.2l.3.17a2 2 0 0 0 2 0l.3-.17a15.22 15.22 0 0 0 3-2.27l-1.42-1.42a12.56 12.56 0 0 1-2.6 1.94z"/><path d="M20 6.34L13 2.4a2 2 0 0 0-2 0L7.32 4.49 8.78 6 12 4.15l7 3.94v.14a13 13 0 0 1-1.63 6.31L18.84 16A15.08 15.08 0 0 0 21 8.23v-.14a2 2 0 0 0-1-1.75z"/></g></g>',
                        "shield-outline": '<g data-name="Layer 2"><g data-name="shield"><rect width="24" height="24" opacity="0"/><path d="M12 21.85a2 2 0 0 1-1-.25l-.3-.17A15.17 15.17 0 0 1 3 8.23v-.14a2 2 0 0 1 1-1.75l7-3.94a2 2 0 0 1 2 0l7 3.94a2 2 0 0 1 1 1.75v.14a15.17 15.17 0 0 1-7.72 13.2l-.3.17a2 2 0 0 1-.98.25zm0-17.7L5 8.09v.14a13.15 13.15 0 0 0 6.7 11.45l.3.17.3-.17A13.15 13.15 0 0 0 19 8.23v-.14z"/></g></g>',
                        "shopping-bag-outline": '<g data-name="Layer 2"><g data-name="shopping-bag"><rect width="24" height="24" opacity="0"/><path d="M20.12 6.71l-2.83-2.83A3 3 0 0 0 15.17 3H8.83a3 3 0 0 0-2.12.88L3.88 6.71A3 3 0 0 0 3 8.83V18a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V8.83a3 3 0 0 0-.88-2.12zm-12-1.42A1.05 1.05 0 0 1 8.83 5h6.34a1.05 1.05 0 0 1 .71.29L17.59 7H6.41zM18 19H6a1 1 0 0 1-1-1V9h14v9a1 1 0 0 1-1 1z"/><path d="M15 11a1 1 0 0 0-1 1 2 2 0 0 1-4 0 1 1 0 0 0-2 0 4 4 0 0 0 8 0 1 1 0 0 0-1-1z"/></g></g>',
                        "shopping-cart-outline": '<g data-name="Layer 2"><g data-name="shopping-cart"><rect width="24" height="24" opacity="0"/><path d="M21.08 7a2 2 0 0 0-1.7-1H6.58L6 3.74A1 1 0 0 0 5 3H3a1 1 0 0 0 0 2h1.24L7 15.26A1 1 0 0 0 8 16h9a1 1 0 0 0 .89-.55l3.28-6.56A2 2 0 0 0 21.08 7zm-4.7 7H8.76L7.13 8h12.25z"/><circle cx="7.5" cy="19.5" r="1.5"/><circle cx="17.5" cy="19.5" r="1.5"/></g></g>',
                        "shuffle-2-outline": '<g data-name="Layer 2"><g data-name="shuffle-2"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18.71 14.29a1 1 0 0 0-1.42 1.42l.29.29H16a4 4 0 0 1 0-8h1.59l-.3.29a1 1 0 0 0 0 1.42A1 1 0 0 0 18 10a1 1 0 0 0 .71-.29l2-2A1 1 0 0 0 21 7a1 1 0 0 0-.29-.71l-2-2a1 1 0 0 0-1.42 1.42l.29.29H16a6 6 0 0 0-5 2.69A6 6 0 0 0 6 6H4a1 1 0 0 0 0 2h2a4 4 0 0 1 0 8H4a1 1 0 0 0 0 2h2a6 6 0 0 0 5-2.69A6 6 0 0 0 16 18h1.59l-.3.29a1 1 0 0 0 0 1.42A1 1 0 0 0 18 20a1 1 0 0 0 .71-.29l2-2A1 1 0 0 0 21 17a1 1 0 0 0-.29-.71z"/></g></g>',
                        "shuffle-outline": '<g data-name="Layer 2"><g data-name="shuffle"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M18 9.31a1 1 0 0 0 1 1 1 1 0 0 0 1-1V5a1 1 0 0 0-1-1h-4.3a1 1 0 0 0-1 1 1 1 0 0 0 1 1h1.89L12 10.59 6.16 4.76a1 1 0 0 0-1.41 1.41L10.58 12l-6.29 6.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L18 7.42z"/><path d="M19 13.68a1 1 0 0 0-1 1v1.91l-2.78-2.79a1 1 0 0 0-1.42 1.42L16.57 18h-1.88a1 1 0 0 0 0 2H19a1 1 0 0 0 1-1.11v-4.21a1 1 0 0 0-1-1z"/></g></g>',
                        "skip-back-outline": '<g data-name="Layer 2"><g data-name="skip-back"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M16.45 6.2a2.1 2.1 0 0 0-2.21.26l-5.1 4.21-.14.15V7a1 1 0 0 0-2 0v10a1 1 0 0 0 2 0v-3.82l.14.15 5.1 4.21a2.06 2.06 0 0 0 1.3.46 2.23 2.23 0 0 0 .91-.2 1.76 1.76 0 0 0 1.05-1.59V7.79a1.76 1.76 0 0 0-1.05-1.59zM15.5 16l-4.82-4 4.82-3.91z"/></g></g>',
                        "skip-forward-outline": '<g data-name="Layer 2"><g data-name="skip-forward"><rect width="24" height="24" opacity="0"/><path d="M16 6a1 1 0 0 0-1 1v3.82l-.14-.15-5.1-4.21a2.1 2.1 0 0 0-2.21-.26 1.76 1.76 0 0 0-1 1.59v8.42a1.76 1.76 0 0 0 1 1.59 2.23 2.23 0 0 0 .91.2 2.06 2.06 0 0 0 1.3-.46l5.1-4.21.14-.15V17a1 1 0 0 0 2 0V7a1 1 0 0 0-1-1zm-7.5 9.91V8l4.82 4z"/></g></g>',
                        "slash-outline": '<g data-name="Layer 2"><g data-name="slash"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm8 10a7.92 7.92 0 0 1-1.69 4.9L7.1 5.69A7.92 7.92 0 0 1 12 4a8 8 0 0 1 8 8zM4 12a7.92 7.92 0 0 1 1.69-4.9L16.9 18.31A7.92 7.92 0 0 1 12 20a8 8 0 0 1-8-8z"/></g></g>',
                        "smartphone-outline": '<g data-name="Layer 2"><g data-name="smartphone"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M17 2H7a3 3 0 0 0-3 3v14a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V5a3 3 0 0 0-3-3zm1 17a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1z"/><circle cx="12" cy="16.5" r="1.5"/><path d="M14.5 6h-5a1 1 0 0 0 0 2h5a1 1 0 0 0 0-2z"/></g></g>',
                        "speaker-outline": '<g data-name="Layer 2"><g data-name="speaker"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M12 11a3 3 0 1 0-3-3 3 3 0 0 0 3 3zm0-4a1 1 0 1 1-1 1 1 1 0 0 1 1-1z"/><path d="M12 12a3.5 3.5 0 1 0 3.5 3.5A3.5 3.5 0 0 0 12 12zm0 5a1.5 1.5 0 1 1 1.5-1.5A1.5 1.5 0 0 1 12 17z"/><path d="M17 2H7a3 3 0 0 0-3 3v14a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V5a3 3 0 0 0-3-3zm1 17a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1z"/></g></g>',
                        "square-outline": '<g data-name="Layer 2"><g data-name="square"><rect width="24" height="24" opacity="0"/><path d="M18 21H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1z"/></g></g>',
                        "star-outline": '<g data-name="Layer 2"><g data-name="star"><rect width="24" height="24" transform="rotate(90 12 12)" opacity="0"/><path d="M17.56 21a1 1 0 0 1-.46-.11L12 18.22l-5.1 2.67a1 1 0 0 1-1.45-1.06l1-5.63-4.12-4a1 1 0 0 1-.25-1 1 1 0 0 1 .81-.68l5.7-.83 2.51-5.13a1 1 0 0 1 1.8 0l2.54 5.12 5.7.83a1 1 0 0 1 .81.68 1 1 0 0 1-.25 1l-4.12 4 1 5.63a1 1 0 0 1-.4 1 1 1 0 0 1-.62.18zM12 16.1a.92.92 0 0 1 .46.11l3.77 2-.72-4.21a1 1 0 0 1 .29-.89l3-2.93-4.2-.62a1 1 0 0 1-.71-.56L12 5.25 10.11 9a1 1 0 0 1-.75.54l-4.2.62 3 2.93a1 1 0 0 1 .29.89l-.72 4.16 3.77-2a.92.92 0 0 1 .5-.04z"/></g></g>',
                        "stop-circle-outline": '<g data-name="Layer 2"><g data-name="stop-circle"><rect width="24" height="24" opacity="0"/><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><path d="M14.75 8h-5.5A1.25 1.25 0 0 0 8 9.25v5.5A1.25 1.25 0 0 0 9.25 16h5.5A1.25 1.25 0 0 0 16 14.75v-5.5A1.25 1.25 0 0 0 14.75 8zM14 14h-4v-4h4z"/></g></g>',
                        "sun-outline": '<g data-name="Layer 2"><g data-name="sun"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M12 6a1 1 0 0 0 1-1V3a1 1 0 0 0-2 0v2a1 1 0 0 0 1 1z"/><path d="M21 11h-2a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2z"/><path d="M6 12a1 1 0 0 0-1-1H3a1 1 0 0 0 0 2h2a1 1 0 0 0 1-1z"/><path d="M6.22 5a1 1 0 0 0-1.39 1.47l1.44 1.39a1 1 0 0 0 .73.28 1 1 0 0 0 .72-.31 1 1 0 0 0 0-1.41z"/><path d="M17 8.14a1 1 0 0 0 .69-.28l1.44-1.39A1 1 0 0 0 17.78 5l-1.44 1.42a1 1 0 0 0 0 1.41 1 1 0 0 0 .66.31z"/><path d="M12 18a1 1 0 0 0-1 1v2a1 1 0 0 0 2 0v-2a1 1 0 0 0-1-1z"/><path d="M17.73 16.14a1 1 0 0 0-1.39 1.44L17.78 19a1 1 0 0 0 .69.28 1 1 0 0 0 .72-.3 1 1 0 0 0 0-1.42z"/><path d="M6.27 16.14l-1.44 1.39a1 1 0 0 0 0 1.42 1 1 0 0 0 .72.3 1 1 0 0 0 .67-.25l1.44-1.39a1 1 0 0 0-1.39-1.44z"/><path d="M12 8a4 4 0 1 0 4 4 4 4 0 0 0-4-4zm0 6a2 2 0 1 1 2-2 2 2 0 0 1-2 2z"/></g></g>',
                        "swap-outline": '<g data-name="Layer 2"><g data-name="swap"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M4 9h13l-1.6 1.2a1 1 0 0 0-.2 1.4 1 1 0 0 0 .8.4 1 1 0 0 0 .6-.2l4-3a1 1 0 0 0 0-1.59l-3.86-3a1 1 0 0 0-1.23 1.58L17.08 7H4a1 1 0 0 0 0 2z"/><path d="M20 16H7l1.6-1.2a1 1 0 0 0-1.2-1.6l-4 3a1 1 0 0 0 0 1.59l3.86 3a1 1 0 0 0 .61.21 1 1 0 0 0 .79-.39 1 1 0 0 0-.17-1.4L6.92 18H20a1 1 0 0 0 0-2z"/></g></g>',
                        "sync-outline": '<g data-name="Layer 2"><g data-name="sync"><rect width="24" height="24" opacity="0"/><path d="M21.66 10.37a.62.62 0 0 0 .07-.19l.75-4a1 1 0 0 0-2-.36l-.37 2a9.22 9.22 0 0 0-16.58.84 1 1 0 0 0 .55 1.3 1 1 0 0 0 1.31-.55A7.08 7.08 0 0 1 12.07 5a7.17 7.17 0 0 1 6.24 3.58l-1.65-.27a1 1 0 1 0-.32 2l4.25.71h.16a.93.93 0 0 0 .34-.06.33.33 0 0 0 .1-.06.78.78 0 0 0 .2-.11l.08-.1a1.07 1.07 0 0 0 .14-.16.58.58 0 0 0 .05-.16z"/><path d="M19.88 14.07a1 1 0 0 0-1.31.56A7.08 7.08 0 0 1 11.93 19a7.17 7.17 0 0 1-6.24-3.58l1.65.27h.16a1 1 0 0 0 .16-2L3.41 13a.91.91 0 0 0-.33 0H3a1.15 1.15 0 0 0-.32.14 1 1 0 0 0-.18.18l-.09.1a.84.84 0 0 0-.07.19.44.44 0 0 0-.07.17l-.75 4a1 1 0 0 0 .8 1.22h.18a1 1 0 0 0 1-.82l.37-2a9.22 9.22 0 0 0 16.58-.83 1 1 0 0 0-.57-1.28z"/></g></g>',
                        "text-outline": '<g data-name="Layer 2"><g data-name="text"><rect width="24" height="24" opacity="0"/><path d="M20 4H4a1 1 0 0 0-1 1v3a1 1 0 0 0 2 0V6h6v13H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2h-2V6h6v2a1 1 0 0 0 2 0V5a1 1 0 0 0-1-1z"/></g></g>',
                        "thermometer-minus-outline": '<g data-name="Layer 2"><g data-name="thermometer-minus"><rect width="24" height="24" opacity="0"/><rect x="2" y="5" width="6" height="2" rx="1" ry="1"/><path d="M14 22a5 5 0 0 1-3-9V5a3 3 0 0 1 3-3 3 3 0 0 1 3 3v8a5 5 0 0 1-3 9zm0-18a1 1 0 0 0-1 1v8.54a1 1 0 0 1-.5.87A3 3 0 0 0 11 17a3 3 0 0 0 6 0 3 3 0 0 0-1.5-2.59 1 1 0 0 1-.5-.87V5a.93.93 0 0 0-.29-.69A1 1 0 0 0 14 4z"/></g></g>',
                        "thermometer-outline": '<g data-name="Layer 2"><g data-name="thermometer"><rect width="24" height="24" opacity="0"/><path d="M12 22a5 5 0 0 1-3-9V5a3 3 0 0 1 3-3 3 3 0 0 1 3 3v8a5 5 0 0 1-3 9zm0-18a1 1 0 0 0-1 1v8.54a1 1 0 0 1-.5.87A3 3 0 0 0 9 17a3 3 0 0 0 6 0 3 3 0 0 0-1.5-2.59 1 1 0 0 1-.5-.87V5a.93.93 0 0 0-.29-.69A1 1 0 0 0 12 4z"/></g></g>',
                        "thermometer-plus-outline": '<g data-name="Layer 2"><g data-name="thermometer-plus"><rect width="24" height="24" opacity="0"/><rect x="2" y="5" width="6" height="2" rx="1" ry="1"/><rect x="2" y="5" width="6" height="2" rx="1" ry="1" transform="rotate(-90 5 6)"/><path d="M14 22a5 5 0 0 1-3-9V5a3 3 0 0 1 3-3 3 3 0 0 1 3 3v8a5 5 0 0 1-3 9zm0-18a1 1 0 0 0-1 1v8.54a1 1 0 0 1-.5.87A3 3 0 0 0 11 17a3 3 0 0 0 6 0 3 3 0 0 0-1.5-2.59 1 1 0 0 1-.5-.87V5a.93.93 0 0 0-.29-.69A1 1 0 0 0 14 4z"/></g></g>',
                        "toggle-left-outline": '<g data-name="Layer 2"><g data-name="toggle-left"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><path d="M15 5H9a7 7 0 0 0 0 14h6a7 7 0 0 0 0-14zm0 12H9A5 5 0 0 1 9 7h6a5 5 0 0 1 0 10z"/><path d="M9 9a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "toggle-right-outline": '<g data-name="Layer 2"><g data-name="toggle-right"><rect width="24" height="24" opacity="0"/><path d="M15 5H9a7 7 0 0 0 0 14h6a7 7 0 0 0 0-14zm0 12H9A5 5 0 0 1 9 7h6a5 5 0 0 1 0 10z"/><path d="M15 9a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "trash-2-outline": '<g data-name="Layer 2"><g data-name="trash-2"><rect width="24" height="24" opacity="0"/><path d="M21 6h-5V4.33A2.42 2.42 0 0 0 13.5 2h-3A2.42 2.42 0 0 0 8 4.33V6H3a1 1 0 0 0 0 2h1v11a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V8h1a1 1 0 0 0 0-2zM10 4.33c0-.16.21-.33.5-.33h3c.29 0 .5.17.5.33V6h-4zM18 19a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V8h12z"/><path d="M9 17a1 1 0 0 0 1-1v-4a1 1 0 0 0-2 0v4a1 1 0 0 0 1 1z"/><path d="M15 17a1 1 0 0 0 1-1v-4a1 1 0 0 0-2 0v4a1 1 0 0 0 1 1z"/></g></g>',
                        "trash-outline": '<g data-name="Layer 2"><g data-name="trash"><rect width="24" height="24" opacity="0"/><path d="M21 6h-5V4.33A2.42 2.42 0 0 0 13.5 2h-3A2.42 2.42 0 0 0 8 4.33V6H3a1 1 0 0 0 0 2h1v11a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V8h1a1 1 0 0 0 0-2zM10 4.33c0-.16.21-.33.5-.33h3c.29 0 .5.17.5.33V6h-4zM18 19a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V8h12z"/></g></g>',
                        "trending-down-outline": '<g data-name="Layer 2"><g data-name="trending-down"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M21 12a1 1 0 0 0-2 0v2.3l-4.24-5a1 1 0 0 0-1.27-.21L9.22 11.7 4.77 6.36a1 1 0 1 0-1.54 1.28l5 6a1 1 0 0 0 1.28.22l4.28-2.57 4 4.71H15a1 1 0 0 0 0 2h5a1.1 1.1 0 0 0 .36-.07l.14-.08a1.19 1.19 0 0 0 .15-.09.75.75 0 0 0 .14-.17 1.1 1.1 0 0 0 .09-.14.64.64 0 0 0 .05-.17A.78.78 0 0 0 21 17z"/></g></g>',
                        "trending-up-outline": '<g data-name="Layer 2"><g data-name="trending-up"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M21 7a.78.78 0 0 0 0-.21.64.64 0 0 0-.05-.17 1.1 1.1 0 0 0-.09-.14.75.75 0 0 0-.14-.17l-.12-.07a.69.69 0 0 0-.19-.1h-.2A.7.7 0 0 0 20 6h-5a1 1 0 0 0 0 2h2.83l-4 4.71-4.32-2.57a1 1 0 0 0-1.28.22l-5 6a1 1 0 0 0 .13 1.41A1 1 0 0 0 4 18a1 1 0 0 0 .77-.36l4.45-5.34 4.27 2.56a1 1 0 0 0 1.27-.21L19 9.7V12a1 1 0 0 0 2 0V7z"/></g></g>',
                        "tv-outline": '<g data-name="Layer 2"><g data-name="tv"><rect width="24" height="24" opacity="0"/><path d="M18 6h-3.59l2.3-2.29a1 1 0 1 0-1.42-1.42L12 5.59l-3.29-3.3a1 1 0 1 0-1.42 1.42L9.59 6H6a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V9a3 3 0 0 0-3-3zm1 13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1z"/></g></g>',
                        "twitter-outline": '<g data-name="Layer 2"><g data-name="twitter"><polyline points="0 0 24 0 24 24 0 24" opacity="0"/><path d="M8.51 20h-.08a10.87 10.87 0 0 1-4.65-1.09A1.38 1.38 0 0 1 3 17.47a1.41 1.41 0 0 1 1.16-1.18 6.63 6.63 0 0 0 2.54-.89 9.49 9.49 0 0 1-3.51-9.07 1.41 1.41 0 0 1 1-1.15 1.35 1.35 0 0 1 1.43.41 7.09 7.09 0 0 0 4.88 2.75 4.5 4.5 0 0 1 1.41-3.1 4.47 4.47 0 0 1 6.37.19.7.7 0 0 0 .78.1A1.39 1.39 0 0 1 21 7.13a6.66 6.66 0 0 1-1.28 2.6A10.79 10.79 0 0 1 8.51 20zm0-2h.08a8.79 8.79 0 0 0 9.09-8.59 1.32 1.32 0 0 1 .37-.85 5.19 5.19 0 0 0 .62-1 2.56 2.56 0 0 1-1.91-.85A2.45 2.45 0 0 0 15 6a2.5 2.5 0 0 0-1.79.69 2.53 2.53 0 0 0-.72 2.42l.26 1.14-1.17.08a8.3 8.3 0 0 1-6.54-2.4 7.12 7.12 0 0 0 3.73 6.46l.95.54-.63.9a5.62 5.62 0 0 1-2.68 1.92A8.34 8.34 0 0 0 8.5 18zM19 6.65z"/></g></g>',
                        "umbrella-outline": '<g data-name="Layer 2"><g data-name="umbrella"><rect width="24" height="24" opacity="0"/><path d="M12 2A10 10 0 0 0 2 12a1 1 0 0 0 1 1h8v6a3 3 0 0 0 6 0 1 1 0 0 0-2 0 1 1 0 0 1-2 0v-6h8a1 1 0 0 0 1-1A10 10 0 0 0 12 2zm-7.94 9a8 8 0 0 1 15.88 0z"/></g></g>',
                        "undo-outline": '<g data-name="Layer 2"><g data-name="undo"><rect width="24" height="24" transform="rotate(-90 12 12)" opacity="0"/><path d="M20.22 21a1 1 0 0 1-1-.76 8.91 8.91 0 0 0-7.8-6.69v1.12a1.78 1.78 0 0 1-1.09 1.64A2 2 0 0 1 8.18 16l-5.06-4.41a1.76 1.76 0 0 1 0-2.68l5.06-4.42a2 2 0 0 1 2.18-.3 1.78 1.78 0 0 1 1.09 1.64V7A10.89 10.89 0 0 1 21.5 17.75a10.29 10.29 0 0 1-.31 2.49 1 1 0 0 1-1 .76zm-9.77-9.5a11.07 11.07 0 0 1 8.81 4.26A9 9 0 0 0 10.45 9a1 1 0 0 1-1-1V6.08l-4.82 4.17 4.82 4.21v-2a1 1 0 0 1 1-.96z"/></g></g>',
                        "unlock-outline": '<g data-name="Layer 2"><g data-name="unlock"><rect width="24" height="24" opacity="0"/><path d="M17 8h-7V6a2 2 0 0 1 4 0 1 1 0 0 0 2 0 4 4 0 0 0-8 0v2H7a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-8a3 3 0 0 0-3-3zm1 11a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1z"/><path d="M12 12a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"/></g></g>',
                        "upload-outline": '<g data-name="Layer 2"><g data-name="upload"><rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"/><rect x="4" y="4" width="16" height="2" rx="1" ry="1" transform="rotate(180 12 5)"/><rect x="17" y="5" width="4" height="2" rx="1" ry="1" transform="rotate(90 19 6)"/><rect x="3" y="5" width="4" height="2" rx="1" ry="1" transform="rotate(90 5 6)"/><path d="M8 14a1 1 0 0 1-.8-.4 1 1 0 0 1 .2-1.4l4-3a1 1 0 0 1 1.18 0l4 2.82a1 1 0 0 1 .24 1.39 1 1 0 0 1-1.4.24L12 11.24 8.6 13.8a1 1 0 0 1-.6.2z"/><path d="M12 21a1 1 0 0 1-1-1v-8a1 1 0 0 1 2 0v8a1 1 0 0 1-1 1z"/></g></g>',
                        "video-off-outline": '<g data-name="Layer 2"><g data-name="video-off"><rect width="24" height="24" opacity="0"/><path d="M17 15.59l-2-2L8.41 7l-2-2-1.7-1.71a1 1 0 0 0-1.42 1.42l.54.53L5.59 7l9.34 9.34 1.46 1.46 2.9 2.91a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M14 17H5a1 1 0 0 1-1-1V8a1 1 0 0 1 .4-.78L3 5.8A3 3 0 0 0 2 8v8a3 3 0 0 0 3 3h9a2.94 2.94 0 0 0 1.66-.51L14.14 17a.7.7 0 0 1-.14 0z"/><path d="M21 7.15a1.7 1.7 0 0 0-1.85.3l-2.15 2V8a3 3 0 0 0-3-3H7.83l2 2H14a1 1 0 0 1 1 1v4.17l4.72 4.72a1.73 1.73 0 0 0 .6.11 1.68 1.68 0 0 0 .69-.15 1.6 1.6 0 0 0 1-1.48V8.63A1.6 1.6 0 0 0 21 7.15zm-1 7.45L17.19 12 20 9.4z"/></g></g>',
                        "video-outline": '<g data-name="Layer 2"><g data-name="video"><rect width="24" height="24" opacity="0"/><path d="M21 7.15a1.7 1.7 0 0 0-1.85.3l-2.15 2V8a3 3 0 0 0-3-3H5a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h9a3 3 0 0 0 3-3v-1.45l2.16 2a1.74 1.74 0 0 0 1.16.45 1.68 1.68 0 0 0 .69-.15 1.6 1.6 0 0 0 1-1.48V8.63A1.6 1.6 0 0 0 21 7.15zM15 16a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1zm5-1.4L17.19 12 20 9.4z"/></g></g>',
                        "volume-down-outline": '<g data-name="Layer 2"><g data-name="volume-down"><rect width="24" height="24" opacity="0"/><path d="M20.78 8.37a1 1 0 1 0-1.56 1.26 4 4 0 0 1 0 4.74A1 1 0 0 0 20 16a1 1 0 0 0 .78-.37 6 6 0 0 0 0-7.26z"/><path d="M16.47 3.12a1 1 0 0 0-1 0L9 7.57H4a1 1 0 0 0-1 1v6.86a1 1 0 0 0 1 1h5l6.41 4.4A1.06 1.06 0 0 0 16 21a1 1 0 0 0 1-1V4a1 1 0 0 0-.53-.88zM15 18.1l-5.1-3.5a1 1 0 0 0-.57-.17H5V9.57h4.33a1 1 0 0 0 .57-.17L15 5.9z"/></g></g>',
                        "volume-mute-outline": '<g data-name="Layer 2"><g data-name="volume-mute"><rect width="24" height="24" opacity="0"/><path d="M17 21a1.06 1.06 0 0 1-.57-.17L10 16.43H5a1 1 0 0 1-1-1V8.57a1 1 0 0 1 1-1h5l6.41-4.4A1 1 0 0 1 18 4v16a1 1 0 0 1-1 1zM6 14.43h4.33a1 1 0 0 1 .57.17l5.1 3.5V5.9l-5.1 3.5a1 1 0 0 1-.57.17H6z"/></g></g>',
                        "volume-off-outline": '<g data-name="Layer 2"><g data-name="volume-off"><rect width="24" height="24" opacity="0"/><path d="M4.71 3.29a1 1 0 0 0-1.42 1.42l16 16a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M16.91 14.08l1.44 1.44a6 6 0 0 0-.07-7.15 1 1 0 1 0-1.56 1.26 4 4 0 0 1 .19 4.45z"/><path d="M21 12a6.51 6.51 0 0 1-1.78 4.39l1.42 1.42A8.53 8.53 0 0 0 23 12a8.75 8.75 0 0 0-3.36-6.77 1 1 0 1 0-1.28 1.54A6.8 6.8 0 0 1 21 12z"/><path d="M13.5 18.1l-5.1-3.5a1 1 0 0 0-.57-.17H3.5V9.57h3.24l-2-2H2.5a1 1 0 0 0-1 1v6.86a1 1 0 0 0 1 1h5l6.41 4.4a1.06 1.06 0 0 0 .57.17 1 1 0 0 0 1-1v-1.67l-2-2z"/><path d="M13.5 5.9v4.77l2 2V4a1 1 0 0 0-1.57-.83L9.23 6.4l1.44 1.44z"/></g></g>',
                        "volume-up-outline": '<g data-name="Layer 2"><g data-name="volume-up"><rect width="24" height="24" opacity="0"/><path d="M18.28 8.37a1 1 0 1 0-1.56 1.26 4 4 0 0 1 0 4.74A1 1 0 0 0 17.5 16a1 1 0 0 0 .78-.37 6 6 0 0 0 0-7.26z"/><path d="M19.64 5.23a1 1 0 1 0-1.28 1.54A6.8 6.8 0 0 1 21 12a6.8 6.8 0 0 1-2.64 5.23 1 1 0 0 0-.13 1.41A1 1 0 0 0 19 19a1 1 0 0 0 .64-.23A8.75 8.75 0 0 0 23 12a8.75 8.75 0 0 0-3.36-6.77z"/><path d="M15 3.12a1 1 0 0 0-1 0L7.52 7.57h-5a1 1 0 0 0-1 1v6.86a1 1 0 0 0 1 1h5l6.41 4.4a1.06 1.06 0 0 0 .57.17 1 1 0 0 0 1-1V4a1 1 0 0 0-.5-.88zm-1.47 15L8.4 14.6a1 1 0 0 0-.57-.17H3.5V9.57h4.33a1 1 0 0 0 .57-.17l5.1-3.5z"/></g></g>',
                        "wifi-off-outline": '<g data-name="Layer 2"><g data-name="wifi-off"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="19" r="1"/><path d="M12.44 11l-1.9-1.89-2.46-2.44-1.55-1.55-1.82-1.83a1 1 0 0 0-1.42 1.42l1.38 1.37 1.46 1.46 2.23 2.24 1.55 1.54 2.74 2.74 2.79 2.8 3.85 3.85a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"/><path d="M21.72 7.93A13.93 13.93 0 0 0 12 4a14.1 14.1 0 0 0-4.44.73l1.62 1.62a11.89 11.89 0 0 1 11.16 3 1 1 0 0 0 .69.28 1 1 0 0 0 .72-.31 1 1 0 0 0-.03-1.39z"/><path d="M3.82 6.65a14.32 14.32 0 0 0-1.54 1.28 1 1 0 0 0 1.38 1.44 13.09 13.09 0 0 1 1.6-1.29z"/><path d="M17 13.14a1 1 0 0 0 .71.3 1 1 0 0 0 .72-1.69A9 9 0 0 0 12 9h-.16l2.35 2.35A7 7 0 0 1 17 13.14z"/><path d="M7.43 10.26a8.8 8.8 0 0 0-1.9 1.49A1 1 0 0 0 7 13.14a7.3 7.3 0 0 1 2-1.41z"/><path d="M8.53 15.4a1 1 0 1 0 1.39 1.44 3.06 3.06 0 0 1 3.84-.25l-2.52-2.52a5 5 0 0 0-2.71 1.33z"/></g></g>',
                        "wifi-outline": '<g data-name="Layer 2"><g data-name="wifi"><rect width="24" height="24" opacity="0"/><circle cx="12" cy="19" r="1"/><path d="M12 14a5 5 0 0 0-3.47 1.4 1 1 0 1 0 1.39 1.44 3.08 3.08 0 0 1 4.16 0 1 1 0 1 0 1.39-1.44A5 5 0 0 0 12 14z"/><path d="M12 9a9 9 0 0 0-6.47 2.75A1 1 0 0 0 7 13.14a7 7 0 0 1 10.08 0 1 1 0 0 0 .71.3 1 1 0 0 0 .72-1.69A9 9 0 0 0 12 9z"/><path d="M21.72 7.93a14 14 0 0 0-19.44 0 1 1 0 0 0 1.38 1.44 12 12 0 0 1 16.68 0 1 1 0 0 0 .69.28 1 1 0 0 0 .72-.31 1 1 0 0 0-.03-1.41z"/></g></g>'
                    }
                },
                "./package/src/animation.scss": function(e, t, a) {
                    var r = a("./node_modules/css-loader/index.js!./node_modules/sass-loader/lib/loader.js!./package/src/animation.scss");
                    "string" === typeof r && (r = [
                        [e.i, r, ""]
                    ]);
                    var n = {
                        hmr: !0,
                        transform: void 0,
                        insertInto: void 0
                    };
                    a("./node_modules/style-loader/lib/addStyles.js")(r, n);
                    r.locals && (e.exports = r.locals)
                },
                "./package/src/default-attrs.json": function(e) {
                    e.exports = {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 24,
                        height: 24,
                        viewBox: "0 0 24 24"
                    }
                },
                "./package/src/icon.js": function(e, t, a) {
                    "use strict";
                    a.r(t);
                    var r = a("./node_modules/classnames/dedupe.js"),
                        n = a.n(r),
                        o = a("./package/src/default-attrs.json");

                    function i(e, t) {
                        if (null == e) return {};
                        var a, r, n = function(e, t) {
                            if (null == e) return {};
                            var a, r, n = {},
                                o = Object.keys(e);
                            for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                            return n
                        }(e, t);
                        if (Object.getOwnPropertySymbols) {
                            var o = Object.getOwnPropertySymbols(e);
                            for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || Object.prototype.propertyIsEnumerable.call(e, a) && (n[a] = e[a])
                        }
                        return n
                    }

                    function l(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var a = null != arguments[t] ? arguments[t] : {},
                                r = Object.keys(a);
                            "function" === typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(a).filter(function(e) {
                                return Object.getOwnPropertyDescriptor(a, e).enumerable
                            }))), r.forEach(function(t) {
                                c(e, t, a[t])
                            })
                        }
                        return e
                    }

                    function c(e, t, a) {
                        return t in e ? Object.defineProperty(e, t, {
                            value: a,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : e[t] = a, e
                    }

                    function u(e, t) {
                        for (var a = 0; a < t.length; a++) {
                            var r = t[a];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                        }
                    }
                    var d = {
                            hover: !0
                        },
                        s = function(e) {
                            return "string" === typeof e || e instanceof String
                        },
                        h = function() {
                            function e(t, a) {
                                ! function(e, t) {
                                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                                }(this, e), this.name = t, this.contents = a, this.attrs = l({}, o, {
                                    class: "eva eva-".concat(t)
                                })
                            }
                            var t, a, r;
                            return t = e, (a = [{
                                key: "toSvg",
                                value: function() {
                                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                        t = e.animation,
                                        a = i(e, ["animation"]),
                                        r = function(e) {
                                            if (!e) return null;
                                            e.hover && (e.hover = s(e.hover) ? JSON.parse(e.hover) : e.hover);
                                            var t = l({}, d, e),
                                                a = t.hover ? "eva-icon-hover-".concat(t.type) : "eva-icon-".concat(t.type);
                                            return t.class = n()({
                                                "eva-animation": !0,
                                                "eva-infinite": s(e.infinite) ? JSON.parse(e.infinite) : e.infinite
                                            }, a), t
                                        }(t),
                                        o = r ? r.class : "",
                                        c = l({}, this.attrs, a, {
                                            class: n()(this.attrs.class, e.class, o)
                                        }),
                                        u = "<svg ".concat(function(e) {
                                            return Object.keys(e).map(function(t) {
                                                return "".concat(t, '="').concat(e[t], '"')
                                            }).join(" ")
                                        }(c), ">").concat(this.contents, "</svg>");
                                    return r && r.hover ? '<i class="eva-hover">'.concat(u, "</i>") : u
                                }
                            }, {
                                key: "toString",
                                value: function() {
                                    return this.contents
                                }
                            }]) && u(t.prototype, a), r && u(t, r), e
                        }();
                    t.default = h
                },
                "./package/src/icons.js": function(e, t, a) {
                    "use strict";
                    a.r(t);
                    var r = a("./package/src/icon.js"),
                        n = a("./package-build/eva-icons.json");
                    t.default = Object.keys(n).map(function(e) {
                        return new r.default(e, n[e])
                    }).reduce(function(e, t) {
                        return e[t.name] = t, e
                    }, {})
                },
                "./package/src/index.js": function(e, t, a) {
                    "use strict";
                    a.r(t);
                    var r = a("./package/src/icons.js");
                    a.d(t, "icons", function() {
                        return r.default
                    });
                    var n = a("./package/src/replace.js");
                    a.d(t, "replace", function() {
                        return n.default
                    });
                    a("./package/src/animation.scss")
                },
                "./package/src/replace.js": function(e, t, a) {
                    "use strict";
                    a.r(t);
                    var r = a("./node_modules/classnames/dedupe.js"),
                        n = a.n(r),
                        o = a("./package/src/icons.js");

                    function i(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var a = null != arguments[t] ? arguments[t] : {},
                                r = Object.keys(a);
                            "function" === typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(a).filter(function(e) {
                                return Object.getOwnPropertyDescriptor(a, e).enumerable
                            }))), r.forEach(function(t) {
                                l(e, t, a[t])
                            })
                        }
                        return e
                    }

                    function l(e, t, a) {
                        return t in e ? Object.defineProperty(e, t, {
                            value: a,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : e[t] = a, e
                    }

                    function c(e, t) {
                        if (null == e) return {};
                        var a, r, n = function(e, t) {
                            if (null == e) return {};
                            var a, r, n = {},
                                o = Object.keys(e);
                            for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                            return n
                        }(e, t);
                        if (Object.getOwnPropertySymbols) {
                            var o = Object.getOwnPropertySymbols(e);
                            for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || Object.prototype.propertyIsEnumerable.call(e, a) && (n[a] = e[a])
                        }
                        return n
                    }
                    var u = {
                            "data-eva-animation": "type",
                            "data-eva-hover": "hover",
                            "data-eva-infinite": "infinite"
                        },
                        d = {
                            "data-eva": "name",
                            "data-eva-width": "width",
                            "data-eva-height": "height",
                            "data-eva-fill": "fill"
                        };
                    t.default = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        if ("undefined" === typeof document) throw new Error("`eva.replace()` only works in a browser environment.");
                        var t = document.querySelectorAll("[data-eva]");
                        Array.from(t).forEach(function(t) {
                            return function(e) {
                                var t, a, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                                    s = function(e) {
                                        return Array.from(e.attributes).reduce(function(e, t) {
                                            return u[t.name] ? e.animation = i({}, e.animation, l({}, u[t.name], t.value)) : e = i({}, e, function(e) {
                                                return d[e.name] ? l({}, d[e.name], e.value) : l({}, e.name, e.value)
                                            }(t)), e
                                        }, {})
                                    }(e),
                                    h = s.name,
                                    p = c(s, ["name"]),
                                    f = o.default[h].toSvg(i({}, r, p, {
                                        animation: (t = r.animation, a = p.animation, t || a ? i({}, t, a) : null)
                                    }, {
                                        class: n()(r.class, p.class)
                                    })),
                                    g = (new DOMParser).parseFromString(f, "text/html"),
                                    m = g.querySelector(".eva-hover") || g.querySelector("svg");
                                e.parentNode.replaceChild(m, e)
                            }(t, e)
                        })
                    }
                }
            })
        }, e.exports = r()
    }, function(e, t, a) {}, function(e, t) {
        e.exports = function(e) {
            if (!e.webpackPolyfill) {
                var t = Object.create(e);
                t.children || (t.children = []), Object.defineProperty(t, "loaded", {
                    enumerable: !0,
                    get: function() {
                        return t.l
                    }
                }), Object.defineProperty(t, "id", {
                    enumerable: !0,
                    get: function() {
                        return t.i
                    }
                }), Object.defineProperty(t, "exports", {
                    enumerable: !0
                }), t.webpackPolyfill = 1
            }
            return t
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.extendDefaultTheme = t.defaultProps = void 0;
        var r = a(90),
            n = a(91),
            o = {
                theme: n.base
            };
        t.defaultProps = o;
        t.extendDefaultTheme = function(e) {
            o.theme = (0, r.deepMerge)(n.base, e)
        }
    }, function(e, t, a) {
        "use strict";

        function r() {
            return (r = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }

        function n(e) {
            return e && "object" === typeof e && !Array.isArray(e)
        }

        function o(e) {
            for (var t = arguments.length, a = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) a[i - 1] = arguments[i];
            if (!a.length) return e;
            var l = r({}, e);
            return a.forEach(function(e) {
                n(e) && Object.keys(e).forEach(function(t) {
                    n(e[t]) ? l[t] ? l[t] = o(l[t], e[t]) : l[t] = r({}, e[t]) : l[t] = e[t]
                })
            }), l
        }
        t.__esModule = !0, t.isObject = n, t.deepMerge = o, t.default = void 0;
        var i = {
            deepMerge: o,
            isObject: n
        };
        t.default = i
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.base = void 0;
        var r = a(21);
        t.base = r.base
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.selectedStyle = t.activeStyle = t.backgroundStyle = t.backgroundIsDark = t.normalizeBackground = void 0;
        var r = a(1),
            n = a(16),
            o = a(49),
            i = function(e, t) {
                var a = e;
                return e && (t.dark && e.dark && "boolean" !== typeof e.dark ? a = e.dark : !t.dark && e.light && "boolean" !== typeof e.light && (a = e.light), a = (0, o.evalStyle)(a, t)), a
            };
        t.normalizeBackground = i;
        t.backgroundIsDark = function(e, t) {
            var a, r = i(e, t);
            if (r)
                if ("object" === typeof r) {
                    var o = r.color,
                        l = r.dark,
                        c = r.opacity;
                    if ("boolean" === typeof l) a = l;
                    else if (o && (!c || "weak" !== c)) {
                        var u = (0, n.normalizeColor)(r.color, t);
                        u && (a = (0, n.colorIsDark)(u))
                    }
                } else {
                    var d = (0, n.normalizeColor)(r, t);
                    d && (a = (0, n.colorIsDark)(d))
                }
            return a
        };
        var l = function(e, t, a) {
            var o = i(e, t),
                l = a || t.global.colors.text;
            if ("object" === typeof o) {
                var c, u = [];
                if (o.image) !1 === o.dark ? c = l.light : o.dark ? c = l.dark : a || (c = "inherit"), u.push((0, r.css)(["background-image:", ";background-repeat:", ";background-position:", ";background-size:", ";color:", ";"], o.image, o.repeat || "no-repeat", o.position || "center center", o.size || "cover", c));
                if (o.color) {
                    var d = (0, n.normalizeColor)(o.color, t),
                        s = (0, n.getRGBA)(d, !0 === o.opacity ? t.global.opacity.medium : t.global.opacity[o.opacity] || o.opacity) || d;
                    u.push((0, r.css)(["background-color:", ";", ""], s, (!o.opacity || "weak" !== o.opacity) && "color: " + l[o.dark || (0, n.colorIsDark)(s) ? "dark" : "light"] + ";"))
                }
                return !1 === o.dark ? u.push((0, r.css)(["color:", ";"], l.light)) : o.dark && u.push((0, r.css)(["color:", ";"], l.dark)), u
            }
            if (o) {
                if (0 === o.lastIndexOf("url", 0)) return (0, r.css)(["background:", " no-repeat center center;background-size:cover;"], o);
                var h = (0, n.normalizeColor)(o, t);
                if (h) return (0, r.css)(["background:", ";color:", ";"], h, l[(0, n.colorIsDark)(h) ? "dark" : "light"])
            }
        };
        t.backgroundStyle = l;
        var c = (0, r.css)(["", " color:", ";"], function(e) {
            return l((0, n.normalizeColor)(e.theme.global.hover.background, e.theme), e.theme)
        }, function(e) {
            return (0, n.normalizeColor)(e.theme.global.hover.color, e.theme)
        });
        t.activeStyle = c;
        var u = (0, r.css)(["", " color:", ";"], function(e) {
            return l((0, n.normalizeColor)(e.theme.global.selected.background, e.theme), e.theme)
        }, function(e) {
            return (0, n.normalizeColor)(e.theme.global.selected.color, e.theme)
        });
        t.selectedStyle = u
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.debounceDelay = t.debounce = void 0;
        t.debounce = function(e, t) {
            var a;
            return function() {
                for (var r = arguments.length, n = new Array(r), o = 0; o < r; o++) n[o] = arguments[o];
                clearTimeout(a), a = setTimeout(function() {
                    return e.apply(void 0, n)
                }, t)
            }
        };
        t.debounceDelay = function(e) {
            return e.theme.global.debounceDelay
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.isNodeBeforeScroll = t.isNodeAfterScroll = t.findVisibleParent = t.makeNodeUnfocusable = t.makeNodeFocusable = t.copyAttribute = t.setTabIndex = t.setFocusWithoutScroll = t.getNewContainer = t.getBodyChildElements = t.getFirstFocusableDescendant = t.findScrollParents = t.filterByFocusable = void 0;
        var r = function(e) {
            return Array.prototype.filter.call(e || [], function(e) {
                var t = e.tagName.toLowerCase(),
                    a = t.match(/(svg|a|area|input|select|textarea|button|iframe|div)$/) && e.focus;
                return "a" === t ? a && e.childNodes.length > 0 && e.getAttribute("href") : "svg" === t || "div" === t ? a && e.hasAttribute("tabindex") && "-1" !== e.getAttribute("tabindex") : a
            })
        };
        t.filterByFocusable = r;
        t.findScrollParents = function(e, t) {
            var a = [];
            if (e) {
                for (var r = e.parentNode; r && r.getBoundingClientRect;) {
                    var n = r.getBoundingClientRect();
                    t ? n.width && r.scrollWidth > n.width + 10 && a.push(r) : n.height && r.scrollHeight > n.height + 10 && a.push(r), r = r.parentNode
                }
                0 === a.length ? a.push(document) : "body" === a[0].tagName.toLowerCase() && (a.length = 0, a.push(document))
            }
            return a
        };
        t.getFirstFocusableDescendant = function(e) {
            for (var t = e.getElementsByTagName("*"), a = 0; a < t.length; a += 1) {
                var r = t[a],
                    n = r.tagName.toLowerCase();
                if ("input" === n || "select" === n) return r
            }
        };
        t.getBodyChildElements = function() {
            var e = /^(script|link)$/i,
                t = [];
            return [].forEach.call(document.body.children, function(a) {
                e.test(a.tagName) || t.push(a)
            }), t
        };
        t.getNewContainer = function() {
            var e = document.createElement("div");
            return document.body.appendChild(e), e
        };
        t.setFocusWithoutScroll = function(e) {
            var t = window.scrollX,
                a = window.scrollY;
            e.focus(), window.scrollTo(t, a)
        };
        var n = function(e) {
            return function(t) {
                t.setAttribute("tabindex", e)
            }
        };
        t.setTabIndex = n;
        var o = function(e) {
            return function(t) {
                return function(a) {
                    a.setAttribute(t, a.getAttribute(e))
                }
            }
        };
        t.copyAttribute = o;
        var i = function(e) {
                return function(t) {
                    return t.removeAttribute(e)
                }
            },
            l = n(-1),
            c = o("tabindex")("data-g-tabindex"),
            u = o("data-g-tabindex")("tabindex"),
            d = i("tabindex"),
            s = i("data-g-tabindex");
        t.makeNodeFocusable = function(e) {
            e.hasAttribute("aria-live") || (e.setAttribute("aria-hidden", !1), r(e.getElementsByTagName("*")).forEach(function(e) {
                e.hasAttribute("data-g-tabindex") ? u(e) : d(e), s(e)
            }))
        };
        t.makeNodeUnfocusable = function(e) {
            e.hasAttribute("aria-live") || (e.setAttribute("aria-hidden", !0), r(e.getElementsByTagName("*")).forEach(function(e) {
                e.hasAttribute("tabindex") && c(e), l(e)
            }))
        };
        t.findVisibleParent = function e(t) {
            if (t) return t.offsetParent ? t : e(t.parentElement) || t
        };
        t.isNodeAfterScroll = function(e, t) {
            void 0 === t && (t = window);
            var a = e.getBoundingClientRect().bottom,
                r = t.getBoundingClientRect(),
                n = r.height;
            return a >= r.top + n
        };
        t.isNodeBeforeScroll = function(e, t) {
            return void 0 === t && (t = window), e.getBoundingClientRect().top <= t.getBoundingClientRect().top
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.translateEndAngle = t.arcCommands = t.polarToCartesian = t.baseUnit = void 0;
        t.baseUnit = 24;
        var r = function(e, t, a, r) {
            var n = (r - 90) * Math.PI / 180;
            return {
                x: e + a * Math.cos(n),
                y: t + a * Math.sin(n)
            }
        };
        t.polarToCartesian = r;
        t.arcCommands = function(e, t, a, n, o) {
            var i = o;
            o - n >= 360 && (i = n + 359.99);
            var l = r(e, t, a, i),
                c = r(e, t, a, n),
                u = i - n <= 180 ? "0" : "1";
            return ["M", l.x.toFixed(10), l.y.toFixed(10), "A", a.toFixed(10), a.toFixed(10), 0, u, 0, c.x.toFixed(10), c.y.toFixed(10)].join(" ")
        };
        t.translateEndAngle = function(e, t, a) {
            return Math.min(360, Math.max(0, e + t * a))
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.genericProps = t.colorPropType = t.backgroundPropType = t.a11yTitlePropType = void 0;
        var r = a(50),
            n = r.PropTypes.string.description("Custom title to be used by screen readers.");
        t.a11yTitlePropType = n;
        var o = r.PropTypes.oneOfType([r.PropTypes.string, r.PropTypes.shape({
            color: r.PropTypes.string,
            opacity: r.PropTypes.oneOfType([r.PropTypes.oneOf(["weak", "medium", "strong"]), r.PropTypes.bool])
        })]).description("Background color");
        t.backgroundPropType = o;
        var i = r.PropTypes.oneOfType([r.PropTypes.string, r.PropTypes.shape({
            dark: r.PropTypes.string,
            light: r.PropTypes.string
        })]);
        t.colorPropType = i;
        var l = ["xxsmall", "xsmall", "small", "medium", "large", "xlarge"],
            c = {
                a11yTitle: n,
                alignSelf: r.PropTypes.oneOf(["start", "center", "end", "stretch"]).description("How to align along the cross axis when contained in\n      a Box or along the column axis when contained in a Grid."),
                gridArea: r.PropTypes.string.description("The name of the area to place\n    this inside a parent Grid."),
                margin: r.PropTypes.oneOfType([r.PropTypes.oneOf(["none"].concat(l)), r.PropTypes.shape({
                    bottom: r.PropTypes.oneOfType([r.PropTypes.oneOf(l), r.PropTypes.string]),
                    horizontal: r.PropTypes.oneOfType([r.PropTypes.oneOf(l), r.PropTypes.string]),
                    left: r.PropTypes.oneOfType([r.PropTypes.oneOf(l), r.PropTypes.string]),
                    right: r.PropTypes.oneOfType([r.PropTypes.oneOf(l), r.PropTypes.string]),
                    top: r.PropTypes.oneOfType([r.PropTypes.oneOf(l), r.PropTypes.string]),
                    vertical: r.PropTypes.oneOfType([r.PropTypes.oneOf(l), r.PropTypes.string])
                }), r.PropTypes.string]).description("The amount of margin around the component. An object can\n      be specified to distinguish horizontal margin, vertical margin, and\n      margin on a particular side.")
            };
        t.genericProps = c
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            },
            n = function(e) {
                return function(t) {
                    return this.reactDesc || (this.reactDesc = {}), this.reactDesc[e] = t, this
                }
            },
            o = {
                defaultValue: n("defaultValue"),
                description: n("description"),
                deprecated: n("deprecated"),
                format: n("format")
            },
            i = function(e) {
                var t = r({
                    type: e
                }, o);
                return Object.defineProperty(t, "isRequired", {
                    get: function() {
                        return this.reactDesc || (this.reactDesc = {}), this.reactDesc.required = !0, this
                    },
                    enumerable: !0,
                    configurable: !0
                }), t
            },
            l = function(e) {
                return function(t) {
                    var a = r({
                        args: t,
                        type: e
                    }, o);
                    return Object.defineProperty(a, "isRequired", {
                        get: function() {
                            return this.reactDesc || (this.reactDesc = {}), this.reactDesc.required = !0, this
                        },
                        enumerable: !0,
                        configurable: !0
                    }), a
                }
            },
            c = {
                custom: function(e) {
                    var t = e.bind(null);
                    return t.type = "func", Object.keys(o).forEach(function(e) {
                        t[e] = o[e]
                    }), t
                }
            };

        function u(e) {
            Object.defineProperty(c, e, {
                get: function() {
                    return i(e)
                },
                enumerable: !0,
                configurable: !0
            })
        }

        function d(e) {
            Object.defineProperty(c, e, {
                get: function() {
                    return l(e)
                },
                enumerable: !0,
                configurable: !0
            })
        }
        u("any"), u("array"), u("bool"), u("element"), u("func"), u("node"), u("number"), u("object"), u("symbol"), u("string"), d("arrayOf"), d("instanceOf"), d("objectOf"), d("oneOfType"), d("oneOf"), d("shape"), t.default = c
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = function(e) {
            if (!e) throw new Error("react-desc: component is required");
            var t = {
                    propTypes: {}
                },
                a = e,
                r = function(e) {
                    return function(r) {
                        return t[e] = r, a
                    }
                };
            return a.availableAt = r("availableAt"), a.description = r("description"), a.details = r("details"), a.deprecated = r("deprecated"), a.usage = r("usage"), a.intrinsicElement = r("intrinsicElement"), a.toJSON = n.default.bind(null, e, t), a.toTypescript = i.default.bind(null, e, t), a.toMarkdown = o.default.bind(null, e, t), Object.defineProperty(a, "propTypes", {
                get: function() {
                    return a.propTypesValue
                },
                set: function(e) {
                    a.propTypesValue || (a.propTypesValue = {}), Object.keys(e).forEach(function(r) {
                        var n = e[r];
                        return n.type && (t.propTypes[r] = n, n = d(n), e[r].reactDesc.required && (n = n.isRequired)), a.propTypesValue[r] = n, n
                    })
                },
                enumerable: !0,
                configurable: !0
            }), a
        };
        var r = l(a(9)),
            n = l(a(51)),
            o = l(a(99)),
            i = l(a(100));

        function l(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var c = function(e) {
                return e.map(function(e) {
                    return d(e)
                })
            },
            u = function(e) {
                var t = {};
                return Object.keys(e).forEach(function(a) {
                    t[a] = d(e[a])
                }), t
            },
            d = function e(t) {
                var a = void 0;
                if (t && t.type) {
                    if (!r.default[t.type]) throw new Error("react-desc: unknown type " + t.type);
                    a = t.args ? "oneOfType" === t.type || "arrayOf" === t.type ? Array.isArray(t.args) ? r.default[t.type](c(t.args)) : r.default[t.type](e(t.args)) : "shape" === t.type ? r.default[t.type](u(t.args)) : r.default[t.type](t.args) : r.default[t.type]
                } else a = t;
                return a
            }
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        };
        t.default = function(e, t) {
            if (!e) throw new Error("react-desc: component is required");
            var a = (0, i.default)(e, t),
                n = function(e) {
                    var t = e.availableAt;
                    if (!t) return "";
                    var a = void 0;
                    a = Array.isArray(t) ? t.map(function(e) {
                        return c(e)
                    }).join(" ") : c(t);
                    return "\n" + a
                }(a),
                o = function(e) {
                    var t = e.description,
                        a = e.details,
                        r = e.deprecated,
                        n = e.name;
                    return "## " + (r ? "~~" + n + "~~" : n) + (r ? " (" + r + ")" : "") + "\n" + t + (a ? "\n\n" + a : "") + "\n"
                }(a),
                u = function(e) {
                    var t = e.usage;
                    return t ? "\n## Usage\n\n" + l + "javascript\n" + t + "\n" + l : ""
                }(a),
                d = function(e) {
                    var t = e.properties;
                    return "\n\n## Properties\n" + (void 0 === t ? [] : t).map(function(e) {
                        var t = e.defaultValue,
                            a = e.deprecated,
                            n = e.description,
                            o = e.format,
                            i = e.name,
                            c = e.required;
                        return "\n" + (a ? "**~~" + i + "~~**" : "**" + i + "**") + (a ? " (" + a + ")" : "") + "\n\n" + (c ? "Required. " : "") + n + (t ? function(e) {
                            return " Defaults to `" + ("object" === ("undefined" === typeof e ? "undefined" : r(e)) ? JSON.stringify(e, void 0, 2) : e) + "`."
                        }(t) : "") + "\n\n" + l + "\n" + o + "\n" + l
                    }).join("\n") + "\n  "
                }(a),
                s = function(e) {
                    var t = e.intrinsicElement;
                    return t ? "\n## Intrinsic element\n\n" + l + "\n" + t + "\n" + l : ""
                }(a);
            return "" + o + n + u + d + s
        };
        var n, o = a(51),
            i = (n = o) && n.__esModule ? n : {
                default: n
            };
        var l = "```";

        function c(e) {
            return "[![](" + e.badge + ")](" + e.url + ")"
        }
    }, function(e, t, a) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var a = arguments[t];
                for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
            }
            return e
        };
        t.default = function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            if (!e) throw new Error("react-desc: component is required");
            var a = r({
                name: e.displayName || e.name
            }, t);
            if (t && (delete a.propTypes, t.propTypes)) {
                var n = [];
                Object.keys(t.propTypes).forEach(function(e) {
                    var a = t.propTypes[e];
                    n.push(l(a, e))
                }), n.length > 0 && (a.properties = n)
            }
            return a
        };
        var n = function(e) {
                return e.map(function(e) {
                    return i(e)
                })
            },
            o = function(e) {
                return "{" + Object.keys(e).map(function(t) {
                    var a = e[t],
                        r = void 0;
                    return r = a.type && ("arrayOf" === a.type || "oneOfType" === a.type || "oneOf" === a.type) && Array.isArray(a.args) ? "" + i(a) : "shape" === a.type ? "" + i(a) : i(a), t + (a.reactDesc && a.reactDesc.required ? "" : "?") + ": " + r
                }).join(",") + "}"
            },
            i = function e(t, a) {
                var r = void 0;
                if (Array.isArray(t)) r = n(t).join(a);
                else if ("function" !== typeof t && t.type) switch (t.type) {
                    case "array":
                        r = "any[]";
                        break;
                    case "arrayOf":
                        r = "oneOfType" === t.args.type ? "(" + e(t.args, " | ") + ")[]" : e(t.args, "\n") + "[]";
                        break;
                    case "bool":
                        r = "boolean";
                        break;
                    case "func":
                        r = "((...args: any[]) => any)";
                        break;
                    case "node":
                        r = "React.ReactNode";
                        break;
                    case "element":
                        r = "JSX.Element";
                        break;
                    case "instanceOf":
                    case "symbol":
                        r = "any";
                        break;
                    case "objectOf":
                        r = "{ [key: string]: " + e(t.args) + " }";
                        break;
                    case "oneOf":
                        r = t.args.map(function(e) {
                            return '"' + e + '"'
                        }).join(" | ");
                        break;
                    case "oneOfType":
                        r = "" + e(t.args, " | ");
                        break;
                    case "shape":
                        r = "" + o(t.args);
                        break;
                    default:
                        r = "" + t.type
                } else r = "any";
                return r
            },
            l = function(e, t) {
                var a = r({}, e.reactDesc, {
                    name: t
                });
                return a.format = i(e), a
            }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.getDeviceBreakpoint = t.getBreakpoint = void 0;
        t.getBreakpoint = function(e, t) {
            var a;
            return Object.keys(t.global.breakpoints).sort(function(e, a) {
                var r = t.global.breakpoints[e],
                    n = t.global.breakpoints[a];
                return r ? n ? r.value ? n.value ? r.value - n.value : -1 : 1 : -1 : 1
            }).some(function(r) {
                var n = t.global.breakpoints[r];
                return !(!n || n.value && !(n.value >= e)) && (a = r, !0)
            }), a
        };
        t.getDeviceBreakpoint = function(e, t) {
            return t.global.deviceBreakpoints[e]
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.ROUTER_PROPS = void 0;
        var r = a(50),
            n = {
                path: r.PropTypes.string.description("Indicates the path to be used for react-router link.").isRequired,
                method: r.PropTypes.oneOf(["push", "replace"]).description("Indicates whether the browser history should be appended to or replaced.").defaultValue("push")
            };
        t.ROUTER_PROPS = n
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.throttle = void 0;
        t.throttle = function(e, t, a) {
            var r, n;
            return void 0 === t && (t = 250), void 0 === a && (a = void 0),
                function() {
                    for (var o = arguments.length, i = new Array(o), l = 0; l < o; l++) i[l] = arguments[l];
                    var c = Date.now();
                    r && c < r + t ? (clearTimeout(n), n = setTimeout(function() {
                        r = c, e.apply(a, i)
                    }, t)) : (r = c, e.apply(a, i))
                }
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.themeDocUtils = void 0;
        t.themeDocUtils = {
            breakpointStyle: function(e) {
                return {
                    "global.breakpoints": {
                        description: e,
                        type: "object",
                        defaultValue: "{\n    small: {\n      value: '768px',\n      borderSize: {\n        xsmall: '1px',\n        small: '2px',\n        medium: '4px',\n        large: '6px',\n        xlarge: '12px',\n      },\n      edgeSize: {\n        none: '0px',\n        hair: '1px',\n        xxsmall: '2px',\n        xsmall: '3px',\n        small: '6px',\n        medium: '12px',\n        large: '24px',\n        xlarge: '48px',\n      },\n      size: {\n        xxsmall: '24px',\n        xsmall: '48px',\n        small: '96px',\n        medium: '192px',\n        large: '384px',\n        xlarge: '768px',\n        full: '100%',\n      },\n    },\n    medium: {\n      value: '1536px',\n    },\n    large: {},\n  }"
                    }
                }
            },
            disabledStyle: {
                "global.control.disabled.opacity": {
                    description: "The opacity when a component is disabled.",
                    type: "number",
                    defaultValue: .3
                }
            },
            edgeStyle: function(e) {
                return {
                    "global.edgeSize": {
                        description: e,
                        type: "object",
                        defaultValue: "{\n    edgeSize: {\n      none: '0px',\n      hair: '1px',\n      xxsmall: '3px',\n      xsmall: '6px',\n      small: '12px',\n      medium: '24px',\n      large: '48px',\n      xlarge: '96px',\n      responsiveBreakpoint: 'small',\n    },\n  }"
                    }
                }
            },
            focusStyle: {
                "global.focus.border.color": {
                    description: "The color around the component when in focus.",
                    type: "string | { dark: string, light: string }",
                    defaultValue: "focus"
                }
            },
            inputStyle: {
                "global.input.weight": {
                    description: "The font weight of the text entered.",
                    type: "number",
                    defaultValue: 600
                },
                "global.input.padding": {
                    description: "The padding of the text.",
                    type: "string",
                    defaultValue: "12px"
                }
            },
            placeholderStyle: {
                "global.colors.placeholder": {
                    description: "The placeholder color used for the component.",
                    type: "string",
                    defaultValue: "#AAAAAA"
                }
            },
            responsiveBreakpoint: function(e) {
                return {
                    "global.edgeSize.responsiveBreakpoint": {
                        description: e,
                        type: "string",
                        defaultValue: "small"
                    }
                }
            }
        }
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.base = t.generate = void 0;
        var r = a(6),
            n = a(1),
            o = a(33),
            i = a(32),
            l = a(34),
            c = a(14),
            u = a(30),
            d = a(29),
            s = a(18),
            h = a(24),
            p = a(35),
            f = a(36),
            g = a(23),
            m = a(31),
            y = a(38),
            v = a(37),
            b = a(21),
            w = a(20),
            z = a(16);

        function x() {
            return (x = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        var k = ["#6FFFB0", "#FD6FFF", "#81FCED", "#FFCA58"],
            M = {
                critical: "#FF4040",
                error: "#FF4040",
                warning: "#FFAA15",
                ok: "#00C781",
                unknown: "#CCCCCC",
                disabled: "#CCCCCC"
            },
            A = k[0],
            L = {
                active: (0, r.rgba)(221, 221, 221, .5),
                black: "#000000",
                border: {
                    dark: (0, r.rgba)(255, 255, 255, .33),
                    light: (0, r.rgba)(0, 0, 0, .33)
                },
                brand: "#7D4CDB",
                control: {
                    dark: "accent-1",
                    light: "brand"
                },
                focus: A,
                placeholder: "#AAAAAA",
                selected: "brand",
                text: {
                    dark: "#f8f8f8",
                    light: "#444444"
                },
                icon: {
                    dark: "#f8f8f8",
                    light: "#666666"
                },
                white: "#FFFFFF"
            },
            S = function(e, t) {
                return e.forEach(function(e, a) {
                    L[t + "-" + (a + 1)] = e
                })
            };
        S(k, "accent"), S(["#333333", "#555555", "#777777", "#999999", "#999999", "#999999"], "dark"), S(["#F8F8F8", "#F2F2F2", "#EDEDED", "#DADADA", "#DADADA", "#DADADA"], "light"), S(["#00873D", "#3D138D", "#00739D", "#A2423D"], "neutral"), Object.keys(M).forEach(function(e) {
            L["status-" + e] = M[e]
        });
        var O = function(e, t) {
            void 0 === e && (e = 24), void 0 === t && (t = 6);
            var a = .75 * e,
                k = e / t,
                M = function(t) {
                    return {
                        size: a + t * k + "px",
                        height: e + t * k + "px",
                        maxWidth: e * (a + t * k) + "px"
                    }
                },
                A = (0, w.deepMerge)(b.base, {
                    global: {
                        animation: {
                            duration: "1s",
                            jiggle: {
                                duration: "0.1s"
                            }
                        },
                        borderSize: {
                            xsmall: "1px",
                            small: "2px",
                            medium: e / 6 + "px",
                            large: e / 2 + "px",
                            xlarge: e + "px"
                        },
                        breakpoints: {
                            small: {
                                value: 32 * e,
                                borderSize: {
                                    xsmall: "1px",
                                    small: "2px",
                                    medium: e / 6 + "px",
                                    large: e / 4 + "px",
                                    xlarge: e / 2 + "px"
                                },
                                edgeSize: {
                                    none: "0px",
                                    hair: "1px",
                                    xxsmall: "2px",
                                    xsmall: e / 8 + "px",
                                    small: e / 4 + "px",
                                    medium: e / 2 + "px",
                                    large: e + "px",
                                    xlarge: 2 * e + "px"
                                },
                                size: {
                                    xxsmall: e + "px",
                                    xsmall: 2 * e + "px",
                                    small: 4 * e + "px",
                                    medium: 8 * e + "px",
                                    large: 16 * e + "px",
                                    xlarge: 32 * e + "px",
                                    full: "100%"
                                }
                            },
                            medium: {
                                value: 64 * e
                            },
                            large: {}
                        },
                        deviceBreakpoints: {
                            phone: "small",
                            tablet: "medium",
                            computer: "large"
                        },
                        colors: L,
                        control: {
                            border: {
                                width: "1px",
                                radius: "4px",
                                color: "border"
                            },
                            disabled: {
                                opacity: .3
                            }
                        },
                        debounceDelay: 300,
                        drop: {
                            background: "#ffffff",
                            border: {
                                radius: "0px"
                            },
                            shadowSize: "small",
                            zIndex: "20"
                        },
                        edgeSize: {
                            none: "0px",
                            hair: "1px",
                            xxsmall: e / 8 + "px",
                            xsmall: e / 4 + "px",
                            small: e / 2 + "px",
                            medium: e + "px",
                            large: 2 * e + "px",
                            xlarge: 4 * e + "px",
                            responsiveBreakpoint: "small"
                        },
                        elevation: {
                            light: {
                                none: "none",
                                xsmall: "0px 1px 2px rgba(0, 0, 0, 0.20)",
                                small: "0px 2px 4px rgba(0, 0, 0, 0.20)",
                                medium: "0px 4px 8px rgba(0, 0, 0, 0.20)",
                                large: "0px 8px 16px rgba(0, 0, 0, 0.20)",
                                xlarge: "0px 12px 24px rgba(0, 0, 0, 0.20)"
                            },
                            dark: {
                                none: "none",
                                xsmall: "0px 2px 2px rgba(255, 255, 255, 0.40)",
                                small: "0px 4px 4px rgba(255, 255, 255, 0.40)",
                                medium: "0px 6px 8px rgba(255, 255, 255, 0.40)",
                                large: "0px 8px 16px rgba(255, 255, 255, 0.40)",
                                xlarge: "0px 12px 24px rgba(255, 255, 255, 0.40)"
                            }
                        },
                        focus: {
                            border: {
                                color: "focus"
                            }
                        },
                        font: x({}, M(0)),
                        hover: {
                            background: {
                                dark: {
                                    color: "active",
                                    opacity: "medium"
                                },
                                light: {
                                    color: "active",
                                    opacity: "medium"
                                }
                            },
                            color: {
                                dark: "white",
                                light: "black"
                            }
                        },
                        input: {
                            padding: e / 2 + "px",
                            weight: 600
                        },
                        opacity: {
                            strong: .8,
                            medium: .4,
                            weak: .1
                        },
                        selected: {
                            background: "selected",
                            color: "white"
                        },
                        spacing: e + "px",
                        size: {
                            xxsmall: 2 * e + "px",
                            xsmall: 4 * e + "px",
                            small: 8 * e + "px",
                            medium: 16 * e + "px",
                            large: 32 * e + "px",
                            xlarge: 48 * e + "px",
                            xxlarge: 64 * e + "px",
                            full: "100%"
                        }
                    },
                    accordion: {
                        border: {
                            side: "bottom",
                            color: "border"
                        },
                        heading: {
                            level: "4"
                        },
                        icons: {
                            collapse: s.FormUp,
                            expand: c.FormDown
                        }
                    },
                    anchor: {
                        textDecoration: "none",
                        fontWeight: 600,
                        color: {
                            dark: "accent-1",
                            light: "brand"
                        },
                        hover: {
                            textDecoration: "underline"
                        }
                    },
                    box: {
                        responsiveBreakpoint: "small"
                    },
                    button: {
                        border: {
                            width: "2px",
                            radius: .75 * e + "px"
                        },
                        primary: {},
                        padding: {
                            vertical: e / 4 - 2 + "px",
                            horizontal: e - 2 + "px"
                        }
                    },
                    calendar: {
                        small: {
                            fontSize: a - k + "px",
                            lineHeight: 1.375,
                            daySize: 8 * e / 7 + "px",
                            slideDuration: "0.2s"
                        },
                        medium: {
                            fontSize: a + "px",
                            lineHeight: 1.45,
                            daySize: 16 * e / 7 + "px",
                            slideDuration: "0.5s"
                        },
                        large: {
                            fontSize: a + 3 * k + "px",
                            lineHeight: 1.11,
                            daySize: 32 * e / 7 + "px",
                            slideDuration: "0.8s"
                        },
                        icons: {
                            previous: g.Previous,
                            next: h.Next,
                            small: {
                                previous: d.FormPrevious,
                                next: u.FormNext
                            }
                        }
                    },
                    carousel: {
                        icons: {
                            current: m.Subtract,
                            next: h.Next,
                            previous: g.Previous
                        }
                    },
                    chart: {},
                    checkBox: {
                        border: {
                            color: {
                                dark: "rgba(255, 255, 255, 0.5)",
                                light: "rgba(0, 0, 0, 0.15)"
                            },
                            width: "2px"
                        },
                        check: {
                            radius: "4px",
                            thickness: "4px"
                        },
                        icon: {},
                        icons: {},
                        hover: {
                            border: {
                                color: {
                                    dark: "white",
                                    light: "black"
                                }
                            }
                        },
                        size: e + "px",
                        toggle: {
                            color: {
                                dark: "#d9d9d9",
                                light: "#d9d9d9"
                            },
                            radius: e + "px",
                            size: 2 * e + "px",
                            knob: {}
                        }
                    },
                    clock: {
                        analog: {
                            hour: {
                                color: {
                                    dark: "light-2",
                                    light: "dark-3"
                                },
                                width: e / 3 + "px",
                                size: e + "px",
                                shape: "round"
                            },
                            minute: {
                                color: {
                                    dark: "light-4",
                                    light: "dark-3"
                                },
                                width: e / 6 + "px",
                                size: Math.round(e / 2) + "px",
                                shape: "round"
                            },
                            second: {
                                color: {
                                    dark: "accent-1",
                                    light: "accent-1"
                                },
                                width: e / 8 + "px",
                                size: Math.round(e / 2.666) + "px",
                                shape: "round"
                            },
                            size: {
                                small: 3 * e + "px",
                                medium: 4 * e + "px",
                                large: 6 * e + "px",
                                xlarge: 9 * e + "px",
                                huge: 12 * e + "px"
                            }
                        },
                        digital: {
                            text: {
                                xsmall: {
                                    size: a - 2 * k + "px",
                                    height: 1.5
                                },
                                small: {
                                    size: a - k + "px",
                                    height: 1.43
                                },
                                medium: {
                                    size: a + "px",
                                    height: 1.375
                                },
                                large: {
                                    size: a + k + "px",
                                    height: 1.167
                                },
                                xlarge: {
                                    size: a + 2 * k + "px",
                                    height: 1.1875
                                },
                                xxlarge: {
                                    size: a + 4 * k + "px",
                                    height: 1.125
                                }
                            }
                        }
                    },
                    collapsible: {
                        minSpeed: 200,
                        baseline: 500
                    },
                    dataTable: {
                        header: {},
                        groupHeader: {
                            border: {
                                side: "bottom",
                                size: "xsmall"
                            },
                            fill: "vertical",
                            pad: {
                                horizontal: "small",
                                vertical: "xsmall"
                            },
                            background: {
                                dark: "dark-2",
                                light: "light-2"
                            }
                        },
                        icons: {
                            ascending: c.FormDown,
                            contract: s.FormUp,
                            descending: s.FormUp,
                            expand: c.FormDown
                        },
                        resize: {
                            border: {
                                side: "right",
                                color: "border"
                            }
                        },
                        primary: {
                            weight: "bold"
                        }
                    },
                    diagram: {
                        line: {
                            color: "accent-1"
                        }
                    },
                    formField: {
                        border: {
                            color: "border",
                            position: "inner",
                            side: "bottom",
                            error: {
                                color: {
                                    dark: "white",
                                    light: "status-critical"
                                }
                            }
                        },
                        content: {
                            pad: {
                                horizontal: "small",
                                bottom: "small"
                            }
                        },
                        error: {
                            margin: {
                                vertical: "xsmall",
                                horizontal: "small"
                            },
                            color: {
                                dark: "status-critical",
                                light: "status-critical"
                            }
                        },
                        help: {
                            margin: {
                                left: "small"
                            },
                            color: {
                                dark: "dark-3",
                                light: "dark-3"
                            }
                        },
                        label: {
                            margin: {
                                vertical: "xsmall",
                                horizontal: "small"
                            }
                        },
                        margin: {
                            bottom: "small"
                        }
                    },
                    grommet: {},
                    heading: {
                        font: {},
                        level: {
                            1: {
                                font: {},
                                small: x({}, M(4)),
                                medium: x({}, M(8)),
                                large: x({}, M(16)),
                                xlarge: x({}, M(24))
                            },
                            2: {
                                font: {},
                                small: x({}, M(2)),
                                medium: x({}, M(4)),
                                large: x({}, M(8)),
                                xlarge: x({}, M(12))
                            },
                            3: {
                                font: {},
                                small: x({}, M(1)),
                                medium: x({}, M(2)),
                                large: x({}, M(4)),
                                xlarge: x({}, M(6))
                            },
                            4: {
                                font: {},
                                small: x({}, M(0)),
                                medium: x({}, M(0)),
                                large: x({}, M(0)),
                                xlarge: x({}, M(0))
                            },
                            5: {
                                font: {},
                                small: x({}, M(-.5)),
                                medium: x({}, M(-.5)),
                                large: x({}, M(-.5)),
                                xlarge: x({}, M(-.5))
                            },
                            6: {
                                font: {},
                                small: x({}, M(-1)),
                                medium: x({}, M(-1)),
                                large: x({}, M(-1)),
                                xlarge: x({}, M(-1))
                            }
                        },
                        responsiveBreakpoint: "small",
                        weight: 600
                    },
                    layer: {
                        background: "white",
                        border: {
                            radius: "4px"
                        },
                        container: {
                            zIndex: "15"
                        },
                        overlay: {
                            background: "rgba(0, 0, 0, 0.5)"
                        },
                        responsiveBreakpoint: "small",
                        zIndex: "10"
                    },
                    maskedInput: {},
                    menu: {
                        icons: {
                            down: c.FormDown
                        }
                    },
                    meter: {
                        color: "accent-1"
                    },
                    paragraph: {
                        small: x({}, M(-1)),
                        medium: x({}, M(0)),
                        large: x({}, M(1)),
                        xlarge: x({}, M(2)),
                        xxlarge: x({}, M(4))
                    },
                    radioButton: {
                        border: {
                            color: {
                                dark: "rgba(255, 255, 255, 0.5)",
                                light: "rgba(0, 0, 0, 0.15)"
                            },
                            width: "2px"
                        },
                        check: {
                            radius: "100%"
                        },
                        hover: {
                            border: {
                                color: {
                                    dark: "white",
                                    light: "black"
                                }
                            }
                        },
                        icon: {},
                        icons: {},
                        gap: "small",
                        size: e + "px"
                    },
                    rangeInput: {
                        track: {
                            height: "4px",
                            color: (0, n.css)(["", ";"], function(e) {
                                return (0, r.rgba)((0, z.normalizeColor)("border", e.theme), .2)
                            })
                        },
                        thumb: {}
                    },
                    rangeSelector: {
                        background: {
                            invert: {
                                color: "light-4"
                            }
                        }
                    },
                    select: {
                        container: {},
                        control: {},
                        icons: {
                            down: c.FormDown
                        },
                        options: {
                            box: {
                                align: "start",
                                pad: "small"
                            },
                            text: {
                                margin: "none"
                            }
                        },
                        step: 20
                    },
                    tab: {
                        active: {
                            color: "text"
                        },
                        border: {
                            side: "bottom",
                            size: "small",
                            color: {
                                dark: "accent-1",
                                light: "brand"
                            },
                            active: {
                                color: {
                                    dark: "white",
                                    light: "black"
                                }
                            },
                            hover: {
                                color: {
                                    dark: "white",
                                    light: "black"
                                }
                            }
                        },
                        color: "control",
                        hover: {
                            color: {
                                dark: "white",
                                light: "black"
                            }
                        },
                        margin: {
                            vertical: "xxsmall",
                            horizontal: "small"
                        },
                        pad: {
                            bottom: "xsmall"
                        }
                    },
                    tabs: {
                        header: {},
                        panel: {}
                    },
                    table: {
                        header: {
                            align: "start",
                            pad: {
                                horizontal: "small",
                                vertical: "xsmall"
                            },
                            border: "bottom",
                            verticalAlign: "bottom",
                            fill: "vertical"
                        },
                        body: {
                            align: "start",
                            pad: {
                                horizontal: "small",
                                vertical: "xsmall"
                            }
                        },
                        footer: {
                            align: "start",
                            pad: {
                                horizontal: "small",
                                vertical: "xsmall"
                            },
                            border: "top",
                            verticalAlign: "top",
                            fill: "vertical"
                        }
                    },
                    text: {
                        xsmall: x({}, M(-1.5)),
                        small: x({}, M(-1)),
                        medium: x({}, M(0)),
                        large: x({}, M(1)),
                        xlarge: x({}, M(2)),
                        xxlarge: x({}, M(4))
                    },
                    textArea: {},
                    textInput: {},
                    video: {
                        captions: {
                            background: "rgba(0, 0, 0, 0.7)"
                        },
                        icons: {
                            closedCaption: i.ClosedCaption,
                            configure: o.Actions,
                            fullScreen: l.Expand,
                            pause: p.Pause,
                            play: f.Play,
                            reduceVolume: v.VolumeLow,
                            volume: y.Volume
                        },
                        scrubber: {
                            color: "light-4"
                        }
                    },
                    worldMap: {
                        color: "light-3",
                        continent: {
                            active: "8px",
                            base: "6px"
                        },
                        hover: {
                            color: "light-4"
                        },
                        place: {
                            active: "20px",
                            base: "8px"
                        }
                    }
                });
            return (0, w.deepFreeze)(A)
        };
        t.generate = O;
        var C = O(24);
        t.base = C
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.grommet = void 0;
        var r = a(1),
            n = (0, a(20).deepFreeze)({
                global: {
                    colors: {
                        background: "#ffffff"
                    },
                    font: {
                        family: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Fira Sans", "Droid Sans",  "Helvetica Neue", Arial, sans-serif,  "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"'
                    }
                },
                button: {
                    extend: (0, r.css)(["", ";"], function(e) {
                        return !e.plain && "font-weight: bold;"
                    })
                }
            });
        t.grommet = n
    }, function(e, t, a) {
        "use strict";
        t.__esModule = !0, t.dark = void 0;
        var r = a(6),
            n = a(1),
            o = a(20),
            i = a(16),
            l = {
                critical: "#FF3333",
                error: "#FF3333",
                warning: "#F7E464",
                ok: "#7DD892",
                unknown: "#a8a8a8",
                disabled: "#a8a8a8"
            },
            c = {
                active: (0, r.rgba)(102, 102, 102, .5),
                background: "#111111",
                black: "#000000",
                brand: "#FD6FFF",
                control: {
                    dark: "#FFCA58",
                    light: "#403216"
                },
                focus: "#FFCA58",
                icon: {
                    dark: "#f8f8f8",
                    light: "#666666"
                },
                placeholder: "#AAAAAA",
                text: {
                    dark: "#eeeeee",
                    light: "#444444"
                },
                white: "#FFFFFF"
            },
            u = function(e, t) {
                return e.forEach(function(e, a) {
                    c[t + "-" + (a + 1)] = e
                })
            };
        u(["#FD6FFF", "#60EB9F", "#60EBE1", "#FFCA58"], "accent"), u(["#EB6060", "#01C781", "#6095EB", "#FFB200"], "neutral"), Object.keys(l).forEach(function(e) {
            c["status-" + e] = l[e]
        });
        var d = (0, o.deepFreeze)({
            global: {
                colors: c,
                drop: {
                    background: "#333333"
                },
                focus: {
                    border: {
                        color: (0, n.css)(["", ";"], function(e) {
                            return (0, i.normalizeColor)("focus", e.theme)
                        }),
                        width: "2px"
                    }
                },
                font: {
                    family: "Arial"
                },
                input: {
                    weight: 700
                }
            },
            anchor: {
                color: "control"
            },
            layer: {
                background: "#111111",
                overlay: {
                    background: (0, r.rgba)(48, 48, 48, .5)
                }
            }
        });
        t.dark = d
    }, , , , , , function(e, t, a) {
        "use strict";
        var r = a(0),
            n = a.n(r),
            o = a(9),
            i = a.n(o),
            l = a(1);
        a.d(t, "a", function() {
            return l.ThemeContext
        });
        var c = a(19);
        l.ThemeContext.Extend = function(e) {
            var t = e.children,
                a = e.value;
            return n.a.createElement(l.ThemeContext.Consumer, null, function(e) {
                return n.a.createElement(l.ThemeContext.Provider, {
                    value: Object(c.b)(e, a)
                }, t)
            })
        }, l.ThemeContext.Extend.propTypes = {
            children: i.a.node.isRequired,
            value: i.a.shape({}).isRequired
        }
    }, function(e, t, a) {
        "use strict";
        var r, n = a(0),
            o = a.n(n),
            i = a(12),
            l = a(1),
            c = a(4),
            u = a(63),
            d = function(e, t) {
                var a = e;
                return e && (t.dark && e.dark && "boolean" !== typeof e.dark ? a = e.dark : !t.dark && e.light && "boolean" !== typeof e.light && (a = e.light), a = Object(u.d)(a, t)), a
            },
            s = function(e, t) {
                var a, r = d(e, t);
                if (r)
                    if ("object" === typeof r) {
                        var n = r.color,
                            o = r.dark,
                            i = r.opacity;
                        if ("boolean" === typeof o) a = o;
                        else if (n && (!i || "weak" !== i)) {
                            var l = Object(c.c)(r.color, t);
                            l && (a = Object(c.a)(l))
                        }
                    } else {
                        var u = Object(c.c)(r, t);
                        u && (a = Object(c.a)(u))
                    }
                return a
            },
            h = function(e, t, a) {
                var r = d(e, t),
                    n = a || t.global.colors.text;
                if ("object" === typeof r) {
                    var o, i = [];
                    if (r.image) !1 === r.dark ? o = n.light : r.dark ? o = n.dark : a || (o = "inherit"), i.push(Object(l.css)(["background-image:", ";background-repeat:", ";background-position:", ";background-size:", ";color:", ";"], r.image, r.repeat || "no-repeat", r.position || "center center", r.size || "cover", o));
                    if (r.color) {
                        var u = Object(c.c)(r.color, t),
                            s = Object(c.b)(u, !0 === r.opacity ? t.global.opacity.medium : t.global.opacity[r.opacity] || r.opacity) || u;
                        i.push(Object(l.css)(["background-color:", ";", ""], s, (!r.opacity || "weak" !== r.opacity) && "color: " + n[r.dark || Object(c.a)(s) ? "dark" : "light"] + ";"))
                    }
                    return !1 === r.dark ? i.push(Object(l.css)(["color:", ";"], n.light)) : r.dark && i.push(Object(l.css)(["color:", ";"], n.dark)), i
                }
                if (r) {
                    if (0 === r.lastIndexOf("url", 0)) return Object(l.css)(["background:", " no-repeat center center;background-size:cover;"], r);
                    var h = Object(c.c)(r, t);
                    if (h) return Object(l.css)(["background:", ";color:", ";"], h, n[Object(c.a)(h) ? "dark" : "light"])
                }
            },
            p = Object(l.css)(["", " color:", ";"], function(e) {
                return h(Object(c.c)(e.theme.global.hover.background, e.theme), e.theme)
            }, function(e) {
                return Object(c.c)(e.theme.global.hover.color, e.theme)
            }),
            f = (Object(l.css)(["", " color:", ";"], function(e) {
                return h(Object(c.c)(e.theme.global.selected.background, e.theme), e.theme)
            }, function(e) {
                return Object(c.c)(e.theme.global.selected.color, e.theme)
            }), a(5)),
            g = a(10),
            m = a(113),
            y = a(11),
            v = {
                baseline: "baseline",
                center: "center",
                end: "flex-end",
                start: "flex-start",
                stretch: "stretch"
            },
            b = Object(l.css)(["align-items:", ";"], function(e) {
                return v[e.align]
            }),
            w = {
                around: "around",
                between: "between",
                center: "center",
                end: "flex-end",
                start: "flex-start",
                stretch: "stretch"
            },
            z = Object(l.css)(["align-content:", ";"], function(e) {
                return w[e.alignContent]
            }),
            x = {
                auto: "auto",
                full: "100%",
                "1/2": "50%",
                "1/4": "25%",
                "2/4": "50%",
                "3/4": "75%",
                "1/3": "33.33%",
                "2/3": "66.66%"
            },
            k = Object(l.css)(["flex-basis:", ";"], function(e) {
                return x[e.basis] || e.theme.global.size[e.basis] || e.basis
            }),
            M = Object(l.css)(["box-shadow:", ";"], function(e) {
                return e.theme.global.elevation[e.theme.dark && !e.theme.darkChanged || !e.theme.dark && e.theme.darkChanged ? "dark" : "light"][e.elevationProp]
            }),
            A = ((r = {})[!0] = "1 1", r[!1] = "0 0", r.grow = "1 0", r.shrink = "0 1", r),
            L = Object(l.css)(["flex:", ";"], function(e) {
                return ("boolean" === typeof(t = e.flex) || "string" === typeof t ? A[t] : (t.grow ? t.grow : 0) + " " + (t.shrink ? t.shrink : 0)) + (!0 === e.flex || e.basis ? "" : " auto");
                var t
            }),
            S = {
                around: "space-around",
                between: "space-between",
                center: "center",
                end: "flex-end",
                evenly: "space-evenly",
                start: "flex-start"
            },
            O = Object(l.css)(["justify-content:", ";"], function(e) {
                return S[e.justify]
            }),
            C = {
                full: "100%"
            },
            T = {
                xsmall: 1,
                small: 5,
                medium: 10,
                large: 50,
                xlarge: 200
            },
            j = {
                xsmall: 1.001,
                small: 1.01,
                medium: 1.1,
                large: 1.5,
                xlarge: 2
            },
            E = {
                xsmall: .1,
                small: 1,
                medium: 5,
                large: 400,
                xlarge: 1e3
            },
            _ = {
                xsmall: .001,
                small: .01,
                medium: .05,
                large: .1,
                xlarge: .5
            },
            P = function(e, t) {
                if (void 0 === t && (t = "medium"), "fadeIn" === e) return ["opacity: 0;", "opacity: 1;"];
                if ("fadeOut" === e) return ["opacity: 1;", "opacity: 0;"];
                if ("jiggle" === e) {
                    var a = E[t];
                    return ["transform: rotate(-" + a + "deg);", "transform: rotate(" + a + "deg);"]
                }
                return "pulse" === e ? ["transform: scale(1);", "transform: scale(" + j[t] + ")"] : "flipIn" === e ? ["transform: rotateY(90deg);", "transform: rotateY(0);"] : "flipOut" === e ? ["transform: rotateY(0);", "transform: rotateY(90deg);"] : "slideDown" === e ? ["transform: translateY(-" + T[t] + "%);", "transform: none;"] : "slideLeft" === e ? ["transform: translateX(" + T[t] + "%);", "transform: none;"] : "slideRight" === e ? ["transform: translateX(-" + T[t] + "%);", "transform: none;"] : "slideUp" === e ? ["transform: translateY(" + T[t] + "%);", "transform: none;"] : "zoomIn" === e ? ["transform: scale(" + (1 - _[t]) + ");", "transform: none;"] : "zoomOut" === e ? ["transform: scale(" + (1 + _[t]) + ");", "transform: none;"] : []
            },
            V = function(e, t) {
                return e ? e / 1e3 + "s" : t
            },
            H = function(e, t) {
                var a, r = P(e.type, e.size);
                if (r) {
                    var n = Object(l.css)(["from{", ";}to{", ";}"], r[0], r[1]);
                    return Object(l.css)(["", " ", " ", " ", ""], Object(l.keyframes)(["", ""], n), V(e.duration, (t.global.animation[e.type] ? t.global.animation[e.type].duration : void 0) || t.global.animation.duration), V(e.delay, "0s"), "jiggle" === (a = e.type) ? "alternate infinite" : "pulse" === a ? "alternate infinite" : "forwards")
                }
                return ""
            },
            I = function(e) {
                var t = P(e.type, e.size);
                return t ? t[0] + " " + function(e) {
                    return "flipIn" === e.type || "flipOut" === e.type ? "perspective: 1000px; transform-style: preserve-3d;" : ""
                }(e) : ""
            },
            F = Object(l.css)(["", ";"], function(e) {
                return Object(l.css)(["", " animation:", ";"], "string" === typeof(t = e.animation) ? I({
                    type: t
                }) : Array.isArray(t) ? t.map(function(e) {
                    return I("string" === typeof e ? {
                        type: e
                    } : e)
                }).join("") : "object" === typeof t ? I(t) : "", function e(t, a) {
                    return "string" === typeof t ? H({
                        type: t
                    }, a) : Array.isArray(t) ? t.reduce(function(t, r, n) {
                        return Object(l.css)(["", "", " ", ""], t, n > 0 ? "," : "", e(r, a))
                    }, "") : "object" === typeof t ? H(t, a) : ""
                }(e.animation, e.theme));
                var t
            }),
            R = l.default.div.withConfig({
                displayName: "StyledBox",
                componentId: "sc-13pk1d4-0"
            })(["display:flex;box-sizing:border-box;outline:none;", ";", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", ""], function(e) {
                return !e.basis && "max-width: 100%;"
            }, u.f, function(e) {
                return e.heightProp && "height: " + (e.theme.global.size[e.heightProp] || e.heightProp) + ";"
            }, function(e) {
                return e.widthProp && "width: " + (e.theme.global.size[e.widthProp] || e.widthProp) + ";"
            }, function(e) {
                return e.align && b
            }, function(e) {
                return e.alignContent && z
            }, function(e) {
                return e.background && h(e.background, e.theme)
            }, function(e) {
                return e.border && function(e, t, a) {
                    var r = [],
                        n = Object(c.c)(e.color || "border", a),
                        o = e.size || "xsmall",
                        i = e.style || "solid",
                        u = "string" === typeof e ? e : e.side || "all",
                        d = i + " " + (a.global.borderSize[o] || o) + " " + n,
                        s = a.box.responsiveBreakpoint && a.global.breakpoints[a.box.responsiveBreakpoint],
                        h = s && (s.borderSize[o] || o) && i + " " + (s.borderSize[o] || o) + " " + n;
                    return "top" === u || "bottom" === u || "left" === u || "right" === u ? (r.push(Object(l.css)(["border-", ":", ";"], u, d)), h && r.push(Object(y.a)(s, "\n        border-" + u + ": " + h + ";\n      "))) : "vertical" === u ? (r.push(Object(l.css)(["border-left:", ";border-right:", ";"], d, d)), h && r.push(Object(y.a)(s, "\n        border-left: " + h + ";\n        border-right: " + h + ";\n      "))) : "horizontal" === u ? (r.push(Object(l.css)(["border-top:", ";border-bottom:", ";"], d, d)), h && r.push(Object(y.a)(s, "\n        border-top: " + h + ";\n        border-bottom: " + h + ";\n      "))) : (r.push(Object(l.css)(["border:", ";"], d)), h && r.push(Object(y.a)(s, "border: " + h + ";"))), r
                }(e.border, e.responsive, e.theme)
            }, function(e) {
                return e.directionProp && function(e, t) {
                    var a = [Object(l.css)(["min-width:0;min-height:0;flex-direction:", ";"], "row-responsive" === e ? "row" : e)];
                    if ("row-responsive" === e && t.box.responsiveBreakpoint) {
                        var r = t.global.breakpoints[t.box.responsiveBreakpoint];
                        r && a.push(Object(y.a)(r, "\n        flex-direction: column;\n        flex-basis: auto;\n        justify-content: flex-start;\n        align-items: stretch;\n      "))
                    }
                    return a
                }(e.directionProp, e.theme)
            }, function(e) {
                return void 0 !== e.flex && L
            }, function(e) {
                return e.basis && k
            }, function(e) {
                return e.fillProp && ("horizontal" === (t = e.fillProp) ? "width: 100%;" : "vertical" === t ? "height: 100%;" : t ? "\n      width: 100%;\n      height: 100%;\n    " : void 0);
                var t
            }, function(e) {
                return e.justify && O
            }, function(e) {
                return e.pad && Object(u.c)("padding", e.pad, e.responsive, e.theme.box.responsiveBreakpoint, e.theme)
            }, function(e) {
                return e.round && function(e, t, a) {
                    var r = a.box.responsiveBreakpoint && a.global.breakpoints[a.box.responsiveBreakpoint],
                        n = [];
                    if ("object" === typeof e) {
                        var o = C[e.size] || a.global.edgeSize[e.size || "medium"] || e.size,
                            i = r && r.edgeSize[e.size] && (r.edgeSize[e.size] || e.size);
                        "top" === e.corner ? (n.push(Object(l.css)(["border-top-left-radius:", ";border-top-right-radius:", ";"], o, o)), i && n.push(Object(y.a)(r, "\n          border-top-left-radius: " + i + ";\n          border-top-right-radius: " + i + ";\n        "))) : "bottom" === e.corner ? (n.push(Object(l.css)(["border-bottom-left-radius:", ";border-bottom-right-radius:", ";"], o, o)), i && n.push(Object(y.a)(r, "\n          border-bottom-left-radius: " + i + ";\n          border-bottom-right-radius: " + i + ";\n        "))) : "left" === e.corner ? (n.push(Object(l.css)(["border-top-left-radius:", ";border-bottom-left-radius:", ";"], o, o)), i && n.push(Object(y.a)(r, "\n          border-top-left-radius: " + i + ";\n          border-bottom-left-radius: " + i + ";\n        "))) : "right" === e.corner ? (n.push(Object(l.css)(["border-top-right-radius:", ";border-bottom-right-radius:", ";"], o, o)), i && n.push(Object(y.a)(r, "\n          border-top-right-radius: " + i + ";\n          border-bottom-right-radius: " + i + ";\n        "))) : e.corner ? (n.push(Object(l.css)(["border-", "-radius:", ";"], e.corner, o)), i && n.push(Object(y.a)(r, "\n          border-" + e.corner + "-radius: " + i + ";\n        "))) : (n.push(Object(l.css)(["border-radius:", ";"], o)), i && n.push(Object(y.a)(r, "\n          border-radius: " + i + ";\n        ")))
                    } else {
                        var c = !0 === e ? "medium" : e;
                        n.push(Object(l.css)(["border-radius:", ";"], C[c] || a.global.edgeSize[c] || c));
                        var u = r && r.edgeSize[c];
                        u && n.push(Object(y.a)(r, "\n        border-radius: " + u + ";\n      "))
                    }
                    return n
                }(e.round, e.responsive, e.theme)
            }, function(e) {
                return e.wrapProp && "flex-wrap: wrap;"
            }, function(e) {
                return e.overflowProp && Object(u.g)(e.overflowProp)
            }, function(e) {
                return e.elevationProp && M
            }, function(e) {
                return e.animation && F
            }, function(e) {
                return e.theme.box && e.theme.box.extend
            });
        R.defaultProps = {}, Object.setPrototypeOf(R.defaultProps, f.a);
        var N = l.default.div.withConfig({
            displayName: "StyledBox__StyledBoxGap",
            componentId: "sc-13pk1d4-1"
        })(["flex:0 0 auto;", ";"], function(e) {
            return e.gap && function(e, t, a, r) {
                var n = r.box.responsiveBreakpoint && r.global.breakpoints[r.box.responsiveBreakpoint],
                    o = n && n.edgeSize[t] && n.edgeSize[t],
                    i = [];
                return "column" === e ? (i.push(Object(l.css)(["height:", ";"], r.global.edgeSize[t] || t)), o && i.push(Object(y.a)(n, "height: " + o + ";"))) : (i.push("width: " + (r.global.edgeSize[t] || t) + ";"), a && "row-responsive" === e && i.push(Object(y.a)(n, "\n        width: auto;\n        height: " + o + ";\n      "))), i
            }(e.directionProp, e.gap, e.responsive, e.theme)
        });

        function D() {
            return (D = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }

        function U(e, t, a) {
            return t in e ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = a, e
        }
        N.defaultProps = {}, Object.setPrototypeOf(N.defaultProps, f.a);
        var B = function(e) {
            var t, a;

            function r() {
                return e.apply(this, arguments) || this
            }
            return a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, t.__proto__ = a, r.prototype.render = function() {
                var e, t = this.props,
                    a = t.a11yTitle,
                    r = t.background,
                    i = t.children,
                    l = t.direction,
                    c = t.elevation,
                    u = t.fill,
                    d = t.forwardRef,
                    h = t.gap,
                    p = t.overflow,
                    f = t.responsive,
                    g = t.tag,
                    y = t.as,
                    v = t.wrap,
                    b = t.width,
                    w = t.height,
                    z = t.theme,
                    x = function(e, t) {
                        if (null == e) return {};
                        var a, r, n = {},
                            o = Object.keys(e);
                        for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                        return n
                    }(t, ["a11yTitle", "background", "children", "direction", "elevation", "fill", "forwardRef", "gap", "overflow", "responsive", "tag", "as", "wrap", "width", "height", "theme"]),
                    k = this.context || z,
                    M = i;
                h && (M = [], n.Children.forEach(i, function(t, a) {
                    t && (void 0 === e ? e = a : M.push(o.a.createElement(N, {
                        key: a,
                        gap: h,
                        directionProp: l,
                        responsive: f
                    }))), M.push(t)
                }));
                var A = o.a.createElement(R, D({
                    as: !y && g ? g : y,
                    "aria-label": a,
                    background: r,
                    ref: d,
                    directionProp: l,
                    elevationProp: c,
                    fillProp: u,
                    overflowProp: p,
                    wrapProp: v,
                    widthProp: b,
                    heightProp: w,
                    responsive: f
                }, x), M);
                if (r || k.darkChanged) {
                    var L = s(r, k),
                        S = void 0 !== L && L !== k.dark;
                    (S || k.darkChanged) && (L = void 0 === L ? k.dark : L, A = o.a.createElement(m.a.Provider, {
                        value: D({}, k, {
                            dark: L,
                            darkChanged: S
                        })
                    }, A))
                }
                return A
            }, r
        }(n.Component);
        U(B, "contextType", m.a), U(B, "displayName", "Box"), U(B, "defaultProps", {
            direction: "column",
            margin: "none",
            pad: "none",
            responsive: !0
        }), Object.setPrototypeOf(B.defaultProps, f.a);
        var W = Object(i.a)(l.withTheme, g.b)(B);
        var $ = Object(l.css)(["&:hover{", " ", ";}"], function(e) {
                return e.hoverIndicator && function(e, t) {
                    var a;
                    return a = !0 === e || "background" === e ? t.global.hover.background : e, Object(l.css)(["", " color:", ";"], h(a, t), Object(c.c)(t.global.hover.color, t))
                }(e.hoverIndicator, e.theme)
            }, function(e) {
                return !e.plain && Object(l.css)(["box-shadow:0px 0px 0px 2px ", ";"], function(e) {
                    return e.colorValue ? Object(c.c)(e.colorValue, e.theme) : Object(c.c)(e.theme.button.border.color || "control", e.theme)
                }(e))
            }),
            q = Object(l.css)(["color:inherit;border:none;padding:0;text-align:inherit;"]),
            Q = l.default.button.withConfig({
                displayName: "StyledButton",
                componentId: "sc-323bzc-0"
            })(["display:inline-block;box-sizing:border-box;cursor:pointer;outline:none;font:inherit;text-decoration:none;margin:0;background:transparent;overflow:visible;text-transform:none;", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", ""], u.f, function(e) {
                return e.plain && q
            }, function(e) {
                return !e.plain && function(e) {
                    return Object(l.css)(["border:", " solid ", ";border-radius:", ";color:", ";padding:", " ", ";font-size:", ";line-height:", ";"], e.theme.button.border.width, Object(c.c)(e.colorValue || e.theme.button.border.color || "control", e.theme), e.theme.button.border.radius, Object(c.c)(e.theme.button.color || "text", e.theme), e.theme.button.padding.vertical, e.theme.button.padding.horizontal, e.theme.text.medium.size, e.theme.text.medium.height)
                }(e)
            }, function(e) {
                return e.primary && function(e) {
                    return Object(l.css)(["", " border-radius:", ";"], h(Object(c.c)(e.colorValue || e.theme.button.primary.color || "control", e.theme), e.theme, e.theme.button.color), e.theme.button.border.radius)
                }(e)
            }, function(e) {
                return !e.disabled && !e.focus && $
            }, function(e) {
                return !e.disabled && e.active && p
            }, function(e) {
                return e.disabled && Object(u.b)(e.theme.button.disabled && e.theme.button.disabled.opacity)
            }, function(e) {
                return e.focus && (!e.plain || e.focusIndicator) && u.e
            }, function(e) {
                return !e.plain && "\n    transition: 0.1s ease-in-out;\n  "
            }, function(e) {
                return e.fillContainer && "\n  width: 100%;\n  height: 100%;\n  max-width: none;\n  flex: 1 0 auto;\n"
            }, function(e) {
                return e.hasIcon && !e.hasLabel && "\n    line-height: 0;\n  "
            }, function(e) {
                return e.pad && e.hasIcon && !e.hasLabel && "\npadding: " + e.theme.global.edgeSize.small + ";\n"
            }, function(e) {
                return e.theme.button.extend
            });

        function Y() {
            return (Y = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }

        function G(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }

        function K(e, t, a) {
            return t in e ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = a, e
        }
        Q.defaultProps = {}, Object.setPrototypeOf(Q.defaultProps, f.a);
        var X = function(e) {
                var t = d(Object(c.c)(e.color || e.theme.button.primary.color || e.theme.global.colors.control || "brand", e.theme), e.theme);
                return Object(c.a)(t, e.theme)
            },
            Z = function(e) {
                var t, a;

                function r(t) {
                    var a;
                    K(G(a = e.call(this, t) || this), "state", {}), K(G(a), "onMouseOver", function(e) {
                        var t = a.props.onMouseOver;
                        a.setState({
                            hover: !0
                        }), t && t(e)
                    }), K(G(a), "onMouseOut", function(e) {
                        var t = a.props.onMouseOut;
                        a.setState({
                            hover: !1
                        }), t && t(e)
                    });
                    var r = t.children,
                        n = t.icon,
                        o = t.label;
                    return (n || o) && r && console.warn("Button should not have children if icon or label is provided"), a
                }
                return a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, t.__proto__ = a, r.prototype.render = function() {
                    var e = this.props,
                        t = e.a11yTitle,
                        a = e.color,
                        r = e.forwardRef,
                        i = e.children,
                        l = e.disabled,
                        c = e.icon,
                        u = e.fill,
                        d = e.focus,
                        s = e.href,
                        h = e.label,
                        p = e.onClick,
                        f = e.plain,
                        g = e.primary,
                        m = e.reverse,
                        y = e.theme,
                        v = e.type,
                        b = e.as,
                        w = function(e, t) {
                            if (null == e) return {};
                            var a, r, n = {},
                                o = Object.keys(e);
                            for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                            return n
                        }(e, ["a11yTitle", "color", "forwardRef", "children", "disabled", "icon", "fill", "focus", "href", "label", "onClick", "plain", "primary", "reverse", "theme", "type", "as"]),
                        z = this.state.hover,
                        x = c;
                    g && c && !c.props.color && (x = Object(n.cloneElement)(c, {
                        color: y.global.colors.text[X(this.props) ? "dark" : "light"]
                    }));
                    var k, M = !b && s ? "a" : b,
                        A = m ? h : x,
                        L = m ? x : h;
                    return k = A && L ? o.a.createElement(W, {
                        direction: "row",
                        align: "center",
                        justify: "center",
                        gap: "small"
                    }, A, L) : "function" === typeof i ? i({
                        hover: z,
                        focus: d
                    }) : A || L || i, o.a.createElement(Q, Y({}, w, {
                        as: M,
                        ref: r,
                        "aria-label": t,
                        colorValue: a,
                        disabled: l,
                        hasIcon: !!c,
                        hasLabel: !!h,
                        fillContainer: u,
                        focus: d,
                        href: s,
                        onClick: p,
                        onMouseOver: this.onMouseOver,
                        onMouseOut: this.onMouseOut,
                        pad: !f,
                        plain: "undefined" !== typeof f ? f : n.Children.count(i) > 0 || c && !h,
                        primary: g,
                        type: s ? void 0 : v
                    }), k)
                }, r
            }(n.Component);
        K(Z, "defaultProps", {
            type: "button",
            focusIndicator: !0
        }), Object.setPrototypeOf(Z.defaultProps, f.a);
        var J, ee = Object(i.a)(Object(g.a)(), l.withTheme, g.b)(Z),
            te = a(13),
            ae = function(e) {
                return Array.prototype.filter.call(e || [], function(e) {
                    var t = e.tagName.toLowerCase(),
                        a = t.match(/(svg|a|area|input|select|textarea|button|iframe|div)$/) && e.focus;
                    return "a" === t ? a && e.childNodes.length > 0 && e.getAttribute("href") : "svg" === t || "div" === t ? a && e.hasAttribute("tabindex") && "-1" !== e.getAttribute("tabindex") : a
                })
            },
            re = function(e, t) {
                var a = [];
                if (e) {
                    for (var r = e.parentNode; r && r.getBoundingClientRect;) {
                        var n = r.getBoundingClientRect();
                        t ? n.width && r.scrollWidth > n.width + 10 && a.push(r) : n.height && r.scrollHeight > n.height + 10 && a.push(r), r = r.parentNode
                    }
                    0 === a.length ? a.push(document) : "body" === a[0].tagName.toLowerCase() && (a.length = 0, a.push(document))
                }
                return a
            },
            ne = function() {
                var e = /^(script|link)$/i,
                    t = [];
                return [].forEach.call(document.body.children, function(a) {
                    e.test(a.tagName) || t.push(a)
                }), t
            },
            oe = function() {
                var e = document.createElement("div");
                return document.body.appendChild(e), e
            },
            ie = function(e) {
                var t = window.scrollX,
                    a = window.scrollY;
                e.focus(), window.scrollTo(t, a)
            },
            le = function(e) {
                return function(t) {
                    return function(a) {
                        a.setAttribute(t, a.getAttribute(e))
                    }
                }
            },
            ce = function(e) {
                return function(t) {
                    return t.removeAttribute(e)
                }
            },
            ue = (J = -1, function(e) {
                e.setAttribute("tabindex", J)
            }),
            de = le("tabindex")("data-g-tabindex"),
            se = le("data-g-tabindex")("tabindex"),
            he = ce("tabindex"),
            pe = ce("data-g-tabindex"),
            fe = function(e) {
                e.hasAttribute("aria-live") || (e.setAttribute("aria-hidden", !1), ae(e.getElementsByTagName("*")).forEach(function(e) {
                    e.hasAttribute("data-g-tabindex") ? se(e) : he(e), pe(e)
                }))
            },
            ge = function(e) {
                e.hasAttribute("aria-live") || (e.setAttribute("aria-hidden", !0), ae(e.getElementsByTagName("*")).forEach(function(e) {
                    e.hasAttribute("tabindex") && de(e), ue(e)
                }))
            },
            me = function e(t) {
                if (t) return t.offsetParent ? t : e(t.parentElement) || t
            },
            ye = a(9),
            ve = a.n(ye);

        function be() {
            return (be = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }

        function we(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }

        function ze(e, t, a) {
            return t in e ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = a, e
        }
        var xe = function(e) {
                return function(t) {
                    return !t.contains(e)
                }
            },
            ke = function(e) {
                var t, a;

                function r() {
                    for (var t, a = arguments.length, r = new Array(a), n = 0; n < a; n++) r[n] = arguments[n];
                    return ze(we(t = e.call.apply(e, [this].concat(r)) || this), "ref", o.a.createRef()), ze(we(t), "removeTrap", function() {
                        var e = t.props.restrictScroll,
                            a = t.ref.current;
                        ne().filter(xe(a)).forEach(fe), e && (document.body.style.overflow = t.bodyOverflowStyle)
                    }), ze(we(t), "trapFocus", function() {
                        var e = t.props.restrictScroll,
                            a = t.ref.current;
                        ne().filter(xe(a)).forEach(ge), e && (t.bodyOverflowStyle = document.body.style.overflow, document.body.style.overflow = "hidden")
                    }), t
                }
                a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, t.__proto__ = a;
                var n = r.prototype;
                return n.componentDidMount = function() {
                    var e = this,
                        t = this.props.hidden;
                    setTimeout(function() {
                        t || e.trapFocus()
                    }, 0)
                }, n.componentWillUnmount = function() {
                    this.removeTrap()
                }, n.render = function() {
                    var e = this.props,
                        t = e.children,
                        a = e.hidden,
                        r = function(e, t) {
                            if (null == e) return {};
                            var a, r, n = {},
                                o = Object.keys(e);
                            for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                            return n
                        }(e, ["children", "hidden"]);
                    return delete r.restrictScroll, o.a.createElement("div", be({
                        ref: this.ref,
                        "aria-hidden": a
                    }, r), t)
                }, r
            }(n.Component);
        ze(ke, "defaultProps", {
            hidden: !1,
            restrictScroll: !1
        }), ze(ke, "propTypes", {
            hidden: ve.a.bool,
            restrictScroll: ve.a.bool
        });
        var Me = {
            8: "onBackspace",
            9: "onTab",
            13: "onEnter",
            27: "onEsc",
            32: "onSpace",
            37: "onLeft",
            38: "onUp",
            39: "onRight",
            40: "onDown",
            188: "onComma",
            16: "onShift"
        };
        var Ae = function(e) {
            var t, a;

            function r() {
                for (var t, a, r, n, o = arguments.length, i = new Array(o), l = 0; l < o; l++) i[l] = arguments[l];
                return t = e.call.apply(e, [this].concat(i)) || this, a = function(e) {
                    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return e
                }(t), n = function(e) {
                    for (var a, r = t.props.onKeyDown, n = e.keyCode ? e.keyCode : e.which, o = Me[n], i = arguments.length, l = new Array(i > 1 ? i - 1 : 0), c = 1; c < i; c++) l[c - 1] = arguments[c];
                    o && t.props[o] && (a = t.props)[o].apply(a, [e].concat(l)), r && r.apply(void 0, [e].concat(l))
                }, (r = "onKeyDown") in a ? Object.defineProperty(a, r, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : a[r] = n, t
            }
            a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, t.__proto__ = a;
            var o = r.prototype;
            return o.componentDidMount = function() {
                "document" === this.props.target && document.addEventListener("keydown", this.onKeyDown)
            }, o.componentWillUnmount = function() {
                "document" === this.props.target && document.removeEventListener("keydown", this.onKeyDown)
            }, o.render = function() {
                var e = this.props,
                    t = e.children;
                return "document" === e.target ? t : Object(n.cloneElement)(n.Children.only(t), {
                    onKeyDown: this.onKeyDown
                })
            }, r
        }(n.Component);
        var Le = Object(l.keyframes)(["0%{opacity:0.5;transform:scale(0.8);}100%{opacity:1;transform:scale(1);}"]),
            Se = l.default.div.withConfig({
                displayName: "StyledDrop",
                componentId: "sc-16s5rx8-0"
            })(["", " border-radius:", ";position:fixed;z-index:", ";outline:none;", " opacity:0;transform-origin:", ";animation:", " 0.1s forwards;animation-delay:0.01s;@media screen and (-ms-high-contrast:active),(-ms-high-contrast:none){display:flex;align-items:stretch;}", ""], u.a, function(e) {
                return e.theme.global.drop.border.radius
            }, function(e) {
                return e.theme.global.drop.zIndex
            }, function(e) {
                return !e.plain && h(e.theme.global.drop.background, e.theme)
            }, function(e) {
                return function(e) {
                    var t = "top";
                    e.bottom && (t = "bottom");
                    var a = "left";
                    return e.right && (a = "right"), t + " " + a
                }(e.alignProp)
            }, Le, function(e) {
                return e.theme.global.drop && e.theme.global.drop.extend
            });

        function Oe() {
            return (Oe = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }

        function Ce(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }

        function Te(e, t, a) {
            return t in e ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = a, e
        }
        Se.defaultProps = {}, Object.setPrototypeOf(Se.defaultProps, f.a);
        var je = function(e) {
                27 === (e.keyCode ? e.keyCode : e.which) && e.stopPropagation()
            },
            Ee = function(e) {
                var t, a;

                function r() {
                    for (var t, a = arguments.length, r = new Array(a), n = 0; n < a; n++) r[n] = arguments[n];
                    return Te(Ce(t = e.call.apply(e, [this].concat(r)) || this), "dropRef", o.a.createRef()), Te(Ce(t), "addScrollListener", function() {
                        var e = t.props.dropTarget;
                        t.scrollParents = re(e), t.scrollParents.forEach(function(e) {
                            return e.addEventListener("scroll", t.place)
                        })
                    }), Te(Ce(t), "removeScrollListener", function() {
                        t.scrollParents.forEach(function(e) {
                            return e.removeEventListener("scroll", t.place)
                        })
                    }), Te(Ce(t), "onClickDocument", function(e) {
                        var a = t.props,
                            r = a.dropTarget,
                            n = a.onClickOutside,
                            o = r,
                            i = t.dropRef.current;
                        n && i && !o.contains(e.target) && !i.contains(e.target) && n()
                    }), Te(Ce(t), "onResize", function() {
                        t.removeScrollListener(), t.addScrollListener(), t.place(!1)
                    }), Te(Ce(t), "place", function(e) {
                        var a = t.props,
                            r = a.align,
                            n = a.dropTarget,
                            o = a.responsive,
                            i = a.stretch,
                            l = a.theme,
                            c = window.innerWidth,
                            u = window.innerHeight,
                            d = n,
                            s = t.dropRef.current;
                        if (s && d) {
                            s.style.left = "", s.style.top = "", s.style.bottom = "", s.style.width = "", e || (s.style.maxHeight = "");
                            var h, p, f, g = me(d).getBoundingClientRect(),
                                m = s.getBoundingClientRect(),
                                v = Math.min(i ? Math.max(g.width, m.width) : m.width, c);
                            r.left ? "left" === r.left ? h = g.left : "right" === r.left && (h = g.left + g.width) : r.right ? "left" === r.right ? h = g.left - v : "right" === r.right && (h = g.left + g.width - v) : h = g.left + g.width / 2 - v / 2, h + v > c ? h -= h + v - c : h < 0 && (h = 0);
                            var b = m.height;
                            b = r.top ? u - (p = "top" === r.top ? g.top : g.bottom) : r.bottom ? f = "bottom" === r.bottom ? g.bottom : g.top : u - (p = g.top + g.height / 2 - m.height / 2), o && (m.height > b || b < u / 10) && (r.top && p > u / 2 ? (p = "", b = f = "bottom" === r.top ? g.top : g.bottom) : r.bottom && b < u / 2 && (f = "", b = u - (p = "bottom" === r.bottom ? g.top : g.bottom))), s.style.left = h + "px", i && (s.style.width = v + .1 + "px"), "" !== p && (s.style.top = p + "px"), "" !== f && (s.style.bottom = u - f + "px"), e || (l.drop && l.drop.maxHeight && (b = Math.min(b, Object(y.b)(l.drop.maxHeight))), s.style.maxHeight = b + "px")
                        }
                    }), Te(Ce(t), "onEsc", function(e) {
                        var a = t.props.onEsc;
                        e.stopPropagation(), a && a(e)
                    }), Te(Ce(t), "preventClickBubbling", function(e) {
                        e.stopPropagation(), e.nativeEvent.stopImmediatePropagation()
                    }), t
                }
                a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, t.__proto__ = a;
                var n = r.prototype;
                return n.componentDidMount = function() {
                    var e = this.props.restrictFocus;
                    this.addScrollListener(), window.addEventListener("resize", this.onResize), document.addEventListener("mousedown", this.onClickDocument), this.place(!1), e && this.dropRef.current.focus()
                }, n.componentDidUpdate = function() {
                    this.place(!0)
                }, n.componentWillUnmount = function() {
                    this.removeScrollListener(), window.removeEventListener("resize", this.onResize), document.removeEventListener("mousedown", this.onClickDocument)
                }, n.render = function() {
                    var e = this.props,
                        t = e.align,
                        a = e.children,
                        r = e.elevation,
                        n = (e.onClickOutside, e.onEsc),
                        i = e.onKeyDown,
                        l = e.plain,
                        c = e.theme,
                        u = function(e, t) {
                            if (null == e) return {};
                            var a, r, n = {},
                                o = Object.keys(e);
                            for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                            return n
                        }(e, ["align", "children", "elevation", "onClickOutside", "onEsc", "onKeyDown", "plain", "theme"]),
                        d = this.context || c,
                        h = o.a.createElement(Se, Oe({
                            as: W,
                            plain: l,
                            elevation: l ? void 0 : r || d.global.drop.shadowSize || "small",
                            tabIndex: "-1",
                            ref: this.dropRef,
                            alignProp: t,
                            onMouseDown: this.preventClickBubbling
                        }, u), a);
                    if (d.global.drop.background) {
                        var p = s(d.global.drop.background, d);
                        p !== d.dark && (h = o.a.createElement(m.a.Provider, {
                            value: Oe({}, d, {
                                dark: p
                            })
                        }, h))
                    }
                    return o.a.createElement(ke, {
                        onKeyDown: n && je
                    }, o.a.createElement(Ae, {
                        onEsc: n && this.onEsc,
                        onKeyDown: i,
                        target: "document"
                    }, h))
                }, r
            }(n.Component);

        function _e() {
            return (_e = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }

        function Pe(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }

        function Ve(e, t, a) {
            return t in e ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = a, e
        }
        Te(Ee, "contextType", m.a), Te(Ee, "defaultProps", {
            align: {
                top: "top",
                left: "left"
            },
            overflow: "auto",
            stretch: "width"
        }), Object.setPrototypeOf(Ee.defaultProps, f.a);
        var He = function(e) {
            var t, a;

            function r() {
                for (var t, a = arguments.length, r = new Array(a), n = 0; n < a; n++) r[n] = arguments[n];
                return Ve(Pe(t = e.call.apply(e, [this].concat(r)) || this), "originalFocusedElement", document.activeElement), Ve(Pe(t), "dropContainer", oe()), t
            }
            a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, t.__proto__ = a;
            var n = r.prototype;
            return n.componentWillUnmount = function() {
                this.props.restrictFocus && this.originalFocusedElement && (this.originalFocusedElement.focus ? ie(this.originalFocusedElement) : this.originalFocusedElement.parentNode && this.originalFocusedElement.parentNode.focus && ie(this.originalFocusedElement.parentNode)), document.body.removeChild(this.dropContainer)
            }, n.render = function() {
                var e = this.props,
                    t = e.target,
                    a = function(e, t) {
                        if (null == e) return {};
                        var a, r, n = {},
                            o = Object.keys(e);
                        for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                        return n
                    }(e, ["target"]);
                return Object(te.createPortal)(o.a.createElement(Ee, _e({
                    dropTarget: t
                }, a)), this.dropContainer)
            }, r
        }(n.Component);
        Ve(He, "defaultProps", {
            align: {
                top: "top",
                left: "left"
            },
            plain: !1
        });
        var Ie = He;

        function Fe() {
            return (Fe = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }

        function Re(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }

        function Ne(e, t, a) {
            return t in e ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = a, e
        }
        a.d(t, "a", function() {
            return Ue
        });
        var De = function(e) {
            var t, a;

            function r(t) {
                var a;
                return Ne(Re(a = e.call(this, t) || this), "buttonRef", Object(n.createRef)()), Ne(Re(a), "onDropClose", function() {
                    var e = a.props.onClose;
                    a.setState({
                        show: !1
                    }, function() {
                        e && e()
                    })
                }), Ne(Re(a), "onToggle", function() {
                    var e = a.props,
                        t = e.onClose,
                        r = e.onOpen,
                        n = a.state.show;
                    a.setState({
                        show: !n
                    }, function() {
                        return n ? t && t() : r && r()
                    })
                }), a.state = {
                    show: t.open || !1
                }, a
            }
            a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, t.__proto__ = a, r.getDerivedStateFromProps = function(e, t) {
                var a = t.show,
                    r = e.open;
                return void 0 !== r && r !== a ? {
                    show: r
                } : null
            };
            var i = r.prototype;
            return i.componentDidMount = function() {
                this.props.open && this.forceUpdate()
            }, i.componentDidUpdate = function(e, t) {
                var a = this.props.forwardRef;
                !this.state.show && t.show && ie((a || this.buttonRef).current)
            }, i.render = function() {
                var e, t = this.props,
                    a = t.disabled,
                    r = t.dropAlign,
                    n = t.dropProps,
                    i = t.forwardRef,
                    l = t.dropContent,
                    c = t.dropTarget,
                    u = t.id,
                    d = (t.open, function(e, t) {
                        if (null == e) return {};
                        var a, r, n = {},
                            o = Object.keys(e);
                        for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                        return n
                    }(t, ["disabled", "dropAlign", "dropProps", "forwardRef", "dropContent", "dropTarget", "id", "open"])),
                    s = this.state.show;
                return delete d.onClose, delete d.onOpen, s && (i || this.buttonRef).current && (e = o.a.createElement(Ie, Fe({
                    id: u ? u + "__drop" : void 0,
                    restrictFocus: !0,
                    align: r,
                    target: c || (i || this.buttonRef).current,
                    onClickOutside: this.onDropClose,
                    onEsc: this.onDropClose
                }, n), l)), o.a.createElement(o.a.Fragment, null, o.a.createElement(ee, Fe({
                    id: u,
                    ref: i || this.buttonRef,
                    disabled: a,
                    onClick: this.onToggle
                }, d)), e)
            }, r
        }(n.Component);
        Ne(De, "defaultProps", {
            a11yTitle: "Open Drop",
            dropAlign: {
                top: "top",
                left: "left"
            }
        });
        var Ue = Object(i.a)(g.b)(De)
    }, function(e, t, a) {
        "use strict";
        var r = a(0),
            n = a.n(r),
            o = a(1),
            i = a(47),
            l = a(113),
            c = n.a.createContext(void 0),
            u = function(e, t) {
                var a;
                return Object.keys(t.global.breakpoints).sort(function(e, a) {
                    var r = t.global.breakpoints[e],
                        n = t.global.breakpoints[a];
                    return r ? n ? r.value ? n.value ? r.value - n.value : -1 : 1 : -1 : 1
                }).some(function(r) {
                    var n = t.global.breakpoints[r];
                    return !(!n || n.value && !(n.value >= e)) && (a = r, !0)
                }), a
            },
            d = function(e, t) {
                return t.global.deviceBreakpoints[e]
            },
            s = a(19),
            h = a(42),
            p = a(63),
            f = a(5),
            g = Object(o.css)(["width:100vw;height:100vh;overflow:auto;"]),
            m = o.default.div.withConfig({
                displayName: "StyledGrommet",
                componentId: "sc-19lkkz7-0"
            })(["", " ", " ", " ", " ", ""], function(e) {
                return !e.plain && p.a
            }, function(e) {
                return e.full && g
            }, function(e) {
                return e.theme.global.font.face
            }, function(e) {
                return e.theme.grommet.extend
            }, function(e) {
                return e.cssVars && Object.keys(e.theme.global.colors).filter(function(t) {
                    return "string" === typeof e.theme.global.colors[t]
                }).map(function(t) {
                    return "--" + t + ": " + e.theme.global.colors[t] + ";"
                }).join("\n")
            });

        function y() {
            return (y = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }

        function v(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }

        function b(e, t, a) {
            return t in e ? Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = a, e
        }

        function w() {
            var e = function(e, t) {
                t || (t = e.slice(0));
                return e.raw = t, e
            }(["\n  body { margin: 0; }\n"]);
            return w = function() {
                return e
            }, e
        }
        m.defaultProps = {}, Object.setPrototypeOf(m.defaultProps, f.a), a.d(t, "a", function() {
            return k
        });
        var z = Object(o.createGlobalStyle)(w()),
            x = function(e) {
                var t, a;

                function r() {
                    for (var t, a = arguments.length, r = new Array(a), n = 0; n < a; n++) r[n] = arguments[n];
                    return b(v(t = e.call.apply(e, [this].concat(r)) || this), "state", {}), b(v(t), "onResize", function() {
                        var e = t.state,
                            a = e.theme,
                            r = e.responsive,
                            n = u(window.innerWidth, a);
                        n !== r && t.setState({
                            responsive: n
                        })
                    }), t
                }
                a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, t.__proto__ = a, r.getDerivedStateFromProps = function(e, t) {
                    var a = e.theme,
                        r = void 0 === a ? {} : a,
                        n = t.theme,
                        o = t.themeProp,
                        l = Object(s.b)(h.a, r);
                    if (!n || r !== o) {
                        if ("undefined" === typeof r.dark) {
                            var c = l.global.colors.background;
                            l.dark = !!c && Object(i.a)(c)
                        }
                        return {
                            theme: l,
                            themeProp: r
                        }
                    }
                    return null
                };
                var o = r.prototype;
                return o.componentDidMount = function() {
                    window.addEventListener("resize", this.onResize), this.onResize()
                }, o.componentWillUnmount = function() {
                    window.removeEventListener("resize", this.onResize)
                }, o.deviceResponsive = function() {
                    var e = this.props.userAgent,
                        t = this.state.theme;
                    if (e) return /(tablet|ipad|playbook|silk)|(android(?!.*mobile))/i.test(e) ? d("tablet", t) : /Mobile|iPhone|Android/.test(e) ? d("phone", t) : d("computer", t)
                }, o.render = function() {
                    var e = this.props,
                        t = e.children,
                        a = e.full,
                        r = function(e, t) {
                            if (null == e) return {};
                            var a, r, n = {},
                                o = Object.keys(e);
                            for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                            return n
                        }(e, ["children", "full"]);
                    delete r.theme;
                    var o = this.state,
                        i = o.theme,
                        u = o.responsive || this.deviceResponsive() || i.global.deviceBreakpoints.tablet;
                    return n.a.createElement(l.a.Provider, {
                        value: i
                    }, n.a.createElement(c.Provider, {
                        value: u
                    }, n.a.createElement(m, y({
                        full: a
                    }, r), t), a && n.a.createElement(z, null)))
                }, r
            }(r.Component);
        b(x, "displayName", "Grommet");
        var k = x
    }, function(e, t, a) {
        "use strict";
        var r = a(0),
            n = a.n(r),
            o = a(12),
            i = a(10),
            l = a(1),
            c = a(4),
            u = a(11),
            d = a(63),
            s = a(5),
            h = Object(l.css)(["box-sizing:border-box;width:100%;height:", ";background:", ";", ""], function(e) {
                return e.theme.rangeInput.track.height
            }, function(e) {
                return Object(c.c)(e.theme.rangeInput.track.color, e.theme)
            }, function(e) {
                return e.theme.rangeInput && e.theme.rangeInput.track && e.theme.rangeInput.track.extend
            }),
            p = Object(l.css)(["box-sizing:border-box;position:relative;border-radius:", ";height:", ";width:", ";overflow:visible;background:", ";-webkit-appearance:none;cursor:pointer;", ""], function(e) {
                return e.theme.global.spacing
            }, function(e) {
                return e.theme.global.spacing
            }, function(e) {
                return e.theme.global.spacing
            }, function(e) {
                return Object(c.c)(e.theme.rangeInput.thumb.color || "control", e.theme)
            }, function(e) {
                return e.theme.rangeInput && e.theme.rangeInput.thumb && e.theme.rangeInput.thumb.extend
            }),
            f = Object(l.css)(["", " margin-top:0px;height:", ";width:", ";", ""], p, function(e) {
                return e.theme.global.spacing
            }, function(e) {
                return e.theme.global.spacing
            }, function(e) {
                return e.theme.rangeInput && e.theme.rangeInput.thumb && e.theme.rangeInput.thumb.extend
            }),
            g = l.default.input.withConfig({
                displayName: "StyledRangeInput",
                componentId: "sc-15st9ck-0"
            })(["box-sizing:border-box;position:relative;-webkit-appearance:none;border-color:transparent;height:", ";width:100%;padding:0px;cursor:pointer;background:transparent;&:focus{outline:none;}&::-moz-focus-inner{border:none;}&::-moz-focus-outer{border:none;}&::-webkit-slider-runnable-track{", "}&::-webkit-slider-thumb{margin-top:-", "px;", " ", "}&::-moz-range-track{", "}&::-moz-range-thumb{", "}&::-ms-thumb{", "}", " &::-ms-track{", " border-color:transparent;color:transparent;}&::-ms-fill-lower{background:", ";border-color:transparent;}&::-ms-fill-upper{background:", ";border-color:transparent;}", " ", ""], function(e) {
                return e.theme.global.spacing
            }, h, function(e) {
                return .5 * (Object(u.b)(e.theme.global.spacing) - Object(u.b)(e.theme.rangeInput.track.height || 0))
            }, p, function(e) {
                return !e.disabled && Object(l.css)(["&:hover{box-shadow:0px 0px 0px 2px ", ";}"], Object(c.c)(e.theme.rangeInput.thumb.color || "control", e.theme))
            }, h, f, f, function(e) {
                return !e.disabled && Object(l.css)(["&:hover::-moz-range-thumb{box-shadow:0px 0px 0px 2px ", ";}&:hover::-ms-thumb{box-shadow:0px 0px 0px 2px ", ";}"], Object(c.c)(e.theme.rangeInput.thumb.color || "control", e.theme), Object(c.c)(e.theme.rangeInput.thumb.color || "control", e.theme))
            }, h, function(e) {
                return Object(c.c)(e.theme.rangeInput.track.color, e.theme)
            }, function(e) {
                return Object(c.c)(e.theme.rangeInput.track.color, e.theme)
            }, function(e) {
                return e.focus && d.e
            }, function(e) {
                return e.theme.rangeInput && e.theme.rangeInput.extend
            });

        function m() {
            return (m = Object.assign || function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = arguments[t];
                    for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
                }
                return e
            }).apply(this, arguments)
        }
        g.defaultProps = {}, Object.setPrototypeOf(g.defaultProps, s.a), a.d(t, "a", function() {
            return v
        });
        var y = function(e) {
            var t, a;

            function r() {
                return e.apply(this, arguments) || this
            }
            return a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, t.__proto__ = a, r.prototype.render = function() {
                var e = this.props,
                    t = e.forwardRef,
                    a = function(e, t) {
                        if (null == e) return {};
                        var a, r, n = {},
                            o = Object.keys(e);
                        for (r = 0; r < o.length; r++) a = o[r], t.indexOf(a) >= 0 || (n[a] = e[a]);
                        return n
                    }(e, ["forwardRef"]);
                return n.a.createElement(g, m({}, a, {
                    ref: t,
                    type: "range"
                }))
            }, r
        }(r.Component);
        var v = Object(o.a)(Object(i.a)(), i.b)(y)
    }]
]);
//# sourceMappingURL=2.0ab4378a.chunk.js.map